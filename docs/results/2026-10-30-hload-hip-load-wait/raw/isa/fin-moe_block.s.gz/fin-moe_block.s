_ZN12_GLOBAL__N_116moe_block_kernelILi1ELi8EEEvNS_9BlockArgsE: ; @_ZN12_GLOBAL__N_116moe_block_kernelILi1ELi8EEEvNS_9BlockArgsE
; %bb.0:
	s_clause 0x1
	s_load_b96 s[28:30], s[0:1], 0xc0
	s_load_b256 s[52:59], s[0:1], 0xa0
	s_wait_kmcnt 0x0
	s_bitcmp0_b32 s30, 21
	s_cbranch_scc1 .LBB0_3
; %bb.1:
	s_mul_hi_u32 s2, ttmp9, 0x24924925
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_sub_co_i32 s3, ttmp9, s2
	s_lshr_b32 s3, s3, 1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_add_co_i32 s3, s3, s2
	s_lshr_b32 s2, s3, 2
	s_and_b32 s3, s30, 0xffff
	s_mul_i32 s2, s2, 7
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_sub_co_i32 s2, ttmp9, s2
	s_mul_i32 s2, s3, s2
	s_delay_alu instid0(SALU_CYCLE_1)
	s_cmp_eq_u32 s2, 0
	s_cbranch_scc1 .LBB0_3
.LBB0_2:                                ; =>This Inner Loop Header: Depth=1
	s_add_co_i32 s2, s2, -1
	s_sleep 8
	s_cmp_lg_u32 s2, 0
	s_cbranch_scc1 .LBB0_2
.LBB0_3:
	s_lshl_b32 s4, s29, 4
	s_getpc_b64 s[6:7]
	s_sext_i32_i16 s7, s7
	s_add_co_u32 s6, s6, _ZN12_GLOBAL__N_116g_moe_block_syncE@rel32@lo+8
	s_add_co_ci_u32 s7, s7, _ZN12_GLOBAL__N_116g_moe_block_syncE@rel32@hi+16
	s_ashr_i32 s5, s4, 31
	v_cmp_eq_u32_e64 s2, 0, v0
	s_lshl_b64 s[4:5], s[4:5], 2
	s_delay_alu instid0(SALU_CYCLE_1)
	s_add_nc_u64 s[34:35], s[6:7], s[4:5]
	s_and_saveexec_b32 s3, s2
	s_cbranch_execz .LBB0_7
; %bb.4:
	s_mov_b32 s5, exec_lo
	s_mov_b32 s4, exec_lo
	v_mbcnt_lo_u32_b32 v1, s5, 0
                                        ; implicit-def: $vgpr2
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_eq_u32_e32 0, v1
	s_cbranch_execz .LBB0_6
; %bb.5:
	s_bcnt1_i32_b32 s5, s5
	s_wait_alu 0xfffe
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s5
	global_atomic_add_u32 v2, v2, v3, s[34:35] offset:8 th:TH_ATOMIC_RETURN scope:SCOPE_DEV
.LBB0_6:
	s_or_b32 exec_lo, exec_lo, s4
	s_wait_loadcnt 0x0
	v_readfirstlane_b32 s4, v2
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s4, v1
	ds_store_b32 v2, v1 offset:64
.LBB0_7:
	s_or_b32 exec_lo, exec_lo, s3
	s_clause 0x2
	s_load_b512 s[12:27], s[0:1], 0x0
	s_load_b512 s[36:51], s[0:1], 0x40
	s_load_b256 s[60:67], s[0:1], 0x80
	s_mov_b32 s0, exec_lo
	v_cmpx_gt_u32_e32 16, v0
	s_cbranch_execz .LBB0_9
; %bb.8:
	v_and_b32_e32 v1, 7, v0
	v_lshlrev_b32_e32 v3, 28, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v2, v1, 22, 0.5
	v_cmp_ne_u32_e32 vcc_lo, 1, v1
	v_cndmask_b32_e32 v2, 0.5, v2, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v1, 0, v2 :: v_dual_lshlrev_b32 v2, 2, v0
	v_and_or_b32 v1, 0x80000000, v3, v1
	ds_store_b32 v2, v1
.LBB0_9:
	s_or_b32 exec_lo, exec_lo, s0
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v41, 31, v0
	s_wait_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	ds_load_b32 v1, v2 offset:64
	s_add_co_i32 s31, s59, s58
	v_lshrrev_b32_e32 v14, 5, v0
	s_mov_b32 s0, -1
	s_wait_dscnt 0x0
	v_cmp_le_i32_e32 vcc_lo, s31, v1
	v_readfirstlane_b32 s29, v1
	s_cbranch_vccz .LBB0_371
; %bb.10:
	s_add_co_i32 s0, s53, 7
	s_sub_co_i32 s71, s29, s31
	s_ashr_i32 s1, s0, 31
	s_abs_i32 s4, s71
	s_lshr_b32 s1, s1, 29
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_add_co_i32 s0, s0, s1
	s_ashr_i32 s70, s0, 3
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_abs_i32 s0, s70
	s_cvt_f32_u32 s1, s0
	s_sub_co_i32 s3, 0, s0
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_iflag_f32_e32 v1, s1
	v_readfirstlane_b32 s1, v1
	s_mul_f32 s1, s1, 0x4f7ffffe
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_cvt_u32_f32 s1, s1
	s_wait_alu 0xfffe
	s_mul_i32 s3, s3, s1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_mul_hi_u32 s3, s1, s3
	s_add_co_i32 s1, s1, s3
	s_xor_b32 s3, s71, s70
	s_wait_alu 0xfffe
	s_mul_hi_u32 s1, s4, s1
	s_ashr_i32 s3, s3, 31
	s_wait_alu 0xfffe
	s_mul_i32 s5, s1, s0
	s_wait_alu 0xfffe
	s_sub_co_i32 s4, s4, s5
	s_add_co_i32 s5, s1, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s6, s4, s0
	s_cmp_ge_u32 s4, s0
	s_cselect_b32 s1, s5, s1
	s_cselect_b32 s4, s6, s4
	s_wait_alu 0xfffe
	s_add_co_i32 s5, s1, 1
	s_cmp_ge_u32 s4, s0
	s_wait_alu 0xfffe
	s_cselect_b32 s0, s5, s1
	s_ashr_i32 s1, s52, 31
	s_wait_alu 0xfffe
	s_xor_b32 s0, s0, s3
	s_wait_alu 0xfffe
	s_sub_co_i32 s68, s0, s3
	s_mov_b32 s0, s52
	s_ashr_i32 s69, s68, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[4:5], s[68:69], s[0:1]
	v_cmp_gt_i32_e64 s0, s52, v41
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_kmcnt 0x0
	s_wait_alu 0xfffe
	s_add_nc_u64 s[10:11], s[14:15], s[4:5]
	s_and_saveexec_b32 s3, s0
	s_cbranch_execz .LBB0_12
; %bb.11:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11]
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	v_and_b32_e32 v2, 0xffff, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v3, v2
	v_or_b32_e32 v4, 0x8000, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo
	v_and_b32_e32 v5, 0x7f80, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v1, 16, v1
	v_and_b32_e32 v2, 0x7f, v2
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s1, 0, v2
	s_or_b32 vcc_lo, vcc_lo, s1
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	v_or_b32_e32 v1, v41, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v2, 0xffff, v1
.LBB0_12:
	s_or_b32 exec_lo, exec_lo, s3
	v_or_b32_e32 v99, 32, v41
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e64 s1, s52, v99
	s_and_saveexec_b32 s4, s1
	s_cbranch_execz .LBB0_14
; %bb.13:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11] offset:64
	s_wait_loadcnt 0x0
	v_and_b32_e32 v4, 0xffff, v1
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_not_b32_e32 v5, v4
	v_or_b32_e32 v6, 0x8000, v4
	v_and_b32_e32 v7, 0x7f80, v4
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v1, v6, v5 :: v_dual_and_b32 v4, 0x7f, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v7
	v_cmp_eq_u32_e64 s3, 0, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v1, 16, v1
	s_or_b32 vcc_lo, vcc_lo, s3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_or_b32_e32 v1, v41, v1
	v_xor_b32_e32 v4, 0xffdf, v1
.LBB0_14:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v1, 64, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e64 s3, s52, v1
	s_and_saveexec_b32 s5, s3
	s_cbranch_execz .LBB0_16
; %bb.15:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11] offset:128
	s_wait_loadcnt 0x0
	v_and_b32_e32 v3, 0xffff, v1
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_not_b32_e32 v5, v3
	v_or_b32_e32 v6, 0x8000, v3
	v_and_b32_e32 v7, 0x7f80, v3
	v_and_b32_e32 v3, 0x7f, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v6, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v7
	v_cmp_eq_u32_e64 s4, 0, v3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v1, 16, v1
	s_or_b32 vcc_lo, vcc_lo, s4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_or_b32_e32 v1, v41, v1
	v_xor_b32_e32 v3, 0xffbf, v1
.LBB0_16:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	v_or_b32_e32 v1, 0x60, v41
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e64 s4, s52, v1
	s_and_saveexec_b32 s6, s4
	s_cbranch_execz .LBB0_18
; %bb.17:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11] offset:192
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	v_and_b32_e32 v6, 0xffff, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v7, v6
	v_or_b32_e32 v8, 0x8000, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v8, v7, vcc_lo
	v_and_b32_e32 v9, 0x7f80, v6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v1, 16, v1
	v_and_b32_e32 v6, 0x7f, v6
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s5, 0, v6
	s_or_b32 vcc_lo, vcc_lo, s5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	v_or_b32_e32 v1, v41, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v6, 0xff9f, v1
.LBB0_18:
	s_or_b32 exec_lo, exec_lo, s6
	v_or_b32_e32 v1, 0x80, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e64 s5, s52, v1
	s_and_saveexec_b32 s7, s5
	s_cbranch_execz .LBB0_20
; %bb.19:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11] offset:256
	s_wait_loadcnt 0x0
	v_and_b32_e32 v5, 0xffff, v1
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_not_b32_e32 v7, v5
	v_or_b32_e32 v8, 0x8000, v5
	v_and_b32_e32 v9, 0x7f80, v5
	v_and_b32_e32 v5, 0x7f, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v8, v7, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v9
	v_cmp_eq_u32_e64 s6, 0, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v1, 16, v1
	s_or_b32 vcc_lo, vcc_lo, s6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_or_b32_e32 v1, v41, v1
	v_xor_b32_e32 v5, 0xff7f, v1
.LBB0_20:
	s_or_b32 exec_lo, exec_lo, s7
	v_or_b32_e32 v1, 0xa0, v41
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e64 s6, s52, v1
	s_and_saveexec_b32 s8, s6
	s_cbranch_execz .LBB0_22
; %bb.21:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11] offset:320
	s_wait_loadcnt 0x0
	v_and_b32_e32 v8, 0xffff, v1
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_not_b32_e32 v9, v8
	v_or_b32_e32 v10, 0x8000, v8
	v_and_b32_e32 v11, 0x7f80, v8
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v1, v10, v9 :: v_dual_and_b32 v8, 0x7f, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v11
	v_cmp_eq_u32_e64 s7, 0, v8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v1, 16, v1
	s_or_b32 vcc_lo, vcc_lo, s7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_or_b32_e32 v1, v41, v1
	v_xor_b32_e32 v8, 0xff5f, v1
.LBB0_22:
	s_or_b32 exec_lo, exec_lo, s8
	v_or_b32_e32 v1, 0xc0, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e64 s7, s52, v1
	s_and_saveexec_b32 s9, s7
	s_cbranch_execz .LBB0_24
; %bb.23:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11] offset:384
	s_wait_loadcnt 0x0
	v_and_b32_e32 v7, 0xffff, v1
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_not_b32_e32 v9, v7
	v_or_b32_e32 v10, 0x8000, v7
	v_and_b32_e32 v11, 0x7f80, v7
	v_and_b32_e32 v7, 0x7f, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v10, v9, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v11
	v_cmp_eq_u32_e64 s8, 0, v7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v1, 16, v1
	s_or_b32 vcc_lo, vcc_lo, s8
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_or_b32_e32 v1, v41, v1
	v_xor_b32_e32 v7, 0xff3f, v1
.LBB0_24:
	s_or_b32 exec_lo, exec_lo, s9
	v_or_b32_e32 v9, 0xe0, v41
	v_mov_b32_e32 v1, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e64 s8, s52, v9
	v_mov_b32_e32 v9, 0
	s_and_saveexec_b32 s33, s8
	s_cbranch_execz .LBB0_26
; %bb.25:
	v_lshlrev_b32_e32 v9, 1, v41
	global_load_u16 v9, v9, s[10:11] offset:448
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v9
	v_and_b32_e32 v10, 0xffff, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v11, v10
	v_or_b32_e32 v12, 0x8000, v10
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, v12, v11, vcc_lo
	v_and_b32_e32 v13, 0x7f80, v10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v9, 16, v9
	v_and_b32_e32 v10, 0x7f, v10
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s9, 0, v10
	s_or_b32 vcc_lo, vcc_lo, s9
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
	v_or_b32_e32 v9, v41, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v9, 0xff1f, v9
.LBB0_26:
	s_or_b32 exec_lo, exec_lo, s33
	s_cmp_gt_i32 s56, 0
	s_cselect_b32 s33, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_38
; %bb.27:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	v_max_u32_e32 v1, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_max3_u32 v1, v1, v3, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v1, v1, v5, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_max3_u32 v1, v1, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v1
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v11
	ds_bpermute_b32 v11, v12, v1
	v_xor_b32_e32 v12, 4, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v11
	ds_bpermute_b32 v11, v12, v1
	v_xor_b32_e32 v12, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v11
	ds_bpermute_b32 v11, v12, v1
	v_xor_b32_e32 v12, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v12, vcc_lo
	v_lshlrev_b32_e32 v10, 2, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v11
	ds_bpermute_b32 v10, v10, v1
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)
	v_readfirstlane_b32 s59, v1
	s_and_not1_b32 s9, 31, s59
	v_cmp_eq_u32_e32 vcc_lo, s9, v41
	s_and_not1_b32 s9, 0xffff, s59
	s_and_saveexec_b32 s72, vcc_lo
	s_cbranch_execz .LBB0_29
; %bb.28:
	s_wait_alu 0xfffe
	s_lshr_b32 s73, s9, 5
	s_cmp_gt_u32 s9, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 1
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_29:
	s_or_b32 exec_lo, exec_lo, s72
	s_and_b32 s72, s59, 0xffff0000
	s_brev_b32 s73, 1
	s_cmp_gt_i32 s59, -1
	s_cselect_b32 s59, 0xffff0000, s73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_xor_b32 s81, s59, s72
	s_sub_f32 s59, s81, s81
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)
	s_mul_f32 s72, s59, 0x3fb8aa3b
	s_xor_b32 s73, s72, 0x80000000
	s_rndne_f32 s74, s72
	s_fmamk_f32 s73, s59, 0x3fb8aa3b, s73
	s_cmp_nlt_f32 s59, 0xc2ce8ed0
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_sub_f32 s72, s72, s74
	s_fmamk_f32 s73, s59, 0x32a5705f, s73
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s59, 0x42b17218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_add_f32 s72, s72, s73
	s_cvt_i32_f32 s73, s74
	v_s_exp_f32 s72, s72
	s_wait_alu 0xf1ff
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_1)
	v_ldexp_f32 v1, s72, s73
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0x7f800000, v1, vcc_lo
	s_cmp_gt_i32 s56, 1
	s_cselect_b32 s76, -1, 0
	s_cmp_lt_i32 s56, 2
	s_cbranch_scc1 .LBB0_39
.LBB0_30:
	v_mbcnt_lo_u32_b32 v11, -1, 0
	v_max_u32_e32 v10, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v12, 16, v11
	v_xor_b32_e32 v13, 8, v11
	v_max3_u32 v10, v10, v3, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	v_max3_u32 v10, v10, v5, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v11, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_max3_u32 v10, v10, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	ds_bpermute_b32 v12, v12, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 4, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 2, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 1, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s59, v10
	s_and_not1_b32 s72, 31, s59
	s_and_not1_b32 s79, 0xffff, s59
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s72, v41
	s_and_saveexec_b32 s72, vcc_lo
	s_cbranch_execz .LBB0_32
; %bb.31:
	s_lshr_b32 s73, s79, 5
	s_cmp_gt_u32 s79, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s73, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s73, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_32:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s72
	s_and_b32 s72, s59, 0xffff0000
	s_brev_b32 s73, 1
	s_cmp_gt_i32 s59, -1
	s_wait_alu 0xfffe
	s_cselect_b32 s59, 0xffff0000, s73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_xor_b32 s59, s59, s72
	s_sub_f32 s72, s59, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s73, s72, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s74, s73, 0x80000000
	s_rndne_f32 s75, s73
	s_fmamk_f32 s74, s72, 0x3fb8aa3b, s74
	s_cmp_nlt_f32 s72, 0xc2ce8ed0
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_sub_f32 s73, s73, s75
	s_fmamk_f32 s74, s72, 0x32a5705f, s74
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s72, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s73, s73, s74
	s_cvt_i32_f32 s74, s75
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s73, s73
	s_wait_alu 0xf1ff
	v_ldexp_f32 v10, s73, s74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v1, v1, v10
	s_cmp_gt_i32 s56, 2
	s_cselect_b32 s77, -1, 0
	s_cmp_lt_i32 s56, 3
	s_cbranch_scc0 .LBB0_40
.LBB0_33:
	s_mov_b32 s80, -1
	s_mov_b32 s84, 0
	s_cmp_gt_i32 s56, 3
	s_cselect_b32 s78, -1, 0
	s_cmp_lt_i32 s56, 4
	s_cbranch_scc0 .LBB0_43
.LBB0_34:
	s_mov_b32 s82, -1
	s_mov_b32 s85, 0
	s_cmp_gt_i32 s56, 4
	s_cselect_b32 s75, -1, 0
	s_cmp_lt_i32 s56, 5
	s_cbranch_scc0 .LBB0_46
.LBB0_35:
	s_mov_b32 s83, -1
	s_mov_b32 s93, 0
	s_cmp_gt_i32 s56, 5
	s_cselect_b32 s74, -1, 0
	s_cmp_lt_i32 s56, 6
	s_cbranch_scc0 .LBB0_49
.LBB0_36:
	s_mov_b32 s90, -1
	s_mov_b32 s94, 0
	s_cmp_gt_i32 s56, 6
	s_cselect_b32 s73, -1, 0
	s_cmp_lt_i32 s56, 7
	s_cbranch_scc0 .LBB0_52
.LBB0_37:
	s_mov_b32 s91, -1
	s_mov_b32 s95, 0
	s_branch .LBB0_55
.LBB0_38:
	s_mov_b32 s9, -1
	s_mov_b32 s81, 0
	s_cmp_gt_i32 s56, 1
	s_cselect_b32 s76, -1, 0
	s_cmp_lt_i32 s56, 2
	s_cbranch_scc0 .LBB0_30
.LBB0_39:
	s_mov_b32 s59, 0
	s_mov_b32 s79, -1
	s_cmp_gt_i32 s56, 2
	s_cselect_b32 s77, -1, 0
	s_cmp_lt_i32 s56, 3
	s_cbranch_scc1 .LBB0_33
.LBB0_40:
	v_mbcnt_lo_u32_b32 v11, -1, 0
	v_max_u32_e32 v10, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v12, 16, v11
	v_xor_b32_e32 v13, 8, v11
	v_max3_u32 v10, v10, v3, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	v_max3_u32 v10, v10, v5, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v11, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_max3_u32 v10, v10, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	ds_bpermute_b32 v12, v12, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 4, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 2, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 1, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s72, v10
	s_and_not1_b32 s73, 31, s72
	s_and_not1_b32 s80, 0xffff, s72
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s73, v41
	s_and_saveexec_b32 s73, vcc_lo
	s_cbranch_execz .LBB0_42
; %bb.41:
	s_lshr_b32 s74, s80, 5
	s_cmp_gt_u32 s80, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s74, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_42:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s73
	s_and_b32 s73, s72, 0xffff0000
	s_brev_b32 s74, 1
	s_cmp_gt_i32 s72, -1
	s_wait_alu 0xfffe
	s_cselect_b32 s72, 0xffff0000, s74
	s_wait_alu 0xfffe
	s_xor_b32 s84, s72, s73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_sub_f32 s72, s84, s81
	s_wait_alu 0xfffe
	s_mul_f32 s73, s72, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2)
	s_xor_b32 s74, s73, 0x80000000
	s_rndne_f32 s75, s73
	s_wait_alu 0xfffe
	s_fmamk_f32 s74, s72, 0x3fb8aa3b, s74
	s_cmp_nlt_f32 s72, 0xc2ce8ed0
	s_sub_f32 s73, s73, s75
	s_wait_alu 0xfffe
	s_fmamk_f32 s74, s72, 0x32a5705f, s74
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s72, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s73, s73, s74
	s_cvt_i32_f32 s74, s75
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s73, s73
	s_wait_alu 0xf1ff
	v_ldexp_f32 v10, s73, s74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v1, v1, v10
	s_cmp_gt_i32 s56, 3
	s_cselect_b32 s78, -1, 0
	s_cmp_lt_i32 s56, 4
	s_cbranch_scc1 .LBB0_34
.LBB0_43:
	v_mbcnt_lo_u32_b32 v11, -1, 0
	v_max_u32_e32 v10, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v12, 16, v11
	v_xor_b32_e32 v13, 8, v11
	v_max3_u32 v10, v10, v3, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	v_max3_u32 v10, v10, v5, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v11, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_max3_u32 v10, v10, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	ds_bpermute_b32 v12, v12, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 4, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 2, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 1, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s72, v10
	s_and_not1_b32 s73, 31, s72
	s_and_not1_b32 s82, 0xffff, s72
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s73, v41
	s_and_saveexec_b32 s73, vcc_lo
	s_cbranch_execz .LBB0_45
; %bb.44:
	s_lshr_b32 s74, s82, 5
	s_cmp_gt_u32 s82, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s74, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_45:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s73
	s_and_b32 s73, s72, 0xffff0000
	s_brev_b32 s74, 1
	s_cmp_gt_i32 s72, -1
	s_wait_alu 0xfffe
	s_cselect_b32 s72, 0xffff0000, s74
	s_wait_alu 0xfffe
	s_xor_b32 s85, s72, s73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_sub_f32 s72, s85, s81
	s_wait_alu 0xfffe
	s_mul_f32 s73, s72, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2)
	s_xor_b32 s74, s73, 0x80000000
	s_rndne_f32 s75, s73
	s_wait_alu 0xfffe
	s_fmamk_f32 s74, s72, 0x3fb8aa3b, s74
	s_cmp_nlt_f32 s72, 0xc2ce8ed0
	s_sub_f32 s73, s73, s75
	s_wait_alu 0xfffe
	s_fmamk_f32 s74, s72, 0x32a5705f, s74
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s72, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s73, s73, s74
	s_cvt_i32_f32 s74, s75
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s73, s73
	s_wait_alu 0xf1ff
	v_ldexp_f32 v10, s73, s74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v1, v1, v10
	s_cmp_gt_i32 s56, 4
	s_cselect_b32 s75, -1, 0
	s_cmp_lt_i32 s56, 5
	s_cbranch_scc1 .LBB0_35
.LBB0_46:
	v_mbcnt_lo_u32_b32 v11, -1, 0
	v_max_u32_e32 v10, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v12, 16, v11
	v_xor_b32_e32 v13, 8, v11
	v_max3_u32 v10, v10, v3, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	v_max3_u32 v10, v10, v5, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v11, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_max3_u32 v10, v10, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	ds_bpermute_b32 v12, v12, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 4, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 2, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 1, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s72, v10
	s_and_not1_b32 s73, 31, s72
	s_and_not1_b32 s83, 0xffff, s72
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s73, v41
	s_and_saveexec_b32 s73, vcc_lo
	s_cbranch_execz .LBB0_48
; %bb.47:
	s_lshr_b32 s74, s83, 5
	s_cmp_gt_u32 s83, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s74, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s74, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_48:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s73
	s_and_b32 s73, s72, 0xffff0000
	s_brev_b32 s74, 1
	s_cmp_gt_i32 s72, -1
	s_wait_alu 0xfffe
	s_cselect_b32 s72, 0xffff0000, s74
	s_wait_alu 0xfffe
	s_xor_b32 s93, s72, s73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_sub_f32 s72, s93, s81
	s_wait_alu 0xfffe
	s_mul_f32 s73, s72, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2)
	s_xor_b32 s74, s73, 0x80000000
	s_rndne_f32 s86, s73
	s_wait_alu 0xfffe
	s_fmamk_f32 s74, s72, 0x3fb8aa3b, s74
	s_cmp_nlt_f32 s72, 0xc2ce8ed0
	s_sub_f32 s73, s73, s86
	s_wait_alu 0xfffe
	s_fmamk_f32 s74, s72, 0x32a5705f, s74
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s72, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s73, s73, s74
	s_cvt_i32_f32 s74, s86
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s73, s73
	s_wait_alu 0xf1ff
	v_ldexp_f32 v10, s73, s74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v1, v1, v10
	s_cmp_gt_i32 s56, 5
	s_cselect_b32 s74, -1, 0
	s_cmp_lt_i32 s56, 6
	s_cbranch_scc1 .LBB0_36
.LBB0_49:
	v_mbcnt_lo_u32_b32 v11, -1, 0
	v_max_u32_e32 v10, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v12, 16, v11
	v_xor_b32_e32 v13, 8, v11
	v_max3_u32 v10, v10, v3, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	v_max3_u32 v10, v10, v5, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v11, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_max3_u32 v10, v10, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	ds_bpermute_b32 v12, v12, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 4, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 2, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 1, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s72, v10
	s_and_not1_b32 s73, 31, s72
	s_and_not1_b32 s90, 0xffff, s72
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s73, v41
	s_and_saveexec_b32 s73, vcc_lo
	s_cbranch_execz .LBB0_51
; %bb.50:
	s_lshr_b32 s86, s90, 5
	s_cmp_gt_u32 s90, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s86, 1
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s86, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s86, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s86, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s86, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s86, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s86, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_51:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s73
	s_and_b32 s73, s72, 0xffff0000
	s_brev_b32 s86, 1
	s_cmp_gt_i32 s72, -1
	s_cselect_b32 s72, 0xffff0000, s86
	s_wait_alu 0xfffe
	s_xor_b32 s94, s72, s73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_sub_f32 s72, s94, s81
	s_wait_alu 0xfffe
	s_mul_f32 s73, s72, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)
	s_xor_b32 s86, s73, 0x80000000
	s_rndne_f32 s87, s73
	s_fmamk_f32 s86, s72, 0x3fb8aa3b, s86
	s_cmp_nlt_f32 s72, 0xc2ce8ed0
	s_sub_f32 s73, s73, s87
	s_delay_alu instid0(SALU_CYCLE_1)
	s_fmamk_f32 s86, s72, 0x32a5705f, s86
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s72, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s73, s73, s86
	s_cvt_i32_f32 s86, s87
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s73, s73
	s_wait_alu 0xf1ff
	v_ldexp_f32 v10, s73, s86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v1, v1, v10
	s_cmp_gt_i32 s56, 6
	s_cselect_b32 s73, -1, 0
	s_cmp_lt_i32 s56, 7
	s_cbranch_scc1 .LBB0_37
.LBB0_52:
	v_mbcnt_lo_u32_b32 v11, -1, 0
	v_max_u32_e32 v10, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v12, 16, v11
	v_xor_b32_e32 v13, 8, v11
	v_max3_u32 v10, v10, v3, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	v_max3_u32 v10, v10, v5, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v11, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_max3_u32 v10, v10, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	ds_bpermute_b32 v12, v12, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 4, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 2, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v12, v13, v10
	v_xor_b32_e32 v13, 1, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v11, v13, vcc_lo
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s72, v10
	s_and_not1_b32 s86, 31, s72
	s_and_not1_b32 s91, 0xffff, s72
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s86, v41
	s_and_saveexec_b32 s86, vcc_lo
	s_cbranch_execz .LBB0_54
; %bb.53:
	s_lshr_b32 s87, s91, 5
	s_cmp_gt_u32 s91, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s87, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s87, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s87, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s87, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s87, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s87, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s87, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_54:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s86
	s_and_b32 s86, s72, 0xffff0000
	s_brev_b32 s87, 1
	s_cmp_gt_i32 s72, -1
	s_wait_alu 0xfffe
	s_cselect_b32 s72, 0xffff0000, s87
	s_wait_alu 0xfffe
	s_xor_b32 s95, s72, s86
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_sub_f32 s72, s95, s81
	s_wait_alu 0xfffe
	s_mul_f32 s86, s72, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2)
	s_xor_b32 s87, s86, 0x80000000
	s_rndne_f32 s88, s86
	s_wait_alu 0xfffe
	s_fmamk_f32 s87, s72, 0x3fb8aa3b, s87
	s_cmp_nlt_f32 s72, 0xc2ce8ed0
	s_sub_f32 s86, s86, s88
	s_wait_alu 0xfffe
	s_fmamk_f32 s87, s72, 0x32a5705f, s87
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s72, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s86, s86, s87
	s_cvt_i32_f32 s87, s88
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s86, s86
	s_wait_alu 0xf1ff
	v_ldexp_f32 v10, s86, s87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v1, v1, v10
.LBB0_55:
	s_cmp_gt_i32 s56, 7
	s_mov_b32 s96, 0
	s_cselect_b32 s72, -1, 0
	s_cmp_lt_i32 s56, 8
	s_mov_b32 s92, -1
	s_cbranch_scc1 .LBB0_65
; %bb.56:
	v_max_u32_e32 v2, v2, v4
	v_mbcnt_lo_u32_b32 v4, -1, 0
	s_brev_b32 s87, 1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_max3_u32 v2, v2, v3, v6
	v_xor_b32_e32 v3, 16, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_max3_u32 v2, v2, v5, v8
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	v_xor_b32_e32 v5, 8, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_max3_u32 v2, v2, v7, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v4, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v4, v5, vcc_lo
	ds_bpermute_b32 v3, v3, v2
	v_lshlrev_b32_e32 v5, 2, v5
	s_wait_dscnt 0x0
	v_max_u32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	v_xor_b32_e32 v5, 4, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v4, v5, vcc_lo
	v_lshlrev_b32_e32 v5, 2, v5
	s_wait_dscnt 0x0
	v_max_u32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	v_xor_b32_e32 v5, 2, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v4, v5, vcc_lo
	v_lshlrev_b32_e32 v5, 2, v5
	s_wait_dscnt 0x0
	v_max_u32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	v_xor_b32_e32 v5, 1, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v4, v5, vcc_lo
	v_lshlrev_b32_e32 v4, 2, v4
	s_wait_dscnt 0x0
	v_max_u32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	s_wait_dscnt 0x0
	v_max_u32_e32 v2, v2, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s86, v2
	s_and_not1_b32 s92, 0xffff, s86
	s_and_b32 s88, s86, 0xffff0000
	s_cmp_gt_i32 s86, -1
	s_wait_alu 0xfffe
	s_cselect_b32 s86, 0xffff0000, s87
	s_wait_alu 0xfffe
	s_xor_b32 s96, s86, s88
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_sub_f32 s86, s96, s81
	s_wait_alu 0xfffe
	s_mul_f32 s87, s86, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)
	s_xor_b32 s88, s87, 0x80000000
	s_rndne_f32 s89, s87
	s_fmamk_f32 s88, s86, 0x3fb8aa3b, s88
	s_cmp_nlt_f32 s86, 0xc2ce8ed0
	s_sub_f32 s87, s87, s89
	s_delay_alu instid0(SALU_CYCLE_1)
	s_fmamk_f32 s88, s86, 0x32a5705f, s88
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s86, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s87, s87, s88
	s_cvt_i32_f32 s88, s89
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s87, s87
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s87, s88
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v1, v1, v2
	s_cmp_eq_u32 s57, 0
	s_cbranch_scc0 .LBB0_66
.LBB0_57:
	v_mov_b32_e32 v1, 0
	s_and_saveexec_b32 s57, s0
	s_cbranch_execz .LBB0_90
; %bb.58:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[10:11]
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v1, 16, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v1, s81, v1
	v_mul_f32_e32 v2, 0x3fb8aa3b, v1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v3, 0x3fb8aa3b, v1, -v2
	v_rndne_f32_e32 v4, v2
	v_dual_fmamk_f32 v3, v1, 0x32a5705f, v3 :: v_dual_sub_f32 v2, v2, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v2, v2, v3
	v_cvt_i32_f32_e32 v3, v4
	v_exp_f32_e32 v2, v2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v2, v2, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v1, 0x7f800000, v2, vcc_lo
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s0, s1
	s_cbranch_execnz .LBB0_91
.LBB0_59:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s3
	s_cbranch_execz .LBB0_92
.LBB0_60:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[10:11] offset:128
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v2, s81, v2
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3
	v_rndne_f32_e32 v5, v3
	v_dual_fmamk_f32 v4, v2, 0x32a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	v_exp_f32_e32 v3, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo
	v_add_f32_e32 v1, v1, v2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s4
	s_cbranch_execnz .LBB0_93
.LBB0_61:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s5
	s_cbranch_execz .LBB0_94
.LBB0_62:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[10:11] offset:256
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v2, s81, v2
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3
	v_rndne_f32_e32 v5, v3
	v_dual_fmamk_f32 v4, v2, 0x32a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	v_exp_f32_e32 v3, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo
	v_add_f32_e32 v1, v1, v2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s6
	s_cbranch_execnz .LBB0_95
.LBB0_63:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s7
	s_cbranch_execz .LBB0_96
.LBB0_64:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[10:11] offset:384
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v2, s81, v2
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3
	v_rndne_f32_e32 v5, v3
	v_dual_fmamk_f32 v4, v2, 0x32a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	v_exp_f32_e32 v3, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo
	v_add_f32_e32 v1, v1, v2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s8
	s_cbranch_execnz .LBB0_97
	s_branch .LBB0_98
.LBB0_65:
	s_cmp_eq_u32 s57, 0
	s_cbranch_scc1 .LBB0_57
.LBB0_66:
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_99
.LBB0_67:
	s_sub_f32 s0, s81, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_wait_alu 0xfffe
	s_sub_f32 s1, s1, s4
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v3, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.68:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.69:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.70:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.71:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v2
	s_lshl_b32 s89, s0, 16
	s_and_not1_b32 vcc_lo, exec_lo, s76
	s_mov_b32 s88, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_100
.LBB0_72:
	s_sub_f32 s0, s59, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v3, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.73:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.74:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.75:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.76:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v2
	s_lshl_b32 s88, s0, 16
	s_and_not1_b32 vcc_lo, exec_lo, s77
	s_mov_b32 s87, 0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_101
.LBB0_77:
	s_and_not1_b32 vcc_lo, exec_lo, s78
	s_mov_b32 s86, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_106
.LBB0_78:
	s_sub_f32 s0, s85, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v3, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.79:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.80:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.81:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.82:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v2
	s_lshl_b32 s86, s0, 16
	s_and_not1_b32 vcc_lo, exec_lo, s75
	s_mov_b32 s85, 0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_107
.LBB0_83:
	s_and_not1_b32 vcc_lo, exec_lo, s74
	s_mov_b32 s84, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_112
.LBB0_84:
	s_sub_f32 s0, s94, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v3, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.85:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.86:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.87:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.88:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v2
	s_lshl_b32 s84, s0, 16
	s_and_not1_b32 vcc_lo, exec_lo, s73
	s_mov_b32 s59, 0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_113
.LBB0_89:
	s_and_not1_b32 vcc_lo, exec_lo, s72
	s_mov_b32 s33, 0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_118
	s_branch .LBB0_123
.LBB0_90:
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s0, s1
	s_cbranch_execz .LBB0_59
.LBB0_91:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[10:11] offset:64
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v2, s81, v2
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3
	v_rndne_f32_e32 v5, v3
	v_dual_fmamk_f32 v4, v2, 0x32a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	v_exp_f32_e32 v3, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo
	v_add_f32_e32 v1, v1, v2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s3
	s_cbranch_execnz .LBB0_60
.LBB0_92:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_61
.LBB0_93:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[10:11] offset:192
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v2, s81, v2
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3
	v_rndne_f32_e32 v5, v3
	v_dual_fmamk_f32 v4, v2, 0x32a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	v_exp_f32_e32 v3, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo
	v_add_f32_e32 v1, v1, v2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s5
	s_cbranch_execnz .LBB0_62
.LBB0_94:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s6
	s_cbranch_execz .LBB0_63
.LBB0_95:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[10:11] offset:320
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v2, s81, v2
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3
	v_rndne_f32_e32 v5, v3
	v_dual_fmamk_f32 v4, v2, 0x32a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	v_exp_f32_e32 v3, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo
	v_add_f32_e32 v1, v1, v2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s7
	s_cbranch_execnz .LBB0_64
.LBB0_96:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_and_saveexec_b32 s0, s8
	s_cbranch_execz .LBB0_98
.LBB0_97:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[10:11] offset:448
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_subrev_f32_e32 v2, s81, v2
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3
	v_rndne_f32_e32 v5, v3
	v_dual_fmamk_f32 v4, v2, 0x32a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	v_exp_f32_e32 v3, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo
	v_add_f32_e32 v1, v1, v2
.LBB0_98:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_mbcnt_lo_u32_b32 v2, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_xor_b32_e32 v3, 16, v2
	v_xor_b32_e32 v4, 8, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v2, v3, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v2, v4, vcc_lo
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v3, 2, v3
	ds_bpermute_b32 v3, v3, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v3
	ds_bpermute_b32 v3, v4, v1
	v_xor_b32_e32 v4, 4, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v2, v4, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v1, v1, v3 :: v_dual_lshlrev_b32 v4, 2, v4
	ds_bpermute_b32 v3, v4, v1
	v_xor_b32_e32 v4, 2, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v4, v2, v4 :: v_dual_add_f32 v1, v1, v3
	v_lshlrev_b32_e32 v4, 2, v4
	ds_bpermute_b32 v3, v4, v1
	v_xor_b32_e32 v4, 1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v1, v1, v3 :: v_dual_lshlrev_b32 v2, 2, v2
	ds_bpermute_b32 v2, v2, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_67
.LBB0_99:
	s_mov_b32 s89, 0
	s_and_not1_b32 vcc_lo, exec_lo, s76
	s_mov_b32 s88, 0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_72
.LBB0_100:
	s_and_not1_b32 vcc_lo, exec_lo, s77
	s_mov_b32 s87, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_77
.LBB0_101:
	s_sub_f32 s0, s84, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v3, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.102:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.103:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.104:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.105:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v2
	s_lshl_b32 s87, s0, 16
	s_and_not1_b32 vcc_lo, exec_lo, s78
	s_mov_b32 s86, 0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_78
.LBB0_106:
	s_and_not1_b32 vcc_lo, exec_lo, s75
	s_mov_b32 s85, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_83
.LBB0_107:
	s_sub_f32 s0, s93, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v3, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.108:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.109:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.110:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.111:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v2
	s_lshl_b32 s85, s0, 16
	s_and_not1_b32 vcc_lo, exec_lo, s74
	s_mov_b32 s84, 0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_84
.LBB0_112:
	s_and_not1_b32 vcc_lo, exec_lo, s73
	s_mov_b32 s59, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_89
.LBB0_113:
	s_sub_f32 s0, s95, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v3, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.114:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.115:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.116:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.117:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v2
	s_lshl_b32 s59, s0, 16
	s_and_not1_b32 vcc_lo, exec_lo, s72
	s_mov_b32 s33, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_123
.LBB0_118:
	s_sub_f32 s0, s96, s81
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_mul_f32 s1, s0, 0x3fb8aa3b
	s_wait_alu 0xfffe
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x3fb8aa3b, s3
	s_cmp_nlt_f32 s0, 0xc2ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0x32a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_ngt_f32 s0, 0x42b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v1, v1, v2
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v2, v3, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.119:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.120:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.121:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.122:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s0, v1
	s_lshl_b32 s33, s0, 16
.LBB0_123:
	s_mul_i32 s0, s68, s70
	s_ashr_i32 s11, s54, 31
	s_wait_alu 0xfffe
	s_sub_co_i32 s1, s71, s0
	s_lshr_b32 s0, s11, 28
	s_wait_alu 0xfffe
	v_lshl_or_b32 v43, s1, 3, v14
	s_lshr_b32 s3, s54, 31
	s_add_co_i32 s0, s54, s0
	s_wait_alu 0xfffe
	s_add_co_i32 s3, s54, s3
	s_ashr_i32 s93, s0, 4
	v_cmp_gt_i32_e64 s1, s53, v43
	s_wait_alu 0xfffe
	s_ashr_i32 s0, s3, 1
	s_ashr_i32 s71, s53, 31
	s_wait_alu 0xfffe
	s_ashr_i32 s6, s0, 31
	s_ashr_i32 s3, s93, 31
	s_cmp_gt_i32 s9, -1
	v_cndmask_b32_e64 v1, 0, v43, s1
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s9, s52
	v_mov_b32_e32 v66, 0
	s_cselect_b32 s5, -1, 0
	v_mov_b32_e32 v68, 0
	v_mov_b32_e32 v64, 0
	v_ashrrev_i32_e32 v2, 31, v1
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v106, 0
	v_mov_b32_e32 v69, 0
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v108, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_mov_b32 s5, 0
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_mov_b32 s70, s53
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_125
; %bb.124:
	s_mul_i32 s4, s9, 3
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v108, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[3:4], null, s9, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[4:5], null, s9, s71, v[4:5]
	v_mul_lo_u32 v5, v3, s6
	v_mad_co_u64_u32 v[64:65], null, v3, s0, s[22:23]
	v_mul_lo_u32 v7, v3, s3
	v_mad_co_u64_u32 v[68:69], null, v3, s93, s[24:25]
	v_mul_lo_u32 v6, v4, s0
	v_mul_lo_u32 v4, v4, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v65, v6, v65, v5
	v_add3_u32 v69, v4, v69, v7
.LBB0_125:
	s_cmp_gt_i32 s79, -1
	v_mov_b32_e32 v62, 0
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s79, s52
	v_mov_b32_e32 v63, 0
	s_cselect_b32 s5, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_127
; %bb.126:
	s_mul_i32 s4, s79, 3
	s_mov_b32 s5, 0
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v106, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[3:4], null, s79, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[4:5], null, s79, s71, v[4:5]
	v_mul_lo_u32 v5, v3, s6
	v_mad_co_u64_u32 v[62:63], null, v3, s0, s[22:23]
	v_mul_lo_u32 v7, v3, s3
	v_mad_co_u64_u32 v[66:67], null, v3, s93, s[24:25]
	v_mul_lo_u32 v6, v4, s0
	v_mul_lo_u32 v4, v4, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v63, v6, v63, v5
	v_add3_u32 v67, v4, v67, v7
.LBB0_127:
	s_cmp_gt_i32 s80, -1
	v_mov_b32_e32 v70, 0
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s80, s52
	v_mov_b32_e32 v72, 0
	s_cselect_b32 s5, -1, 0
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v107, 0
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v8, 0
	v_mov_b32_e32 v73, 0
	v_mov_b32_e32 v61, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_129
; %bb.128:
	s_mul_i32 s4, s80, 3
	s_mov_b32 s5, 0
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v107, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[3:4], null, s80, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[4:5], null, s80, s71, v[4:5]
	v_mul_lo_u32 v5, v3, s6
	v_mad_co_u64_u32 v[60:61], null, v3, s0, s[22:23]
	v_mul_lo_u32 v7, v3, s3
	v_mad_co_u64_u32 v[72:73], null, v3, s93, s[24:25]
	v_mul_lo_u32 v6, v4, s0
	v_mul_lo_u32 v4, v4, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v61, v6, v61, v5
	v_add3_u32 v73, v4, v73, v7
.LBB0_129:
	s_cmp_gt_i32 s82, -1
	v_mov_b32_e32 v58, 0
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s82, s52
	v_mov_b32_e32 v59, 0
	s_cselect_b32 s5, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_131
; %bb.130:
	s_mul_i32 s4, s82, 3
	s_mov_b32 s5, 0
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v8, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[3:4], null, s82, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[4:5], null, s82, s71, v[4:5]
	v_mul_lo_u32 v5, v3, s6
	v_mad_co_u64_u32 v[58:59], null, v3, s0, s[22:23]
	v_mul_lo_u32 v7, v3, s3
	v_mad_co_u64_u32 v[70:71], null, v3, s93, s[24:25]
	v_mul_lo_u32 v6, v4, s0
	v_mul_lo_u32 v4, v4, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v59, v6, v59, v5
	v_add3_u32 v71, v4, v71, v7
.LBB0_131:
	s_cmp_gt_i32 s83, -1
	v_mov_b32_e32 v74, 0
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s83, s52
	v_mov_b32_e32 v76, 0
	s_cselect_b32 s5, -1, 0
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v105, 0
	s_wait_loadcnt 0x0
	scratch_store_b32 off, v8, off offset:8 ; 4-byte Folded Spill
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v8, 0
	v_mov_b32_e32 v77, 0
	v_mov_b32_e32 v57, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_133
; %bb.132:
	s_mul_i32 s4, s83, 3
	s_mov_b32 s5, 0
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v105, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[3:4], null, s83, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[4:5], null, s83, s71, v[4:5]
	v_mul_lo_u32 v5, v3, s6
	v_mad_co_u64_u32 v[56:57], null, v3, s0, s[22:23]
	v_mul_lo_u32 v7, v3, s3
	v_mad_co_u64_u32 v[76:77], null, v3, s93, s[24:25]
	v_mul_lo_u32 v6, v4, s0
	v_mul_lo_u32 v4, v4, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v57, v6, v57, v5
	v_add3_u32 v77, v4, v77, v7
.LBB0_133:
	s_cmp_gt_i32 s90, -1
	v_mov_b32_e32 v54, 0
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s90, s52
	v_mov_b32_e32 v55, 0
	s_cselect_b32 s5, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_135
; %bb.134:
	s_mul_i32 s4, s90, 3
	s_mov_b32 s5, 0
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v8, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[3:4], null, s90, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[4:5], null, s90, s71, v[4:5]
	v_mul_lo_u32 v5, v3, s6
	v_mad_co_u64_u32 v[54:55], null, v3, s0, s[22:23]
	v_mul_lo_u32 v7, v3, s3
	v_mad_co_u64_u32 v[74:75], null, v3, s93, s[24:25]
	v_mul_lo_u32 v6, v4, s0
	v_mul_lo_u32 v4, v4, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v55, v6, v55, v5
	v_add3_u32 v75, v4, v75, v7
.LBB0_135:
	s_cmp_gt_i32 s91, -1
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v13, 0
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s91, s52
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v80, 0
	s_cselect_b32 s5, -1, 0
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v52, 0
	s_wait_loadcnt 0x0
	scratch_store_b32 off, v8, off          ; 4-byte Folded Spill
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v8, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_137
; %bb.136:
	s_mul_i32 s4, s91, 3
	s_mov_b32 s5, 0
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v8, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[3:4], null, s91, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[4:5], null, s91, s71, v[4:5]
	v_mul_lo_u32 v5, v3, s6
	v_mad_co_u64_u32 v[52:53], null, v3, s0, s[22:23]
	v_mul_lo_u32 v7, v3, s3
	v_mad_co_u64_u32 v[80:81], null, v3, s93, s[24:25]
	v_mul_lo_u32 v6, v4, s0
	v_mul_lo_u32 v4, v4, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v53, v6, v53, v5
	v_add3_u32 v81, v4, v81, v7
.LBB0_137:
	s_cmp_gt_i32 s92, -1
	v_mov_b32_e32 v48, 0
	s_cselect_b32 s4, -1, 0
	s_cmp_lt_i32 s92, s52
	v_mov_b32_e32 v49, 0
	s_cselect_b32 s5, -1, 0
	s_wait_loadcnt 0x0
	scratch_store_b32 off, v8, off offset:4 ; 4-byte Folded Spill
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_139
; %bb.138:
	s_mul_i32 s4, s92, 3
	s_mov_b32 s5, 0
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[26:27], s[4:5]
	global_load_b32 v13, v3, s[4:5] offset:8
	v_mad_co_u64_u32 v[2:3], null, s92, s70, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mad_co_u64_u32 v[3:4], null, s92, s71, v[3:4]
	v_mul_lo_u32 v4, v2, s6
	v_mad_co_u64_u32 v[48:49], null, v2, s0, s[22:23]
	v_mul_lo_u32 v6, v2, s3
	v_mad_co_u64_u32 v[78:79], null, v2, s93, s[24:25]
	v_mul_lo_u32 v5, v3, s0
	v_mul_lo_u32 v3, v3, s93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add3_u32 v49, v5, v49, v4
	v_add3_u32 v79, v3, v79, v6
.LBB0_139:
	v_mov_b32_e32 v42, 0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[64:65]
	v_cmp_gt_i32_e64 s3, s93, v41
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_mov_b32 v97, v42 :: v_dual_mov_b32 v96, v42
	v_mov_b32_e32 v103, v42
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_141
; %bb.140:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v64, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v65, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v68, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v69, vcc_lo
	global_load_b64 v[96:97], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v103, v[4:5], off
.LBB0_141:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[62:63]
	v_dual_mov_b32 v95, v42 :: v_dual_mov_b32 v94, v42
	v_mov_b32_e32 v102, v42
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_143
; %bb.142:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v62, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v63, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v66, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v67, vcc_lo
	global_load_b64 v[94:95], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v102, v[4:5], off
.LBB0_143:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[60:61]
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v92, 0
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v100, 0
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_145
; %bb.144:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v60, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v61, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v72, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v73, vcc_lo
	global_load_b64 v[92:93], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v100, v[4:5], off
.LBB0_145:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[58:59]
	v_mov_b32_e32 v90, 0
	v_mov_b32_e32 v98, 0
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_147
; %bb.146:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v58, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v59, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v70, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v71, vcc_lo
	global_load_b64 v[90:91], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v98, v[4:5], off
.LBB0_147:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[56:57]
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v88, 0
	v_mov_b32_e32 v89, 0
	v_mov_b32_e32 v119, 0
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_149
; %bb.148:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v56, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v57, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v76, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v77, vcc_lo
	global_load_b64 v[88:89], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v119, v[4:5], off
.LBB0_149:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[54:55]
	v_mov_b32_e32 v86, 0
	v_mov_b32_e32 v118, 0
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_151
; %bb.150:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v54, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v55, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v74, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v75, vcc_lo
	global_load_b64 v[86:87], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v118, v[4:5], off
.LBB0_151:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[52:53]
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v84, 0
	v_mov_b32_e32 v85, 0
	v_mov_b32_e32 v117, 0
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_153
; %bb.152:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v52, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v53, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v80, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v81, vcc_lo
	global_load_b64 v[84:85], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v117, v[4:5], off
.LBB0_153:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[48:49]
	v_mov_b32_e32 v82, 0
	v_mov_b32_e32 v116, 0
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB0_155
; %bb.154:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v48, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v49, v3, vcc_lo
	v_add_co_u32 v4, vcc_lo, v78, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v79, vcc_lo
	global_load_b64 v[82:83], v[2:3], off th:TH_LOAD_NT
	global_load_u8 v116, v[4:5], off
.LBB0_155:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshr_b32 s0, s55, 31
	s_ashr_i32 s5, s55, 31
	s_wait_alu 0xfffe
	s_add_co_i32 s0, s55, s0
	s_lshr_b32 s4, s5, 28
	s_wait_alu 0xfffe
	s_ashr_i32 s0, s0, 1
	s_add_co_i32 s4, s55, s4
	s_wait_alu 0xfffe
	v_mad_co_i64_i32 v[46:47], null, v1, s0, 0
	s_ashr_i32 s91, s4, 4
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v50, 0
	s_wait_alu 0xfffe
	v_cmp_gt_i32_e64 s0, s91, v41
	v_mov_b32_e32 v51, 0
	s_and_saveexec_b32 s4, s0
	s_cbranch_execz .LBB0_157
; %bb.156:
	v_lshlrev_b64_e32 v[2:3], 3, v[41:42]
	v_add_co_u32 v4, vcc_lo, s48, v46
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s49, v47, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, v4, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo
	global_load_b64 v[50:51], v[2:3], off th:TH_LOAD_NT
.LBB0_157:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_mad_co_i64_i32 v[44:45], null, v1, s91, s[50:51]
	s_and_saveexec_b32 s4, s0
	s_cbranch_execz .LBB0_159
; %bb.158:
	v_add_co_u32 v1, vcc_lo, v44, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v45, vcc_lo
	global_load_u8 v101, v[1:2], off
.LBB0_159:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_mov_b32_e32 v3, 0
	s_lshl_b64 s[6:7], s[68:69], 1
	s_ashr_i32 s57, s56, 31
	s_wait_alu 0xfffe
	s_add_nc_u64 s[6:7], s[16:17], s[6:7]
	s_mov_b32 s10, s54
	global_load_u16 v1, v3, s[6:7]
	s_mov_b32 s4, s55
	s_bitcmp1_b32 s30, 17
	s_mul_u64 s[8:9], s[56:57], s[10:11]
	s_wait_alu 0xfffe
	s_mul_u64 s[6:7], s[68:69], s[4:5]
	s_cselect_b32 s4, -1, 0
	s_mul_u64 s[8:9], s[8:9], s[68:69]
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s1
	s_wait_loadcnt 0x0
	v_readfirstlane_b32 s90, v1
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s16, s4
	s_cbranch_execz .LBB0_197
; %bb.160:
	v_cmp_ne_u64_e64 s4, 0, v[64:65]
	v_cmp_gt_i32_e64 s5, s93, v41
	v_cmp_le_i32_e32 vcc_lo, s93, v41
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s17, s4
	s_cbranch_execz .LBB0_164
; %bb.161:
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_lshl_b64 s[4:5], s[8:9], 1
	v_mov_b32_e32 v3, 0
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[62:63], s[4:5]
	v_lshlrev_b32_e32 v1, 5, v1
	s_mov_b32 s22, 0
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_u32 v1, s4, s4, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s5, 0, s4
.LBB0_162:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, s4, 0x400, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v2, s4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s5, s93, v4
	s_or_b32 s22, s5, s22
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execnz .LBB0_162
; %bb.163:
	s_or_b32 exec_lo, exec_lo, s22
.LBB0_164:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s17
	v_cmp_ne_u64_e64 s4, 0, v[62:63]
	s_xor_b32 s5, vcc_lo, -1
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s17, s4
	s_cbranch_execz .LBB0_168
; %bb.165:
	s_mul_u64 s[22:23], s[56:57], s[68:69]
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_wait_alu 0xfffe
	s_lshl_b64 s[22:23], s[22:23], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[22:23], 2
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_mul_u64 s[22:23], s[22:23], s[10:11]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[22:23]
	s_wait_alu 0xfffe
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
	s_mov_b32 s22, 0
.LBB0_166:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s93, v4
	s_wait_alu 0xfffe
	s_or_b32 s22, s4, s22
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execnz .LBB0_166
; %bb.167:
	s_or_b32 exec_lo, exec_lo, s22
.LBB0_168:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s17
	v_cmp_ne_u64_e32 vcc_lo, 0, v[60:61]
	s_and_b32 s4, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s17, s4
	s_cbranch_execz .LBB0_172
; %bb.169:
	s_mul_u64 s[22:23], s[56:57], s[68:69]
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_wait_alu 0xfffe
	s_lshl_b64 s[22:23], s[22:23], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[22:23], 4
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_mul_u64 s[22:23], s[22:23], s[10:11]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[22:23]
	s_wait_alu 0xfffe
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
	s_mov_b32 s22, 0
.LBB0_170:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s93, v4
	s_wait_alu 0xfffe
	s_or_b32 s22, s4, s22
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execnz .LBB0_170
; %bb.171:
	s_or_b32 exec_lo, exec_lo, s22
.LBB0_172:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s17
	v_cmp_ne_u64_e32 vcc_lo, 0, v[58:59]
	s_and_b32 s4, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s17, s4
	s_cbranch_execz .LBB0_176
; %bb.173:
	s_mul_u64 s[22:23], s[56:57], s[68:69]
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_wait_alu 0xfffe
	s_lshl_b64 s[22:23], s[22:23], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[22:23], 6
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_mul_u64 s[22:23], s[22:23], s[10:11]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[22:23]
	s_wait_alu 0xfffe
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
	s_mov_b32 s22, 0
.LBB0_174:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s93, v4
	s_wait_alu 0xfffe
	s_or_b32 s22, s4, s22
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execnz .LBB0_174
; %bb.175:
	s_or_b32 exec_lo, exec_lo, s22
.LBB0_176:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s17
	v_cmp_ne_u64_e32 vcc_lo, 0, v[56:57]
	s_and_b32 s4, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s17, s4
	s_cbranch_execz .LBB0_180
; %bb.177:
	s_mul_u64 s[22:23], s[56:57], s[68:69]
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_wait_alu 0xfffe
	s_lshl_b64 s[22:23], s[22:23], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[22:23], 8
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_mul_u64 s[22:23], s[22:23], s[10:11]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[22:23]
	s_wait_alu 0xfffe
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
	s_mov_b32 s22, 0
.LBB0_178:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s93, v4
	s_wait_alu 0xfffe
	s_or_b32 s22, s4, s22
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execnz .LBB0_178
; %bb.179:
	s_or_b32 exec_lo, exec_lo, s22
.LBB0_180:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s17
	v_cmp_ne_u64_e32 vcc_lo, 0, v[54:55]
	s_and_b32 s4, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s17, s4
	s_cbranch_execz .LBB0_184
; %bb.181:
	s_mul_u64 s[22:23], s[56:57], s[68:69]
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_wait_alu 0xfffe
	s_lshl_b64 s[22:23], s[22:23], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[22:23], 10
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_mul_u64 s[22:23], s[22:23], s[10:11]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[22:23]
	s_wait_alu 0xfffe
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
	s_mov_b32 s22, 0
.LBB0_182:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s93, v4
	s_wait_alu 0xfffe
	s_or_b32 s22, s4, s22
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execnz .LBB0_182
; %bb.183:
	s_or_b32 exec_lo, exec_lo, s22
.LBB0_184:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s17
	v_cmp_ne_u64_e32 vcc_lo, 0, v[52:53]
	s_and_b32 s4, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s17, s4
	s_cbranch_execz .LBB0_188
; %bb.185:
	s_mul_u64 s[22:23], s[56:57], s[68:69]
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_wait_alu 0xfffe
	s_lshl_b64 s[22:23], s[22:23], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[22:23], 12
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_mul_u64 s[22:23], s[22:23], s[10:11]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[22:23]
	s_wait_alu 0xfffe
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
	s_mov_b32 s22, 0
.LBB0_186:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s93, v4
	s_wait_alu 0xfffe
	s_or_b32 s22, s4, s22
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execnz .LBB0_186
; %bb.187:
	s_or_b32 exec_lo, exec_lo, s22
.LBB0_188:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s17
	v_cmp_ne_u64_e32 vcc_lo, 0, v[48:49]
	s_and_b32 s4, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB0_192
; %bb.189:
	s_mul_u64 s[22:23], s[56:57], s[68:69]
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_wait_alu 0xfffe
	s_lshl_b64 s[22:23], s[22:23], 1
	s_mov_b32 s17, 0
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[22:23], 14
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_mul_u64 s[22:23], s[22:23], s[10:11]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[22:23]
	s_wait_alu 0xfffe
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
.LBB0_190:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s93, v4
	s_or_b32 s17, s4, s17
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_and_not1_b32 exec_lo, exec_lo, s17
	s_cbranch_execnz .LBB0_190
; %bb.191:
	s_or_b32 exec_lo, exec_lo, s17
.LBB0_192:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_and_saveexec_b32 s5, s0
	s_cbranch_execz .LBB0_196
; %bb.193:
	v_dual_mov_b32 v4, v41 :: v_dual_and_b32 v1, 31, v0
	s_lshl_b64 s[22:23], s[6:7], 1
	s_mov_b32 s17, 0
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[64:65], s[22:23]
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_u32 v1, s4, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s23, 0, s4
.LBB0_194:                              ; =>This Inner Loop Header: Depth=1
	s_clause 0x1
	global_load_b128 v[5:8], v[1:2], off
	global_load_b128 v[9:12], v[1:2], off offset:16
	v_add_nc_u32_e32 v4, 32, v4
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_le_i32_e64 s4, s91, v4
	s_or_b32 s17, s4, s17
	s_wait_loadcnt 0x1
	v_xor3_b32 v3, v5, v3, v6
	v_xor3_b32 v3, v3, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor3_b32 v3, v3, v9, v10
	v_xor3_b32 v3, v3, v11, v12
	s_and_not1_b32 exec_lo, exec_lo, s17
	s_cbranch_execnz .LBB0_194
; %bb.195:
	s_or_b32 exec_lo, exec_lo, s17
.LBB0_196:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	;;#ASMSTART
	;;#ASMEND
.LBB0_197:
	s_or_b32 exec_lo, exec_lo, s16
	s_and_saveexec_b32 s4, s2
	s_cbranch_execz .LBB0_200
; %bb.198:
	v_mov_b32_e32 v1, 0
	global_load_b32 v2, v1, s[34:35] scope:SCOPE_DEV
	s_wait_loadcnt 0x0
	global_inv scope:SCOPE_DEV
	v_cmp_le_u32_e32 vcc_lo, s31, v2
	s_cbranch_vccnz .LBB0_200
.LBB0_199:                              ; =>This Inner Loop Header: Depth=1
	s_sleep 1
	global_load_b32 v2, v1, s[34:35] scope:SCOPE_DEV
	s_wait_loadcnt 0x0
	global_inv scope:SCOPE_DEV
	v_cmp_gt_u32_e32 vcc_lo, s31, v2
	s_cbranch_vccnz .LBB0_199
.LBB0_200:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_wait_loadcnt 0x0
	s_wait_storecnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_wait_loadcnt 0x0
	global_inv scope:SCOPE_DEV
	s_and_saveexec_b32 s92, s1
	s_cbranch_execz .LBB0_365
; %bb.201:
	v_lshlrev_b32_e32 v104, 4, v41
	s_lshl_b64 s[4:5], s[8:9], 1
	scratch_store_b32 off, v13, off offset:12 ; 4-byte Folded Spill
	s_wait_alu 0xfffe
	s_add_nc_u64 s[22:23], s[62:63], s[4:5]
                                        ; implicit-def: $vgpr12
                                        ; implicit-def: $vgpr20
                                        ; implicit-def: $vgpr28
                                        ; implicit-def: $vgpr40
                                        ; implicit-def: $vgpr24
                                        ; implicit-def: $vgpr36
                                        ; implicit-def: $vgpr16
                                        ; implicit-def: $vgpr32
	s_and_saveexec_b32 s1, s3
	s_cbranch_execz .LBB0_203
; %bb.202:
	s_and_b32 s4, s76, exec_lo
	s_cselect_b32 s5, s11, 0
	s_cselect_b32 s4, s10, 0
	v_lshlrev_b32_e32 v1, 1, v104
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_and_b32 s8, s77, exec_lo
	s_mov_b32 s9, 0
	s_cselect_b32 s8, 2, 0
	s_clause 0x1
	global_load_b128 v[29:32], v1, s[22:23]
	global_load_b128 v[13:16], v1, s[22:23] offset:16
	s_wait_alu 0xfffe
	s_mul_u64 s[16:17], s[8:9], s[10:11]
	v_add_co_u32 v5, s8, s22, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v6, null, s23, 0, s8
	s_lshl_b64 s[16:17], s[16:17], 1
	s_and_b32 s8, s78, exec_lo
	s_cselect_b32 s8, 3, 0
	v_add_co_u32 v1, vcc_lo, v5, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s5, v6, vcc_lo
	s_wait_alu 0xfffe
	s_mul_u64 s[4:5], s[8:9], s[10:11]
	v_add_co_u32 v3, vcc_lo, v5, s16
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, s17, v6, vcc_lo
	s_wait_alu 0xfffe
	v_add_co_u32 v5, vcc_lo, v5, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, s5, v6, vcc_lo
	s_clause 0x5
	global_load_b128 v[33:36], v[1:2], off
	global_load_b128 v[21:24], v[1:2], off offset:16
	global_load_b128 v[37:40], v[3:4], off
	global_load_b128 v[25:28], v[3:4], off offset:16
	global_load_b128 v[17:20], v[5:6], off
	global_load_b128 v[9:12], v[5:6], off offset:16
.LBB0_203:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_cndmask_b32_e64 v1, 0, v104, s0
	s_lshl_b64 s[4:5], s[6:7], 1
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v110, 0
	s_wait_alu 0xfffe
	s_add_nc_u64 s[16:17], s[64:65], s[4:5]
	v_dual_mov_b32 v42, 0 :: v_dual_lshlrev_b32 v5, 1, v1
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v112, 0
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v114, 0
	s_clause 0x1
	global_load_b128 v[1:4], v5, s[16:17] offset:16
	global_load_b128 v[5:8], v5, s[16:17]
	v_mov_b32_e32 v115, 0
	s_and_saveexec_b32 s6, s3
	s_cbranch_execz .LBB0_221
; %bb.204:
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v109, 0
	s_mov_b32 s3, exec_lo
	v_cmpx_ne_u64_e32 0, v[64:65]
	s_cbranch_execz .LBB0_206
; %bb.205:
	v_and_b32_e32 v113, 15, v96
	s_wait_loadcnt 0x9
	v_lshlrev_b32_e32 v109, 16, v29
	v_and_b32_e32 v29, 0xffff0000, v29
	v_lshlrev_b32_e32 v111, 16, v31
	v_and_b32_e32 v31, 0xffff0000, v31
	v_lshlrev_b32_e32 v113, 2, v113
	ds_load_b32 v113, v113
	s_wait_dscnt 0x0
	v_fma_f32 v109, v113, v109, 0
	v_lshrrev_b32_e32 v113, 2, v96
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v113, 60, v113
	ds_load_b32 v113, v113
	v_lshlrev_b32_e32 v110, 16, v30
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v109, v113, v29 :: v_dual_and_b32 v30, 0xffff0000, v30
	v_lshrrev_b32_e32 v29, 6, v96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v29, 60, v29
	ds_load_b32 v29, v29
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v109, v29, v110 :: v_dual_lshlrev_b32 v112, 16, v32
	v_lshrrev_b32_e32 v29, 10, v96
	v_and_b32_e32 v29, 60, v29
	ds_load_b32 v29, v29
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v109, v29, v30 :: v_dual_and_b32 v32, 0xffff0000, v32
	v_lshrrev_b32_e32 v29, 14, v96
	v_lshrrev_b32_e32 v30, 22, v96
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v29, 60, v29
	v_and_b32_e32 v30, 60, v30
	ds_load_b32 v29, v29
	ds_load_b32 v30, v30
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v109, v29, v111
	v_lshrrev_b32_e32 v29, 18, v96
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v29, 60, v29
	ds_load_b32 v29, v29
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v109, v29, v31
	v_lshrrev_b32_e32 v29, 26, v96
	v_and_b32_e32 v31, 15, v97
	v_lshrrev_b32_e32 v96, 6, v97
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v109, v30, v112
	v_and_b32_e32 v29, 60, v29
	s_delay_alu instid0(VALU_DEP_4)
	v_lshlrev_b32_e32 v31, 2, v31
	v_lshrrev_b32_e32 v30, 2, v97
	ds_load_b32 v29, v29
	ds_load_b32 v31, v31
	v_and_b32_e32 v30, 60, v30
	ds_load_b32 v30, v30
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v109, v29, v32
	v_and_b32_e32 v32, 60, v96
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v96, 16, v13
	v_lshrrev_b32_e32 v29, 10, v97
	v_and_b32_e32 v13, 0xffff0000, v13
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v109, v31, v96
	v_and_b32_e32 v29, 60, v29
	v_lshrrev_b32_e32 v31, 14, v97
	v_lshrrev_b32_e32 v96, 26, v97
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v109, v30, v13
	ds_load_b32 v32, v32
	ds_load_b32 v29, v29
	v_and_b32_e32 v31, 60, v31
	v_lshrrev_b32_e32 v13, 18, v97
	v_lshrrev_b32_e32 v30, 22, v97
	v_and_b32_e32 v96, 60, v96
	v_lshlrev_b32_e32 v97, 16, v14
	v_and_b32_e32 v14, 0xffff0000, v14
	v_and_b32_e32 v13, 60, v13
	v_and_b32_e32 v30, 60, v30
	ds_load_b32 v96, v96
	ds_load_b32 v31, v31
	ds_load_b32 v30, v30
	ds_load_b32 v13, v13
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v109, v32, v97 :: v_dual_and_b32 v32, 7, v103
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v109, v29, v14
	v_and_b32_e32 v29, 0x7f, v103
	v_cvt_f32_ubyte0_e32 v32, v32
	v_lshlrev_b32_e32 v14, 16, v15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cmp_lt_u32_e32 vcc_lo, 7, v29
	v_cmp_ne_u32_e64 s1, 0x7f, v29
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v109, v31, v14 :: v_dual_and_b32 v14, 0xffff0000, v15
	v_lshl_add_u32 v15, v29, 20, 0x3c000000
	v_mul_f32_e32 v31, 0x3b000000, v32
	v_lshlrev_b32_e32 v29, 16, v16
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v109, v13, v14 :: v_dual_and_b32 v14, 0xffff0000, v16
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v31, v15, vcc_lo
	v_lshlrev_b32_e32 v15, 24, v103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v109, v30, v29
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v13, 0x7fc00000, v13, s1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v109, v96, v14
	v_and_or_b32 v13, 0x80000000, v15, v13
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v109, v109, v13, 0
.LBB0_206:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v13, 1, v104
	s_and_b32 s1, s75, exec_lo
	s_mov_b32 s5, 0
	s_cselect_b32 s4, 4, 0
	s_mov_b32 s3, exec_lo
	v_add_co_u32 v96, s1, s22, v13
	s_wait_alu 0xfffe
	s_mul_u64 s[8:9], s[4:5], s[10:11]
	v_add_co_ci_u32_e64 v97, null, s23, 0, s1
	s_wait_alu 0xfffe
	s_lshl_b64 s[8:9], s[8:9], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v29, vcc_lo, v96, s8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v30, null, s9, v97, vcc_lo
	s_clause 0x1
	global_load_b128 v[13:16], v[29:30], off offset:16
	global_load_b128 v[29:32], v[29:30], off
	v_cmpx_ne_u64_e32 0, v[62:63]
	s_cbranch_execz .LBB0_208
; %bb.207:
	v_and_b32_e32 v111, 15, v94
	s_wait_loadcnt 0x9
	v_lshlrev_b32_e32 v104, 16, v35
	v_lshlrev_b32_e32 v42, 16, v33
	v_lshlrev_b32_e32 v110, 16, v36
	v_and_b32_e32 v36, 0xffff0000, v36
	v_lshlrev_b32_e32 v111, 2, v111
	v_and_b32_e32 v33, 0xffff0000, v33
	ds_load_b32 v111, v111
	s_wait_dscnt 0x0
	v_fma_f32 v42, v111, v42, 0
	v_lshrrev_b32_e32 v111, 2, v94
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v111, 60, v111
	ds_load_b32 v111, v111
	v_lshlrev_b32_e32 v103, 16, v34
	v_and_b32_e32 v34, 0xffff0000, v34
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v42, v111, v33
	v_lshrrev_b32_e32 v33, 6, v94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v33, 60, v33
	ds_load_b32 v33, v33
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v42, v33, v103
	v_lshrrev_b32_e32 v33, 10, v94
	v_and_b32_e32 v33, 60, v33
	ds_load_b32 v33, v33
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v42, v33, v34 :: v_dual_and_b32 v35, 0xffff0000, v35
	v_lshrrev_b32_e32 v33, 14, v94
	v_lshrrev_b32_e32 v34, 22, v94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v33, 60, v33
	v_and_b32_e32 v34, 60, v34
	ds_load_b32 v33, v33
	ds_load_b32 v34, v34
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v42, v33, v104
	v_lshrrev_b32_e32 v33, 18, v94
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v33, 60, v33
	ds_load_b32 v33, v33
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v42, v33, v35
	v_lshrrev_b32_e32 v33, 26, v94
	v_and_b32_e32 v35, 15, v95
	v_lshrrev_b32_e32 v94, 6, v95
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v33, 60, v33
	v_dual_fmac_f32 v42, v34, v110 :: v_dual_lshlrev_b32 v35, 2, v35
	v_lshrrev_b32_e32 v34, 2, v95
	ds_load_b32 v33, v33
	ds_load_b32 v35, v35
	v_and_b32_e32 v34, 60, v34
	ds_load_b32 v34, v34
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v42, v33, v36
	v_and_b32_e32 v36, 60, v94
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v94, 16, v21
	v_lshrrev_b32_e32 v33, 10, v95
	v_and_b32_e32 v21, 0xffff0000, v21
	ds_load_b32 v36, v36
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v42, v35, v94
	v_lshrrev_b32_e32 v94, 26, v95
	v_lshrrev_b32_e32 v35, 14, v95
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v42, v34, v21
	v_and_b32_e32 v94, 60, v94
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v35, 60, v35
	v_lshrrev_b32_e32 v21, 18, v95
	v_lshrrev_b32_e32 v34, 22, v95
	v_lshlrev_b32_e32 v95, 16, v22
	ds_load_b32 v94, v94
	ds_load_b32 v35, v35
	v_and_b32_e32 v33, 60, v33
	v_and_b32_e32 v21, 60, v21
	v_and_b32_e32 v34, 60, v34
	v_and_b32_e32 v22, 0xffff0000, v22
	ds_load_b32 v33, v33
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v42, v36, v95
	ds_load_b32 v34, v34
	ds_load_b32 v21, v21
	v_and_b32_e32 v36, 7, v102
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v36, v36
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v42, v33, v22
	v_lshlrev_b32_e32 v22, 16, v23
	v_and_b32_e32 v33, 0x7f, v102
	v_fmac_f32_e32 v42, v35, v22
	v_and_b32_e32 v22, 0xffff0000, v23
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v23, v33, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v33
	v_mul_f32_e32 v35, 0x3b000000, v36
	v_cmp_ne_u32_e64 s1, 0x7f, v33
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v42, v21, v22 :: v_dual_lshlrev_b32 v33, 16, v24
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v21, v35, v23 :: v_dual_and_b32 v22, 0xffff0000, v24
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v42, v34, v33 :: v_dual_lshlrev_b32 v23, 24, v102
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v21, 0x7fc00000, v21, s1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v42, v94, v22
	v_and_or_b32 v21, 0x80000000, v23, v21
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v42, v42, v21, 0
.LBB0_208:
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s1, s74, exec_lo
	s_cselect_b32 s4, 5, 0
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v111, 0
	s_wait_alu 0xfffe
	s_mul_u64 s[4:5], s[4:5], s[10:11]
	s_mov_b32 s3, exec_lo
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_loadcnt 0x9
	s_wait_alu 0xfffe
	v_add_co_u32 v33, vcc_lo, v96, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v34, null, s5, v97, vcc_lo
	s_wait_loadcnt 0x8
	s_clause 0x1
	global_load_b128 v[21:24], v[33:34], off offset:16
	global_load_b128 v[33:36], v[33:34], off
	v_cmpx_ne_u64_e32 0, v[60:61]
	s_cbranch_execz .LBB0_210
; %bb.209:
	v_and_b32_e32 v104, 15, v92
	s_wait_loadcnt 0x9
	v_lshlrev_b32_e32 v94, 16, v37
	v_lshlrev_b32_e32 v103, 16, v40
	v_and_b32_e32 v37, 0xffff0000, v37
	v_lshlrev_b32_e32 v102, 16, v39
	v_lshlrev_b32_e32 v104, 2, v104
	v_and_b32_e32 v40, 0xffff0000, v40
	ds_load_b32 v104, v104
	s_wait_dscnt 0x0
	v_fma_f32 v94, v104, v94, 0
	v_lshrrev_b32_e32 v104, 2, v92
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v104, 60, v104
	ds_load_b32 v104, v104
	v_lshlrev_b32_e32 v95, 16, v38
	v_and_b32_e32 v38, 0xffff0000, v38
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v94, v104, v37
	v_lshrrev_b32_e32 v37, 6, v92
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v37, 60, v37
	ds_load_b32 v37, v37
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v94, v37, v95
	v_lshrrev_b32_e32 v37, 10, v92
	v_and_b32_e32 v37, 60, v37
	ds_load_b32 v37, v37
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v94, v37, v38 :: v_dual_and_b32 v39, 0xffff0000, v39
	v_lshrrev_b32_e32 v37, 14, v92
	v_lshrrev_b32_e32 v38, 22, v92
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v37, 60, v37
	v_and_b32_e32 v38, 60, v38
	ds_load_b32 v37, v37
	ds_load_b32 v38, v38
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v94, v37, v102
	v_lshrrev_b32_e32 v37, 18, v92
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v37, 60, v37
	ds_load_b32 v37, v37
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v94, v37, v39
	v_lshrrev_b32_e32 v37, 26, v92
	v_lshrrev_b32_e32 v92, 6, v93
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v94, v38, v103 :: v_dual_and_b32 v37, 60, v37
	v_lshrrev_b32_e32 v38, 2, v93
	ds_load_b32 v37, v37
	v_and_b32_e32 v39, 15, v93
	v_and_b32_e32 v38, 60, v38
	v_lshlrev_b32_e32 v39, 2, v39
	ds_load_b32 v38, v38
	ds_load_b32 v39, v39
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v94, v37, v40
	v_and_b32_e32 v40, 60, v92
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v92, 16, v25
	v_lshrrev_b32_e32 v37, 10, v93
	ds_load_b32 v40, v40
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v94, v39, v92
	v_lshrrev_b32_e32 v92, 26, v93
	v_lshrrev_b32_e32 v39, 14, v93
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v92, 60, v92
	ds_load_b32 v92, v92
	v_and_b32_e32 v37, 60, v37
	ds_load_b32 v37, v37
	v_and_b32_e32 v25, 0xffff0000, v25
	v_fmac_f32_e32 v94, v38, v25
	v_lshrrev_b32_e32 v25, 18, v93
	v_lshrrev_b32_e32 v38, 22, v93
	v_lshlrev_b32_e32 v93, 16, v26
	v_and_b32_e32 v39, 60, v39
	v_and_b32_e32 v26, 0xffff0000, v26
	v_and_b32_e32 v25, 60, v25
	v_and_b32_e32 v38, 60, v38
	ds_load_b32 v39, v39
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v94, v40, v93
	v_and_b32_e32 v40, 7, v100
	ds_load_b32 v38, v38
	ds_load_b32 v25, v25
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v94, v37, v26
	v_lshlrev_b32_e32 v26, 16, v27
	v_and_b32_e32 v37, 0x7f, v100
	v_cvt_f32_ubyte0_e32 v40, v40
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_lt_u32_e32 vcc_lo, 7, v37
	v_cmp_ne_u32_e64 s1, 0x7f, v37
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v94, v39, v26
	v_and_b32_e32 v26, 0xffff0000, v27
	v_lshl_add_u32 v27, v37, 20, 0x3c000000
	v_mul_f32_e32 v39, 0x3b000000, v40
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v94, v25, v26 :: v_dual_lshlrev_b32 v37, 16, v28
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v25, v39, v27 :: v_dual_and_b32 v26, 0xffff0000, v28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v94, v38, v37 :: v_dual_lshlrev_b32 v27, 24, v100
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v25, 0x7fc00000, v25, s1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v94, v92, v26
	v_and_or_b32 v25, 0x80000000, v27, v25
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v111, v94, v25, 0
.LBB0_210:
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s1, s73, exec_lo
	s_mov_b32 s5, 0
	s_cselect_b32 s4, 6, 0
	s_mov_b32 s3, exec_lo
	s_wait_alu 0xfffe
	s_mul_u64 s[8:9], s[4:5], s[10:11]
	s_wait_alu 0xfffe
	s_lshl_b64 s[8:9], s[8:9], 1
	s_wait_loadcnt 0x9
	s_wait_alu 0xfffe
	v_add_co_u32 v37, vcc_lo, v96, s8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, s9, v97, vcc_lo
	s_wait_loadcnt 0x8
	s_clause 0x1
	global_load_b128 v[25:28], v[37:38], off offset:16
	global_load_b128 v[37:40], v[37:38], off
	v_cmpx_ne_u64_e32 0, v[58:59]
	s_cbranch_execz .LBB0_212
; %bb.211:
	v_and_b32_e32 v100, 15, v90
	s_wait_loadcnt 0x9
	v_lshlrev_b32_e32 v92, 16, v17
	v_lshlrev_b32_e32 v95, 16, v20
	v_and_b32_e32 v17, 0xffff0000, v17
	v_lshlrev_b32_e32 v94, 16, v19
	v_lshlrev_b32_e32 v100, 2, v100
	v_and_b32_e32 v20, 0xffff0000, v20
	ds_load_b32 v100, v100
	s_wait_dscnt 0x0
	v_fma_f32 v92, v100, v92, 0
	v_lshrrev_b32_e32 v100, 2, v90
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v100, 60, v100
	ds_load_b32 v100, v100
	v_lshlrev_b32_e32 v93, 16, v18
	v_and_b32_e32 v18, 0xffff0000, v18
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v92, v100, v17
	v_lshrrev_b32_e32 v17, 6, v90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v17, 60, v17
	ds_load_b32 v17, v17
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v92, v17, v93 :: v_dual_and_b32 v19, 0xffff0000, v19
	v_lshrrev_b32_e32 v17, 10, v90
	v_and_b32_e32 v17, 60, v17
	ds_load_b32 v17, v17
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v92, v17, v18
	v_lshrrev_b32_e32 v17, 14, v90
	v_lshrrev_b32_e32 v18, 22, v90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v18, 60, v18
	ds_load_b32 v17, v17
	ds_load_b32 v18, v18
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v92, v17, v94
	v_lshrrev_b32_e32 v17, 18, v90
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v17, 60, v17
	ds_load_b32 v17, v17
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v92, v17, v19
	v_lshrrev_b32_e32 v17, 26, v90
	v_lshrrev_b32_e32 v90, 6, v91
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v92, v18, v95 :: v_dual_and_b32 v17, 60, v17
	v_lshrrev_b32_e32 v18, 2, v91
	ds_load_b32 v17, v17
	v_and_b32_e32 v19, 15, v91
	v_and_b32_e32 v18, 60, v18
	v_lshlrev_b32_e32 v19, 2, v19
	ds_load_b32 v18, v18
	ds_load_b32 v19, v19
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v92, v17, v20
	v_lshrrev_b32_e32 v17, 10, v91
	v_and_b32_e32 v20, 60, v90
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v90, 16, v9
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v17, 60, v17
	ds_load_b32 v20, v20
	ds_load_b32 v17, v17
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v92, v19, v90
	v_lshrrev_b32_e32 v19, 14, v91
	v_and_b32_e32 v9, 0xffff0000, v9
	v_lshrrev_b32_e32 v90, 26, v91
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v92, v18, v9 :: v_dual_and_b32 v19, 60, v19
	v_lshrrev_b32_e32 v9, 18, v91
	v_lshrrev_b32_e32 v18, 22, v91
	v_and_b32_e32 v90, 60, v90
	v_lshlrev_b32_e32 v91, 16, v10
	v_and_b32_e32 v10, 0xffff0000, v10
	s_delay_alu instid0(VALU_DEP_4)
	v_and_b32_e32 v18, 60, v18
	ds_load_b32 v90, v90
	ds_load_b32 v19, v19
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v92, v20, v91 :: v_dual_and_b32 v9, 60, v9
	ds_load_b32 v18, v18
	v_and_b32_e32 v20, 7, v98
	ds_load_b32 v9, v9
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v92, v17, v10
	v_lshlrev_b32_e32 v10, 16, v11
	v_and_b32_e32 v17, 0x7f, v98
	v_cvt_f32_ubyte0_e32 v20, v20
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_lt_u32_e32 vcc_lo, 7, v17
	v_cmp_ne_u32_e64 s1, 0x7f, v17
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v92, v19, v10
	v_and_b32_e32 v10, 0xffff0000, v11
	v_lshl_add_u32 v11, v17, 20, 0x3c000000
	v_mul_f32_e32 v19, 0x3b000000, v20
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v92, v9, v10 :: v_dual_lshlrev_b32 v17, 16, v12
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v9, v19, v11 :: v_dual_and_b32 v10, 0xffff0000, v12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v92, v18, v17 :: v_dual_lshlrev_b32 v11, 24, v98
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v9, 0x7fc00000, v9, s1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v92, v90, v10
	v_and_or_b32 v9, 0x80000000, v11, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v110, v92, v9, 0
.LBB0_212:
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s1, s72, exec_lo
	s_cselect_b32 s4, 7, 0
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v113, 0
	s_wait_alu 0xfffe
	s_mul_u64 s[4:5], s[4:5], s[10:11]
	s_mov_b32 s3, exec_lo
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_loadcnt 0x9
	s_wait_alu 0xfffe
	v_add_co_u32 v17, vcc_lo, v96, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, s5, v97, vcc_lo
	s_wait_loadcnt 0x8
	s_clause 0x1
	global_load_b128 v[9:12], v[17:18], off offset:16
	global_load_b128 v[17:20], v[17:18], off
	v_cmpx_ne_u64_e32 0, v[56:57]
	s_cbranch_execz .LBB0_214
; %bb.213:
	v_and_b32_e32 v94, 15, v88
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v90, 16, v29
	v_and_b32_e32 v29, 0xffff0000, v29
	v_lshlrev_b32_e32 v92, 16, v31
	v_lshlrev_b32_e32 v94, 2, v94
	ds_load_b32 v94, v94
	s_wait_dscnt 0x0
	v_fma_f32 v90, v94, v90, 0
	v_lshrrev_b32_e32 v94, 2, v88
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v94, 60, v94
	ds_load_b32 v94, v94
	v_lshlrev_b32_e32 v91, 16, v30
	v_and_b32_e32 v30, 0xffff0000, v30
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v94, v29
	v_lshrrev_b32_e32 v29, 6, v88
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v29, 60, v29
	ds_load_b32 v29, v29
	v_lshlrev_b32_e32 v93, 16, v32
	v_and_b32_e32 v32, 0xffff0000, v32
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v29, v91
	v_lshrrev_b32_e32 v29, 10, v88
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v29, 60, v29
	ds_load_b32 v29, v29
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v90, v29, v30 :: v_dual_and_b32 v31, 0xffff0000, v31
	v_lshrrev_b32_e32 v29, 14, v88
	v_lshrrev_b32_e32 v30, 22, v88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v29, 60, v29
	v_and_b32_e32 v30, 60, v30
	ds_load_b32 v29, v29
	ds_load_b32 v30, v30
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v90, v29, v92
	v_lshrrev_b32_e32 v29, 18, v88
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v29, 60, v29
	ds_load_b32 v29, v29
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v29, v31
	v_lshrrev_b32_e32 v29, 26, v88
	v_lshrrev_b32_e32 v88, 6, v89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_b32_e32 v29, 60, v29
	v_fmac_f32_e32 v90, v30, v93
	v_lshrrev_b32_e32 v30, 2, v89
	ds_load_b32 v29, v29
	v_and_b32_e32 v31, 15, v89
	v_and_b32_e32 v30, 60, v30
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v31, 2, v31
	ds_load_b32 v30, v30
	ds_load_b32 v31, v31
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v90, v29, v32
	v_lshrrev_b32_e32 v29, 10, v89
	v_and_b32_e32 v32, 60, v88
	v_lshlrev_b32_e32 v88, 16, v13
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v29, 60, v29
	ds_load_b32 v32, v32
	ds_load_b32 v29, v29
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v90, v31, v88
	v_lshrrev_b32_e32 v31, 14, v89
	v_and_b32_e32 v13, 0xffff0000, v13
	v_lshrrev_b32_e32 v88, 26, v89
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v90, v30, v13 :: v_dual_and_b32 v31, 60, v31
	v_lshrrev_b32_e32 v13, 18, v89
	v_lshrrev_b32_e32 v30, 22, v89
	v_and_b32_e32 v88, 60, v88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v13, 60, v13
	v_and_b32_e32 v30, 60, v30
	ds_load_b32 v88, v88
	ds_load_b32 v31, v31
	ds_load_b32 v30, v30
	ds_load_b32 v13, v13
	v_lshlrev_b32_e32 v89, 16, v14
	v_and_b32_e32 v14, 0xffff0000, v14
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v90, v32, v89
	v_and_b32_e32 v32, 7, v119
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v90, v29, v14
	v_lshlrev_b32_e32 v14, 16, v15
	v_and_b32_e32 v29, 0x7f, v119
	v_cvt_f32_ubyte0_e32 v32, v32
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v90, v31, v14
	v_and_b32_e32 v14, 0xffff0000, v15
	v_lshl_add_u32 v15, v29, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v29
	v_mul_f32_e32 v31, 0x3b000000, v32
	v_cmp_ne_u32_e64 s1, 0x7f, v29
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v90, v13, v14 :: v_dual_lshlrev_b32 v29, 16, v16
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v13, v31, v15 :: v_dual_and_b32 v14, 0xffff0000, v16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v90, v30, v29 :: v_dual_lshlrev_b32 v15, 24, v119
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v13, 0x7fc00000, v13, s1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v90, v88, v14
	v_and_or_b32 v13, 0x80000000, v15, v13
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v113, v90, v13, 0
.LBB0_214:
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[54:55]
	s_cbranch_execz .LBB0_216
; %bb.215:
	s_wait_loadcnt 0x7
	v_and_b32_e32 v13, 15, v86
	v_lshrrev_b32_e32 v14, 2, v86
	v_lshrrev_b32_e32 v15, 6, v86
	s_wait_loadcnt 0x4
	v_lshlrev_b32_e32 v89, 16, v34
	v_lshrrev_b32_e32 v16, 10, v86
	v_lshlrev_b32_e32 v13, 2, v13
	v_and_b32_e32 v14, 60, v14
	v_and_b32_e32 v15, 60, v15
	v_lshrrev_b32_e32 v29, 14, v86
	v_lshrrev_b32_e32 v30, 18, v86
	ds_load_b32 v13, v13
	ds_load_b32 v14, v14
	ds_load_b32 v15, v15
	v_lshrrev_b32_e32 v31, 22, v86
	v_lshrrev_b32_e32 v32, 26, v86
	v_and_b32_e32 v16, 60, v16
	v_and_b32_e32 v29, 60, v29
	v_lshlrev_b32_e32 v91, 16, v35
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v31, 60, v31
	v_and_b32_e32 v32, 60, v32
	ds_load_b32 v16, v16
	ds_load_b32 v29, v29
	ds_load_b32 v30, v30
	ds_load_b32 v31, v31
	ds_load_b32 v32, v32
	v_and_b32_e32 v34, 0xffff0000, v34
	v_lshlrev_b32_e32 v86, 16, v33
	v_and_b32_e32 v33, 0xffff0000, v33
	v_lshrrev_b32_e32 v88, 2, v87
	v_lshrrev_b32_e32 v90, 14, v87
	s_wait_dscnt 0x7
	v_fma_f32 v13, v13, v86, 0
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v14, v33
	v_lshrrev_b32_e32 v14, 6, v87
	v_lshrrev_b32_e32 v33, 10, v87
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v13, v15, v89 :: v_dual_and_b32 v14, 60, v14
	v_lshrrev_b32_e32 v15, 18, v87
	v_lshrrev_b32_e32 v89, 22, v87
	v_and_b32_e32 v33, 60, v33
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v13, v16, v34 :: v_dual_and_b32 v34, 0xffff0000, v35
	v_lshlrev_b32_e32 v35, 16, v36
	v_and_b32_e32 v15, 60, v15
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v13, v29, v91
	v_and_b32_e32 v29, 0xffff0000, v36
	v_lshlrev_b32_e32 v36, 16, v21
	v_and_b32_e32 v21, 0xffff0000, v21
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v13, v30, v34
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v13, v31, v35
	v_and_b32_e32 v86, 15, v87
	v_lshrrev_b32_e32 v87, 26, v87
	v_and_b32_e32 v31, 60, v89
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v13, v32, v29 :: v_dual_lshlrev_b32 v16, 2, v86
	v_and_b32_e32 v86, 60, v88
	v_and_b32_e32 v35, 60, v87
	ds_load_b32 v16, v16
	ds_load_b32 v30, v86
	ds_load_b32 v14, v14
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v13, v16, v36 :: v_dual_lshlrev_b32 v16, 16, v22
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v30, v21
	v_and_b32_e32 v21, 0xffff0000, v22
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v13, v14, v16 :: v_dual_and_b32 v22, 0xffff0000, v23
	v_lshlrev_b32_e32 v16, 16, v23
	v_lshlrev_b32_e32 v23, 16, v24
	v_and_b32_e32 v34, 60, v90
	ds_load_b32 v29, v33
	ds_load_b32 v32, v34
	ds_load_b32 v15, v15
	ds_load_b32 v31, v31
	ds_load_b32 v33, v35
	v_and_b32_e32 v14, 7, v118
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v14, v14
	s_wait_dscnt 0x4
	v_dual_mul_f32 v14, 0x3b000000, v14 :: v_dual_fmac_f32 v13, v29, v21
	v_and_b32_e32 v21, 0x7f, v118
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v32, v16
	v_lshl_add_u32 v16, v21, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v21
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v13, v15, v22
	v_and_b32_e32 v15, 0xffff0000, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v14, v14, v16, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v21
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v13, v31, v23 :: v_dual_lshlrev_b32 v16, 24, v118
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v14, 0x7fc00000, v14 :: v_dual_fmac_f32 v13, v33, v15
	v_and_or_b32 v14, 0x80000000, v16, v14
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v112, v13, v14, 0
.LBB0_216:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v115, 0
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[52:53]
	s_cbranch_execz .LBB0_218
; %bb.217:
	s_wait_loadcnt 0x7
	v_and_b32_e32 v13, 15, v84
	v_lshrrev_b32_e32 v14, 2, v84
	v_lshrrev_b32_e32 v15, 6, v84
	s_wait_loadcnt 0x2
	v_lshlrev_b32_e32 v32, 16, v38
	v_lshrrev_b32_e32 v16, 10, v84
	v_lshlrev_b32_e32 v13, 2, v13
	v_and_b32_e32 v14, 60, v14
	v_and_b32_e32 v15, 60, v15
	v_lshlrev_b32_e32 v29, 16, v37
	v_lshrrev_b32_e32 v21, 14, v84
	ds_load_b32 v13, v13
	ds_load_b32 v14, v14
	ds_load_b32 v15, v15
	v_lshrrev_b32_e32 v22, 18, v84
	v_lshrrev_b32_e32 v23, 22, v84
	v_lshrrev_b32_e32 v24, 26, v84
	v_and_b32_e32 v21, 60, v21
	v_lshlrev_b32_e32 v36, 16, v39
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v23, 60, v23
	v_and_b32_e32 v24, 60, v24
	v_and_b32_e32 v34, 0xffff0000, v38
	v_lshrrev_b32_e32 v31, 2, v85
	v_lshrrev_b32_e32 v33, 14, v85
	v_lshrrev_b32_e32 v35, 26, v85
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v31, 60, v31
	s_wait_dscnt 0x2
	v_fma_f32 v13, v13, v29, 0
	v_and_b32_e32 v16, 60, v16
	v_and_b32_e32 v29, 15, v85
	ds_load_b32 v16, v16
	ds_load_b32 v21, v21
	ds_load_b32 v22, v22
	ds_load_b32 v23, v23
	ds_load_b32 v24, v24
	v_and_b32_e32 v30, 0xffff0000, v37
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v14, v30
	v_lshrrev_b32_e32 v14, 6, v85
	v_lshrrev_b32_e32 v30, 10, v85
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v13, v15, v32 :: v_dual_and_b32 v14, 60, v14
	v_lshrrev_b32_e32 v15, 18, v85
	v_lshrrev_b32_e32 v32, 22, v85
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v13, v16, v34 :: v_dual_lshlrev_b32 v16, 2, v29
	v_and_b32_e32 v29, 0xffff0000, v39
	v_and_b32_e32 v15, 60, v15
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v13, v21, v36
	ds_load_b32 v16, v16
	v_and_b32_e32 v21, 0xffff0000, v40
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v13, v22, v29
	ds_load_b32 v22, v31
	ds_load_b32 v14, v14
	v_lshlrev_b32_e32 v36, 16, v25
	v_and_b32_e32 v25, 0xffff0000, v25
	v_lshlrev_b32_e32 v34, 16, v40
	v_and_b32_e32 v29, 60, v30
	v_and_b32_e32 v30, 60, v33
	v_and_b32_e32 v31, 60, v35
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v13, v23, v34
	v_and_b32_e32 v23, 60, v32
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v13, v24, v21
	ds_load_b32 v21, v29
	ds_load_b32 v24, v30
	ds_load_b32 v15, v15
	ds_load_b32 v23, v23
	ds_load_b32 v29, v31
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v13, v16, v36 :: v_dual_lshlrev_b32 v16, 16, v26
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v13, v22, v25 :: v_dual_and_b32 v22, 0xffff0000, v26
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v13, v14, v16 :: v_dual_and_b32 v14, 7, v117
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v13, v21, v22 :: v_dual_lshlrev_b32 v16, 16, v27
	v_and_b32_e32 v21, 0x7f, v117
	v_cvt_f32_ubyte0_e32 v14, v14
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v13, v24, v16 :: v_dual_and_b32 v22, 0xffff0000, v27
	v_lshl_add_u32 v16, v21, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_mul_f32_e32 v14, 0x3b000000, v14
	v_cmp_lt_u32_e32 vcc_lo, 7, v21
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v13, v15, v22 :: v_dual_lshlrev_b32 v24, 16, v28
	v_and_b32_e32 v15, 0xffff0000, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v14, v14, v16, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v21
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v13, v23, v24 :: v_dual_lshlrev_b32 v16, 24, v117
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v14, 0x7fc00000, v14 :: v_dual_fmac_f32 v13, v29, v15
	v_and_or_b32 v14, 0x80000000, v16, v14
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v115, v13, v14, 0
.LBB0_218:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[48:49]
	s_cbranch_execz .LBB0_220
; %bb.219:
	s_wait_loadcnt 0x7
	v_and_b32_e32 v13, 15, v82
	v_lshrrev_b32_e32 v14, 2, v82
	v_lshrrev_b32_e32 v15, 6, v82
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v27, 16, v18
	v_lshlrev_b32_e32 v25, 16, v17
	v_lshlrev_b32_e32 v13, 2, v13
	v_and_b32_e32 v14, 60, v14
	v_and_b32_e32 v15, 60, v15
	v_lshrrev_b32_e32 v16, 10, v82
	v_and_b32_e32 v17, 0xffff0000, v17
	ds_load_b32 v13, v13
	ds_load_b32 v14, v14
	ds_load_b32 v15, v15
	v_lshrrev_b32_e32 v21, 14, v82
	v_lshrrev_b32_e32 v22, 18, v82
	v_lshrrev_b32_e32 v23, 22, v82
	v_lshrrev_b32_e32 v24, 26, v82
	v_and_b32_e32 v18, 0xffff0000, v18
	v_and_b32_e32 v21, 60, v21
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v23, 60, v23
	v_lshrrev_b32_e32 v26, 2, v83
	v_lshrrev_b32_e32 v28, 14, v83
	v_lshrrev_b32_e32 v29, 26, v83
	s_wait_dscnt 0x2
	v_fma_f32 v13, v13, v25, 0
	v_and_b32_e32 v16, 60, v16
	v_and_b32_e32 v25, 15, v83
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v13, v14, v17
	v_lshrrev_b32_e32 v14, 6, v83
	v_lshrrev_b32_e32 v17, 10, v83
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v13, v15, v27 :: v_dual_and_b32 v24, 60, v24
	ds_load_b32 v16, v16
	ds_load_b32 v21, v21
	ds_load_b32 v22, v22
	ds_load_b32 v23, v23
	ds_load_b32 v24, v24
	v_and_b32_e32 v14, 60, v14
	v_lshrrev_b32_e32 v15, 18, v83
	v_lshrrev_b32_e32 v27, 22, v83
	v_and_b32_e32 v17, 60, v17
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v15, 60, v15
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v13, v16, v18 :: v_dual_and_b32 v18, 0xffff0000, v19
	v_lshlrev_b32_e32 v30, 16, v19
	v_lshlrev_b32_e32 v16, 2, v25
	v_and_b32_e32 v25, 60, v26
	v_lshlrev_b32_e32 v19, 16, v20
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v13, v21, v30
	ds_load_b32 v16, v16
	v_lshlrev_b32_e32 v21, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v9
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v13, v22, v18
	ds_load_b32 v18, v25
	ds_load_b32 v14, v14
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v13, v23, v19 :: v_dual_and_b32 v20, 0xffff0000, v20
	v_and_b32_e32 v19, 60, v27
	v_and_b32_e32 v23, 60, v29
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v13, v24, v20
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v13, v16, v21 :: v_dual_lshlrev_b32 v16, 16, v10
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v18, v9
	v_and_b32_e32 v9, 0xffff0000, v10
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v13, v14, v16 :: v_dual_lshlrev_b32 v14, 16, v11
	v_and_b32_e32 v22, 60, v28
	ds_load_b32 v17, v17
	ds_load_b32 v20, v22
	ds_load_b32 v15, v15
	ds_load_b32 v19, v19
	ds_load_b32 v22, v23
	v_and_b32_e32 v11, 0xffff0000, v11
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v13, v17, v9 :: v_dual_lshlrev_b32 v16, 16, v12
	v_and_b32_e32 v9, 0x7f, v116
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v20, v14
	v_lshl_add_u32 v14, v9, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v9
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v13, v15, v11
	v_and_b32_e32 v11, 0xffff0000, v12
	v_lshlrev_b32_e32 v12, 24, v116
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v13, v19, v16
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v13, v22, v11 :: v_dual_and_b32 v10, 7, v116
	v_cvt_f32_ubyte0_e32 v10, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v10, 0x3b000000, v10
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v14, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v9
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v9, 0x7fc00000, v10, vcc_lo
	v_and_or_b32 v9, 0x80000000, v12, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v114, v13, v9, 0
.LBB0_220:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
.LBB0_221:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s94, exec_lo
	v_cmpx_gt_i32_e64 s93, v99
	s_cbranch_execz .LBB0_257
; %bb.222:
	s_wait_loadcnt 0x3
	v_add_co_u32 v27, s9, 0x100, v64
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v28, null, 0, v65, s9
	v_add_co_u32 v29, s9, v68, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v30, null, 0, v69, s9
	v_add_co_u32 v31, s9, 0x100, v62
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v32, null, 0, v63, s9
	v_add_co_u32 v33, s9, v66, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v34, null, 0, v67, s9
	v_add_co_u32 v35, s9, 0x100, v60
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v36, null, 0, v61, s9
	s_wait_loadcnt 0x2
	v_add_co_u32 v37, s9, v72, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v73, s9
	v_add_co_u32 v39, s9, 0x100, v58
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v40, null, 0, v59, s9
	v_add_co_u32 v66, s9, v70, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v67, null, 0, v71, s9
	v_add_co_u32 v68, s9, 0x100, v56
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v69, null, 0, v57, s9
	v_add_co_u32 v70, s9, v76, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v71, null, 0, v77, s9
	v_add_co_u32 v72, s9, 0x100, v54
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v73, null, 0, v55, s9
	v_add_co_u32 v74, s9, v74, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v75, null, 0, v75, s9
	v_add_co_u32 v76, s9, 0x100, v52
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v77, null, 0, v53, s9
	v_add_co_u32 v80, s9, v80, 32
	v_and_b32_e32 v25, 31, v0
	s_mul_u64 s[50:51], s[56:57], s[68:69]
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v81, null, 0, v81, s9
	v_add_co_u32 v82, s9, 0x100, v48
	s_wait_alu 0xfffe
	s_lshl_b64 s[80:81], s[50:51], 1
	v_add_co_ci_u32_e64 v83, null, 0, v49, s9
	v_add_co_u32 v78, s9, v78, 32
	v_cmp_ne_u64_e64 s1, 0, v[62:63]
	v_cmp_ne_u64_e64 s3, 0, v[60:61]
	v_cmp_ne_u64_e64 s4, 0, v[58:59]
	v_cmp_ne_u64_e64 s5, 0, v[56:57]
	v_cmp_ne_u64_e64 s6, 0, v[54:55]
	v_cmp_ne_u64_e64 s7, 0, v[52:53]
	v_cmp_ne_u64_e64 s8, 0, v[48:49]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[50:51], s[80:81], 2
	s_add_nc_u64 s[72:73], s[80:81], 4
	s_add_nc_u64 s[74:75], s[80:81], 6
	s_add_nc_u64 s[76:77], s[80:81], 8
	s_add_nc_u64 s[78:79], s[80:81], 10
	s_add_nc_u64 s[82:83], s[80:81], 12
	s_add_nc_u64 s[80:81], s[80:81], 14
	v_lshlrev_b32_e32 v26, 3, v25
	v_add_co_ci_u32_e64 v79, null, 0, v79, s9
	v_lshlrev_b32_e32 v84, 5, v25
	s_wait_alu 0xfffe
	s_mul_u64 s[50:51], s[50:51], s[10:11]
	s_mul_u64 s[72:73], s[72:73], s[10:11]
	s_mul_u64 s[74:75], s[74:75], s[10:11]
	s_mul_u64 s[76:77], s[76:77], s[10:11]
	s_mul_u64 s[78:79], s[78:79], s[10:11]
	s_mul_u64 s[82:83], s[82:83], s[10:11]
	s_mul_u64 s[10:11], s[80:81], s[10:11]
	s_mov_b64 s[24:25], 32
	s_wait_alu 0xfffe
	s_add_nc_u64 s[50:51], s[62:63], s[50:51]
	s_add_nc_u64 s[72:73], s[62:63], s[72:73]
	s_add_nc_u64 s[74:75], s[62:63], s[74:75]
	s_add_nc_u64 s[76:77], s[62:63], s[76:77]
	s_add_nc_u64 s[78:79], s[62:63], s[78:79]
	s_add_nc_u64 s[80:81], s[62:63], s[82:83]
	s_add_nc_u64 s[82:83], s[62:63], s[10:11]
	s_mov_b32 s11, 0
	v_cmp_ne_u64_e32 vcc_lo, 0, v[64:65]
	s_branch .LBB0_224
.LBB0_223:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_add_co_u32 v27, s9, 0x100, v27
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v28, null, 0, v28, s9
	v_add_co_u32 v29, s9, v29, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v30, null, 0, v30, s9
	v_add_co_u32 v31, s9, 0x100, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v32, null, 0, v32, s9
	v_add_co_u32 v33, s9, v33, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v34, null, 0, v34, s9
	v_add_co_u32 v35, s9, 0x100, v35
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v36, null, 0, v36, s9
	v_add_co_u32 v37, s9, v37, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v38, s9
	v_add_co_u32 v39, s9, 0x100, v39
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v40, null, 0, v40, s9
	v_add_co_u32 v66, s9, v66, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v67, null, 0, v67, s9
	v_add_co_u32 v68, s9, 0x100, v68
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v69, null, 0, v69, s9
	v_add_co_u32 v70, s9, v70, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v71, null, 0, v71, s9
	v_add_co_u32 v72, s9, 0x100, v72
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v73, null, 0, v73, s9
	v_add_co_u32 v74, s9, v74, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v75, null, 0, v75, s9
	v_add_co_u32 v76, s9, 0x100, v76
	s_add_nc_u64 s[24:25], s[24:25], 32
	v_add_co_ci_u32_e64 v77, null, 0, v77, s9
	v_add_co_u32 v80, s9, v80, 32
	s_wait_loadcnt 0x1
	s_wait_alu 0xfffe
	v_add_nc_u32_e32 v9, s24, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v81, null, 0, v81, s9
	v_add_co_u32 v82, s9, 0x100, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v83, null, 0, v83, s9
	v_add_co_u32 v78, s9, v78, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v79, null, 0, v79, s9
	v_cmp_le_i32_e64 s9, s93, v9
	s_add_nc_u64 s[22:23], s[22:23], 0x400
	s_add_nc_u64 s[50:51], s[50:51], 0x400
	s_add_nc_u64 s[72:73], s[72:73], 0x400
	s_add_nc_u64 s[74:75], s[74:75], 0x400
	s_add_nc_u64 s[76:77], s[76:77], 0x400
	s_add_nc_u64 s[78:79], s[78:79], 0x400
	s_add_nc_u64 s[80:81], s[80:81], 0x400
	s_or_b32 s11, s9, s11
	s_add_nc_u64 s[82:83], s[82:83], 0x400
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s11
	s_cbranch_execz .LBB0_256
.LBB0_224:                              ; =>This Inner Loop Header: Depth=1
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v23, 0
	v_mov_b32_e32 v92, 0
	s_and_saveexec_b32 s10, vcc_lo
	s_cbranch_execz .LBB0_226
; %bb.225:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_loadcnt 0x1
	v_add_co_u32 v9, s9, v27, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v28, s9
	v_add_co_u32 v11, s9, v29, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v30, s9
	global_load_b64 v[23:24], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v92, v[11:12], off
.LBB0_226:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v91, 0
	s_and_saveexec_b32 s10, s1
	s_cbranch_execz .LBB0_228
; %bb.227:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v9, s9, v31, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v32, s9
	v_add_co_u32 v11, s9, v33, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v34, s9
	global_load_b64 v[21:22], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v91, v[11:12], off
.LBB0_228:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v90, 0
	s_and_saveexec_b32 s10, s3
	s_cbranch_execz .LBB0_230
; %bb.229:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v9, s9, v35, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v36, s9
	v_add_co_u32 v11, s9, v37, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v38, s9
	global_load_b64 v[19:20], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v90, v[11:12], off
.LBB0_230:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v89, 0
	s_and_saveexec_b32 s10, s4
	s_cbranch_execz .LBB0_232
; %bb.231:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v9, s9, v39, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v40, s9
	v_add_co_u32 v11, s9, v66, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v67, s9
	global_load_b64 v[17:18], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v89, v[11:12], off
.LBB0_232:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v88, 0
	s_and_saveexec_b32 s10, s5
	s_cbranch_execz .LBB0_234
; %bb.233:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v9, s9, v68, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v69, s9
	v_add_co_u32 v11, s9, v70, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v71, s9
	global_load_b64 v[15:16], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v88, v[11:12], off
.LBB0_234:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v87, 0
	s_and_saveexec_b32 s10, s6
	s_cbranch_execz .LBB0_236
; %bb.235:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v9, s9, v72, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v73, s9
	v_add_co_u32 v85, s9, v74, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v86, null, 0, v75, s9
	global_load_b64 v[13:14], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v87, v[85:86], off
.LBB0_236:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v86, 0
	s_and_saveexec_b32 s10, s7
	s_cbranch_execz .LBB0_238
; %bb.237:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v9, s9, v76, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v77, s9
	v_add_co_u32 v85, s9, v80, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v86, null, 0, v81, s9
	global_load_b64 v[11:12], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v86, v[85:86], off
.LBB0_238:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0
	v_mov_b32_e32 v85, 0
	s_and_saveexec_b32 s10, s8
	s_cbranch_execz .LBB0_247
; %bb.239:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v9, s9, v82, v26
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v83, s9
	v_add_co_u32 v93, s9, v78, v25
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v94, null, 0, v79, s9
	global_load_b64 v[9:10], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v85, v[93:94], off
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s57, vcc_lo
	s_cbranch_execnz .LBB0_248
.LBB0_240:                              ;   in Loop: Header=BB0_224 Depth=1
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s57, s1
	s_cbranch_execz .LBB0_249
.LBB0_241:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	v_add_co_u32 v23, s9, s50, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v24, null, s51, 0, s9
	global_load_b128 v[92:95], v[23:24], off offset:1024
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v98, 16, v94
	v_and_b32_e32 v94, 0xffff0000, v94
	v_lshlrev_b32_e32 v100, 16, v95
	v_and_b32_e32 v102, 0xffff0000, v95
	v_and_b32_e32 v95, 15, v21
	v_lshlrev_b32_e32 v96, 16, v92
	v_and_b32_e32 v92, 0xffff0000, v92
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v95, 2, v95
	ds_load_b32 v95, v95
	s_wait_dscnt 0x0
	v_fma_f32 v96, v95, v96, 0
	v_lshrrev_b32_e32 v95, 2, v21
	v_and_b32_e32 v95, 60, v95
	ds_load_b32 v95, v95
	v_lshlrev_b32_e32 v97, 16, v93
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v96, v95, v92 :: v_dual_and_b32 v93, 0xffff0000, v93
	v_lshrrev_b32_e32 v92, 6, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v92, 60, v92
	ds_load_b32 v92, v92
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v96, v92, v97
	v_lshrrev_b32_e32 v92, 10, v21
	v_and_b32_e32 v92, 60, v92
	ds_load_b32 v92, v92
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v96, v92, v93
	v_lshrrev_b32_e32 v92, 14, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v92, 60, v92
	ds_load_b32 v92, v92
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v96, v92, v98
	v_lshrrev_b32_e32 v92, 18, v21
	v_and_b32_e32 v92, 60, v92
	ds_load_b32 v92, v92
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v96, v92, v94
	global_load_b128 v[92:95], v[23:24], off offset:1040
	v_lshrrev_b32_e32 v23, 22, v21
	v_lshrrev_b32_e32 v21, 26, v21
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v23, 60, v23
	ds_load_b32 v23, v23
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v24, 16, v92
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v96, v23, v100 :: v_dual_and_b32 v23, 15, v22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v23, 2, v23
	ds_load_b32 v23, v23
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v96, v21, v102
	v_lshrrev_b32_e32 v21, 2, v22
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v96, v23, v24
	v_lshrrev_b32_e32 v23, 6, v22
	v_and_b32_e32 v24, 0xffff0000, v92
	v_lshlrev_b32_e32 v92, 16, v94
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v23, 60, v23
	ds_load_b32 v23, v23
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v96, v21, v24
	v_lshrrev_b32_e32 v21, 10, v22
	v_lshlrev_b32_e32 v24, 16, v93
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v96, v23, v24
	v_lshrrev_b32_e32 v23, 14, v22
	v_and_b32_e32 v24, 0xffff0000, v93
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v23, 60, v23
	ds_load_b32 v23, v23
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v96, v21, v24
	v_lshrrev_b32_e32 v21, 18, v22
	v_lshrrev_b32_e32 v24, 22, v22
	v_lshrrev_b32_e32 v22, 26, v22
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v21, 60, v21
	v_and_b32_e32 v24, 60, v24
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v22, 60, v22
	ds_load_b32 v21, v21
	ds_load_b32 v24, v24
	ds_load_b32 v22, v22
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v96, v23, v92 :: v_dual_and_b32 v23, 0xffff0000, v94
	v_and_b32_e32 v92, 7, v91
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v96, v21, v23
	v_and_b32_e32 v21, 0x7f, v91
	v_cvt_f32_ubyte0_e32 v23, v92
	v_lshlrev_b32_e32 v91, 24, v91
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v92, v21, 20, 0x3c000000
	v_cmp_lt_u32_e64 s9, 7, v21
	v_mul_f32_e32 v23, 0x3b000000, v23
	v_cmp_ne_u32_e64 s10, 0x7f, v21
	v_lshlrev_b32_e32 v21, 16, v95
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e64 v23, v23, v92, s9
	v_and_b32_e32 v92, 0xffff0000, v95
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v96, v24, v21
	v_cndmask_b32_e64 v21, 0x7fc00000, v23, s10
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v96, v22, v92
	v_and_or_b32 v21, 0x80000000, v91, v21
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v42, v96, v21
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s57, s3
	s_cbranch_execnz .LBB0_250
.LBB0_242:                              ;   in Loop: Header=BB0_224 Depth=1
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s57, s4
	s_cbranch_execz .LBB0_251
.LBB0_243:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	v_add_co_u32 v23, s9, s74, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v24, null, s75, 0, s9
	s_wait_loadcnt 0x1
	global_load_b128 v[19:22], v[23:24], off offset:1024
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v93, 16, v22
	v_and_b32_e32 v94, 0xffff0000, v22
	v_and_b32_e32 v22, 15, v17
	v_lshlrev_b32_e32 v90, 16, v19
	v_and_b32_e32 v19, 0xffff0000, v19
	v_lshlrev_b32_e32 v92, 16, v21
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v22, 2, v22
	ds_load_b32 v22, v22
	s_wait_dscnt 0x0
	v_fma_f32 v90, v22, v90, 0
	v_lshrrev_b32_e32 v22, 2, v17
	v_and_b32_e32 v22, 60, v22
	ds_load_b32 v22, v22
	v_lshlrev_b32_e32 v91, 16, v20
	v_and_b32_e32 v20, 0xffff0000, v20
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v22, v19
	v_lshrrev_b32_e32 v19, 6, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v19, v19
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v90, v19, v91 :: v_dual_and_b32 v21, 0xffff0000, v21
	v_lshrrev_b32_e32 v19, 10, v17
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v19, v19
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v19, v20
	v_lshrrev_b32_e32 v19, 14, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v19, v19
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v19, v92
	v_lshrrev_b32_e32 v19, 18, v17
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v19, v19
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v19, v21
	global_load_b128 v[19:22], v[23:24], off offset:1040
	v_lshrrev_b32_e32 v23, 22, v17
	v_lshrrev_b32_e32 v17, 26, v17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v23, 60, v23
	v_and_b32_e32 v17, 60, v17
	ds_load_b32 v23, v23
	ds_load_b32 v17, v17
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v90, v23, v93
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v90, v17, v94
	v_lshrrev_b32_e32 v17, 2, v18
	v_and_b32_e32 v17, 60, v17
	ds_load_b32 v17, v17
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v24, 16, v19
	v_and_b32_e32 v19, 0xffff0000, v19
	v_and_b32_e32 v23, 15, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v23, 2, v23
	ds_load_b32 v23, v23
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v23, v24
	v_lshrrev_b32_e32 v23, 6, v18
	v_fmac_f32_e32 v90, v17, v19
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v23, 60, v23
	v_lshrrev_b32_e32 v17, 10, v18
	ds_load_b32 v19, v23
	v_and_b32_e32 v17, 60, v17
	v_lshlrev_b32_e32 v23, 16, v20
	v_and_b32_e32 v20, 0xffff0000, v20
	ds_load_b32 v17, v17
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v90, v19, v23
	v_lshrrev_b32_e32 v19, 14, v18
	v_lshlrev_b32_e32 v23, 16, v21
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v19, v19
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v90, v17, v20
	v_lshrrev_b32_e32 v17, 18, v18
	v_lshrrev_b32_e32 v20, 22, v18
	v_lshrrev_b32_e32 v18, 26, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v20, 60, v20
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v18, 60, v18
	ds_load_b32 v17, v17
	ds_load_b32 v20, v20
	ds_load_b32 v18, v18
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v90, v19, v23 :: v_dual_and_b32 v19, 0xffff0000, v21
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v90, v17, v19 :: v_dual_and_b32 v21, 7, v89
	v_and_b32_e32 v17, 0x7f, v89
	v_cvt_f32_ubyte0_e32 v19, v21
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v21, v17, 20, 0x3c000000
	v_cmp_lt_u32_e64 s9, 7, v17
	v_mul_f32_e32 v19, 0x3b000000, v19
	v_cmp_ne_u32_e64 s10, 0x7f, v17
	v_lshlrev_b32_e32 v17, 16, v22
	v_and_b32_e32 v22, 0xffff0000, v22
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v19, v19, v21, s9
	v_lshlrev_b32_e32 v21, 24, v89
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v90, v20, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v17, 0x7fc00000, v19, s10
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v18, v22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v17, 0x80000000, v21, v17
	v_fmac_f32_e32 v110, v90, v17
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s10, s5
	s_cbranch_execnz .LBB0_252
.LBB0_244:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s10, s6
	s_cbranch_execz .LBB0_253
.LBB0_245:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_loadcnt 0x1
	v_add_co_u32 v19, s9, s78, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v20, null, s79, 0, s9
	v_and_b32_e32 v23, 15, v13
	v_lshrrev_b32_e32 v24, 2, v13
	s_wait_loadcnt 0x0
	v_lshrrev_b32_e32 v88, 6, v13
	s_clause 0x1
	global_load_b128 v[15:18], v[19:20], off offset:1024
	global_load_b128 v[19:22], v[19:20], off offset:1040
	v_lshrrev_b32_e32 v89, 10, v13
	v_lshlrev_b32_e32 v23, 2, v23
	v_lshrrev_b32_e32 v90, 14, v13
	v_lshrrev_b32_e32 v91, 18, v13
	v_lshrrev_b32_e32 v92, 22, v13
	v_lshrrev_b32_e32 v13, 26, v13
	ds_load_b32 v23, v23
	v_and_b32_e32 v89, 60, v89
	v_and_b32_e32 v91, 60, v91
	v_lshrrev_b32_e32 v95, 10, v14
	v_and_b32_e32 v13, 60, v13
	v_lshrrev_b32_e32 v96, 22, v14
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v97, 16, v17
	v_and_b32_e32 v17, 0xffff0000, v17
	v_lshlrev_b32_e32 v94, 16, v16
	v_and_b32_e32 v24, 60, v24
	v_lshlrev_b32_e32 v93, 16, v15
	v_and_b32_e32 v15, 0xffff0000, v15
	v_and_b32_e32 v16, 0xffff0000, v16
	v_and_b32_e32 v92, 60, v92
	ds_load_b32 v24, v24
	v_and_b32_e32 v88, 60, v88
	ds_load_b32 v88, v88
	s_wait_dscnt 0x2
	v_fma_f32 v23, v23, v93, 0
	v_and_b32_e32 v93, 15, v14
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v23, v24, v15
	v_lshrrev_b32_e32 v15, 2, v14
	v_lshrrev_b32_e32 v24, 6, v14
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v23, v88, v94
	v_and_b32_e32 v90, 60, v90
	ds_load_b32 v89, v89
	ds_load_b32 v90, v90
	ds_load_b32 v91, v91
	ds_load_b32 v92, v92
	ds_load_b32 v13, v13
	v_and_b32_e32 v15, 60, v15
	v_lshrrev_b32_e32 v88, 14, v14
	v_lshrrev_b32_e32 v94, 18, v14
	v_lshrrev_b32_e32 v14, 26, v14
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v23, v89, v16 :: v_dual_and_b32 v14, 60, v14
	v_and_b32_e32 v89, 60, v95
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v23, v90, v97
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v23, v91, v17
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v91, 16, v19
	v_and_b32_e32 v19, 0xffff0000, v19
	v_lshlrev_b32_e32 v90, 16, v18
	v_and_b32_e32 v18, 0xffff0000, v18
	v_and_b32_e32 v17, 60, v88
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v23, v92, v90 :: v_dual_lshlrev_b32 v16, 2, v93
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v23, v13, v18
	ds_load_b32 v16, v16
	v_and_b32_e32 v24, 60, v24
	ds_load_b32 v24, v24
	ds_load_b32 v15, v15
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v23, v16, v91 :: v_dual_lshlrev_b32 v16, 16, v20
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v23, v15, v19 :: v_dual_and_b32 v88, 60, v94
	v_lshlrev_b32_e32 v19, 16, v21
	v_and_b32_e32 v90, 60, v96
	v_and_b32_e32 v15, 0xffff0000, v20
	v_fmac_f32_e32 v23, v24, v16
	ds_load_b32 v13, v89
	ds_load_b32 v17, v17
	ds_load_b32 v18, v88
	ds_load_b32 v88, v90
	ds_load_b32 v14, v14
	v_and_b32_e32 v16, 7, v87
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v23, v13, v15
	v_and_b32_e32 v13, 0x7f, v87
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v15, v16
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v23, v17, v19 :: v_dual_and_b32 v16, 0xffff0000, v21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v17, v13, 20, 0x3c000000
	v_mul_f32_e32 v15, 0x3b000000, v15
	v_cmp_lt_u32_e64 s9, 7, v13
	v_lshlrev_b32_e32 v19, 16, v22
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v23, v18, v16 :: v_dual_lshlrev_b32 v16, 24, v87
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v15, v15, v17, s9
	v_cmp_ne_u32_e64 s9, 0x7f, v13
	v_and_b32_e32 v17, 0xffff0000, v22
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v23, v88, v19
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v13, 0x7fc00000, v15, s9
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v23, v14, v17
	v_and_or_b32 v13, 0x80000000, v16, v13
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v112, v23, v13
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s10, s7
	s_cbranch_execnz .LBB0_254
.LBB0_246:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s10, s8
	s_cbranch_execz .LBB0_223
	s_branch .LBB0_255
.LBB0_247:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s57, vcc_lo
	s_cbranch_execz .LBB0_240
.LBB0_248:                              ;   in Loop: Header=BB0_224 Depth=1
	v_add_co_u32 v97, s9, s22, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v98, null, s23, 0, s9
	global_load_b128 v[93:96], v[97:98], off offset:1024
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v104, 16, v96
	v_and_b32_e32 v116, 0xffff0000, v96
	v_and_b32_e32 v96, 15, v23
	v_lshlrev_b32_e32 v100, 16, v93
	v_and_b32_e32 v93, 0xffff0000, v93
	v_lshlrev_b32_e32 v102, 16, v94
	v_and_b32_e32 v94, 0xffff0000, v94
	v_lshlrev_b32_e32 v96, 2, v96
	ds_load_b32 v96, v96
	s_wait_dscnt 0x0
	v_fma_f32 v100, v96, v100, 0
	v_lshrrev_b32_e32 v96, 2, v23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v96, 60, v96
	ds_load_b32 v96, v96
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v100, v96, v93 :: v_dual_lshlrev_b32 v103, 16, v95
	v_lshrrev_b32_e32 v93, 6, v23
	v_and_b32_e32 v93, 60, v93
	ds_load_b32 v93, v93
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v100, v93, v102 :: v_dual_and_b32 v95, 0xffff0000, v95
	v_lshrrev_b32_e32 v93, 10, v23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v93, 60, v93
	ds_load_b32 v93, v93
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v100, v93, v94
	v_lshrrev_b32_e32 v93, 14, v23
	v_and_b32_e32 v93, 60, v93
	ds_load_b32 v93, v93
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v100, v93, v103
	v_lshrrev_b32_e32 v93, 18, v23
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v93, 60, v93
	ds_load_b32 v93, v93
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v100, v93, v95
	global_load_b128 v[93:96], v[97:98], off offset:1040
	v_lshrrev_b32_e32 v97, 22, v23
	v_lshrrev_b32_e32 v23, 26, v23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v97, 60, v97
	v_and_b32_e32 v23, 60, v23
	ds_load_b32 v97, v97
	ds_load_b32 v23, v23
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v100, v97, v104
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v100, v23, v116
	v_lshrrev_b32_e32 v23, 2, v24
	v_and_b32_e32 v23, 60, v23
	ds_load_b32 v23, v23
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v98, 16, v93
	v_and_b32_e32 v93, 0xffff0000, v93
	v_and_b32_e32 v97, 15, v24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v97, 2, v97
	ds_load_b32 v97, v97
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v100, v97, v98
	v_lshrrev_b32_e32 v97, 6, v24
	v_fmac_f32_e32 v100, v23, v93
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v97, 60, v97
	v_lshrrev_b32_e32 v23, 10, v24
	ds_load_b32 v93, v97
	v_and_b32_e32 v23, 60, v23
	v_lshlrev_b32_e32 v97, 16, v94
	v_and_b32_e32 v94, 0xffff0000, v94
	ds_load_b32 v23, v23
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v100, v93, v97
	v_lshrrev_b32_e32 v93, 14, v24
	v_lshlrev_b32_e32 v97, 16, v95
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v93, 60, v93
	ds_load_b32 v93, v93
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v100, v23, v94
	v_lshrrev_b32_e32 v23, 18, v24
	v_lshrrev_b32_e32 v94, 22, v24
	v_lshrrev_b32_e32 v24, 26, v24
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v23, 60, v23
	v_and_b32_e32 v94, 60, v94
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v24, 60, v24
	ds_load_b32 v23, v23
	ds_load_b32 v94, v94
	ds_load_b32 v24, v24
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v100, v93, v97 :: v_dual_and_b32 v93, 0xffff0000, v95
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v100, v23, v93 :: v_dual_and_b32 v95, 7, v92
	v_and_b32_e32 v23, 0x7f, v92
	v_cvt_f32_ubyte0_e32 v93, v95
	v_lshlrev_b32_e32 v92, 24, v92
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v95, v23, 20, 0x3c000000
	v_cmp_lt_u32_e64 s9, 7, v23
	v_mul_f32_e32 v93, 0x3b000000, v93
	v_cmp_ne_u32_e64 s10, 0x7f, v23
	v_lshlrev_b32_e32 v23, 16, v96
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v93, v93, v95, s9
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v100, v94, v23 :: v_dual_and_b32 v95, 0xffff0000, v96
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v23, 0x7fc00000, v93, s10
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v100, v24, v95
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v23, 0x80000000, v92, v23
	v_fmac_f32_e32 v109, v100, v23
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s57, s1
	s_cbranch_execnz .LBB0_241
.LBB0_249:                              ;   in Loop: Header=BB0_224 Depth=1
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s57, s3
	s_cbranch_execz .LBB0_242
.LBB0_250:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_loadcnt 0x0
	s_wait_alu 0xfffe
	v_add_co_u32 v91, s9, s72, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v92, null, s73, 0, s9
	global_load_b128 v[21:24], v[91:92], off offset:1024
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v96, 16, v24
	v_and_b32_e32 v97, 0xffff0000, v24
	v_and_b32_e32 v24, 15, v19
	v_lshlrev_b32_e32 v95, 16, v23
	v_and_b32_e32 v23, 0xffff0000, v23
	v_lshlrev_b32_e32 v93, 16, v21
	v_and_b32_e32 v21, 0xffff0000, v21
	v_lshlrev_b32_e32 v24, 2, v24
	ds_load_b32 v24, v24
	s_wait_dscnt 0x0
	v_fma_f32 v93, v24, v93, 0
	v_lshrrev_b32_e32 v24, 2, v19
	s_delay_alu instid0(VALU_DEP_1)
	v_and_b32_e32 v24, 60, v24
	ds_load_b32 v24, v24
	v_lshlrev_b32_e32 v94, 16, v22
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v93, v24, v21 :: v_dual_and_b32 v22, 0xffff0000, v22
	v_lshrrev_b32_e32 v21, 6, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v21, v94
	v_lshrrev_b32_e32 v21, 10, v19
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v21, v22
	v_lshrrev_b32_e32 v21, 14, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v21, v95
	v_lshrrev_b32_e32 v21, 18, v19
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v21, v23
	global_load_b128 v[21:24], v[91:92], off offset:1040
	v_lshrrev_b32_e32 v91, 22, v19
	v_lshrrev_b32_e32 v19, 26, v19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v91, 60, v91
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v91, v91
	ds_load_b32 v19, v19
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v93, v91, v96
	v_and_b32_e32 v91, 15, v20
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v91, 2, v91
	ds_load_b32 v91, v91
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v92, 16, v21
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v93, v19, v97
	v_lshrrev_b32_e32 v19, 2, v20
	v_and_b32_e32 v21, 0xffff0000, v21
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v19, v19
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v93, v91, v92
	v_lshrrev_b32_e32 v91, 6, v20
	v_and_b32_e32 v91, 60, v91
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v93, v19, v21
	v_lshrrev_b32_e32 v19, 10, v20
	ds_load_b32 v21, v91
	v_lshlrev_b32_e32 v91, 16, v22
	v_and_b32_e32 v22, 0xffff0000, v22
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v19, v19
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v93, v21, v91
	v_lshrrev_b32_e32 v21, 14, v20
	v_lshlrev_b32_e32 v91, 16, v23
	s_delay_alu instid0(VALU_DEP_2)
	v_and_b32_e32 v21, 60, v21
	ds_load_b32 v21, v21
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v93, v19, v22
	v_lshrrev_b32_e32 v19, 18, v20
	v_lshrrev_b32_e32 v22, 22, v20
	v_lshrrev_b32_e32 v20, 26, v20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v19, 60, v19
	v_and_b32_e32 v22, 60, v22
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v20, 60, v20
	ds_load_b32 v19, v19
	ds_load_b32 v22, v22
	ds_load_b32 v20, v20
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v93, v21, v91
	v_and_b32_e32 v21, 0xffff0000, v23
	v_and_b32_e32 v23, 7, v90
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v93, v19, v21
	v_and_b32_e32 v19, 0x7f, v90
	v_cvt_f32_ubyte0_e32 v21, v23
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v23, v19, 20, 0x3c000000
	v_cmp_lt_u32_e64 s9, 7, v19
	v_mul_f32_e32 v21, 0x3b000000, v21
	v_cmp_ne_u32_e64 s10, 0x7f, v19
	v_lshlrev_b32_e32 v19, 16, v24
	v_and_b32_e32 v24, 0xffff0000, v24
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v21, v21, v23, s9
	v_lshlrev_b32_e32 v23, 24, v90
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v93, v22, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v19, 0x7fc00000, v21, s10
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v20, v24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v19, 0x80000000, v23, v19
	v_fmac_f32_e32 v111, v93, v19
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s57, s4
	s_cbranch_execnz .LBB0_243
.LBB0_251:                              ;   in Loop: Header=BB0_224 Depth=1
	s_or_b32 exec_lo, exec_lo, s57
	s_and_saveexec_b32 s10, s5
	s_cbranch_execz .LBB0_244
.LBB0_252:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_loadcnt 0x1
	v_add_co_u32 v21, s9, s76, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v22, null, s77, 0, s9
	s_wait_loadcnt 0x0
	v_and_b32_e32 v89, 15, v15
	v_lshrrev_b32_e32 v90, 2, v15
	v_lshrrev_b32_e32 v91, 6, v15
	s_clause 0x1
	global_load_b128 v[17:20], v[21:22], off offset:1024
	global_load_b128 v[21:24], v[21:22], off offset:1040
	v_lshrrev_b32_e32 v92, 10, v15
	v_lshlrev_b32_e32 v89, 2, v89
	v_lshrrev_b32_e32 v93, 14, v15
	v_and_b32_e32 v91, 60, v91
	v_lshrrev_b32_e32 v94, 18, v15
	v_lshrrev_b32_e32 v95, 22, v15
	ds_load_b32 v89, v89
	v_lshrrev_b32_e32 v15, 26, v15
	v_and_b32_e32 v93, 60, v93
	v_and_b32_e32 v94, 60, v94
	v_and_b32_e32 v95, 60, v95
	v_lshrrev_b32_e32 v98, 10, v16
	v_and_b32_e32 v15, 60, v15
	v_lshrrev_b32_e32 v100, 22, v16
	ds_load_b32 v91, v91
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v97, 16, v18
	v_and_b32_e32 v90, 60, v90
	v_lshlrev_b32_e32 v102, 16, v19
	v_and_b32_e32 v19, 0xffff0000, v19
	v_and_b32_e32 v18, 0xffff0000, v18
	v_lshlrev_b32_e32 v96, 16, v17
	ds_load_b32 v90, v90
	v_and_b32_e32 v17, 0xffff0000, v17
	s_wait_dscnt 0x2
	v_fma_f32 v89, v89, v96, 0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v89, v90, v17 :: v_dual_and_b32 v92, 60, v92
	ds_load_b32 v92, v92
	ds_load_b32 v93, v93
	ds_load_b32 v94, v94
	ds_load_b32 v95, v95
	ds_load_b32 v15, v15
	v_lshrrev_b32_e32 v17, 2, v16
	v_lshrrev_b32_e32 v90, 6, v16
	v_fmac_f32_e32 v89, v91, v97
	v_lshrrev_b32_e32 v91, 14, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v90, 60, v90
	v_lshrrev_b32_e32 v97, 18, v16
	ds_load_b32 v90, v90
	ds_load_b32 v17, v17
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v89, v92, v18 :: v_dual_and_b32 v96, 15, v16
	v_lshrrev_b32_e32 v16, 26, v16
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v89, v93, v102
	v_lshlrev_b32_e32 v93, 16, v20
	s_wait_loadcnt_dscnt 0x4
	v_dual_fmac_f32 v89, v94, v19 :: v_dual_lshlrev_b32 v94, 16, v21
	v_and_b32_e32 v21, 0xffff0000, v21
	v_lshlrev_b32_e32 v18, 2, v96
	v_and_b32_e32 v19, 60, v91
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v89, v95, v93
	v_and_b32_e32 v91, 60, v97
	v_and_b32_e32 v93, 60, v100
	ds_load_b32 v18, v18
	v_and_b32_e32 v20, 0xffff0000, v20
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v89, v15, v20
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v89, v18, v94
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v89, v17, v21 :: v_dual_lshlrev_b32 v18, 16, v22
	v_lshlrev_b32_e32 v21, 16, v23
	v_and_b32_e32 v92, 60, v98
	v_and_b32_e32 v16, 60, v16
	v_and_b32_e32 v17, 0xffff0000, v22
	v_fmac_f32_e32 v89, v90, v18
	ds_load_b32 v15, v92
	ds_load_b32 v19, v19
	ds_load_b32 v20, v91
	ds_load_b32 v91, v93
	ds_load_b32 v16, v16
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v89, v15, v17
	v_and_b32_e32 v15, 0x7f, v88
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v89, v19, v21
	v_lshlrev_b32_e32 v21, 16, v24
	v_and_b32_e32 v18, 7, v88
	v_lshl_add_u32 v19, v15, 20, 0x3c000000
	v_cmp_lt_u32_e64 s9, 7, v15
	v_cvt_f32_ubyte0_e32 v17, v18
	v_and_b32_e32 v18, 0xffff0000, v23
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v17, 0x3b000000, v17
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v89, v20, v18
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e64 v17, v17, v19, s9
	v_cmp_ne_u32_e64 s9, 0x7f, v15
	v_and_b32_e32 v19, 0xffff0000, v24
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v89, v91, v21 :: v_dual_lshlrev_b32 v18, 24, v88
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v15, 0x7fc00000, v17, s9
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v89, v16, v19
	v_and_or_b32 v15, 0x80000000, v18, v15
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v113, v89, v15
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s10, s6
	s_cbranch_execnz .LBB0_245
.LBB0_253:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s10, s7
	s_cbranch_execz .LBB0_246
.LBB0_254:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_loadcnt 0x1
	v_add_co_u32 v17, s9, s80, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v18, null, s81, 0, s9
	v_and_b32_e32 v21, 15, v11
	v_lshrrev_b32_e32 v22, 2, v11
	v_lshrrev_b32_e32 v23, 6, v11
	s_clause 0x1
	global_load_b128 v[13:16], v[17:18], off offset:1024
	global_load_b128 v[17:20], v[17:18], off offset:1040
	v_lshrrev_b32_e32 v24, 10, v11
	v_lshlrev_b32_e32 v21, 2, v21
	s_wait_loadcnt 0x2
	v_lshrrev_b32_e32 v87, 14, v11
	v_and_b32_e32 v23, 60, v23
	v_lshrrev_b32_e32 v88, 18, v11
	v_lshrrev_b32_e32 v89, 22, v11
	ds_load_b32 v21, v21
	v_lshrrev_b32_e32 v11, 26, v11
	v_and_b32_e32 v87, 60, v87
	v_lshrrev_b32_e32 v92, 10, v12
	v_and_b32_e32 v89, 60, v89
	v_lshrrev_b32_e32 v93, 22, v12
	v_and_b32_e32 v11, 60, v11
	ds_load_b32 v23, v23
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v91, 16, v14
	v_and_b32_e32 v22, 60, v22
	v_lshlrev_b32_e32 v94, 16, v15
	v_lshlrev_b32_e32 v90, 16, v13
	v_and_b32_e32 v13, 0xffff0000, v13
	v_and_b32_e32 v14, 0xffff0000, v14
	ds_load_b32 v22, v22
	v_and_b32_e32 v15, 0xffff0000, v15
	s_wait_dscnt 0x2
	v_fma_f32 v21, v21, v90, 0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v21, v22, v13 :: v_dual_and_b32 v24, 60, v24
	v_lshrrev_b32_e32 v13, 2, v12
	v_lshrrev_b32_e32 v22, 6, v12
	v_dual_fmac_f32 v21, v23, v91 :: v_dual_and_b32 v88, 60, v88
	ds_load_b32 v24, v24
	ds_load_b32 v87, v87
	ds_load_b32 v88, v88
	ds_load_b32 v89, v89
	ds_load_b32 v11, v11
	v_and_b32_e32 v13, 60, v13
	v_lshrrev_b32_e32 v23, 14, v12
	v_lshrrev_b32_e32 v91, 18, v12
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v21, v24, v14
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v21, v87, v94 :: v_dual_and_b32 v90, 15, v12
	v_lshlrev_b32_e32 v87, 16, v16
	v_and_b32_e32 v16, 0xffff0000, v16
	v_lshrrev_b32_e32 v12, 26, v12
	s_wait_loadcnt_dscnt 0x2
	v_dual_fmac_f32 v21, v88, v15 :: v_dual_lshlrev_b32 v88, 16, v17
	v_and_b32_e32 v17, 0xffff0000, v17
	v_lshlrev_b32_e32 v14, 2, v90
	v_and_b32_e32 v15, 60, v23
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v21, v89, v87
	v_and_b32_e32 v23, 60, v91
	v_and_b32_e32 v87, 60, v93
	ds_load_b32 v14, v14
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v21, v11, v16 :: v_dual_and_b32 v22, 60, v22
	ds_load_b32 v22, v22
	ds_load_b32 v13, v13
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v21, v14, v88 :: v_dual_lshlrev_b32 v14, 16, v18
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v21, v13, v17 :: v_dual_and_b32 v24, 60, v92
	v_lshlrev_b32_e32 v17, 16, v19
	v_and_b32_e32 v12, 60, v12
	v_and_b32_e32 v13, 0xffff0000, v18
	v_fmac_f32_e32 v21, v22, v14
	ds_load_b32 v11, v24
	ds_load_b32 v15, v15
	ds_load_b32 v16, v23
	ds_load_b32 v23, v87
	ds_load_b32 v12, v12
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v21, v11, v13
	v_and_b32_e32 v11, 0x7f, v86
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v21, v15, v17
	v_lshlrev_b32_e32 v17, 16, v20
	v_and_b32_e32 v14, 7, v86
	v_lshl_add_u32 v15, v11, 20, 0x3c000000
	v_cmp_lt_u32_e64 s9, 7, v11
	v_cvt_f32_ubyte0_e32 v13, v14
	v_and_b32_e32 v14, 0xffff0000, v19
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v13, 0x3b000000, v13
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v21, v16, v14
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e64 v13, v13, v15, s9
	v_cmp_ne_u32_e64 s9, 0x7f, v11
	v_and_b32_e32 v15, 0xffff0000, v20
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v21, v23, v17 :: v_dual_lshlrev_b32 v14, 24, v86
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v11, 0x7fc00000, v13, s9
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v21, v12, v15
	v_and_or_b32 v11, 0x80000000, v14, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v115, v21, v11
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s10, s8
	s_cbranch_execz .LBB0_223
.LBB0_255:                              ;   in Loop: Header=BB0_224 Depth=1
	s_wait_loadcnt 0x1
	v_add_co_u32 v15, s9, s82, v84
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v16, null, s83, 0, s9
	v_and_b32_e32 v19, 15, v9
	v_lshrrev_b32_e32 v20, 2, v9
	v_lshrrev_b32_e32 v21, 6, v9
	s_clause 0x1
	global_load_b128 v[11:14], v[15:16], off offset:1024
	global_load_b128 v[15:18], v[15:16], off offset:1040
	v_lshrrev_b32_e32 v22, 10, v9
	v_lshlrev_b32_e32 v19, 2, v19
	v_lshrrev_b32_e32 v23, 14, v9
	v_and_b32_e32 v21, 60, v21
	v_lshrrev_b32_e32 v24, 18, v9
	s_wait_loadcnt 0x2
	v_lshrrev_b32_e32 v86, 22, v9
	ds_load_b32 v19, v19
	v_lshrrev_b32_e32 v9, 26, v9
	v_and_b32_e32 v23, 60, v23
	v_and_b32_e32 v24, 60, v24
	v_lshrrev_b32_e32 v89, 10, v10
	v_lshrrev_b32_e32 v90, 22, v10
	v_and_b32_e32 v9, 60, v9
	ds_load_b32 v21, v21
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v91, 16, v13
	v_and_b32_e32 v20, 60, v20
	v_lshlrev_b32_e32 v87, 16, v11
	v_and_b32_e32 v11, 0xffff0000, v11
	v_and_b32_e32 v13, 0xffff0000, v13
	v_lshlrev_b32_e32 v88, 16, v12
	ds_load_b32 v20, v20
	s_wait_dscnt 0x2
	v_fma_f32 v19, v19, v87, 0
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v87, 15, v10
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v19, v20, v11 :: v_dual_and_b32 v86, 60, v86
	v_lshrrev_b32_e32 v11, 2, v10
	v_lshrrev_b32_e32 v20, 6, v10
	v_fmac_f32_e32 v19, v21, v88
	ds_load_b32 v22, v22
	ds_load_b32 v23, v23
	ds_load_b32 v24, v24
	ds_load_b32 v86, v86
	ds_load_b32 v9, v9
	v_and_b32_e32 v12, 0xffff0000, v12
	v_and_b32_e32 v11, 60, v11
	v_lshrrev_b32_e32 v21, 14, v10
	v_lshrrev_b32_e32 v88, 18, v10
	v_lshrrev_b32_e32 v10, 26, v10
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v19, v22, v12 :: v_dual_lshlrev_b32 v12, 2, v87
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v19, v23, v91
	ds_load_b32 v12, v12
	v_lshlrev_b32_e32 v23, 16, v14
	s_wait_loadcnt_dscnt 0x3
	v_dual_fmac_f32 v19, v24, v13 :: v_dual_lshlrev_b32 v24, 16, v15
	v_and_b32_e32 v15, 0xffff0000, v15
	v_and_b32_e32 v20, 60, v20
	v_and_b32_e32 v13, 60, v21
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v19, v86, v23
	v_and_b32_e32 v21, 60, v88
	v_and_b32_e32 v23, 60, v90
	ds_load_b32 v20, v20
	ds_load_b32 v11, v11
	v_and_b32_e32 v14, 0xffff0000, v14
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v19, v9, v14 :: v_dual_and_b32 v22, 60, v89
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v19, v12, v24
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v19, v11, v15
	v_lshlrev_b32_e32 v15, 16, v17
	v_lshlrev_b32_e32 v12, 16, v16
	v_and_b32_e32 v11, 0xffff0000, v16
	v_dual_fmac_f32 v19, v20, v12 :: v_dual_and_b32 v10, 60, v10
	ds_load_b32 v9, v22
	ds_load_b32 v13, v13
	ds_load_b32 v14, v21
	ds_load_b32 v21, v23
	ds_load_b32 v10, v10
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v19, v9, v11 :: v_dual_and_b32 v12, 7, v85
	v_and_b32_e32 v9, 0x7f, v85
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v11, v12
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v19, v13, v15
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v13, v9, 20, 0x3c000000
	v_mul_f32_e32 v11, 0x3b000000, v11
	v_lshlrev_b32_e32 v15, 16, v18
	v_and_b32_e32 v12, 0xffff0000, v17
	v_cmp_lt_u32_e64 s9, 7, v9
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v19, v14, v12
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v11, v11, v13, s9
	v_cmp_ne_u32_e64 s9, 0x7f, v9
	v_lshlrev_b32_e32 v12, 24, v85
	v_and_b32_e32 v13, 0xffff0000, v18
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v19, v21, v15
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v9, 0x7fc00000, v11, s9
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v19, v10, v13
	v_and_or_b32 v9, 0x80000000, v12, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v114, v19, v9
	s_branch .LBB0_223
.LBB0_256:
	s_or_b32 exec_lo, exec_lo, s11
.LBB0_257:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s94
	s_wait_loadcnt 0x7
	scratch_load_b32 v14, off, off offset:12 ; 4-byte Folded Reload
	s_wait_loadcnt 0x2
	v_mov_b32_e32 v9, 0
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[64:65]
	s_cbranch_execz .LBB0_267
; %bb.258:
	v_mbcnt_lo_u32_b32 v9, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v10, 16, v9
	v_xor_b32_e32 v11, 8, v9
	v_xor_b32_e32 v12, 4, v9
	v_cmp_gt_i32_e32 vcc_lo, 32, v10
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v9, v10, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v9, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v9, v12, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	v_lshlrev_b32_e32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v109
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v109, v10
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v9, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, v9, v12, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v10, v10, v11 :: v_dual_lshlrev_b32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v10
	s_wait_dscnt 0x0
	v_add_f32_e32 v9, v10, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v10, v108, v9
	v_and_b32_e32 v9, 0x7fffffff, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v9
                                        ; implicit-def: $vgpr9
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.259:
	v_bfe_u32 v9, v10, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v9, v10, v9, 0x7fff
                                        ; implicit-def: $vgpr10
	v_lshrrev_b32_e32 v9, 16, v9
; %bb.260:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.261:
	v_lshrrev_b32_e32 v9, 16, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v9, 64, v9
; %bb.262:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v9, 16, v9
	v_mul_f32_e32 v10, s89, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v9, 0x7fffffff, v10
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v9
                                        ; implicit-def: $vgpr9
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.263:
	v_bfe_u32 v9, v10, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v9, v10, v9, 0x7fff
                                        ; implicit-def: $vgpr10
	v_lshrrev_b32_e32 v9, 16, v9
; %bb.264:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.265:
	v_lshrrev_b32_e32 v9, 16, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v9, 64, v9
; %bb.266:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v9, 16, v9
	v_add_f32_e32 v9, 0, v9
.LBB0_267:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[62:63]
	s_cbranch_execz .LBB0_277
; %bb.268:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_xor_b32_e32 v13, 4, v10
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v42, v11
	ds_bpermute_b32 v12, v12, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v11, v11, v12 :: v_dual_lshlrev_b32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v11, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v11, v106, v10
	v_and_b32_e32 v10, 0x7fffffff, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.269:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.270:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.271:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.272:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_mul_f32_e32 v11, s88, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.273:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.274:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.275:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.276:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_add_f32_e32 v9, v9, v10
.LBB0_277:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[60:61]
	s_cbranch_execz .LBB0_287
; %bb.278:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_xor_b32_e32 v13, 4, v10
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	ds_bpermute_b32 v11, v11, v111
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v111, v11
	ds_bpermute_b32 v12, v12, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v11, v11, v12 :: v_dual_lshlrev_b32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v11, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v11, v107, v10
	v_and_b32_e32 v10, 0x7fffffff, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.279:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.280:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.281:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.282:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_mul_f32_e32 v11, s87, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.283:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.284:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.285:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.286:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_add_f32_e32 v9, v9, v10
.LBB0_287:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[58:59]
	s_cbranch_execz .LBB0_297
; %bb.288:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_xor_b32_e32 v13, 4, v10
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v110
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v110, v11
	ds_bpermute_b32 v12, v12, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v11, v11, v12 :: v_dual_lshlrev_b32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v11, v10
	scratch_load_b32 v11, off, off offset:8 th:TH_LOAD_LU ; 4-byte Folded Reload
	s_wait_loadcnt 0x0
	v_mul_f32_e32 v11, v11, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.289:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.290:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.291:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.292:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_mul_f32_e32 v11, s86, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.293:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.294:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.295:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.296:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_add_f32_e32 v9, v9, v10
.LBB0_297:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[56:57]
	s_cbranch_execz .LBB0_307
; %bb.298:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_xor_b32_e32 v13, 4, v10
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	ds_bpermute_b32 v11, v11, v113
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v113, v11
	ds_bpermute_b32 v12, v12, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v11, v11, v12 :: v_dual_lshlrev_b32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v11, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v11, v105, v10
	v_and_b32_e32 v10, 0x7fffffff, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.299:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.300:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.301:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.302:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_mul_f32_e32 v11, s85, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.303:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.304:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.305:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.306:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_add_f32_e32 v9, v9, v10
.LBB0_307:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[54:55]
	s_cbranch_execz .LBB0_317
; %bb.308:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_xor_b32_e32 v13, 4, v10
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	ds_bpermute_b32 v11, v11, v112
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v112, v11
	ds_bpermute_b32 v12, v12, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v11, v11, v12 :: v_dual_lshlrev_b32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v11, v10
	scratch_load_b32 v11, off, off th:TH_LOAD_LU ; 4-byte Folded Reload
	s_wait_loadcnt 0x0
	v_mul_f32_e32 v11, v11, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.309:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.310:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.311:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.312:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_mul_f32_e32 v11, s84, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.313:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.314:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.315:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.316:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_add_f32_e32 v9, v9, v10
.LBB0_317:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[52:53]
	s_cbranch_execz .LBB0_327
; %bb.318:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_xor_b32_e32 v13, 4, v10
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	ds_bpermute_b32 v11, v11, v115
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v115, v11
	ds_bpermute_b32 v12, v12, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v11, v11, v12 :: v_dual_lshlrev_b32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v11, v10
	scratch_load_b32 v11, off, off offset:4 th:TH_LOAD_LU ; 4-byte Folded Reload
	s_wait_loadcnt 0x0
	v_mul_f32_e32 v11, v11, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.319:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.320:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.321:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.322:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_mul_f32_e32 v11, s59, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.323:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.324:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.325:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.326:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_add_f32_e32 v9, v9, v10
.LBB0_327:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_ne_u64_e32 0, v[48:49]
	s_cbranch_execz .LBB0_337
; %bb.328:
	v_mbcnt_lo_u32_b32 v10, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v11, 16, v10
	v_xor_b32_e32 v12, 8, v10
	v_xor_b32_e32 v13, 4, v10
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v10, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v10, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v13, 2, v13
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v114
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v114, v11
	ds_bpermute_b32 v12, v12, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 2, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v10, v13, vcc_lo
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v12
	ds_bpermute_b32 v12, v13, v11
	v_xor_b32_e32 v13, 1, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v11, v11, v12 :: v_dual_lshlrev_b32 v10, 2, v10
	ds_bpermute_b32 v10, v10, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v11, v10
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v11, v14, v10
	v_and_b32_e32 v10, 0x7fffffff, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.329:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.330:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.331:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.332:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_mul_f32_e32 v11, s33, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v11
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.333:
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.334:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.335:
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.336:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v10, 16, v10
	v_add_f32_e32 v9, v9, v10
.LBB0_337:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v10, 0x7fffffff, v9
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s1, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s1, exec_lo, s1
	s_cbranch_execz .LBB0_341
; %bb.338:
	v_bfe_u32 v10, v9, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v9, v9, v10, 0x7fff
	v_lshrrev_b32_e32 v10, 16, v9
                                        ; implicit-def: $vgpr9
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
	s_cbranch_execnz .LBB0_342
.LBB0_339:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_mov_b32_e32 v9, 0
	s_and_saveexec_b32 s1, s0
	s_cbranch_execz .LBB0_343
.LBB0_340:
	v_and_b32_e32 v9, 15, v50
	v_lshrrev_b32_e32 v11, 2, v50
	v_lshrrev_b32_e32 v12, 6, v50
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v15, 16, v5
	v_and_b32_e32 v5, 0xffff0000, v5
	v_lshlrev_b32_e32 v9, 2, v9
	v_and_b32_e32 v11, 60, v11
	s_wait_loadcnt 0x0
	v_lshrrev_b32_e32 v14, 14, v50
	v_lshrrev_b32_e32 v17, 22, v50
	v_lshrrev_b32_e32 v13, 10, v50
	ds_load_b32 v9, v9
	ds_load_b32 v11, v11
	v_and_b32_e32 v12, 60, v12
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v13, 60, v13
	v_lshrrev_b32_e32 v16, 18, v50
	v_lshrrev_b32_e32 v18, 26, v50
	ds_load_b32 v12, v12
	ds_load_b32 v17, v17
	v_and_b32_e32 v14, 60, v14
	ds_load_b32 v13, v13
	ds_load_b32 v14, v14
	s_wait_dscnt 0x5
	v_fma_f32 v9, v9, v15, 0
	v_lshlrev_b32_e32 v15, 16, v6
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v9, v11, v5
	v_and_b32_e32 v5, 0xffff0000, v6
	v_and_b32_e32 v11, 60, v18
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v9, v12, v15 :: v_dual_and_b32 v16, 60, v16
	v_lshrrev_b32_e32 v15, 2, v51
	ds_load_b32 v16, v16
	ds_load_b32 v11, v11
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v9, v13, v5
	v_and_b32_e32 v5, 0xffff0000, v7
	v_lshlrev_b32_e32 v12, 16, v7
	v_and_b32_e32 v6, 15, v51
	v_lshrrev_b32_e32 v7, 6, v51
	v_and_b32_e32 v13, 60, v15
	v_lshrrev_b32_e32 v15, 18, v51
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v9, v14, v12
	v_lshrrev_b32_e32 v14, 10, v51
	v_and_b32_e32 v7, 60, v7
	ds_load_b32 v13, v13
	ds_load_b32 v7, v7
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v9, v16, v5
	v_and_b32_e32 v5, 0xffff0000, v8
	v_lshlrev_b32_e32 v12, 16, v8
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshrrev_b32_e32 v8, 14, v51
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v9, v17, v12
	ds_load_b32 v6, v6
	v_and_b32_e32 v8, 60, v8
	ds_load_b32 v8, v8
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v9, v11, v5
	v_lshrrev_b32_e32 v5, 22, v51
	v_lshlrev_b32_e32 v12, 16, v1
	v_and_b32_e32 v1, 0xffff0000, v1
	v_and_b32_e32 v11, 60, v15
	s_delay_alu instid0(VALU_DEP_4)
	v_and_b32_e32 v5, 60, v5
	ds_load_b32 v11, v11
	ds_load_b32 v5, v5
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v9, v6, v12 :: v_dual_and_b32 v14, 60, v14
	v_lshrrev_b32_e32 v12, 26, v51
	ds_load_b32 v14, v14
	v_and_b32_e32 v12, 60, v12
	ds_load_b32 v12, v12
	v_fmac_f32_e32 v9, v13, v1
	v_and_b32_e32 v1, 7, v101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v1, v1
	v_dual_mul_f32 v1, 0x3b000000, v1 :: v_dual_lshlrev_b32 v6, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v9, v7, v6
	v_lshlrev_b32_e32 v7, 16, v3
	v_and_b32_e32 v2, 0xffff0000, v2
	v_and_b32_e32 v6, 0x7f, v101
	v_and_b32_e32 v3, 0xffff0000, v3
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v9, v14, v2
	v_lshl_add_u32 v2, v6, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v9, v8, v7
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v1, v1, v2 :: v_dual_lshlrev_b32 v2, 16, v4
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v6
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v9, v11, v3
	v_lshlrev_b32_e32 v3, 24, v101
	v_and_b32_e32 v4, 0xffff0000, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, 0x7fc00000, v1, vcc_lo
	v_fmac_f32_e32 v9, v5, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v1, 0x80000000, v3, v1
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v9, v12, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	v_fma_f32 v9, v9, v1, 0
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_mov_b32 s1, exec_lo
	v_cmpx_gt_i32_e64 s91, v99
	s_cbranch_execz .LBB0_347
	s_branch .LBB0_344
.LBB0_341:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
	s_cbranch_execz .LBB0_339
.LBB0_342:
	v_lshrrev_b32_e32 v9, 16, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v9
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_mov_b32_e32 v9, 0
	s_and_saveexec_b32 s1, s0
	s_cbranch_execnz .LBB0_340
.LBB0_343:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s1, exec_lo
	v_cmpx_gt_i32_e64 s91, v99
	s_cbranch_execz .LBB0_347
.LBB0_344:
	v_and_b32_e32 v1, 31, v0
	s_mov_b32 s3, 0
	s_wait_loadcnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_mov_b32 v5, 0 :: v_dual_lshlrev_b32 v2, 3, v1
	v_or_b32_e32 v6, 32, v1
	v_lshlrev_b32_e32 v1, 5, v1
	v_add_co_u32 v2, vcc_lo, v46, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v47, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add_co_u32 v4, s0, s16, v1
	v_add_co_u32 v2, vcc_lo, s48, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_ci_u32_e64 v3, null, s49, v3, vcc_lo
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v7, null, s17, 0, s0
	v_add_co_u32 v1, vcc_lo, 0x100, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo
	v_add_co_u32 v3, vcc_lo, 0x41c, v4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v7, vcc_lo
.LBB0_345:                              ; =>This Inner Loop Header: Depth=1
	global_load_b64 v[7:8], v[1:2], off th:TH_LOAD_NT
	s_wait_loadcnt 0x1
	s_clause 0x1
	global_load_b128 v[11:14], v[3:4], off offset:-28
	global_load_b128 v[15:18], v[3:4], off offset:-12
	v_add_co_u32 v19, vcc_lo, v44, v6
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v20, null, v45, v5, vcc_lo
	v_add_co_u32 v6, vcc_lo, v6, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo
	global_load_i8 v19, v[19:20], off
	v_add_co_u32 v1, vcc_lo, 0x100, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	v_add_co_u32 v3, vcc_lo, 0x400, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo
	s_wait_loadcnt 0x3
	v_and_b32_e32 v20, 15, v7
	v_lshrrev_b32_e32 v21, 2, v7
	v_lshrrev_b32_e32 v22, 6, v7
	v_lshrrev_b32_e32 v23, 10, v7
	v_lshrrev_b32_e32 v24, 14, v7
	v_lshlrev_b32_e32 v20, 2, v20
	v_and_b32_e32 v21, 60, v21
	v_and_b32_e32 v22, 60, v22
	v_lshrrev_b32_e32 v25, 18, v7
	v_lshrrev_b32_e32 v26, 22, v7
	ds_load_b32 v20, v20
	ds_load_b32 v21, v21
	ds_load_b32 v22, v22
	v_lshrrev_b32_e32 v7, 26, v7
	v_and_b32_e32 v23, 60, v23
	s_wait_loadcnt 0x2
	v_lshlrev_b32_e32 v34, 16, v11
	v_and_b32_e32 v24, 60, v24
	v_lshlrev_b32_e32 v35, 16, v13
	v_and_b32_e32 v25, 60, v25
	v_and_b32_e32 v26, 60, v26
	v_and_b32_e32 v7, 60, v7
	ds_load_b32 v23, v23
	ds_load_b32 v24, v24
	ds_load_b32 v25, v25
	ds_load_b32 v26, v26
	ds_load_b32 v7, v7
	v_lshrrev_b32_e32 v28, 2, v8
	v_lshrrev_b32_e32 v29, 6, v8
	v_lshrrev_b32_e32 v30, 10, v8
	v_lshrrev_b32_e32 v31, 14, v8
	v_lshrrev_b32_e32 v32, 18, v8
	v_lshrrev_b32_e32 v33, 22, v8
	s_wait_dscnt 0x7
	v_fma_f32 v20, v20, v34, 0
	v_lshlrev_b32_e32 v34, 16, v12
	v_and_b32_e32 v12, 0xffff0000, v12
	v_and_b32_e32 v11, 0xffff0000, v11
	v_and_b32_e32 v27, 15, v8
	v_lshrrev_b32_e32 v8, 26, v8
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v20, v21, v11 :: v_dual_and_b32 v11, 0xffff0000, v13
	v_and_b32_e32 v8, 60, v8
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v20, v22, v34
	v_lshlrev_b32_e32 v22, 2, v27
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v20, v23, v12 :: v_dual_and_b32 v27, 60, v31
	v_and_b32_e32 v12, 60, v28
	v_and_b32_e32 v23, 60, v29
	ds_load_b32 v22, v22
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v20, v24, v35
	v_and_b32_e32 v24, 60, v30
	ds_load_b32 v23, v23
	ds_load_b32 v12, v12
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v21, 16, v15
	v_and_b32_e32 v15, 0xffff0000, v15
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v20, v25, v11 :: v_dual_lshlrev_b32 v13, 16, v14
	v_and_b32_e32 v14, 0xffff0000, v14
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_fmac_f32 v20, v26, v13 :: v_dual_and_b32 v11, 60, v32
	ds_load_b32 v13, v24
	ds_load_b32 v24, v27
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v20, v7, v14
	v_lshlrev_b32_e32 v14, 16, v16
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v20, v22, v21
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v20, v12, v15
	v_and_b32_e32 v12, 0xffff0000, v16
	s_wait_loadcnt 0x0
	v_and_b32_e32 v15, 7, v19
	v_and_b32_e32 v16, 0x7f, v19
	v_fmac_f32_e32 v20, v23, v14
	v_lshlrev_b32_e32 v14, 16, v17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v15, v15
	v_cmp_lt_u32_e64 s0, 7, v16
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v20, v13, v12
	v_and_b32_e32 v12, 0xffff0000, v17
	v_lshl_add_u32 v13, v16, 20, 0x3c000000
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_mul_f32 v15, 0x3b000000, v15 :: v_dual_fmac_f32 v20, v24, v14
	v_lshlrev_b32_e32 v14, 16, v18
	v_and_b32_e32 v25, 60, v33
	ds_load_b32 v7, v11
	ds_load_b32 v11, v25
	ds_load_b32 v8, v8
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v13, v15, v13, s0
	v_cmp_ne_u32_e64 s0, 0x7f, v16
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v20, v7, v12 :: v_dual_and_b32 v7, 0xffff0000, v18
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e64 v12, 0x7fc00000, v13, s0
	v_cmp_le_i32_e64 s0, s91, v6
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v20, v11, v14
	v_and_or_b32 v11, 0x80000000, v19, v12
	s_wait_alu 0xfffe
	s_or_b32 s3, s0, s3
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v20, v8, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v9, v20, v11
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s3
	s_cbranch_execnz .LBB0_345
; %bb.346:
	s_or_b32 exec_lo, exec_lo, s3
.LBB0_347:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_mbcnt_lo_u32_b32 v1, -1, 0
	s_wait_loadcnt 0x0
	v_lshrrev_b32_e32 v14, 5, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v2, 16, v1
	v_xor_b32_e32 v3, 8, v1
	v_xor_b32_e32 v4, 4, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v3, 2, v3
	v_lshlrev_b32_e32 v2, 2, v2
	ds_bpermute_b32 v2, v2, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v9, v2
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	v_xor_b32_e32 v4, 2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	v_lshlrev_b32_e32 v4, 2, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	v_xor_b32_e32 v4, 1, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	v_cmp_eq_u32_e32 vcc_lo, 0, v41
	s_wait_dscnt 0x0
	v_dual_add_f32 v1, v2, v3 :: v_dual_lshlrev_b32 v2, 2, v4
	ds_bpermute_b32 v2, v2, v1
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB0_365
; %bb.348:
	v_mov_b32_e32 v3, 0
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	global_load_b32 v3, v3, s[60:61]
	s_wait_loadcnt 0x0
	v_mul_f32_e32 v2, v1, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.349:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.350:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.351:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.352:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshl_b32 s0, s90, 16
	s_wait_alu 0xfffe
	s_mul_f32 s1, s0, 0xbfb8aa3b
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2)
	s_xor_b32 s3, s1, 0x80000000
	s_rndne_f32 s4, s1
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0xbfb8aa3b, s3
	s_cmp_ngt_f32 s0, 0x42ce8ed0
	s_sub_f32 s1, s1, s4
	s_wait_alu 0xfffe
	s_fmamk_f32 s3, s0, 0xb2a5705f, s3
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_nlt_f32 s0, 0xc2b17218
	s_wait_alu 0xfffe
	s_add_f32 s1, s1, s3
	s_cvt_i32_f32 s3, s4
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_s_exp_f32 s1, s1
	s_wait_alu 0xf1ff
	v_ldexp_f32 v2, s1, s3
	s_mov_b32 s3, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v2, 1.0, v2
	v_div_scale_f32 v3, null, v2, v2, 1.0
	s_delay_alu instid0(VALU_DEP_1)
	v_rcp_f32_e32 v4, v3
	v_xor_b32_e32 v3, 0x80000000, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v5, v3, v4, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, 1.0, v2, 1.0
	v_mul_f32_e32 v6, v5, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v7, v3, v6, v5
	v_fmac_f32_e32 v6, v7, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v5, v3, v6
	s_wait_alu 0xfffd
	v_div_fmas_f32 v3, v5, v4, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v2, v3, v2, 1.0
	v_and_b32_e32 v3, 0x7fffffff, v2
	v_readfirstlane_b32 s0, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
	s_cbranch_vccz .LBB0_354
; %bb.353:
	s_bfe_u32 s1, s0, 0x10010
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s0, s1
	s_wait_alu 0xfffe
	s_addk_co_i32 s1, 0x7fff
	s_wait_alu 0xfffe
	s_lshr_b32 s1, s1, 16
	s_and_not1_b32 vcc_lo, exec_lo, s3
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_355
	s_branch .LBB0_356
.LBB0_354:
                                        ; implicit-def: $sgpr1
.LBB0_355:
	s_lshr_b32 s0, s0, 16
	s_wait_alu 0xfffe
	s_or_b32 s1, s0, 64
.LBB0_356:
	v_lshlrev_b32_e32 v1, 16, v1
	s_wait_alu 0xfffe
	s_lshl_b32 s0, s1, 16
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, s0, v1
	v_and_b32_e32 v1, 0x7fffffff, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.357:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.358:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.359:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.360:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_lshlrev_b32_e32 v2, 16, v10
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v1, 16, v1
	v_add_f32_e32 v2, v2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.361:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.362:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.363:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.364:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v2, 16, v1
	v_ashrrev_i32_e32 v44, 31, v43
	v_or_b32_e32 v4, 64, v1
	s_mul_u64 s[0:1], s[68:69], s[70:71]
	s_wait_alu 0xfffe
	s_lshl_b64 s[0:1], s[0:1], 1
	v_and_b32_e32 v5, 0x7fffffff, v2
	v_lshlrev_b64_e32 v[2:3], 1, v[43:44]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[0:1], s[66:67], s[0:1]
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_lt_u32_e32 vcc_lo, 0x7f800000, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	s_wait_alu 0xfffe
	v_add_co_u32 v1, vcc_lo, s0, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s1, v3, vcc_lo
	global_store_b16 v[1:2], v4, off
.LBB0_365:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s92
	s_wait_storecnt 0x0
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s0, s2
	s_cbranch_execz .LBB0_370
; %bb.366:
	s_mov_b32 s3, exec_lo
	s_mov_b32 s1, exec_lo
	s_wait_alu 0xfffe
	v_mbcnt_lo_u32_b32 v1, s3, 0
                                        ; implicit-def: $vgpr2
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_eq_u32_e32 0, v1
	s_cbranch_execz .LBB0_368
; %bb.367:
	s_bcnt1_i32_b32 s3, s3
	s_wait_alu 0xfffe
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s3
	s_wait_loadcnt 0x0
	global_atomic_add_u32 v2, v2, v3, s[34:35] offset:4 th:TH_ATOMIC_RETURN scope:SCOPE_DEV
	s_wait_loadcnt 0x0
	global_inv scope:SCOPE_DEV
.LBB0_368:
	s_or_b32 exec_lo, exec_lo, s1
	v_readfirstlane_b32 s1, v2
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v1, s1, v1
	s_add_co_i32 s1, s28, -1
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s1, v1
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB0_370
; %bb.369:
	v_mov_b32_e32 v1, 0
	s_clause 0x2
	global_store_b32 v1, v1, s[34:35] scope:SCOPE_DEV
	global_store_b32 v1, v1, s[34:35] offset:4 scope:SCOPE_DEV
	global_store_b32 v1, v1, s[34:35] offset:8 scope:SCOPE_DEV
.LBB0_370:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_mov_b32 s0, 0
.LBB0_371:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s0
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_493
; %bb.372:
	s_add_co_i32 s0, s55, 7
	s_add_co_i32 s1, s54, 7
	s_wait_alu 0xfffe
	s_ashr_i32 s3, s0, 31
	s_ashr_i32 s5, s1, 31
	s_wait_alu 0xfffe
	s_lshr_b32 s3, s3, 29
	s_lshr_b32 s5, s5, 29
	s_wait_alu 0xfffe
	s_add_co_i32 s0, s0, s3
	s_add_co_i32 s1, s1, s5
	s_bfe_u32 s4, s30, 0x30012
	s_wait_alu 0xfffe
	s_ashr_i32 s0, s0, 3
	s_ashr_i32 s3, s1, 3
	s_cmp_ge_i32 s29, s58
	s_cselect_b32 s6, -1, 0
	s_cmp_lt_i32 s29, s58
	s_cselect_b32 s1, -1, 0
	s_sub_co_i32 s10, s29, s58
	s_cmp_lt_i32 s4, 2
	s_cbranch_scc1 .LBB0_377
; %bb.373:
	s_cmp_lt_i32 s4, 3
	s_wait_alu 0xfffe
	s_mul_i32 s7, s56, s3
	s_cbranch_scc1 .LBB0_378
; %bb.374:
	s_cmp_lt_i32 s4, 4
	s_cbranch_scc1 .LBB0_379
; %bb.375:
	s_cmp_lg_u32 s4, 4
	s_cbranch_scc0 .LBB0_380
; %bb.376:
	s_wait_alu 0xfffe
	s_add_co_i32 s5, s7, -1
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s10, s5
	s_cselect_b32 s5, -1, 0
	s_add_co_i32 s8, s0, -1
	s_wait_alu 0xfffe
	s_and_b32 s5, s6, s5
	s_cmp_eq_u32 s29, s8
	s_cselect_b32 s8, -1, 0
	s_wait_alu 0xfffe
	s_or_b32 s5, s5, s8
	s_mov_b32 s8, 0
	s_branch .LBB0_381
.LBB0_377:
                                        ; implicit-def: $sgpr5
	s_branch .LBB0_389
.LBB0_378:
                                        ; implicit-def: $sgpr5
	s_branch .LBB0_387
.LBB0_379:
                                        ; implicit-def: $sgpr5
	s_branch .LBB0_385
.LBB0_380:
	s_mov_b32 s8, -1
                                        ; implicit-def: $sgpr5
.LBB0_381:
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s8
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_384
; %bb.382:
	s_and_not1_b32 vcc_lo, exec_lo, s6
	s_mov_b32 s5, 0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_384
; %bb.383:
	s_abs_i32 s5, s7
	s_add_co_i32 s11, s10, 1
	s_wait_alu 0xfffe
	s_cvt_f32_u32 s8, s5
	s_sub_co_i32 s9, 0, s5
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_iflag_f32_e32 v1, s8
	v_readfirstlane_b32 s8, v1
	s_mul_f32 s8, s8, 0x4f7ffffe
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_cvt_u32_f32 s8, s8
	s_wait_alu 0xfffe
	s_mul_i32 s9, s9, s8
	s_wait_alu 0xfffe
	s_mul_hi_u32 s9, s8, s9
	s_wait_alu 0xfffe
	s_add_co_i32 s8, s8, s9
	s_wait_alu 0xfffe
	s_mul_hi_u32 s8, s11, s8
	s_wait_alu 0xfffe
	s_mul_i32 s8, s8, s5
	s_wait_alu 0xfffe
	s_sub_co_i32 s8, s11, s8
	s_wait_alu 0xfffe
	s_sub_co_i32 s9, s8, s5
	s_cmp_ge_u32 s8, s5
	s_wait_alu 0xfffe
	s_cselect_b32 s8, s9, s8
	s_wait_alu 0xfffe
	s_sub_co_i32 s9, s8, s5
	s_cmp_ge_u32 s8, s5
	s_wait_alu 0xfffe
	s_cselect_b32 s5, s9, s8
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s5, 0
	s_cselect_b32 s5, -1, 0
.LBB0_384:
	s_cbranch_execnz .LBB0_386
.LBB0_385:
	s_add_co_i32 s5, s0, -1
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s29, s5
	s_cselect_b32 s5, -1, 0
.LBB0_386:
	s_cbranch_execnz .LBB0_388
.LBB0_387:
	s_wait_alu 0xfffe
	s_add_co_i32 s7, s7, -1
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s10, s7
	s_cselect_b32 s5, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s5, s6, s5
.LBB0_388:
	s_cbranch_execnz .LBB0_393
.LBB0_389:
	s_cmp_gt_i32 s4, 0
	s_mov_b32 s4, 0
	s_cbranch_scc0 .LBB0_391
; %bb.390:
	s_add_co_i32 s5, s58, -1
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s29, s5
	s_cselect_b32 s5, -1, 0
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_392
	s_branch .LBB0_393
.LBB0_391:
                                        ; implicit-def: $sgpr5
.LBB0_392:
	s_add_co_i32 s31, s31, -1
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s29, s31
	s_cselect_b32 s5, -1, 0
.LBB0_393:
	s_and_b32 s6, s30, 0xffff
	s_bitcmp0_b32 s30, 16
	s_mov_b32 s7, 0
	s_cbranch_scc1 .LBB0_395
; %bb.394:
	s_ashr_i32 s4, s29, 31
	s_wait_alu 0xfffe
	s_lshr_b32 s4, s4, 30
	s_wait_alu 0xfffe
	s_add_co_i32 s4, s29, s4
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, -4
	s_wait_alu 0xfffe
	s_sub_co_i32 s4, s29, s4
	s_wait_alu 0xfffe
	s_add_co_i32 s4, s4, 1
	s_wait_alu 0xfffe
	s_mul_i32 s4, s4, s6
	s_and_not1_b32 vcc_lo, exec_lo, s7
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_396
	s_branch .LBB0_397
.LBB0_395:
                                        ; implicit-def: $sgpr4
.LBB0_396:
	s_wait_alu 0xfffe
	s_and_b32 s4, s5, exec_lo
	s_cselect_b32 s4, s6, 0
.LBB0_397:
	s_wait_alu 0xfffe
	s_cmp_lt_i32 s4, 1
	s_cbranch_scc1 .LBB0_399
.LBB0_398:                              ; =>This Inner Loop Header: Depth=1
	s_add_co_i32 s4, s4, -1
	s_sleep 0x7f
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s4, 0
	s_cbranch_scc0 .LBB0_398
.LBB0_399:
	s_and_b32 vcc_lo, exec_lo, s1
	s_mov_b32 s1, -1
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_431
; %bb.400:
	s_abs_i32 s1, s0
	s_abs_i32 s6, s29
	s_wait_alu 0xfffe
	s_cvt_f32_u32 s4, s1
	s_sub_co_i32 s5, 0, s1
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_iflag_f32_e32 v1, s4
	v_readfirstlane_b32 s4, v1
	s_mul_f32 s4, s4, 0x4f7ffffe
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_cvt_u32_f32 s4, s4
	s_wait_alu 0xfffe
	s_mul_i32 s5, s5, s4
	s_wait_alu 0xfffe
	s_mul_hi_u32 s5, s4, s5
	s_wait_alu 0xfffe
	s_add_co_i32 s4, s4, s5
	s_xor_b32 s5, s29, s0
	s_wait_alu 0xfffe
	s_mul_hi_u32 s4, s6, s4
	s_ashr_i32 s5, s5, 31
	s_wait_alu 0xfffe
	s_mul_i32 s7, s4, s1
	s_wait_alu 0xfffe
	s_sub_co_i32 s6, s6, s7
	s_add_co_i32 s7, s4, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s8, s6, s1
	s_cmp_ge_u32 s6, s1
	s_cselect_b32 s4, s7, s4
	s_wait_alu 0xfffe
	s_cselect_b32 s6, s8, s6
	s_add_co_i32 s7, s4, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s6, s1
	s_cselect_b32 s1, s7, s4
	s_wait_alu 0xfffe
	s_xor_b32 s1, s1, s5
	s_wait_alu 0xfffe
	s_sub_co_i32 s4, s1, s5
	s_wait_alu 0xfffe
	s_mul_i32 s0, s4, s0
	s_wait_alu 0xfffe
	s_sub_co_i32 s0, s29, s0
	s_wait_alu 0xfffe
	v_lshl_or_b32 v29, s0, 3, v14
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, s55, v29
	s_and_saveexec_b32 s8, vcc_lo
	s_cbranch_execz .LBB0_427
; %bb.401:
	s_lshr_b32 s6, s53, 31
	v_cndmask_b32_e32 v1, 0, v29, vcc_lo
	s_ashr_i32 s5, s4, 31
	s_ashr_i32 s1, s53, 31
	s_mov_b32 s0, s53
	s_wait_alu 0xfffe
	s_add_co_i32 s9, s53, s6
	s_mul_u64 s[6:7], s[4:5], s[0:1]
	s_wait_alu 0xfffe
	s_ashr_i32 s0, s9, 1
	s_lshl_b64 s[6:7], s[6:7], 1
	s_wait_alu 0xfffe
	v_mad_co_i64_i32 v[30:31], null, v1, s0, 0
	s_lshr_b32 s9, s1, 28
	v_or_b32_e32 v2, 32, v41
	s_wait_kmcnt 0x0
	s_add_nc_u64 s[0:1], s[12:13], s[6:7]
	s_wait_alu 0xfffe
	s_add_co_i32 s6, s53, s9
	v_or_b32_e32 v7, 64, v41
	s_wait_alu 0xfffe
	s_ashr_i32 s9, s6, 4
	v_add_co_u32 v54, vcc_lo, s36, v30
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v55, null, s37, v31, vcc_lo
	s_wait_alu 0xfffe
	v_cmp_gt_i32_e32 vcc_lo, s9, v2
	v_mad_co_i64_i32 v[32:33], null, v1, s9, 0
	v_sub_nc_u32_e32 v51, s9, v41
	s_mov_b32 s6, exec_lo
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, 0, v2, vcc_lo
	v_mov_b32_e32 v101, v14
	v_add_co_u32 v58, vcc_lo, s42, v30
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v59, null, s43, v31, vcc_lo
	v_lshlrev_b32_e32 v6, 3, v5
	v_add_co_u32 v27, vcc_lo, s38, v32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v28, null, s39, v33, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_u32 v1, vcc_lo, v54, v6
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v55, vcc_lo
	v_add_co_u32 v3, vcc_lo, v27, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v28, vcc_lo
	v_add_co_u32 v56, vcc_lo, s44, v32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v57, null, s45, v33, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s9, v7
	global_load_b64 v[46:47], v[1:2], off th:TH_LOAD_NT
	global_load_u8 v52, v[3:4], off
	v_dual_mov_b32 v26, 0 :: v_dual_lshlrev_b32 v9, 5, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_add_co_u32 v1, vcc_lo, v58, v6
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v59, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v8, 3, v7
	v_add_co_u32 v3, vcc_lo, v56, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v57, vcc_lo
	v_add_co_u32 v5, vcc_lo, v54, v8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v55, vcc_lo
	global_load_b64 v[44:45], v[1:2], off th:TH_LOAD_NT
	global_load_u8 v53, v[3:4], off
	s_clause 0x1
	global_load_b128 v[17:20], v9, s[0:1] offset:16
	global_load_b128 v[21:24], v9, s[0:1]
	global_load_b64 v[42:43], v[5:6], off th:TH_LOAD_NT
	v_or_b32_e32 v5, 0x60, v41
	v_add_co_u32 v1, vcc_lo, v27, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v28, vcc_lo
	v_add_co_u32 v3, vcc_lo, v58, v8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v59, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s9, v5
	global_load_u8 v49, v[1:2], off
	global_load_b64 v[38:39], v[3:4], off th:TH_LOAD_NT
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v25, 0, v5, vcc_lo
	v_add_co_u32 v5, vcc_lo, v56, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v57, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b32_e32 v8, 3, v25
	v_lshlrev_b32_e32 v7, 5, v7
	global_load_u8 v50, v[5:6], off
	s_clause 0x1
	global_load_b128 v[9:12], v7, s[0:1] offset:16
	global_load_b128 v[13:16], v7, s[0:1]
	v_add_co_u32 v1, vcc_lo, v54, v8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v55, vcc_lo
	v_add_co_u32 v3, vcc_lo, v27, v25
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v28, vcc_lo
	v_add_co_u32 v5, vcc_lo, v58, v8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v59, vcc_lo
	v_add_co_u32 v7, vcc_lo, v56, v25
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, 0, v57, vcc_lo
	v_lshlrev_b32_e32 v25, 5, v25
	global_load_b64 v[36:37], v[1:2], off th:TH_LOAD_NT
	global_load_u8 v48, v[3:4], off
	global_load_b64 v[34:35], v[5:6], off th:TH_LOAD_NT
	global_load_u8 v40, v[7:8], off
	s_clause 0x1
	global_load_b128 v[1:4], v25, s[0:1] offset:16
	global_load_b128 v[5:8], v25, s[0:1]
	v_mov_b32_e32 v25, 0
	v_cmpx_lt_i32_e32 0, v51
	s_cbranch_execz .LBB0_403
; %bb.402:
	v_cmp_gt_i32_e32 vcc_lo, s9, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0, v41, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_u32 v25, vcc_lo, v27, v64
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, 0, v28, vcc_lo
	v_add_co_u32 v27, vcc_lo, v56, v64
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v28, null, 0, v57, vcc_lo
	v_lshlrev_b32_e32 v65, 5, v64
	global_load_u8 v57, v[25:26], off
	global_load_u8 v56, v[27:28], off
	s_clause 0x1
	global_load_b128 v[60:63], v65, s[0:1]
	global_load_b128 v[25:28], v65, s[0:1] offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v67, 16, v61
	v_lshlrev_b32_e32 v66, 3, v64
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_u32 v54, vcc_lo, v54, v66
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v55, null, 0, v55, vcc_lo
	global_load_b64 v[64:65], v[54:55], off th:TH_LOAD_NT
	v_add_co_u32 v54, vcc_lo, v58, v66
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v55, null, 0, v59, vcc_lo
	global_load_b64 v[58:59], v[54:55], off th:TH_LOAD_NT
	v_lshlrev_b32_e32 v55, 24, v56
	s_wait_loadcnt 0x1
	v_and_b32_e32 v73, 15, v64
	v_lshrrev_b32_e32 v74, 2, v64
	v_lshrrev_b32_e32 v75, 6, v64
	v_lshrrev_b32_e32 v76, 10, v64
	v_lshrrev_b32_e32 v77, 14, v64
	v_lshlrev_b32_e32 v73, 2, v73
	v_and_b32_e32 v74, 60, v74
	v_lshrrev_b32_e32 v78, 18, v64
	s_wait_loadcnt 0x0
	v_and_b32_e32 v87, 15, v58
	v_lshrrev_b32_e32 v88, 2, v58
	v_lshrrev_b32_e32 v89, 6, v58
	v_lshrrev_b32_e32 v79, 22, v64
	v_lshrrev_b32_e32 v64, 26, v64
	v_lshlrev_b32_e32 v87, 2, v87
	ds_load_b32 v73, v73
	ds_load_b32 v87, v87
	v_and_b32_e32 v88, 60, v88
	ds_load_b32 v74, v74
	ds_load_b32 v88, v88
	v_lshrrev_b32_e32 v90, 10, v58
	v_lshrrev_b32_e32 v91, 14, v58
	v_lshrrev_b32_e32 v92, 18, v58
	v_lshrrev_b32_e32 v93, 22, v58
	v_lshrrev_b32_e32 v58, 26, v58
	v_and_b32_e32 v89, 60, v89
	v_and_b32_e32 v75, 60, v75
	v_and_b32_e32 v76, 60, v76
	v_and_b32_e32 v77, 60, v77
	v_and_b32_e32 v78, 60, v78
	v_and_b32_e32 v79, 60, v79
	v_and_b32_e32 v64, 60, v64
	v_and_b32_e32 v90, 60, v90
	v_and_b32_e32 v91, 60, v91
	v_and_b32_e32 v92, 60, v92
	v_and_b32_e32 v93, 60, v93
	v_and_b32_e32 v58, 60, v58
	ds_load_b32 v89, v89
	ds_load_b32 v75, v75
	ds_load_b32 v76, v76
	ds_load_b32 v77, v77
	ds_load_b32 v78, v78
	ds_load_b32 v79, v79
	ds_load_b32 v64, v64
	ds_load_b32 v90, v90
	ds_load_b32 v91, v91
	ds_load_b32 v92, v92
	ds_load_b32 v93, v93
	ds_load_b32 v58, v58
	v_lshlrev_b32_e32 v69, 16, v63
	v_lshlrev_b32_e32 v68, 16, v62
	v_and_b32_e32 v61, 0xffff0000, v61
	v_lshlrev_b32_e32 v66, 16, v60
	v_and_b32_e32 v62, 0xffff0000, v62
	v_and_b32_e32 v60, 0xffff0000, v60
	v_and_b32_e32 v94, 15, v59
	v_lshrrev_b32_e32 v81, 2, v65
	s_wait_dscnt 0xf
	v_fma_f32 v73, v73, v66, 0
	v_lshlrev_b32_e32 v54, 24, v57
	v_lshrrev_b32_e32 v95, 2, v59
	v_lshrrev_b32_e32 v96, 6, v59
	v_lshrrev_b32_e32 v82, 6, v65
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v73, v74, v60 :: v_dual_lshlrev_b32 v74, 2, v94
	v_lshrrev_b32_e32 v83, 10, v65
	v_lshrrev_b32_e32 v84, 14, v65
	v_lshrrev_b32_e32 v85, 18, v65
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v73, v75, v67
	v_and_b32_e32 v75, 60, v96
	v_lshrrev_b32_e32 v86, 22, v65
	v_lshrrev_b32_e32 v97, 10, v59
	v_lshrrev_b32_e32 v98, 14, v59
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v73, v76, v61
	v_fma_f32 v66, v87, v66, 0
	v_lshrrev_b32_e32 v99, 18, v59
	v_and_b32_e32 v83, 60, v83
	v_lshrrev_b32_e32 v100, 22, v59
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v73, v77, v68
	v_and_b32_e32 v84, 60, v84
	v_lshrrev_b32_e32 v59, 26, v59
	v_and_b32_e32 v85, 60, v85
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v73, v78, v62 :: v_dual_and_b32 v76, 60, v99
	v_fmac_f32_e32 v66, v88, v60
	v_and_b32_e32 v60, 60, v86
	v_and_b32_e32 v86, 60, v97
	v_and_b32_e32 v87, 60, v100
	v_and_b32_e32 v59, 60, v59
	v_fmac_f32_e32 v66, v89, v67
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v66, v90, v61 :: v_dual_and_b32 v67, 60, v95
	v_fmac_f32_e32 v73, v79, v69
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v66, v91, v68 :: v_dual_and_b32 v61, 60, v98
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v66, v92, v62 :: v_dual_and_b32 v63, 0xffff0000, v63
	v_lshlrev_b32_e32 v71, 16, v26
	v_dual_fmac_f32 v73, v64, v63 :: v_dual_lshlrev_b32 v70, 16, v25
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v66, v93, v69
	v_and_b32_e32 v80, 15, v65
	v_and_b32_e32 v25, 0xffff0000, v25
	v_lshrrev_b32_e32 v65, 26, v65
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v66, v58, v63
	v_lshlrev_b32_e32 v80, 2, v80
	ds_load_b32 v68, v80
	ds_load_b32 v74, v74
	v_lshlrev_b32_e32 v72, 16, v27
	v_and_b32_e32 v27, 0xffff0000, v27
	v_and_b32_e32 v65, 60, v65
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v73, v68, v70
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v66, v74, v70 :: v_dual_and_b32 v81, 60, v81
	ds_load_b32 v62, v81
	ds_load_b32 v67, v67
	ds_load_b32 v75, v75
	v_and_b32_e32 v82, 60, v82
	ds_load_b32 v69, v82
	ds_load_b32 v77, v83
	ds_load_b32 v78, v84
	ds_load_b32 v79, v85
	ds_load_b32 v60, v60
	ds_load_b32 v65, v65
	ds_load_b32 v58, v86
	ds_load_b32 v61, v61
	ds_load_b32 v63, v76
	ds_load_b32 v64, v87
	ds_load_b32 v59, v59
	v_and_b32_e32 v26, 0xffff0000, v26
	v_and_b32_e32 v70, 0x7f, v57
	v_lshlrev_b32_e32 v68, 16, v28
	v_and_b32_e32 v28, 0xffff0000, v28
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v73, v62, v25
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v66, v67, v25
	v_and_b32_e32 v25, 7, v57
	v_and_b32_e32 v57, 0x7f, v56
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v73, v69, v71 :: v_dual_and_b32 v56, 7, v56
	v_fmac_f32_e32 v66, v75, v71
	v_cvt_f32_ubyte0_e32 v25, v25
	v_lshl_add_u32 v62, v70, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v56, v56
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v73, v77, v26
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v66, v58, v26 :: v_dual_mul_f32 v25, 0x3b000000, v25
	v_lshl_add_u32 v26, v57, 20, 0x3c000000
	v_mul_f32_e32 v56, 0x3b000000, v56
	v_fmac_f32_e32 v73, v78, v72
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v66, v61, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v25, v25, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v57
	v_fmac_f32_e32 v73, v79, v27
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v66, v63, v27
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v26, v56, v26, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_fmac_f32_e32 v73, v60, v68
	s_wait_dscnt 0x1
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v66, v64, v68 :: v_dual_cndmask_b32 v25, 0x7fc00000, v25
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v57
	v_fmac_f32_e32 v73, v65, v28
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v66, v59, v28
	v_and_or_b32 v25, 0x80000000, v54, v25
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v26, 0x7fc00000, v26, vcc_lo
	v_and_or_b32 v27, 0x80000000, v55, v26
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fma_f32 v26, v73, v25, 0
	v_fma_f32 v25, v66, v27, 0
.LBB0_403:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s6, exec_lo
	v_cmpx_lt_i32_e32 32, v51
	s_cbranch_execz .LBB0_405
; %bb.404:
	s_wait_loadcnt 0xc
	v_lshlrev_b32_e32 v64, 16, v22
	v_lshlrev_b32_e32 v60, 16, v21
	v_and_b32_e32 v21, 0xffff0000, v21
	v_and_b32_e32 v27, 15, v46
	v_lshrrev_b32_e32 v28, 2, v46
	v_lshrrev_b32_e32 v54, 6, v46
	v_and_b32_e32 v22, 0xffff0000, v22
	v_lshrrev_b32_e32 v55, 10, v46
	v_lshlrev_b32_e32 v27, 2, v27
	v_and_b32_e32 v28, 60, v28
	v_lshrrev_b32_e32 v56, 14, v46
	v_lshrrev_b32_e32 v57, 18, v46
	v_lshrrev_b32_e32 v58, 22, v46
	ds_load_b32 v27, v27
	ds_load_b32 v28, v28
	v_and_b32_e32 v54, 60, v54
	v_lshrrev_b32_e32 v46, 26, v46
	v_lshlrev_b32_e32 v67, 16, v24
	v_and_b32_e32 v24, 0xffff0000, v24
	v_and_b32_e32 v55, 60, v55
	ds_load_b32 v54, v54
	v_and_b32_e32 v58, 60, v58
	v_and_b32_e32 v46, 60, v46
	v_and_b32_e32 v59, 15, v47
	v_lshrrev_b32_e32 v61, 2, v47
	v_lshrrev_b32_e32 v62, 6, v47
	v_lshrrev_b32_e32 v63, 10, v47
	v_lshrrev_b32_e32 v65, 18, v47
	v_lshrrev_b32_e32 v66, 22, v47
	v_lshrrev_b32_e32 v68, 18, v44
	v_lshrrev_b32_e32 v69, 22, v44
	s_wait_dscnt 0x2
	v_fma_f32 v27, v27, v60, 0
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v27, v28, v21 :: v_dual_and_b32 v68, 60, v68
	v_lshrrev_b32_e32 v28, 14, v47
	v_lshrrev_b32_e32 v47, 26, v47
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v27, v54, v64 :: v_dual_lshlrev_b32 v54, 16, v23
	v_and_b32_e32 v23, 0xffff0000, v23
	v_and_b32_e32 v56, 60, v56
	v_and_b32_e32 v57, 60, v57
	ds_load_b32 v55, v55
	ds_load_b32 v56, v56
	ds_load_b32 v57, v57
	ds_load_b32 v58, v58
	ds_load_b32 v46, v46
	v_and_b32_e32 v28, 60, v28
	v_and_b32_e32 v47, 60, v47
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v27, v55, v22
	v_lshlrev_b32_e32 v55, 2, v59
	v_and_b32_e32 v59, 60, v61
	v_and_b32_e32 v61, 60, v62
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v27, v56, v54 :: v_dual_and_b32 v62, 60, v63
	v_and_b32_e32 v56, 60, v65
	v_and_b32_e32 v63, 60, v66
	v_lshrrev_b32_e32 v65, 6, v44
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v27, v57, v23
	ds_load_b32 v55, v55
	ds_load_b32 v57, v59
	ds_load_b32 v59, v61
	ds_load_b32 v61, v62
	ds_load_b32 v28, v28
	ds_load_b32 v56, v56
	ds_load_b32 v62, v63
	ds_load_b32 v47, v47
	v_and_b32_e32 v63, 15, v44
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v27, v58, v67 :: v_dual_lshlrev_b32 v66, 16, v17
	v_lshrrev_b32_e32 v58, 2, v44
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v63, 2, v63
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v27, v46, v24 :: v_dual_and_b32 v46, 60, v58
	ds_load_b32 v63, v63
	v_and_b32_e32 v58, 60, v65
	v_lshrrev_b32_e32 v65, 14, v44
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v27, v55, v66
	ds_load_b32 v46, v46
	ds_load_b32 v55, v58
	v_lshrrev_b32_e32 v58, 10, v44
	v_lshrrev_b32_e32 v44, 26, v44
	v_and_b32_e32 v65, 60, v65
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v58, 60, v58
	v_and_b32_e32 v44, 60, v44
	s_wait_dscnt 0x2
	v_fma_f32 v60, v63, v60, 0
	v_lshlrev_b32_e32 v63, 16, v18
	v_and_b32_e32 v18, 0xffff0000, v18
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v46, v21 :: v_dual_lshlrev_b32 v21, 16, v19
	v_and_b32_e32 v19, 0xffff0000, v19
	v_and_b32_e32 v17, 0xffff0000, v17
	v_and_b32_e32 v46, 15, v45
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v27, v57, v17 :: v_dual_fmac_f32 v60, v55, v64
	v_lshrrev_b32_e32 v55, 2, v45
	v_lshrrev_b32_e32 v57, 6, v45
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v27, v59, v63
	v_fmac_f32_e32 v27, v61, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v27, v28, v21 :: v_dual_lshlrev_b32 v28, 16, v20
	v_and_b32_e32 v20, 0xffff0000, v20
	v_and_b32_e32 v69, 60, v69
	ds_load_b32 v58, v58
	ds_load_b32 v65, v65
	ds_load_b32 v68, v68
	ds_load_b32 v69, v69
	ds_load_b32 v44, v44
	v_fmac_f32_e32 v27, v56, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v27, v62, v28
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v27, v47, v20 :: v_dual_fmac_f32 v60, v58, v22
	v_lshlrev_b32_e32 v22, 2, v46
	v_and_b32_e32 v46, 60, v55
	v_and_b32_e32 v55, 60, v57
	v_lshrrev_b32_e32 v57, 10, v45
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v60, v65, v54
	ds_load_b32 v22, v22
	ds_load_b32 v46, v46
	ds_load_b32 v54, v55
	v_lshrrev_b32_e32 v58, 22, v45
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v60, v68, v23 :: v_dual_and_b32 v55, 60, v57
	v_lshrrev_b32_e32 v23, 14, v45
	v_lshrrev_b32_e32 v57, 18, v45
	v_lshrrev_b32_e32 v45, 26, v45
	v_and_b32_e32 v58, 60, v58
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v60, v69, v67
	v_and_b32_e32 v23, 60, v23
	v_and_b32_e32 v57, 60, v57
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v60, v44, v24 :: v_dual_and_b32 v45, 60, v45
	ds_load_b32 v24, v55
	ds_load_b32 v23, v23
	ds_load_b32 v44, v57
	ds_load_b32 v55, v58
	ds_load_b32 v45, v45
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v60, v22, v66
	v_lshlrev_b32_e32 v22, 24, v52
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v60, v46, v17
	v_and_b32_e32 v46, 7, v52
	v_and_b32_e32 v52, 0x7f, v52
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v60, v54, v63 :: v_dual_lshlrev_b32 v17, 24, v53
	v_and_b32_e32 v54, 7, v53
	v_cvt_f32_ubyte0_e32 v46, v46
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v60, v24, v18
	v_and_b32_e32 v18, 0x7f, v53
	v_cvt_f32_ubyte0_e32 v24, v54
	v_lshl_add_u32 v53, v52, 20, 0x3c000000
	v_mul_f32_e32 v46, 0x3b000000, v46
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v60, v23, v21
	v_lshl_add_u32 v21, v18, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v23, 0x3b000000, v24 :: v_dual_cndmask_b32 v24, v46, v53
	v_cmp_lt_u32_e32 vcc_lo, 7, v18
	s_wait_dscnt 0x2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v44, v19 :: v_dual_cndmask_b32 v19, v23, v21
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v60, v55, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v21, 0x7fc00000, v24, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v18
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v60, v45, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v18, 0x7fc00000, v19, vcc_lo
	v_and_or_b32 v19, 0x80000000, v22, v21
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v17, 0x80000000, v17, v18
	v_dual_fmac_f32 v26, v27, v19 :: v_dual_fmac_f32 v25, v60, v17
.LBB0_405:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s6, exec_lo
	v_cmpx_lt_i32_e32 64, v51
	s_cbranch_execz .LBB0_407
; %bb.406:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v46, 16, v14
	v_lshlrev_b32_e32 v28, 16, v13
	v_and_b32_e32 v13, 0xffff0000, v13
	v_and_b32_e32 v17, 15, v42
	v_lshrrev_b32_e32 v18, 2, v42
	v_lshrrev_b32_e32 v19, 6, v42
	v_lshlrev_b32_e32 v53, 16, v16
	v_and_b32_e32 v16, 0xffff0000, v16
	v_lshlrev_b32_e32 v17, 2, v17
	v_and_b32_e32 v18, 60, v18
	v_and_b32_e32 v14, 0xffff0000, v14
	v_and_b32_e32 v19, 60, v19
	v_lshrrev_b32_e32 v20, 10, v42
	ds_load_b32 v17, v17
	ds_load_b32 v18, v18
	v_lshrrev_b32_e32 v21, 14, v42
	ds_load_b32 v19, v19
	v_lshrrev_b32_e32 v22, 18, v42
	v_lshrrev_b32_e32 v23, 22, v42
	v_lshrrev_b32_e32 v24, 26, v42
	v_and_b32_e32 v27, 15, v43
	v_lshrrev_b32_e32 v42, 2, v43
	v_lshrrev_b32_e32 v44, 6, v43
	v_lshrrev_b32_e32 v45, 10, v43
	v_lshrrev_b32_e32 v47, 18, v43
	v_lshrrev_b32_e32 v52, 22, v43
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v23, 60, v23
	v_lshrrev_b32_e32 v54, 18, v38
	v_lshrrev_b32_e32 v55, 22, v38
	s_wait_dscnt 0x2
	v_fma_f32 v17, v17, v28, 0
	v_and_b32_e32 v20, 60, v20
	v_and_b32_e32 v54, 60, v54
	v_and_b32_e32 v55, 60, v55
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v17, v18, v13
	v_lshrrev_b32_e32 v18, 14, v43
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v17, v19, v46
	v_lshrrev_b32_e32 v19, 26, v43
	v_lshlrev_b32_e32 v43, 16, v15
	v_and_b32_e32 v15, 0xffff0000, v15
	v_and_b32_e32 v21, 60, v21
	v_and_b32_e32 v24, 60, v24
	ds_load_b32 v20, v20
	ds_load_b32 v21, v21
	ds_load_b32 v22, v22
	ds_load_b32 v23, v23
	ds_load_b32 v24, v24
	v_and_b32_e32 v18, 60, v18
	v_and_b32_e32 v19, 60, v19
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v17, v20, v14 :: v_dual_lshlrev_b32 v20, 2, v27
	v_and_b32_e32 v27, 60, v42
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v17, v21, v43 :: v_dual_and_b32 v42, 60, v44
	v_and_b32_e32 v21, 60, v47
	v_lshrrev_b32_e32 v47, 6, v38
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v17, v22, v15
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v17, v23, v53
	v_lshrrev_b32_e32 v23, 2, v38
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v17, v24, v16 :: v_dual_and_b32 v44, 60, v45
	v_and_b32_e32 v45, 60, v52
	ds_load_b32 v20, v20
	ds_load_b32 v22, v27
	ds_load_b32 v27, v42
	ds_load_b32 v42, v44
	ds_load_b32 v18, v18
	ds_load_b32 v21, v21
	ds_load_b32 v44, v45
	ds_load_b32 v19, v19
	v_and_b32_e32 v45, 15, v38
	v_lshlrev_b32_e32 v52, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v9
	v_and_b32_e32 v23, 60, v23
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v45, 2, v45
	ds_load_b32 v45, v45
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v17, v20, v52
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v17, v22, v9
	v_lshrrev_b32_e32 v22, 2, v39
	s_wait_dscnt 0x0
	v_fma_f32 v28, v45, v28, 0
	v_lshlrev_b32_e32 v45, 16, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v17, v27, v45 :: v_dual_and_b32 v10, 0xffff0000, v10
	v_lshrrev_b32_e32 v27, 22, v39
	v_dual_fmac_f32 v17, v42, v10 :: v_dual_and_b32 v24, 60, v47
	ds_load_b32 v20, v23
	ds_load_b32 v23, v24
	v_lshrrev_b32_e32 v24, 10, v38
	v_lshrrev_b32_e32 v47, 14, v38
	v_lshrrev_b32_e32 v38, 26, v38
	v_and_b32_e32 v27, 60, v27
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_b32_e32 v24, 60, v24
	v_and_b32_e32 v47, 60, v47
	s_delay_alu instid0(VALU_DEP_4)
	v_and_b32_e32 v38, 60, v38
	ds_load_b32 v24, v24
	ds_load_b32 v47, v47
	ds_load_b32 v54, v54
	ds_load_b32 v55, v55
	ds_load_b32 v38, v38
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v28, v20, v13
	v_and_b32_e32 v20, 15, v39
	v_lshlrev_b32_e32 v13, 16, v11
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v28, v23, v46 :: v_dual_and_b32 v11, 0xffff0000, v11
	v_lshrrev_b32_e32 v23, 6, v39
	v_dual_fmac_f32 v17, v18, v13 :: v_dual_lshlrev_b32 v18, 16, v12
	v_and_b32_e32 v12, 0xffff0000, v12
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v28, v24, v14
	v_lshlrev_b32_e32 v14, 2, v20
	v_and_b32_e32 v20, 60, v22
	v_and_b32_e32 v22, 60, v23
	ds_load_b32 v14, v14
	ds_load_b32 v20, v20
	ds_load_b32 v22, v22
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v28, v47, v43
	v_lshrrev_b32_e32 v23, 10, v39
	v_lshrrev_b32_e32 v24, 18, v39
	v_fmac_f32_e32 v17, v21, v11
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v28, v54, v15 :: v_dual_and_b32 v21, 7, v50
	v_lshrrev_b32_e32 v15, 14, v39
	v_lshrrev_b32_e32 v39, 26, v39
	v_and_b32_e32 v23, 60, v23
	v_and_b32_e32 v24, 60, v24
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v28, v55, v53 :: v_dual_and_b32 v15, 60, v15
	v_and_b32_e32 v39, 60, v39
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_fmac_f32 v17, v44, v18 :: v_dual_fmac_f32 v28, v38, v16
	ds_load_b32 v16, v23
	ds_load_b32 v15, v15
	ds_load_b32 v23, v24
	ds_load_b32 v24, v27
	ds_load_b32 v27, v39
	v_fmac_f32_e32 v17, v19, v12
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v28, v14, v52
	v_lshlrev_b32_e32 v14, 24, v49
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v28, v20, v9
	v_and_b32_e32 v20, 7, v49
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v28, v22, v45 :: v_dual_lshlrev_b32 v9, 24, v50
	v_and_b32_e32 v22, 0x7f, v49
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v20, v20
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v28, v16, v10
	v_and_b32_e32 v10, 0x7f, v50
	v_cvt_f32_ubyte0_e32 v16, v21
	v_lshl_add_u32 v21, v22, 20, 0x3c000000
	v_mul_f32_e32 v20, 0x3b000000, v20
	v_cmp_lt_u32_e32 vcc_lo, 7, v22
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v28, v15, v13
	v_lshl_add_u32 v13, v10, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v15, 0x3b000000, v16 :: v_dual_cndmask_b32 v16, v20, v21
	v_cmp_lt_u32_e32 vcc_lo, 7, v10
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v28, v23, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v15, v13, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v22
	s_wait_dscnt 0x1
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v28, v24, v18 :: v_dual_cndmask_b32 v13, 0x7fc00000, v16
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v10
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v28, v27, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, 0x7fc00000, v11, vcc_lo
	v_and_or_b32 v11, 0x80000000, v14, v13
	v_and_or_b32 v9, 0x80000000, v9, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v26, v17, v11 :: v_dual_fmac_f32 v25, v28, v9
.LBB0_407:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s6, exec_lo
	v_cmpx_lt_i32_e32 0x60, v51
	s_cbranch_execz .LBB0_409
; %bb.408:
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v27, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v7
	v_lshlrev_b32_e32 v22, 16, v6
	v_lshlrev_b32_e32 v18, 16, v5
	v_and_b32_e32 v5, 0xffff0000, v5
	v_and_b32_e32 v9, 15, v36
	v_lshrrev_b32_e32 v10, 2, v36
	v_lshrrev_b32_e32 v11, 6, v36
	v_lshlrev_b32_e32 v28, 16, v8
	v_and_b32_e32 v8, 0xffff0000, v8
	v_lshlrev_b32_e32 v9, 2, v9
	v_and_b32_e32 v10, 60, v10
	v_and_b32_e32 v6, 0xffff0000, v6
	v_and_b32_e32 v11, 60, v11
	v_lshrrev_b32_e32 v12, 10, v36
	ds_load_b32 v9, v9
	ds_load_b32 v10, v10
	v_lshrrev_b32_e32 v13, 14, v36
	ds_load_b32 v11, v11
	v_lshrrev_b32_e32 v14, 18, v36
	v_lshrrev_b32_e32 v15, 22, v36
	v_lshrrev_b32_e32 v16, 26, v36
	v_and_b32_e32 v13, 60, v13
	v_and_b32_e32 v17, 15, v37
	v_and_b32_e32 v14, 60, v14
	v_and_b32_e32 v15, 60, v15
	v_lshrrev_b32_e32 v19, 2, v37
	v_lshrrev_b32_e32 v20, 6, v37
	v_lshrrev_b32_e32 v21, 10, v37
	v_lshrrev_b32_e32 v23, 18, v37
	v_lshrrev_b32_e32 v24, 22, v37
	v_lshrrev_b32_e32 v36, 18, v34
	s_wait_dscnt 0x2
	v_fma_f32 v9, v9, v18, 0
	v_and_b32_e32 v12, 60, v12
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v9, v10, v5 :: v_dual_and_b32 v36, 60, v36
	v_lshrrev_b32_e32 v10, 14, v37
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v9, v11, v22 :: v_dual_and_b32 v16, 60, v16
	ds_load_b32 v12, v12
	ds_load_b32 v13, v13
	ds_load_b32 v14, v14
	ds_load_b32 v15, v15
	ds_load_b32 v16, v16
	v_lshrrev_b32_e32 v11, 26, v37
	v_and_b32_e32 v10, 60, v10
	v_lshrrev_b32_e32 v37, 22, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_b32_e32 v11, 60, v11
	v_and_b32_e32 v37, 60, v37
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v9, v12, v6 :: v_dual_lshlrev_b32 v12, 2, v17
	v_and_b32_e32 v17, 60, v19
	v_and_b32_e32 v19, 60, v20
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v9, v13, v27
	v_and_b32_e32 v13, 60, v23
	v_lshrrev_b32_e32 v23, 6, v34
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v9, v14, v7
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v9, v15, v28
	v_lshrrev_b32_e32 v15, 2, v34
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v9, v16, v8 :: v_dual_and_b32 v20, 60, v21
	v_and_b32_e32 v21, 60, v24
	ds_load_b32 v12, v12
	ds_load_b32 v14, v17
	ds_load_b32 v17, v19
	ds_load_b32 v19, v20
	ds_load_b32 v10, v10
	ds_load_b32 v13, v13
	ds_load_b32 v20, v21
	ds_load_b32 v11, v11
	v_and_b32_e32 v21, 15, v34
	v_lshlrev_b32_e32 v24, 16, v1
	v_and_b32_e32 v15, 60, v15
	v_and_b32_e32 v16, 60, v23
	v_lshrrev_b32_e32 v23, 14, v34
	v_lshlrev_b32_e32 v21, 2, v21
	v_and_b32_e32 v1, 0xffff0000, v1
	s_delay_alu instid0(VALU_DEP_3)
	v_and_b32_e32 v23, 60, v23
	ds_load_b32 v21, v21
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v9, v12, v24
	ds_load_b32 v12, v15
	ds_load_b32 v15, v16
	v_lshrrev_b32_e32 v16, 10, v34
	v_lshrrev_b32_e32 v34, 26, v34
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v9, v14, v1
	v_lshrrev_b32_e32 v14, 2, v35
	v_and_b32_e32 v16, 60, v16
	v_and_b32_e32 v34, 60, v34
	ds_load_b32 v16, v16
	ds_load_b32 v23, v23
	ds_load_b32 v36, v36
	ds_load_b32 v37, v37
	ds_load_b32 v34, v34
	s_wait_dscnt 0x7
	v_fma_f32 v18, v21, v18, 0
	v_lshlrev_b32_e32 v21, 16, v2
	v_and_b32_e32 v2, 0xffff0000, v2
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v18, v12, v5
	v_dual_fmac_f32 v9, v17, v21 :: v_dual_and_b32 v12, 15, v35
	v_lshlrev_b32_e32 v5, 16, v3
	v_lshrrev_b32_e32 v17, 22, v35
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v18, v15, v22
	v_lshrrev_b32_e32 v15, 6, v35
	v_fmac_f32_e32 v9, v19, v2
	v_lshrrev_b32_e32 v19, 26, v35
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v18, v16, v6 :: v_dual_and_b32 v3, 0xffff0000, v3
	v_lshlrev_b32_e32 v6, 2, v12
	v_and_b32_e32 v12, 60, v14
	v_and_b32_e32 v14, 60, v15
	ds_load_b32 v6, v6
	ds_load_b32 v12, v12
	ds_load_b32 v14, v14
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v18, v23, v27
	v_lshrrev_b32_e32 v15, 10, v35
	v_lshrrev_b32_e32 v16, 18, v35
	v_fmac_f32_e32 v9, v10, v5
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v18, v36, v7 :: v_dual_and_b32 v17, 60, v17
	v_lshrrev_b32_e32 v7, 14, v35
	v_and_b32_e32 v15, 60, v15
	v_and_b32_e32 v16, 60, v16
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v18, v37, v28 :: v_dual_and_b32 v19, 60, v19
	v_and_b32_e32 v7, 60, v7
	v_dual_fmac_f32 v9, v13, v3 :: v_dual_lshlrev_b32 v10, 16, v4
	v_and_b32_e32 v4, 0xffff0000, v4
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v18, v34, v8
	ds_load_b32 v8, v15
	ds_load_b32 v7, v7
	ds_load_b32 v15, v16
	ds_load_b32 v16, v17
	ds_load_b32 v17, v19
	v_and_b32_e32 v13, 7, v40
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v9, v20, v10 :: v_dual_fmac_f32 v18, v6, v24
	v_lshlrev_b32_e32 v6, 24, v48
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v9, v11, v4 :: v_dual_fmac_f32 v18, v12, v1
	v_and_b32_e32 v12, 7, v48
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v18, v14, v21 :: v_dual_lshlrev_b32 v1, 24, v40
	v_and_b32_e32 v14, 0x7f, v48
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v12, v12
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v18, v8, v2
	v_and_b32_e32 v2, 0x7f, v40
	v_cvt_f32_ubyte0_e32 v8, v13
	v_lshl_add_u32 v13, v14, 20, 0x3c000000
	v_mul_f32_e32 v12, 0x3b000000, v12
	v_cmp_lt_u32_e32 vcc_lo, 7, v14
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v18, v7, v5
	v_lshl_add_u32 v5, v2, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v7, 0x3b000000, v8 :: v_dual_cndmask_b32 v8, v12, v13
	v_cmp_lt_u32_e32 vcc_lo, 7, v2
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v18, v15, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v7, v5, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v14
	s_wait_dscnt 0x1
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v18, v16, v10 :: v_dual_cndmask_b32 v5, 0x7fc00000, v8
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v2
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v18, v17, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, 0x7fc00000, v3, vcc_lo
	v_and_or_b32 v3, 0x80000000, v6, v5
	v_and_or_b32 v1, 0x80000000, v1, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v26, v9, v3 :: v_dual_fmac_f32 v25, v18, v1
.LBB0_409:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_wait_loadcnt 0x1
	v_or_b32_e32 v1, 0x80, v41
	s_mov_b32 s11, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s9, v1
	s_cbranch_execz .LBB0_413
; %bb.410:
	v_and_b32_e32 v13, 31, v0
	s_mov_b64 s[6:7], 0x80
	s_mov_b32 s16, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v1, 3, v13
	v_lshlrev_b32_e32 v9, 5, v13
	v_add_co_u32 v1, vcc_lo, v30, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v31, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v1, vcc_lo, 0x400, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	v_add_co_u32 v3, vcc_lo, 0x80, v32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v33, vcc_lo
	s_wait_loadcnt 0x0
	v_add_co_u32 v5, vcc_lo, s36, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, s37, v2, vcc_lo
	v_add_co_u32 v14, vcc_lo, s38, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v15, null, s39, v4, vcc_lo
	v_add_co_u32 v7, vcc_lo, s42, v1
	v_add_co_u32 v1, s0, s0, v9
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, s43, v2, vcc_lo
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0
	v_add_co_u32 v16, vcc_lo, s44, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v17, null, s45, v4, vcc_lo
	v_add_co_u32 v9, vcc_lo, 0x101c, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo
.LBB0_411:                              ; =>This Inner Loop Header: Depth=1
	global_load_b64 v[11:12], v[5:6], off th:TH_LOAD_NT
	global_load_b128 v[1:4], v[9:10], off offset:-28
	global_load_b64 v[23:24], v[7:8], off th:TH_LOAD_NT
	global_load_b128 v[19:22], v[9:10], off offset:-12
	v_add_co_u32 v27, vcc_lo, v14, v13
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v28, null, 0, v15, vcc_lo
	v_add_co_u32 v30, vcc_lo, v16, v13
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v31, null, 0, v17, vcc_lo
	global_load_i8 v18, v[27:28], off
	global_load_i8 v27, v[30:31], off
	s_wait_alu 0xfffe
	s_add_nc_u64 s[6:7], s[6:7], 32
	v_add_co_u32 v5, vcc_lo, 0x100, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo
	v_add_co_u32 v14, vcc_lo, v14, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo
	v_add_co_u32 v7, vcc_lo, 0x100, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo
	v_add_co_u32 v16, vcc_lo, v16, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo
	v_add_co_u32 v9, vcc_lo, 0x400, v9
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo
	s_wait_loadcnt 0x5
	v_and_b32_e32 v28, 15, v11
	v_lshrrev_b32_e32 v30, 2, v11
	s_wait_loadcnt 0x3
	v_and_b32_e32 v52, 15, v23
	v_lshrrev_b32_e32 v53, 2, v23
	v_lshrrev_b32_e32 v54, 6, v23
	v_lshlrev_b32_e32 v28, 2, v28
	v_and_b32_e32 v30, 60, v30
	v_lshlrev_b32_e32 v52, 2, v52
	v_and_b32_e32 v53, 60, v53
	v_lshrrev_b32_e32 v31, 6, v11
	v_lshrrev_b32_e32 v32, 10, v11
	ds_load_b32 v28, v28
	ds_load_b32 v52, v52
	ds_load_b32 v30, v30
	ds_load_b32 v53, v53
	v_lshrrev_b32_e32 v33, 14, v11
	v_lshrrev_b32_e32 v34, 18, v11
	v_lshrrev_b32_e32 v35, 22, v11
	v_lshrrev_b32_e32 v11, 26, v11
	v_lshrrev_b32_e32 v55, 10, v23
	v_lshrrev_b32_e32 v56, 14, v23
	v_lshrrev_b32_e32 v57, 18, v23
	v_lshrrev_b32_e32 v58, 22, v23
	v_lshrrev_b32_e32 v23, 26, v23
	v_lshlrev_b32_e32 v44, 16, v1
	v_and_b32_e32 v54, 60, v54
	v_and_b32_e32 v31, 60, v31
	v_and_b32_e32 v32, 60, v32
	v_and_b32_e32 v33, 60, v33
	s_wait_loadcnt 0x2
	v_lshlrev_b32_e32 v48, 16, v19
	v_and_b32_e32 v34, 60, v34
	v_and_b32_e32 v35, 60, v35
	v_and_b32_e32 v11, 60, v11
	v_and_b32_e32 v55, 60, v55
	v_and_b32_e32 v56, 60, v56
	v_and_b32_e32 v57, 60, v57
	v_and_b32_e32 v58, 60, v58
	v_and_b32_e32 v23, 60, v23
	ds_load_b32 v54, v54
	ds_load_b32 v31, v31
	ds_load_b32 v32, v32
	ds_load_b32 v33, v33
	ds_load_b32 v34, v34
	ds_load_b32 v35, v35
	ds_load_b32 v11, v11
	ds_load_b32 v55, v55
	ds_load_b32 v56, v56
	ds_load_b32 v57, v57
	ds_load_b32 v58, v58
	ds_load_b32 v23, v23
	s_wait_dscnt 0xf
	v_fma_f32 v28, v28, v44, 0
	v_lshlrev_b32_e32 v45, 16, v2
	v_and_b32_e32 v2, 0xffff0000, v2
	v_and_b32_e32 v1, 0xffff0000, v1
	s_wait_dscnt 0xe
	v_fma_f32 v44, v52, v44, 0
	v_lshlrev_b32_e32 v46, 16, v3
	v_and_b32_e32 v36, 15, v12
	v_lshrrev_b32_e32 v37, 2, v12
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v28, v30, v1 :: v_dual_lshlrev_b32 v47, 16, v4
	v_lshlrev_b32_e32 v50, 16, v21
	v_lshrrev_b32_e32 v38, 6, v12
	v_lshlrev_b32_e32 v36, 2, v36
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v28, v31, v45
	v_and_b32_e32 v4, 0xffff0000, v4
	v_lshrrev_b32_e32 v39, 10, v12
	v_and_b32_e32 v38, 60, v38
	ds_load_b32 v36, v36
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v28, v32, v2 :: v_dual_and_b32 v3, 0xffff0000, v3
	v_dual_fmac_f32 v44, v53, v1 :: v_dual_and_b32 v19, 0xffff0000, v19
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v28, v33, v46 :: v_dual_and_b32 v21, 0xffff0000, v21
	v_dual_fmac_f32 v44, v54, v45 :: v_dual_lshlrev_b32 v51, 16, v22
	v_lshlrev_b32_e32 v49, 16, v20
	v_lshrrev_b32_e32 v40, 14, v12
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v28, v34, v3 :: v_dual_and_b32 v37, 60, v37
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v44, v55, v2 :: v_dual_and_b32 v59, 15, v24
	v_lshrrev_b32_e32 v60, 2, v24
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v28, v35, v47
	v_and_b32_e32 v40, 60, v40
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v44, v56, v46
	v_lshlrev_b32_e32 v52, 2, v59
	ds_load_b32 v2, v37
	ds_load_b32 v32, v38
	ds_load_b32 v37, v52
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v44, v57, v3
	v_fmac_f32_e32 v28, v11, v4
	v_lshrrev_b32_e32 v42, 18, v12
	v_lshrrev_b32_e32 v43, 22, v12
	v_lshrrev_b32_e32 v61, 6, v24
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v44, v58, v47
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v28, v36, v48
	v_and_b32_e32 v42, 60, v42
	v_and_b32_e32 v20, 0xffff0000, v20
	v_lshrrev_b32_e32 v12, 26, v12
	v_dual_fmac_f32 v44, v23, v4 :: v_dual_and_b32 v39, 60, v39
	v_lshrrev_b32_e32 v64, 18, v24
	v_lshrrev_b32_e32 v62, 10, v24
	v_lshrrev_b32_e32 v63, 14, v24
	v_and_b32_e32 v12, 60, v12
	v_lshrrev_b32_e32 v65, 22, v24
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v28, v2, v19
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v44, v37, v48 :: v_dual_and_b32 v43, 60, v43
	v_and_b32_e32 v59, 60, v60
	ds_load_b32 v33, v39
	ds_load_b32 v38, v40
	ds_load_b32 v39, v59
	v_and_b32_e32 v60, 60, v61
	v_fmac_f32_e32 v28, v32, v49
	ds_load_b32 v3, v42
	ds_load_b32 v34, v43
	ds_load_b32 v40, v60
	v_and_b32_e32 v30, 60, v63
	v_lshrrev_b32_e32 v24, 26, v24
	s_wait_loadcnt 0x0
	v_and_b32_e32 v2, 7, v27
	v_and_b32_e32 v22, 0xffff0000, v22
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_b32_e32 v24, 60, v24
	v_cvt_f32_ubyte0_e32 v2, v2
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v28, v33, v20
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v44, v39, v19 :: v_dual_and_b32 v53, 60, v64
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v28, v38, v50
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v44, v40, v49 :: v_dual_and_b32 v1, 60, v62
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v28, v3, v21
	ds_load_b32 v12, v12
	ds_load_b32 v1, v1
	ds_load_b32 v30, v30
	v_and_b32_e32 v31, 60, v65
	s_wait_alu 0xfffe
	v_dual_fmac_f32 v28, v34, v51 :: v_dual_add_nc_u32 v3, s6, v13
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v28, v12, v22
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v44, v1, v20
	ds_load_b32 v4, v53
	ds_load_b32 v11, v31
	ds_load_b32 v23, v24
	v_and_b32_e32 v35, 0x7f, v27
	v_and_b32_e32 v24, 0x7f, v18
	v_mul_f32_e32 v1, 0x3b000000, v2
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v44, v30, v50
	v_and_b32_e32 v31, 7, v18
	v_lshl_add_u32 v32, v35, 20, 0x3c000000
	v_lshl_add_u32 v19, v24, 20, 0x3c000000
	v_cmp_lt_u32_e64 s0, 7, v24
	v_cmp_lt_u32_e64 s1, 7, v35
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e64 v1, v1, v32, s1
	v_cmp_ne_u32_e64 s1, 0x7f, v24
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v44, v4, v21
	v_cvt_f32_ubyte0_e32 v31, v31
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v44, v11, v51
	s_wait_dscnt 0x0
	v_dual_mul_f32 v31, 0x3b000000, v31 :: v_dual_fmac_f32 v44, v23, v22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v2, v31, v19, s0
	v_cmp_ne_u32_e64 s0, 0x7f, v35
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v2, 0x7fc00000, v2, s1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cndmask_b32_e64 v1, 0x7fc00000, v1, s0
	v_cmp_le_i32_e64 s0, s9, v3
	v_and_or_b32 v2, 0x80000000, v18, v2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v1, 0x80000000, v27, v1
	s_or_b32 s16, s0, s16
	v_fmac_f32_e32 v26, v28, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v25, v44, v1
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s16
	s_cbranch_execnz .LBB0_411
; %bb.412:
	s_or_b32 exec_lo, exec_lo, s16
.LBB0_413:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	v_dual_mov_b32 v14, v101 :: v_dual_mov_b32 v1, 0
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v6, -1, 0
	global_load_b32 v1, v1, s[40:41]
	v_xor_b32_e32 v2, 16, v6
	v_xor_b32_e32 v4, 8, v6
	v_xor_b32_e32 v7, 4, v6
	v_xor_b32_e32 v8, 2, v6
	v_xor_b32_e32 v9, 1, v6
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v6, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v2, 2, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v6, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	ds_bpermute_b32 v3, v2, v26
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v6, v7, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v8, v6, v8, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v6, v9, vcc_lo
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_add_f32 v5, v26, v3 :: v_dual_lshlrev_b32 v6, 2, v6
	v_lshlrev_b32_e32 v3, 2, v4
	ds_bpermute_b32 v4, v3, v5
	s_wait_dscnt 0x0
	v_dual_add_f32 v5, v5, v4 :: v_dual_lshlrev_b32 v4, 2, v7
	ds_bpermute_b32 v7, v4, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v5, v7
	v_lshlrev_b32_e32 v5, 2, v8
	ds_bpermute_b32 v8, v5, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v6, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, v1, v7
	v_and_b32_e32 v1, 0x7fffffff, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.414:
	v_bfe_u32 v1, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v7, v1, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.415:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.416:
	v_lshrrev_b32_e32 v1, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.417:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	ds_bpermute_b32 v2, v2, v25
	s_wait_dscnt 0x0
	v_dual_mov_b32 v7, 0 :: v_dual_add_f32 v2, v25, v2
	global_load_b32 v7, v7, s[46:47]
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v6, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v3, v7, v2
	v_and_b32_e32 v2, 0x7fffffff, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
	s_cbranch_execz .LBB0_420
; %bb.418:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
	s_cbranch_execnz .LBB0_421
.LBB0_419:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_eq_u32_e32 vcc_lo, 0, v41
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execnz .LBB0_422
	s_branch .LBB0_427
.LBB0_420:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
	s_cbranch_execz .LBB0_419
.LBB0_421:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_eq_u32_e32 vcc_lo, 0, v41
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB0_427
.LBB0_422:
	v_lshlrev_b32_e32 v1, 16, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v3, 0xbfb8aa3b, v1 :: v_dual_lshlrev_b32 v2, 16, v2
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v1
	v_fma_f32 v4, 0xbfb8aa3b, v1, -v3
	v_rndne_f32_e32 v5, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v4, v1, 0xb2a5705f, v4 :: v_dual_sub_f32 v3, v3, v5
	v_add_f32_e32 v3, v3, v4
	v_cvt_i32_f32_e32 v4, v5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v3, v3
	v_ldexp_f32 v3, v3, v4
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0x7f800000, v3, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v3, 1.0, v3
	v_div_scale_f32 v4, null, v3, v3, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v5, v4
	v_fma_f32 v6, -v4, v5, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v5, v6, v5
	v_div_scale_f32 v6, vcc_lo, v1, v3, v1
	v_mul_f32_e32 v7, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v8, -v4, v7, v6
	v_fmac_f32_e32 v7, v8, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v4, -v4, v7, v6
	s_wait_alu 0xfffd
	v_div_fmas_f32 v4, v4, v5, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v1, v4, v3, v1
	v_mul_f32_e32 v2, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.423:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.424:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.425:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.426:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_ashrrev_i32_e32 v30, 31, v29
	s_ashr_i32 s1, s55, 31
	s_mov_b32 s0, s55
	s_wait_alu 0xfffe
	s_mul_u64 s[0:1], s[4:5], s[0:1]
	v_lshlrev_b64_e32 v[2:3], 1, v[29:30]
	s_wait_alu 0xfffe
	s_lshl_b64 s[0:1], s[0:1], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[0:1], s[64:65], s[0:1]
	s_wait_alu 0xfffe
	v_add_co_u32 v2, vcc_lo, s0, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo
	global_store_b16 v[2:3], v1, off
.LBB0_427:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_wait_loadcnt 0x0
	s_wait_storecnt 0x0
	global_inv scope:SCOPE_DEV
	s_wait_loadcnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s0, s2
	s_cbranch_execz .LBB0_430
; %bb.428:
	s_mov_b32 s1, exec_lo
	s_wait_alu 0xfffe
	v_mbcnt_lo_u32_b32 v1, s1, 0
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_eq_u32_e32 vcc_lo, 0, v1
	s_and_b32 s4, exec_lo, vcc_lo
	s_wait_alu 0xfffe
	s_mov_b32 exec_lo, s4
	s_cbranch_execz .LBB0_430
; %bb.429:
	s_bcnt1_i32_b32 s1, s1
	s_wait_alu 0xfffe
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, s1
	s_wait_loadcnt 0x0
	global_atomic_add_u32 v1, v2, s[34:35] scope:SCOPE_DEV
.LBB0_430:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_mov_b32 s1, 0
.LBB0_431:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s1
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_493
; %bb.432:
	s_abs_i32 s0, s3
	s_abs_i32 s5, s10
	s_wait_alu 0xfffe
	s_cvt_f32_u32 s1, s0
	s_sub_co_i32 s4, 0, s0
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_iflag_f32_e32 v1, s1
	v_readfirstlane_b32 s1, v1
	s_mul_f32 s1, s1, 0x4f7ffffe
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_cvt_u32_f32 s1, s1
	s_wait_alu 0xfffe
	s_mul_i32 s4, s4, s1
	s_wait_alu 0xfffe
	s_mul_hi_u32 s4, s1, s4
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, s4
	s_xor_b32 s4, s10, s3
	s_wait_alu 0xfffe
	s_mul_hi_u32 s1, s5, s1
	s_ashr_i32 s4, s4, 31
	s_wait_alu 0xfffe
	s_mul_i32 s6, s1, s0
	s_wait_alu 0xfffe
	s_sub_co_i32 s5, s5, s6
	s_add_co_i32 s6, s1, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s7, s5, s0
	s_cmp_ge_u32 s5, s0
	s_cselect_b32 s1, s6, s1
	s_wait_alu 0xfffe
	s_cselect_b32 s5, s7, s5
	s_add_co_i32 s6, s1, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s5, s0
	s_cselect_b32 s0, s6, s1
	s_abs_i32 s1, s56
	s_wait_alu 0xfffe
	s_xor_b32 s0, s0, s4
	s_cvt_f32_u32 s5, s1
	s_sub_co_i32 s6, 0, s1
	s_wait_alu 0xfffe
	s_sub_co_i32 s4, s0, s4
	v_rcp_iflag_f32_e32 v1, s5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_readfirstlane_b32 s5, v1
	v_mov_b32_e32 v1, 0
	s_mul_f32 s5, s5, 0x4f7ffffe
	v_mov_b32_e32 v2, v1
	s_wait_alu 0xfffe
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)
	s_cvt_u32_f32 s5, s5
	s_wait_alu 0xfffe
	s_mul_i32 s6, s6, s5
	s_wait_alu 0xfffe
	s_mul_hi_u32 s0, s5, s6
	s_abs_i32 s6, s4
	s_wait_alu 0xfffe
	s_add_co_i32 s5, s5, s0
	s_wait_alu 0xfffe
	s_mul_hi_u32 s0, s6, s5
	s_xor_b32 s5, s4, s56
	s_wait_alu 0xfffe
	s_mul_i32 s7, s0, s1
	s_ashr_i32 s5, s5, 31
	s_wait_alu 0xfffe
	s_sub_co_i32 s6, s6, s7
	s_add_co_i32 s7, s0, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s8, s6, s1
	s_cmp_ge_u32 s6, s1
	s_cselect_b32 s0, s7, s0
	s_wait_alu 0xfffe
	s_cselect_b32 s6, s8, s6
	s_add_co_i32 s7, s0, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s6, s1
	s_cselect_b32 s0, s7, s0
	s_ashr_i32 s1, s52, 31
	s_wait_alu 0xfffe
	s_xor_b32 s0, s0, s5
	s_wait_alu 0xfffe
	s_sub_co_i32 s6, s0, s5
	s_mov_b32 s0, s52
	s_wait_alu 0xfffe
	s_ashr_i32 s7, s6, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[0:1], s[6:7], s[0:1]
	s_wait_alu 0xfffe
	s_lshl_b64 s[0:1], s[0:1], 1
	s_wait_kmcnt 0x0
	s_wait_alu 0xfffe
	s_add_nc_u64 s[8:9], s[14:15], s[0:1]
	s_mov_b32 s1, exec_lo
	v_cmpx_gt_i32_e64 s52, v41
	s_cbranch_execz .LBB0_434
; %bb.433:
	v_lshlrev_b32_e32 v2, 1, v41
	global_load_u16 v2, v2, s[8:9]
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v2
	v_and_b32_e32 v3, 0xffff, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v4, v3
	v_or_b32_e32 v5, 0x8000, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v5, v4, vcc_lo
	v_and_b32_e32 v6, 0x7f80, v3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v2, 16, v2
	v_and_b32_e32 v3, 0x7f, v3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s0, 0, v3
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	v_or_b32_e32 v2, v41, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v2, 0xffff, v2
.LBB0_434:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_or_b32_e32 v7, 32, v41
	v_mov_b32_e32 v3, 0
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_2)
	v_cmpx_gt_i32_e64 s52, v7
	s_cbranch_execz .LBB0_436
; %bb.435:
	v_lshlrev_b32_e32 v3, 1, v41
	global_load_u16 v3, v3, s[8:9] offset:64
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v3
	v_and_b32_e32 v4, 0xffff, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v5, v4
	v_or_b32_e32 v6, 0x8000, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v6, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v3, 16, v3
	v_and_b32_e32 v8, 0x7f80, v4
	v_and_b32_e32 v4, 0x7f, v4
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s0, 0, v4
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_or_b32_e32 v3, v41, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v3, 0xffdf, v3
.LBB0_436:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_or_b32_e32 v4, 64, v41
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s52, v4
	s_cbranch_execz .LBB0_438
; %bb.437:
	v_lshlrev_b32_e32 v1, 1, v41
	global_load_u16 v1, v1, s[8:9] offset:128
	s_wait_loadcnt 0x0
	v_and_b32_e32 v4, 0xffff, v1
	v_cmp_gt_i16_e32 vcc_lo, 0, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v5, v4
	v_or_b32_e32 v6, 0x8000, v4
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v1, v6, v5 :: v_dual_and_b32 v8, 0x7f80, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v8
	v_lshlrev_b32_e32 v1, 16, v1
	v_and_b32_e32 v4, 0x7f, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s0, 0, v4
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	v_or_b32_e32 v1, v41, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v1, 0xffbf, v1
.LBB0_438:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_or_b32_e32 v5, 0x60, v41
	v_mov_b32_e32 v4, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s52, v5
	v_mov_b32_e32 v5, 0
	s_and_saveexec_b32 s1, vcc_lo
	s_cbranch_execz .LBB0_440
; %bb.439:
	v_lshlrev_b32_e32 v5, 1, v41
	global_load_u16 v5, v5, s[8:9] offset:192
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v5
	v_and_b32_e32 v6, 0xffff, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v8, v6
	v_or_b32_e32 v9, 0x8000, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v9, v8, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v5, 16, v5
	v_and_b32_e32 v10, 0x7f80, v6
	v_and_b32_e32 v6, 0x7f, v6
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s0, 0, v6
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	v_or_b32_e32 v5, v41, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v5, 0xff9f, v5
.LBB0_440:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_or_b32_e32 v6, 0x80, v41
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s52, v6
	s_cbranch_execz .LBB0_442
; %bb.441:
	v_lshlrev_b32_e32 v4, 1, v41
	global_load_u16 v4, v4, s[8:9] offset:256
	s_wait_loadcnt 0x0
	v_and_b32_e32 v6, 0xffff, v4
	v_cmp_gt_i16_e32 vcc_lo, 0, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_not_b32_e32 v8, v6
	v_or_b32_e32 v9, 0x8000, v6
	v_and_b32_e32 v10, 0x7f80, v6
	v_and_b32_e32 v6, 0x7f, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v9, v8, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v10
	v_cmp_eq_u32_e64 s0, 0, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v4, 16, v4
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_or_b32_e32 v4, v41, v4
	v_xor_b32_e32 v4, 0xff7f, v4
.LBB0_442:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_or_b32_e32 v8, 0xa0, v41
	v_mov_b32_e32 v6, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s52, v8
	v_mov_b32_e32 v8, 0
	s_and_saveexec_b32 s1, vcc_lo
	s_cbranch_execz .LBB0_444
; %bb.443:
	v_lshlrev_b32_e32 v8, 1, v41
	global_load_u16 v8, v8, s[8:9] offset:320
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v8
	v_and_b32_e32 v9, 0xffff, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v10, v9
	v_or_b32_e32 v11, 0x8000, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v8, v11, v10, vcc_lo
	v_and_b32_e32 v12, 0x7f80, v9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v8, 16, v8
	v_and_b32_e32 v9, 0x7f, v9
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s0, 0, v9
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	v_or_b32_e32 v8, v41, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v8, 0xff5f, v8
.LBB0_444:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_or_b32_e32 v9, 0xc0, v41
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s52, v9
	s_cbranch_execz .LBB0_446
; %bb.445:
	v_lshlrev_b32_e32 v6, 1, v41
	global_load_u16 v6, v6, s[8:9] offset:384
	s_wait_loadcnt 0x0
	v_and_b32_e32 v9, 0xffff, v6
	v_cmp_gt_i16_e32 vcc_lo, 0, v6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_not_b32_e32 v10, v9
	v_or_b32_e32 v11, 0x8000, v9
	v_and_b32_e32 v12, 0x7f80, v9
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v6, v11, v10 :: v_dual_and_b32 v9, 0x7f, v9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v12
	v_cmp_eq_u32_e64 s0, 0, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v6, 16, v6
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_or_b32_e32 v6, v41, v6
	v_xor_b32_e32 v6, 0xff3f, v6
.LBB0_446:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_or_b32_e32 v9, 0xe0, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, s52, v9
	v_mov_b32_e32 v9, 0
	s_and_saveexec_b32 s1, vcc_lo
	s_cbranch_execz .LBB0_448
; %bb.447:
	v_lshlrev_b32_e32 v9, 1, v41
	global_load_u16 v9, v9, s[8:9] offset:448
	s_wait_loadcnt 0x0
	v_cmp_gt_i16_e32 vcc_lo, 0, v9
	v_and_b32_e32 v10, 0xffff, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_not_b32_e32 v11, v10
	v_or_b32_e32 v12, 0x8000, v10
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, v12, v11, vcc_lo
	v_and_b32_e32 v13, 0x7f80, v10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v9, 16, v9
	v_and_b32_e32 v10, 0x7f, v10
	v_cmp_ne_u32_e32 vcc_lo, 0x7f80, v13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_eq_u32_e64 s0, 0, v10
	s_or_b32 vcc_lo, vcc_lo, s0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
	v_or_b32_e32 v9, v41, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_xor_b32_e32 v9, 0xff1f, v9
.LBB0_448:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_mul_i32 s0, s6, s56
	v_mbcnt_lo_u32_b32 v19, -1, 0
	s_wait_alu 0xfffe
	s_sub_co_i32 s0, s4, s0
	s_wait_alu 0xfffe
	s_cmp_lt_i32 s0, 0
	s_cbranch_scc1 .LBB0_494
; %bb.449:
	v_xor_b32_e32 v11, 16, v19
	v_max_u32_e32 v10, v2, v3
	v_xor_b32_e32 v12, 8, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v10, v10, v1, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v19, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_max3_u32 v10, v10, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_max3_u32 v10, v10, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	v_lshlrev_b32_e32 v11, 2, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s1, v10
	s_and_not1_b32 s5, 31, s1
	s_and_not1_b32 s1, 0xffff, s1
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s5, v41
	s_and_saveexec_b32 s5, vcc_lo
	s_cbranch_execz .LBB0_451
; %bb.450:
	s_lshr_b32 s8, s1, 5
	s_cmp_gt_u32 s1, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s8, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s8, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s8, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s8, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s8, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s8, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s8, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_451:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_cmp_lt_i32 s0, 1
	s_cbranch_scc1 .LBB0_495
.LBB0_452:
	v_xor_b32_e32 v11, 16, v19
	v_max_u32_e32 v10, v2, v3
	v_xor_b32_e32 v12, 8, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v10, v10, v1, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v19, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_max3_u32 v10, v10, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_max3_u32 v10, v10, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	v_lshlrev_b32_e32 v11, 2, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s5, v10
	s_and_not1_b32 s8, 31, s5
	s_and_not1_b32 s5, 0xffff, s5
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s8, v41
	s_and_saveexec_b32 s8, vcc_lo
	s_cbranch_execz .LBB0_454
; %bb.453:
	s_lshr_b32 s9, s5, 5
	s_cmp_gt_u32 s5, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s9, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s9, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s9, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s9, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s9, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s9, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s9, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_454:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_cmp_lt_i32 s0, 2
	s_mov_b32 s8, -1
	s_cbranch_scc0 .LBB0_496
.LBB0_455:
	s_cmp_lt_i32 s0, 3
	s_mov_b32 s9, -1
	s_cbranch_scc1 .LBB0_499
.LBB0_456:
	v_xor_b32_e32 v11, 16, v19
	v_max_u32_e32 v10, v2, v3
	v_xor_b32_e32 v12, 8, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v10, v10, v1, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v19, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_max3_u32 v10, v10, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_max3_u32 v10, v10, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	v_lshlrev_b32_e32 v11, 2, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s9, v10
	s_wait_alu 0xfffe
	s_and_not1_b32 s11, 31, s9
	s_and_not1_b32 s9, 0xffff, s9
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s11, v41
	s_and_saveexec_b32 s11, vcc_lo
	s_cbranch_execz .LBB0_458
; %bb.457:
	s_lshr_b32 s14, s9, 5
	s_cmp_gt_u32 s9, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s14, 1
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s14, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s14, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s14, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s14, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s14, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s14, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_458:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	s_cmp_lt_i32 s0, 4
	s_mov_b32 s11, -1
	s_cbranch_scc0 .LBB0_500
.LBB0_459:
	s_cmp_lt_i32 s0, 5
	s_mov_b32 s14, -1
	s_cbranch_scc1 .LBB0_503
.LBB0_460:
	v_xor_b32_e32 v11, 16, v19
	v_max_u32_e32 v10, v2, v3
	v_xor_b32_e32 v12, 8, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v10, v10, v1, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v19, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_max3_u32 v10, v10, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_max3_u32 v10, v10, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	v_lshlrev_b32_e32 v11, 2, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s14, v10
	s_wait_alu 0xfffe
	s_and_not1_b32 s15, 31, s14
	s_and_not1_b32 s14, 0xffff, s14
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s15, v41
	s_and_saveexec_b32 s15, vcc_lo
	s_cbranch_execz .LBB0_462
; %bb.461:
	s_lshr_b32 s16, s14, 5
	s_cmp_gt_u32 s14, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s16, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s16, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s16, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s16, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s16, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s16, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s16, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_462:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s15
	s_cmp_lt_i32 s0, 6
	s_mov_b32 s15, -1
	s_cbranch_scc0 .LBB0_504
.LBB0_463:
	s_cmp_lt_i32 s0, 7
	s_mov_b32 s16, -1
	s_cbranch_scc1 .LBB0_465
.LBB0_464:
	v_max_u32_e32 v2, v2, v3
	v_xor_b32_e32 v3, 16, v19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_max3_u32 v1, v2, v1, v5
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_max3_u32 v1, v1, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v19, v3, vcc_lo
	v_xor_b32_e32 v3, 8, v19
	v_max3_u32 v1, v1, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v3, v19, v3 :: v_dual_lshlrev_b32 v2, 2, v2
	ds_bpermute_b32 v2, v2, v1
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v2
	ds_bpermute_b32 v2, v3, v1
	v_xor_b32_e32 v3, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v19, v3, vcc_lo
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v2
	ds_bpermute_b32 v2, v3, v1
	v_xor_b32_e32 v3, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v19, v3, vcc_lo
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v2
	ds_bpermute_b32 v2, v3, v1
	v_xor_b32_e32 v3, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v19, v3, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v2
	v_lshlrev_b32_e32 v2, 2, v3
	ds_bpermute_b32 v2, v2, v1
	s_wait_dscnt 0x0
	v_max_u32_e32 v1, v1, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s16, v1
	s_wait_alu 0xfffe
	s_and_not1_b32 s16, 0xffff, s16
.LBB0_465:
	s_cmp_eq_u32 s0, 0
	s_wait_alu 0xfffe
	s_cselect_b32 s1, s1, -1
	s_cmp_eq_u32 s0, 1
	s_wait_alu 0xfffe
	s_cselect_b32 s1, s5, s1
	s_cmp_eq_u32 s0, 2
	s_wait_alu 0xfffe
	s_cselect_b32 s1, s8, s1
	s_cmp_eq_u32 s0, 3
	s_wait_alu 0xfffe
	s_cselect_b32 s1, s9, s1
	s_cmp_eq_u32 s0, 4
	s_wait_alu 0xfffe
	s_cselect_b32 s1, s11, s1
	s_cmp_eq_u32 s0, 5
	s_wait_alu 0xfffe
	s_cselect_b32 s1, s14, s1
	s_cmp_eq_u32 s0, 6
	s_wait_alu 0xfffe
	s_cselect_b32 s1, s15, s1
	s_cmp_eq_u32 s0, 7
	s_wait_alu 0xfffe
	s_cselect_b32 s5, s16, s1
	s_mul_i32 s1, s4, s3
	s_wait_alu 0xfffe
	s_cmp_gt_i32 s5, -1
	s_cselect_b32 s0, -1, 0
	s_cmp_lt_i32 s5, s52
	s_cselect_b32 s3, -1, 0
	s_sub_co_i32 s1, s10, s1
	s_wait_alu 0xfffe
	s_and_b32 s0, s0, s3
	v_lshl_or_b32 v8, s1, 3, v14
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, s54, v8
	s_wait_alu 0xfffe
	s_and_b32 s1, s0, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s3, s1
	s_cbranch_execz .LBB0_490
; %bb.466:
	v_cndmask_b32_e32 v1, 0, v8, vcc_lo
	s_ashr_i32 s1, s5, 31
	s_lshl_b32 s8, s5, 1
	s_and_b32 s0, s0, exec_lo
	s_wait_alu 0xfffe
	s_cselect_b32 s8, s8, 0
	v_ashrrev_i32_e32 v2, 31, v1
	s_cselect_b32 s0, s1, 0
	s_ashr_i32 s55, s54, 31
	s_wait_alu 0xfffe
	s_mul_i32 s0, s0, s54
	s_lshr_b32 s9, s53, 31
	v_mad_co_u64_u32 v[1:2], null, s8, s54, v[1:2]
	s_mul_i32 s8, s8, s55
	s_ashr_i32 s1, s53, 31
	s_wait_alu 0xfffe
	s_add_co_i32 s9, s53, s9
	s_lshr_b32 s10, s1, 28
	s_wait_alu 0xfffe
	s_ashr_i32 s9, s9, 1
	s_add_co_i32 s10, s53, s10
	v_add3_u32 v2, s8, s0, v2
	v_add_co_u32 v9, vcc_lo, v1, s54
	s_wait_alu 0xfffe
	s_ashr_i32 s0, s9, 31
	s_ashr_i32 s8, s10, 4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, s55, v2, vcc_lo
	s_wait_alu 0xfffe
	v_mul_lo_u32 v13, v1, s0
	v_mul_lo_u32 v16, v9, s0
	s_ashr_i32 s0, s8, 31
	v_mad_co_u64_u32 v[11:12], null, v1, s9, 0
	v_mul_lo_u32 v14, v2, s9
	v_mul_lo_u32 v15, v10, s9
	v_mad_co_u64_u32 v[5:6], null, v9, s9, 0
	v_mul_lo_u32 v17, v2, s8
	s_wait_alu 0xfffe
	v_mul_lo_u32 v18, v1, s0
	v_mad_co_u64_u32 v[3:4], null, v1, s8, 0
	v_mul_lo_u32 v10, v10, s8
	v_mul_lo_u32 v20, v9, s0
	v_mad_co_u64_u32 v[1:2], null, v9, s8, 0
	v_add3_u32 v12, v12, v13, v14
	v_add3_u32 v6, v6, v16, v15
	v_add3_u32 v4, v4, v18, v17
	v_mov_b32_e32 v21, 0
	s_mov_b32 s0, s53
	v_add3_u32 v2, v2, v20, v10
	v_mov_b32_e32 v20, 0
	s_wait_alu 0xfffe
	s_mul_u64 s[0:1], s[6:7], s[0:1]
	s_mov_b32 s6, exec_lo
	v_cmpx_gt_i32_e64 s8, v41
	s_cbranch_execz .LBB0_468
; %bb.467:
	v_lshlrev_b32_e32 v9, 5, v41
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[0:1], 1
	v_add_co_u32 v24, vcc_lo, s18, v5
	s_wait_alu 0xfffe
	s_add_nc_u64 s[10:11], s[12:13], s[10:11]
	s_clause 0x1
	global_load_b128 v[13:16], v9, s[10:11]
	global_load_b128 v[20:23], v9, s[10:11] offset:16
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v25, null, s19, v6, vcc_lo
	v_add_co_u32 v10, vcc_lo, s20, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v17, null, s21, v4, vcc_lo
	v_add_co_u32 v18, vcc_lo, s20, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, s21, v2, vcc_lo
	v_add_co_u32 v9, vcc_lo, v10, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, 0, v17, vcc_lo
	v_add_co_u32 v17, vcc_lo, v18, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, 0, v26, vcc_lo
	s_wait_loadcnt 0x1
	v_and_b32_e32 v32, 0xffff0000, v14
	v_lshlrev_b32_e32 v27, 3, v41
	v_and_b32_e32 v33, 0xffff0000, v13
	v_lshlrev_b32_e32 v13, 16, v13
	v_lshlrev_b32_e32 v14, 16, v14
	s_delay_alu instid0(VALU_DEP_4)
	v_add_co_u32 v24, vcc_lo, v24, v27
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v25, null, 0, v25, vcc_lo
	s_clause 0x1
	global_load_i8 v9, v[9:10], off
	global_load_i8 v10, v[17:18], off
	global_load_b64 v[17:18], v[24:25], off th:TH_LOAD_NT
	v_add_co_u32 v24, vcc_lo, s18, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v25, null, s19, v12, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v24, vcc_lo, v24, v27
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v25, null, 0, v25, vcc_lo
	global_load_b64 v[24:25], v[24:25], off th:TH_LOAD_NT
	s_wait_loadcnt 0x1
	v_lshrrev_b32_e32 v46, 26, v17
	v_lshrrev_b32_e32 v47, 22, v17
	v_lshrrev_b32_e32 v48, 18, v17
	v_lshrrev_b32_e32 v49, 14, v17
	v_lshrrev_b32_e32 v50, 10, v17
	v_lshrrev_b32_e32 v51, 6, v17
	v_lshrrev_b32_e32 v52, 2, v17
	v_and_b32_e32 v17, 15, v17
	v_and_b32_e32 v49, 60, v49
	v_and_b32_e32 v50, 60, v50
	v_and_b32_e32 v51, 60, v51
	v_and_b32_e32 v52, 60, v52
	v_lshlrev_b32_e32 v17, 2, v17
	s_wait_loadcnt 0x0
	v_lshrrev_b32_e32 v60, 26, v24
	v_lshrrev_b32_e32 v61, 22, v24
	v_lshrrev_b32_e32 v62, 18, v24
	v_lshrrev_b32_e32 v63, 14, v24
	v_lshrrev_b32_e32 v64, 10, v24
	v_lshrrev_b32_e32 v65, 6, v24
	v_lshrrev_b32_e32 v66, 2, v24
	v_and_b32_e32 v24, 15, v24
	v_and_b32_e32 v63, 60, v63
	v_and_b32_e32 v64, 60, v64
	v_and_b32_e32 v62, 60, v62
	v_and_b32_e32 v66, 60, v66
	v_lshlrev_b32_e32 v24, 2, v24
	ds_load_b32 v24, v24
	ds_load_b32 v17, v17
	ds_load_b32 v66, v66
	ds_load_b32 v52, v52
	v_and_b32_e32 v48, 60, v48
	v_lshrrev_b32_e32 v53, 26, v25
	v_lshrrev_b32_e32 v54, 22, v25
	v_lshrrev_b32_e32 v55, 18, v25
	v_lshrrev_b32_e32 v56, 14, v25
	v_lshrrev_b32_e32 v57, 10, v25
	v_lshrrev_b32_e32 v58, 6, v25
	v_lshrrev_b32_e32 v59, 2, v25
	v_and_b32_e32 v25, 15, v25
	v_lshrrev_b32_e32 v38, 26, v18
	v_lshrrev_b32_e32 v39, 22, v18
	v_lshrrev_b32_e32 v40, 18, v18
	v_lshrrev_b32_e32 v42, 14, v18
	v_lshrrev_b32_e32 v43, 10, v18
	v_lshrrev_b32_e32 v44, 6, v18
	v_lshrrev_b32_e32 v45, 2, v18
	v_and_b32_e32 v18, 15, v18
	s_wait_dscnt 0x3
	v_fma_f32 v24, v24, v13, 0
	s_wait_dscnt 0x2
	v_fma_f32 v13, v17, v13, 0
	v_and_b32_e32 v26, 0xffff0000, v23
	v_lshlrev_b32_e32 v23, 16, v23
	v_and_b32_e32 v17, 60, v61
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v24, v66, v33
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v13, v52, v33
	v_and_b32_e32 v65, 60, v65
	ds_load_b32 v65, v65
	ds_load_b32 v51, v51
	ds_load_b32 v64, v64
	ds_load_b32 v50, v50
	ds_load_b32 v63, v63
	ds_load_b32 v49, v49
	ds_load_b32 v61, v62
	ds_load_b32 v48, v48
	v_and_b32_e32 v47, 60, v47
	v_and_b32_e32 v28, 0xffff0000, v21
	v_and_b32_e32 v33, 60, v60
	v_lshlrev_b32_e32 v18, 2, v18
	v_and_b32_e32 v46, 60, v46
	ds_load_b32 v17, v17
	ds_load_b32 v47, v47
	v_and_b32_e32 v31, 0xffff0000, v15
	v_and_b32_e32 v30, 0xffff0000, v16
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v24, v65, v14 :: v_dual_and_b32 v45, 60, v45
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v13, v51, v14 :: v_dual_lshlrev_b32 v14, 2, v25
	ds_load_b32 v25, v33
	ds_load_b32 v33, v46
	ds_load_b32 v14, v14
	ds_load_b32 v18, v18
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v24, v64, v32 :: v_dual_lshlrev_b32 v15, 16, v15
	v_and_b32_e32 v27, 0xffff0000, v22
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v13, v50, v32 :: v_dual_lshlrev_b32 v22, 16, v22
	v_lshlrev_b32_e32 v16, 16, v16
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v24, v63, v15 :: v_dual_lshlrev_b32 v21, 16, v21
	v_and_b32_e32 v32, 60, v59
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v13, v49, v15
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v24, v61, v31 :: v_dual_and_b32 v15, 60, v58
	ds_load_b32 v32, v32
	ds_load_b32 v45, v45
	v_and_b32_e32 v44, 60, v44
	ds_load_b32 v15, v15
	ds_load_b32 v44, v44
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v24, v17, v16
	v_and_b32_e32 v29, 0xffff0000, v20
	v_dual_fmac_f32 v13, v48, v31 :: v_dual_lshlrev_b32 v20, 16, v20
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v24, v25, v30 :: v_dual_and_b32 v31, 60, v57
	v_and_b32_e32 v42, 60, v42
	v_and_b32_e32 v25, 60, v55
	v_fmac_f32_e32 v13, v47, v16
	v_and_b32_e32 v16, 60, v56
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v24, v14, v20 :: v_dual_and_b32 v37, 7, v10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v33, v30 :: v_dual_and_b32 v14, 60, v40
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v24, v32, v29 :: v_dual_and_b32 v43, 60, v43
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v37, v37
	v_dual_fmac_f32 v13, v18, v20 :: v_dual_and_b32 v36, 0x7f, v10
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v24, v15, v21
	ds_load_b32 v17, v31
	ds_load_b32 v31, v43
	ds_load_b32 v16, v16
	ds_load_b32 v30, v42
	v_dual_fmac_f32 v13, v45, v29 :: v_dual_and_b32 v18, 60, v54
	ds_load_b32 v20, v25
	ds_load_b32 v14, v14
	v_and_b32_e32 v25, 60, v39
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v13, v44, v21
	v_and_b32_e32 v34, 0x7f, v9
	v_lshl_add_u32 v68, v36, 20, 0x3c000000
	v_and_b32_e32 v29, 60, v53
	ds_load_b32 v15, v18
	ds_load_b32 v18, v25
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v24, v17, v28
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v13, v31, v28
	v_lshl_add_u32 v67, v34, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v34
	v_and_b32_e32 v35, 7, v9
	v_mul_f32_e32 v28, 0x3b000000, v37
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v24, v16, v22
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v13, v30, v22
	v_cvt_f32_ubyte0_e32 v35, v35
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v24, v20, v27
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v13, v14, v27
	v_mul_f32_e32 v21, 0x3b000000, v35
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v24, v15, v23
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v13, v18, v23
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v16, v21, v67, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v36
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v21, v28, v68 :: v_dual_and_b32 v38, 60, v38
	ds_load_b32 v17, v29
	ds_load_b32 v25, v38
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v14, 0x7fc00000, v16, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v36
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_and_or_b32 v9, 0x80000000, v9, v14
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v16, 0x7fc00000, v21, vcc_lo
	v_and_or_b32 v10, 0x80000000, v10, v16
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v24, v17, v26
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v13, v25, v26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fma_f32 v21, v24, v9, 0
	v_fma_f32 v20, v13, v10, 0
.LBB0_468:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s9, exec_lo
	v_cmpx_gt_i32_e64 s8, v7
	s_cbranch_execz .LBB0_472
; %bb.469:
	v_and_b32_e32 v22, 31, v0
	s_lshl_b64 s[0:1], s[0:1], 1
	s_mov_b64 s[6:7], 32
	s_wait_alu 0xfffe
	s_add_nc_u64 s[0:1], s[12:13], s[0:1]
	s_mov_b32 s10, 0
	v_lshlrev_b32_e32 v0, 5, v22
	v_lshlrev_b32_e32 v13, 3, v22
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_add_co_u32 v0, s0, s0, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v7, null, s1, 0, s0
	v_add_co_u32 v9, vcc_lo, 0x41c, v0
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v10, null, 0, v7, vcc_lo
	v_add_co_u32 v0, vcc_lo, v11, v13
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, 0, v12, vcc_lo
	v_add_co_u32 v5, vcc_lo, v5, v13
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo
	v_add_co_u32 v0, vcc_lo, s18, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s19, v7, vcc_lo
	v_add_co_u32 v5, vcc_lo, s18, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, s19, v6, vcc_lo
	v_add_co_u32 v11, vcc_lo, 0x100, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v12, null, 0, v7, vcc_lo
	v_add_co_u32 v13, vcc_lo, 0x100, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo
	v_add_co_u32 v0, vcc_lo, s20, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s21, v4, vcc_lo
	v_add_co_u32 v1, vcc_lo, s20, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo
	v_add_co_u32 v23, vcc_lo, v0, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v24, null, 0, v3, vcc_lo
	v_add_co_u32 v25, vcc_lo, v1, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo
.LBB0_470:                              ; =>This Inner Loop Header: Depth=1
	global_load_b64 v[17:18], v[11:12], off th:TH_LOAD_NT
	global_load_b64 v[15:16], v[13:14], off th:TH_LOAD_NT
	s_clause 0x1
	global_load_b128 v[4:7], v[9:10], off offset:-28
	global_load_b128 v[0:3], v[9:10], off offset:-12
	v_add_co_u32 v27, vcc_lo, v25, v22
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v28, null, 0, v26, vcc_lo
	v_add_co_u32 v29, vcc_lo, v23, v22
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v30, null, 0, v24, vcc_lo
	global_load_i8 v27, v[27:28], off
	global_load_i8 v28, v[29:30], off
	v_add_co_u32 v9, vcc_lo, 0x400, v9
	s_add_nc_u64 s[6:7], s[6:7], 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo
	v_add_co_u32 v11, vcc_lo, 0x100, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v12, null, 0, v12, vcc_lo
	v_add_co_u32 v13, vcc_lo, 0x100, v13
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v14, null, 0, v14, vcc_lo
	v_add_co_u32 v23, vcc_lo, v23, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v24, null, 0, v24, vcc_lo
	v_add_co_u32 v25, vcc_lo, v25, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, 0, v26, vcc_lo
	s_wait_loadcnt 0x5
	v_lshrrev_b32_e32 v30, 2, v17
	s_wait_loadcnt 0x4
	v_lshrrev_b32_e32 v45, 2, v15
	s_wait_loadcnt 0x3
	v_lshlrev_b32_e32 v61, 16, v7
	v_lshlrev_b32_e32 v60, 16, v6
	v_lshlrev_b32_e32 v59, 16, v5
	v_lshlrev_b32_e32 v58, 16, v4
	v_and_b32_e32 v6, 0xffff0000, v6
	v_and_b32_e32 v4, 0xffff0000, v4
	v_and_b32_e32 v29, 15, v17
	v_and_b32_e32 v5, 0xffff0000, v5
	v_and_b32_e32 v44, 15, v15
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v45, 60, v45
	v_lshlrev_b32_e32 v29, 2, v29
	v_lshrrev_b32_e32 v46, 6, v15
	v_lshlrev_b32_e32 v44, 2, v44
	ds_load_b32 v29, v29
	ds_load_b32 v44, v44
	ds_load_b32 v30, v30
	ds_load_b32 v45, v45
	v_lshrrev_b32_e32 v31, 6, v17
	v_lshrrev_b32_e32 v32, 10, v17
	v_lshrrev_b32_e32 v33, 14, v17
	v_lshrrev_b32_e32 v34, 18, v17
	v_lshrrev_b32_e32 v35, 22, v17
	v_lshrrev_b32_e32 v17, 26, v17
	v_lshrrev_b32_e32 v47, 10, v15
	v_lshrrev_b32_e32 v48, 14, v15
	v_lshrrev_b32_e32 v49, 18, v15
	v_lshrrev_b32_e32 v50, 22, v15
	v_lshrrev_b32_e32 v15, 26, v15
	v_and_b32_e32 v46, 60, v46
	v_and_b32_e32 v31, 60, v31
	v_and_b32_e32 v32, 60, v32
	v_and_b32_e32 v33, 60, v33
	v_and_b32_e32 v34, 60, v34
	v_and_b32_e32 v35, 60, v35
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v47, 60, v47
	v_and_b32_e32 v48, 60, v48
	v_and_b32_e32 v49, 60, v49
	v_and_b32_e32 v50, 60, v50
	v_and_b32_e32 v15, 60, v15
	ds_load_b32 v46, v46
	ds_load_b32 v31, v31
	ds_load_b32 v32, v32
	ds_load_b32 v33, v33
	ds_load_b32 v34, v34
	ds_load_b32 v35, v35
	ds_load_b32 v17, v17
	ds_load_b32 v47, v47
	ds_load_b32 v48, v48
	ds_load_b32 v49, v49
	ds_load_b32 v50, v50
	ds_load_b32 v15, v15
	s_wait_dscnt 0xf
	v_fma_f32 v29, v29, v58, 0
	v_and_b32_e32 v36, 15, v18
	v_lshrrev_b32_e32 v37, 2, v18
	v_lshrrev_b32_e32 v38, 6, v18
	v_lshrrev_b32_e32 v39, 10, v18
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v29, v30, v4
	v_lshlrev_b32_e32 v36, 2, v36
	v_and_b32_e32 v37, 60, v37
	v_lshrrev_b32_e32 v40, 14, v18
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v29, v31, v59 :: v_dual_and_b32 v38, 60, v38
	v_fma_f32 v44, v44, v58, 0
	v_lshrrev_b32_e32 v52, 2, v16
	v_lshrrev_b32_e32 v42, 18, v18
	v_and_b32_e32 v39, 60, v39
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v29, v32, v5
	ds_load_b32 v36, v36
	v_lshrrev_b32_e32 v43, 22, v18
	v_and_b32_e32 v40, 60, v40
	v_lshrrev_b32_e32 v53, 6, v16
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v29, v33, v60
	v_and_b32_e32 v52, 60, v52
	v_and_b32_e32 v42, 60, v42
	v_lshrrev_b32_e32 v18, 26, v18
	v_and_b32_e32 v43, 60, v43
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v29, v34, v6 :: v_dual_fmac_f32 v44, v45, v4
	v_and_b32_e32 v51, 15, v16
	v_lshrrev_b32_e32 v54, 10, v16
	v_and_b32_e32 v53, 60, v53
	v_lshrrev_b32_e32 v55, 14, v16
	v_fmac_f32_e32 v44, v46, v59
	v_lshlrev_b32_e32 v51, 2, v51
	v_and_b32_e32 v18, 60, v18
	v_and_b32_e32 v4, 60, v54
	v_and_b32_e32 v30, 60, v55
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v44, v47, v5
	ds_load_b32 v5, v37
	ds_load_b32 v32, v38
	ds_load_b32 v37, v51
	v_fmac_f32_e32 v29, v35, v61
	ds_load_b32 v33, v39
	ds_load_b32 v38, v40
	ds_load_b32 v39, v52
	v_lshrrev_b32_e32 v56, 18, v16
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v44, v48, v60
	v_lshrrev_b32_e32 v57, 22, v16
	v_lshrrev_b32_e32 v16, 26, v16
	s_wait_loadcnt 0x0
	v_and_b32_e32 v35, 0x7f, v28
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v44, v49, v6 :: v_dual_and_b32 v45, 60, v56
	v_and_b32_e32 v7, 0xffff0000, v7
	ds_load_b32 v6, v42
	ds_load_b32 v34, v43
	ds_load_b32 v40, v53
	ds_load_b32 v18, v18
	ds_load_b32 v4, v4
	ds_load_b32 v30, v30
	v_and_b32_e32 v31, 60, v57
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v44, v50, v61
	v_dual_fmac_f32 v29, v17, v7 :: v_dual_lshlrev_b32 v62, 16, v0
	v_lshlrev_b32_e32 v63, 16, v1
	v_and_b32_e32 v0, 0xffff0000, v0
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v44, v15, v7 :: v_dual_and_b32 v1, 0xffff0000, v1
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v29, v36, v62 :: v_dual_and_b32 v16, 60, v16
	v_lshlrev_b32_e32 v64, 16, v2
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v44, v37, v62 :: v_dual_lshlrev_b32 v65, 16, v3
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v29, v5, v0
	ds_load_b32 v7, v45
	ds_load_b32 v15, v31
	ds_load_b32 v16, v16
	v_and_b32_e32 v2, 0xffff0000, v2
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v44, v39, v0 :: v_dual_and_b32 v31, 7, v27
	v_dual_fmac_f32 v29, v32, v63 :: v_dual_and_b32 v0, 7, v28
	v_and_b32_e32 v17, 0x7f, v27
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v44, v40, v63
	v_and_b32_e32 v3, 0xffff0000, v3
	v_cvt_f32_ubyte0_e32 v31, v31
	v_cvt_f32_ubyte0_e32 v0, v0
	v_fmac_f32_e32 v29, v33, v1
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v44, v4, v1
	v_lshl_add_u32 v5, v17, 20, 0x3c000000
	v_lshl_add_u32 v32, v35, 20, 0x3c000000
	v_mul_f32_e32 v31, 0x3b000000, v31
	v_cmp_lt_u32_e64 s0, 7, v17
	v_mul_f32_e32 v0, 0x3b000000, v0
	v_cmp_lt_u32_e64 s1, 7, v35
	v_fmac_f32_e32 v29, v38, v64
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v44, v30, v64
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v1, v31, v5, s0
	v_cmp_ne_u32_e64 s0, 0x7f, v35
	v_cndmask_b32_e64 v0, v0, v32, s1
	v_fmac_f32_e32 v29, v6, v2
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v44, v7, v2
	v_cmp_ne_u32_e64 s1, 0x7f, v17
	s_wait_alu 0xfffe
	v_add_nc_u32_e32 v2, s6, v22
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v0, 0x7fc00000, v0, s0
	v_fmac_f32_e32 v29, v34, v65
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v44, v15, v65
	v_cndmask_b32_e64 v1, 0x7fc00000, v1, s1
	v_cmp_le_i32_e64 s0, s8, v2
	v_and_or_b32 v0, 0x80000000, v28, v0
	v_fmac_f32_e32 v29, v18, v3
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v44, v16, v3
	v_and_or_b32 v1, 0x80000000, v27, v1
	s_or_b32 s10, s0, s10
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v21, v29, v0 :: v_dual_fmac_f32 v20, v44, v1
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s10
	s_cbranch_execnz .LBB0_470
; %bb.471:
	s_or_b32 exec_lo, exec_lo, s10
.LBB0_472:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_mov_b32 s1, 0
	s_mul_i32 s0, s5, 3
	v_xor_b32_e32 v3, 8, v19
	v_mov_b32_e32 v0, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[0:1], s[0:1], 2
	v_xor_b32_e32 v5, 4, v19
	s_wait_alu 0xfffe
	s_add_nc_u64 s[0:1], s[26:27], s[0:1]
	v_xor_b32_e32 v6, 2, v19
	global_load_b32 v1, v0, s[0:1]
	v_xor_b32_e32 v0, 16, v19
	v_xor_b32_e32 v7, 1, v19
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, v19, v0, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v19, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v5, v19, v5 :: v_dual_lshlrev_b32 v0, 2, v0
	ds_bpermute_b32 v2, v0, v21
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v19, v6, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v7, v19, v7 :: v_dual_add_f32 v4, v21, v2
	v_lshlrev_b32_e32 v2, 2, v3
	ds_bpermute_b32 v3, v2, v4
	s_wait_dscnt 0x0
	v_dual_add_f32 v4, v4, v3 :: v_dual_lshlrev_b32 v3, 2, v5
	ds_bpermute_b32 v5, v3, v4
	s_wait_dscnt 0x0
	v_dual_add_f32 v5, v4, v5 :: v_dual_lshlrev_b32 v4, 2, v6
	ds_bpermute_b32 v6, v4, v5
	s_wait_dscnt 0x0
	v_dual_add_f32 v6, v5, v6 :: v_dual_lshlrev_b32 v5, 2, v7
	ds_bpermute_b32 v7, v5, v6
	s_wait_dscnt 0x0
	v_add_f32_e32 v6, v6, v7
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v1, v6
	v_and_b32_e32 v1, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s5, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s5, exec_lo, s5
; %bb.473:
	v_bfe_u32 v1, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v6, v1, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.474:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s5, s5
; %bb.475:
	v_lshrrev_b32_e32 v1, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.476:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	v_mov_b32_e32 v6, 0
	ds_bpermute_b32 v0, v0, v20
	global_load_b32 v6, v6, s[0:1] offset:4
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v20, v0
	ds_bpermute_b32 v2, v2, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v2
	ds_bpermute_b32 v2, v3, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v2
	ds_bpermute_b32 v2, v4, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v2
	ds_bpermute_b32 v2, v5, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v2
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, v6, v0
	v_and_b32_e32 v0, 0x7fffffff, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.477:
	v_bfe_u32 v0, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v2, v0, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.478:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.479:
	v_lshrrev_b32_e32 v0, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.480:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_lshlrev_b32_e32 v1, 16, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1
	v_fma_f32 v3, 0xbfb8aa3b, v1, -v2
	v_rndne_f32_e32 v4, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v2, v2, v4
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v1
	v_fmamk_f32 v3, v1, 0xb2a5705f, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v2, v2, v3
	v_cvt_i32_f32_e32 v3, v4
	v_exp_f32_e32 v2, v2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v2, v2, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	v_add_f32_e32 v2, 1.0, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v2, v2, v1
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v1, v2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v2, v3, v2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
	s_cbranch_execz .LBB0_483
; %bb.481:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
	s_cbranch_execnz .LBB0_484
.LBB0_482:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_eq_u32_e32 vcc_lo, 0, v41
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execnz .LBB0_485
	s_branch .LBB0_490
.LBB0_483:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
	s_cbranch_execz .LBB0_482
.LBB0_484:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_cmp_eq_u32_e32 vcc_lo, 0, v41
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB0_490
.LBB0_485:
	v_lshlrev_b32_e32 v0, 16, v0
	v_lshlrev_b32_e32 v1, 16, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v1, v0, v1
	v_and_b32_e32 v0, 0x7fffffff, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.486:
	v_bfe_u32 v0, v1, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v1, v0, 0x7fff
                                        ; implicit-def: $vgpr1
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.487:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.488:
	v_lshrrev_b32_e32 v0, 16, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.489:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_ashrrev_i32_e32 v9, 31, v8
	s_ashr_i32 s5, s4, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[0:1], s[4:5], s[54:55]
	s_wait_alu 0xfffe
	s_lshl_b64 s[0:1], s[0:1], 1
	v_lshlrev_b64_e32 v[1:2], 1, v[8:9]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[0:1], s[62:63], s[0:1]
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_u32 v1, vcc_lo, s0, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo
	global_store_b16 v[1:2], v0, off
.LBB0_490:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_wait_loadcnt 0x0
	s_wait_storecnt 0x0
	global_inv scope:SCOPE_DEV
	s_wait_loadcnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s0, s2
	s_cbranch_execz .LBB0_493
; %bb.491:
	s_mov_b32 s0, exec_lo
	s_wait_alu 0xfffe
	v_mbcnt_lo_u32_b32 v0, s0, 0
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_eq_u32_e32 vcc_lo, 0, v0
	s_and_b32 s1, exec_lo, vcc_lo
	s_wait_alu 0xfffe
	s_mov_b32 exec_lo, s1
	s_cbranch_execz .LBB0_493
; %bb.492:
	s_bcnt1_i32_b32 s0, s0
	s_wait_alu 0xfffe
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, s0
	s_wait_loadcnt 0x0
	global_atomic_add_u32 v0, v1, s[34:35] scope:SCOPE_DEV
.LBB0_493:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
.LBB0_494:
	s_mov_b32 s1, -1
	s_cmp_lt_i32 s0, 1
	s_cbranch_scc0 .LBB0_452
.LBB0_495:
	s_mov_b32 s5, -1
	s_cmp_lt_i32 s0, 2
	s_mov_b32 s8, -1
	s_cbranch_scc1 .LBB0_455
.LBB0_496:
	v_xor_b32_e32 v11, 16, v19
	v_max_u32_e32 v10, v2, v3
	v_xor_b32_e32 v12, 8, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v10, v10, v1, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v19, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_max3_u32 v10, v10, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_max3_u32 v10, v10, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	v_lshlrev_b32_e32 v11, 2, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s8, v10
	s_wait_alu 0xfffe
	s_and_not1_b32 s9, 31, s8
	s_and_not1_b32 s8, 0xffff, s8
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s9, v41
	s_and_saveexec_b32 s9, vcc_lo
	s_cbranch_execz .LBB0_498
; %bb.497:
	s_lshr_b32 s11, s8, 5
	s_cmp_gt_u32 s8, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s11, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s11, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s11, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s11, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s11, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s11, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s11, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_498:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_cmp_lt_i32 s0, 3
	s_mov_b32 s9, -1
	s_cbranch_scc0 .LBB0_456
.LBB0_499:
	s_cmp_lt_i32 s0, 4
	s_mov_b32 s11, -1
	s_cbranch_scc1 .LBB0_459
.LBB0_500:
	v_xor_b32_e32 v11, 16, v19
	v_max_u32_e32 v10, v2, v3
	v_xor_b32_e32 v12, 8, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v10, v10, v1, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v19, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_max3_u32 v10, v10, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_max3_u32 v10, v10, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	v_lshlrev_b32_e32 v11, 2, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s11, v10
	s_wait_alu 0xfffe
	s_and_not1_b32 s14, 31, s11
	s_and_not1_b32 s11, 0xffff, s11
	v_cmp_eq_u32_e32 vcc_lo, s14, v41
	s_and_saveexec_b32 s14, vcc_lo
	s_cbranch_execz .LBB0_502
; %bb.501:
	s_wait_alu 0xfffe
	s_lshr_b32 s15, s11, 5
	s_cmp_gt_u32 s11, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s15, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s15, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s15, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s15, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s15, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s15, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s15, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_502:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_cmp_lt_i32 s0, 5
	s_mov_b32 s14, -1
	s_cbranch_scc0 .LBB0_460
.LBB0_503:
	s_cmp_lt_i32 s0, 6
	s_mov_b32 s15, -1
	s_cbranch_scc1 .LBB0_463
.LBB0_504:
	v_xor_b32_e32 v11, 16, v19
	v_max_u32_e32 v10, v2, v3
	v_xor_b32_e32 v12, 8, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v11
	v_max3_u32 v10, v10, v1, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v19, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_max3_u32 v10, v10, v4, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_max3_u32 v10, v10, v6, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v12, 2, v12
	v_lshlrev_b32_e32 v11, 2, v11
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 4, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 2, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	v_lshlrev_b32_e32 v12, 2, v12
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v12, v10
	v_xor_b32_e32 v12, 1, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v12
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, v19, v12, vcc_lo
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	v_lshlrev_b32_e32 v11, 2, v12
	ds_bpermute_b32 v11, v11, v10
	s_wait_dscnt 0x0
	v_max_u32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s15, v10
	s_wait_alu 0xfffe
	s_and_not1_b32 s16, 31, s15
	s_and_not1_b32 s15, 0xffff, s15
	s_wait_alu 0xfffe
	v_cmp_eq_u32_e32 vcc_lo, s16, v41
	s_and_saveexec_b32 s16, vcc_lo
	s_cbranch_execz .LBB0_506
; %bb.505:
	s_lshr_b32 s17, s15, 5
	s_cmp_gt_u32 s15, 31
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s17, 1
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s17, 2
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s17, 3
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s17, 4
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s17, 5
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s17, 6
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_cmp_lg_u32 s17, 7
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	s_cselect_b32 vcc_lo, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo
.LBB0_506:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s16
	s_cmp_lt_i32 s0, 7
	s_mov_b32 s16, -1
	s_cbranch_scc0 .LBB0_464
	s_branch .LBB0_465
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_116moe_block_kernelILi1ELi8EEEvNS_9BlockArgsE
		.amdhsa_group_segment_fixed_size 68
		.amdhsa_private_segment_fixed_size 20
		.amdhsa_kernarg_size 208
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 1
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 120
		.amdhsa_next_free_sgpr 97
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 255
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_116moe_block_kernelILi1ELi8EEEvNS_9BlockArgsE,"axG",@progbits,_ZN12_GLOBAL__N_116moe_block_kernelILi1ELi8EEEvNS_9BlockArgsE,comdat
.Lfunc_end0:
