_ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili: ; @_ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili
; %bb.0:
	s_mov_b32 s2, exec_lo
	v_cmpx_gt_u32_e32 16, v0
	s_cbranch_execz .LBB0_2
; %bb.1:
	v_and_b32_e32 v1, 7, v0
	v_lshlrev_b32_e32 v3, 28, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v2, v1, 22, 0.5
	v_cmp_ne_u32_e32 vcc_lo, 1, v1
	v_cndmask_b32_e32 v2, 0.5, v2, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v1, 0, v2 :: v_dual_lshlrev_b32 v2, 2, v0
	v_and_or_b32 v1, 0x80000000, v3, v1
	ds_store_b32 v2, v1
.LBB0_2:
	s_or_b32 exec_lo, exec_lo, s2
	s_load_b64 s[16:17], s[0:1], 0x48
	v_lshrrev_b32_e32 v1, 5, v0
	s_mov_b32 s2, ttmp9
	s_mov_b32 s3, 0
	s_wait_dscnt 0x0
	s_lshl_b64 s[2:3], s[2:3], 3
	s_barrier_signal -1
	v_or_b32_e32 v40, s2, v1
	v_mov_b32_e32 v41, s3
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_wait_kmcnt 0x0
	v_cmp_gt_i64_e32 vcc_lo, s[16:17], v[40:41]
	s_and_saveexec_b32 s2, vcc_lo
	s_cbranch_execz .LBB0_51
; %bb.3:
	s_clause 0x3
	s_load_b32 s26, s[0:1], 0x50
	s_load_b128 s[8:11], s[0:1], 0x0
	s_load_b128 s[12:15], s[0:1], 0x20
	s_load_b32 s19, s[0:1], 0x40
	v_and_b32_e32 v58, 31, v0
	v_dual_cndmask_b32 v0, 0, v41 :: v_dual_cndmask_b32 v1, 0, v40
	s_load_b64 s[28:29], s[0:1], 0x10
	s_lshl_b32 s24, ttmp7, 2
	s_delay_alu instid0(VALU_DEP_2)
	v_or_b32_e32 v70, 0x60, v58
	s_or_b32 s22, s24, 1
	s_or_b32 s20, s24, 2
	s_or_b32 s18, s24, 3
	s_wait_kmcnt 0x0
	s_lshr_b32 s2, s26, 31
	s_ashr_i32 s27, s26, 31
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s26, s2
	s_lshr_b32 s3, s27, 28
	s_wait_alu 0xfffe
	s_ashr_i32 s2, s2, 1
	s_add_co_i32 s3, s26, s3
	s_wait_alu 0xfffe
	s_ashr_i32 s4, s2, 31
	s_ashr_i32 s33, s3, 4
	v_mul_lo_u32 v2, v0, s2
	v_mad_co_u64_u32 v[44:45], null, v1, s2, 0
	v_mul_lo_u32 v3, v1, s4
	v_cmp_gt_i32_e64 s4, s33, v58
	s_ashr_i32 s2, s33, 31
	v_mul_lo_u32 v0, v0, s33
	v_mad_co_u64_u32 v[42:43], null, v1, s33, 0
	v_cndmask_b32_e64 v4, 0, v58, s4
	s_wait_alu 0xfffe
	v_mul_lo_u32 v1, v1, s2
	v_add3_u32 v45, v45, v3, v2
	v_add_co_u32 v6, vcc_lo, s10, v44
	v_lshlrev_b32_e32 v5, 3, v4
	s_add_co_i32 s21, s19, -1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s11, v45, vcc_lo
	v_add_co_u32 v8, vcc_lo, s12, v44
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v9, null, s13, v45, vcc_lo
	v_add3_u32 v43, v43, v1, v0
	v_add_co_u32 v0, vcc_lo, v6, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v7, vcc_lo
	v_add_co_u32 v2, vcc_lo, v8, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v9, vcc_lo
	v_add_co_u32 v10, vcc_lo, s28, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v11, null, s29, v43, vcc_lo
	v_add_co_u32 v15, vcc_lo, s14, v42
	global_load_b64 v[28:29], v[0:1], off th:TH_LOAD_NT
	global_load_b64 v[30:31], v[2:3], off th:TH_LOAD_NT
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v16, null, s15, v43, vcc_lo
	v_add_co_u32 v0, vcc_lo, v10, v4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v11, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s33, v70
	v_add_co_u32 v2, s2, v15, v4
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v3, null, 0, v16, s2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, 0, v70, vcc_lo
	v_lshlrev_b32_e32 v59, 5, v58
	v_or_b32_e32 v12, 32, v58
	global_load_i8 v64, v[0:1], off
	v_or_b32_e32 v73, 64, v58
	v_add_co_u32 v4, s2, v15, v17
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v5, null, 0, v16, s2
	s_min_i32 s2, s22, s21
	v_cndmask_b32_e64 v0, 0, v59, s4
	s_wait_alu 0xfffe
	s_ashr_i32 s3, s2, 31
	s_min_i32 s6, s20, s21
	s_wait_alu 0xfffe
	s_mul_u64 s[34:35], s[2:3], s[26:27]
	v_cmp_gt_i32_e64 s3, s33, v12
	v_cmp_gt_i32_e64 s2, s33, v73
	v_add_co_u32 v13, s5, s8, v0
	s_clause 0x1
	global_load_i8 v65, v[2:3], off
	global_load_u8 v68, v[4:5], off
	s_min_i32 s30, s18, s21
	s_ashr_i32 s7, s6, 31
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v2, 0, v12, s3
	v_add_co_ci_u32_e64 v14, null, s9, 0, s5
	s_ashr_i32 s31, s30, 31
	s_mul_u64 s[6:7], s[6:7], s[26:27]
	s_lshl_b64 s[34:35], s[34:35], 1
	s_mul_u64 s[36:37], s[30:31], s[26:27]
	v_cndmask_b32_e64 v3, 0, v73, s2
	s_lshl_b64 s[30:31], s[6:7], 1
	v_add_co_u32 v0, s5, v13, s34
	v_lshlrev_b32_e32 v18, 3, v2
	s_lshl_b64 s[6:7], s[36:37], 1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v1, null, s35, v14, s5
	v_add_co_u32 v4, s5, v13, s30
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v5, null, s31, v14, s5
	v_add_co_u32 v20, s5, v13, s6
	v_lshlrev_b32_e32 v19, 3, v3
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v21, null, s7, v14, s5
	v_add_co_u32 v32, s5, v6, v18
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v33, null, 0, v7, s5
	v_add_co_u32 v34, s5, v8, v18
	v_lshlrev_b32_e32 v22, 3, v17
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v35, null, 0, v9, s5
	v_add_co_u32 v36, s5, v6, v19
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v37, null, 0, v7, s5
	v_add_co_u32 v38, s5, v8, v19
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v39, null, 0, v9, s5
	v_add_co_u32 v46, s5, v6, v22
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v47, null, 0, v7, s5
	v_add_co_u32 v60, s5, v8, v22
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v61, null, 0, v9, s5
	v_add_co_u32 v6, s5, v10, v2
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v7, null, 0, v11, s5
	v_add_co_u32 v22, s5, v15, v2
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v23, null, 0, v16, s5
	v_add_co_u32 v48, s5, v10, v3
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v49, null, 0, v11, s5
	v_add_co_u32 v50, s5, v15, v3
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v51, null, 0, v16, s5
	v_add_co_u32 v62, s5, v10, v17
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v63, null, 0, v11, s5
	s_clause 0x3
	global_load_b128 v[8:11], v[0:1], off offset:16
	global_load_b128 v[24:27], v[0:1], off
	global_load_b128 v[0:3], v[4:5], off offset:16
	global_load_b128 v[16:19], v[4:5], off
	global_load_u8 v75, v[6:7], off
	global_load_u8 v74, v[22:23], off
	global_load_u8 v72, v[48:49], off
	global_load_u8 v71, v[50:51], off
	s_clause 0x1
	global_load_b128 v[4:7], v[20:21], off offset:16
	global_load_b128 v[20:23], v[20:21], off
	global_load_b64 v[56:57], v[32:33], off th:TH_LOAD_NT
	global_load_b64 v[54:55], v[34:35], off th:TH_LOAD_NT
	global_load_b64 v[52:53], v[36:37], off th:TH_LOAD_NT
	global_load_b64 v[50:51], v[38:39], off th:TH_LOAD_NT
	global_load_b64 v[48:49], v[46:47], off th:TH_LOAD_NT
	global_load_b64 v[46:47], v[60:61], off th:TH_LOAD_NT
	global_load_u8 v69, v[62:63], off
	s_min_i32 s36, s24, s21
	v_mov_b32_e32 v61, 0
	s_ashr_i32 s37, s36, 31
	s_cmp_lt_i32 s24, s19
	s_mul_u64 s[36:37], s[36:37], s[26:27]
	s_cselect_b32 s41, -1, 0
	s_wait_loadcnt 0x15
	v_and_b32_e32 v15, 15, v28
	s_wait_loadcnt 0x14
	v_lshrrev_b32_e32 v89, 22, v31
	v_lshrrev_b32_e32 v32, 2, v28
	v_lshrrev_b32_e32 v33, 6, v28
	v_lshrrev_b32_e32 v34, 10, v28
	v_lshrrev_b32_e32 v35, 14, v28
	v_lshrrev_b32_e32 v36, 18, v28
	v_lshrrev_b32_e32 v37, 22, v28
	v_and_b32_e32 v38, 15, v29
	v_lshrrev_b32_e32 v39, 2, v29
	v_lshrrev_b32_e32 v78, 6, v30
	v_lshrrev_b32_e32 v80, 14, v30
	v_lshrrev_b32_e32 v28, 26, v28
	v_lshrrev_b32_e32 v60, 6, v29
	v_lshrrev_b32_e32 v62, 10, v29
	v_lshrrev_b32_e32 v63, 14, v29
	s_wait_loadcnt 0x13
	v_and_b32_e32 v90, 7, v64
	v_lshrrev_b32_e32 v66, 18, v29
	v_lshrrev_b32_e32 v67, 22, v29
	v_lshrrev_b32_e32 v29, 26, v29
	v_lshrrev_b32_e32 v77, 2, v30
	v_lshrrev_b32_e32 v79, 10, v30
	v_lshrrev_b32_e32 v81, 18, v30
	v_lshrrev_b32_e32 v82, 22, v30
	v_lshrrev_b32_e32 v84, 2, v31
	v_lshrrev_b32_e32 v88, 18, v31
	v_lshlrev_b32_e32 v15, 2, v15
	v_and_b32_e32 v111, 60, v89
	v_cvt_f32_ubyte0_e32 v89, v90
	v_and_b32_e32 v76, 15, v30
	v_lshrrev_b32_e32 v30, 26, v30
	v_and_b32_e32 v32, 60, v32
	v_and_b32_e32 v33, 60, v33
	v_and_b32_e32 v34, 60, v34
	v_and_b32_e32 v35, 60, v35
	v_and_b32_e32 v36, 60, v36
	v_and_b32_e32 v37, 60, v37
	v_lshlrev_b32_e32 v38, 2, v38
	v_and_b32_e32 v39, 60, v39
	v_and_b32_e32 v94, 60, v78
	v_and_b32_e32 v96, 60, v80
	v_and_b32_e32 v28, 60, v28
	v_and_b32_e32 v60, 60, v60
	v_and_b32_e32 v62, 60, v62
	v_and_b32_e32 v63, 60, v63
	v_and_b32_e32 v66, 60, v66
	v_and_b32_e32 v67, 60, v67
	v_and_b32_e32 v29, 60, v29
	v_lshlrev_b32_e32 v93, 2, v76
	v_and_b32_e32 v77, 60, v77
	v_and_b32_e32 v79, 60, v79
	v_and_b32_e32 v81, 60, v81
	v_and_b32_e32 v108, 60, v82
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v109, 60, v84
	v_and_b32_e32 v110, 60, v88
	ds_load_b32 v101, v15
	ds_load_b32 v99, v32
	ds_load_b32 v97, v33
	ds_load_b32 v95, v34
	ds_load_b32 v92, v35
	ds_load_b32 v90, v36
	ds_load_b32 v88, v37
	ds_load_b32 v84, v28
	ds_load_b32 v82, v38
	ds_load_b32 v80, v39
	ds_load_b32 v78, v60
	ds_load_b32 v76, v62
	ds_load_b32 v39, v63
	ds_load_b32 v38, v66
	ds_load_b32 v37, v67
	ds_load_b32 v36, v29
	ds_load_b32 v105, v93
	ds_load_b32 v104, v77
	ds_load_b32 v103, v94
	ds_load_b32 v102, v79
	ds_load_b32 v100, v96
	ds_load_b32 v98, v81
	ds_load_b32 v96, v108
	ds_load_b32 v94, v30
	v_and_b32_e32 v83, 15, v31
	s_wait_loadcnt 0x12
	v_and_b32_e32 v91, 7, v65
	v_and_b32_e32 v106, 0x7f, v64
	v_lshrrev_b32_e32 v85, 6, v31
	v_lshrrev_b32_e32 v86, 10, v31
	v_lshrrev_b32_e32 v87, 14, v31
	v_lshrrev_b32_e32 v31, 26, v31
	v_lshlrev_b32_e32 v83, 2, v83
	v_cvt_f32_ubyte0_e32 v91, v91
	v_and_b32_e32 v107, 0x7f, v65
	v_lshl_add_u32 v112, v106, 20, 0x3c000000
	v_mul_f32_e32 v15, 0x3b000000, v89
	v_cmp_lt_u32_e64 s5, 7, v106
	v_and_b32_e32 v85, 60, v85
	v_and_b32_e32 v86, 60, v86
	v_and_b32_e32 v87, 60, v87
	v_and_b32_e32 v31, 60, v31
	v_mul_f32_e32 v28, 0x3b000000, v91
	ds_load_b32 v93, v83
	ds_load_b32 v91, v109
	ds_load_b32 v89, v85
	ds_load_b32 v85, v86
	ds_load_b32 v83, v87
	ds_load_b32 v81, v110
	ds_load_b32 v79, v111
	ds_load_b32 v77, v31
	v_lshl_add_u32 v113, v107, 20, 0x3c000000
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v15, v15, v112, s5
	v_cmp_lt_u32_e64 s5, 7, v107
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v28, v28, v113, s5
	v_cmp_ne_u32_e64 s5, 0x7f, v106
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v15, 0x7fc00000, v15, s5
	v_cmp_ne_u32_e64 s5, 0x7f, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v86, 0x80000000, v64, v15
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v28, 0x7fc00000, v28, s5
	s_and_b32 s5, s4, s41
	s_delay_alu instid0(VALU_DEP_1)
	v_and_or_b32 v87, 0x80000000, v65, v28
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s21, s5
	s_cbranch_execz .LBB0_5
; %bb.4:
	s_lshl_b64 s[38:39], s[36:37], 1
	s_delay_alu instid0(SALU_CYCLE_1)
	v_add_co_u32 v13, s5, v13, s38
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v14, null, s39, v14, s5
	s_clause 0x1
	global_load_b128 v[28:31], v[13:14], off
	global_load_b128 v[32:35], v[13:14], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v13, 16, v28
	v_and_b32_e32 v14, 0xffff0000, v28
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v15, v101, v13, 0
	s_wait_dscnt 0xf
	v_fma_f32 v13, v105, v13, 0
	v_dual_fmac_f32 v15, v99, v14 :: v_dual_lshlrev_b32 v28, 16, v29
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v104, v14 :: v_dual_and_b32 v14, 0xffff0000, v29
	v_fmac_f32_e32 v15, v97, v28
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v103, v28 :: v_dual_lshlrev_b32 v28, 16, v30
	v_fmac_f32_e32 v15, v95, v14
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v102, v14
	v_dual_fmac_f32 v15, v92, v28 :: v_dual_and_b32 v14, 0xffff0000, v30
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v100, v28 :: v_dual_lshlrev_b32 v28, 16, v31
	v_fmac_f32_e32 v15, v90, v14
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v98, v14 :: v_dual_and_b32 v14, 0xffff0000, v31
	v_fmac_f32_e32 v15, v88, v28
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v96, v28
	s_wait_loadcnt 0x0
	v_dual_fmac_f32 v15, v84, v14 :: v_dual_lshlrev_b32 v28, 16, v32
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v94, v14 :: v_dual_and_b32 v14, 0xffff0000, v32
	v_fmac_f32_e32 v15, v82, v28
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v93, v28 :: v_dual_lshlrev_b32 v28, 16, v33
	v_fmac_f32_e32 v15, v80, v14
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v91, v14 :: v_dual_and_b32 v14, 0xffff0000, v33
	v_fmac_f32_e32 v15, v78, v28
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v89, v28 :: v_dual_lshlrev_b32 v28, 16, v34
	v_fmac_f32_e32 v15, v76, v14
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v85, v14
	v_dual_fmac_f32 v15, v39, v28 :: v_dual_and_b32 v14, 0xffff0000, v34
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v83, v28 :: v_dual_lshlrev_b32 v28, 16, v35
	v_fmac_f32_e32 v15, v38, v14
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v13, v81, v14 :: v_dual_and_b32 v14, 0xffff0000, v35
	v_fmac_f32_e32 v15, v37, v28
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v79, v28
	v_fmac_f32_e32 v15, v36, v14
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v13, v77, v14
	v_fma_f32 v67, v15, v86, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v66, v13, v87, 0
.LBB0_5:
	s_or_b32 exec_lo, exec_lo, s21
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v12, 5, v12
	s_lshl_b64 s[36:37], s[36:37], 1
	s_cmp_lt_i32 s22, s19
	s_cselect_b32 s40, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v12, 0, v12, s3
	s_and_b32 s21, s4, s40
	v_add_co_u32 v106, s5, s8, v12
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v107, null, s9, 0, s5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v28, s5, v106, s36
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v29, null, s37, v107, s5
	s_clause 0x1
	global_load_b128 v[12:15], v[28:29], off offset:16
	global_load_b128 v[28:31], v[28:29], off
	s_and_saveexec_b32 s5, s21
	s_cbranch_execz .LBB0_7
; %bb.6:
	s_wait_loadcnt 0x11
	v_lshlrev_b32_e32 v34, 16, v25
	v_lshlrev_b32_e32 v32, 16, v24
	v_and_b32_e32 v24, 0xffff0000, v24
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v33, v101, v32, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v33, v99, v24
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v33, v97, v34
	s_wait_dscnt 0xf
	v_fma_f32 v32, v105, v32, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v32, v104, v24
	v_and_b32_e32 v24, 0xffff0000, v25
	v_lshlrev_b32_e32 v25, 16, v26
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v32, v103, v34
	v_fmac_f32_e32 v33, v95, v24
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v32, v102, v24
	v_dual_fmac_f32 v33, v92, v25 :: v_dual_and_b32 v24, 0xffff0000, v26
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v32, v100, v25 :: v_dual_lshlrev_b32 v25, 16, v27
	v_fmac_f32_e32 v33, v90, v24
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v32, v98, v24 :: v_dual_fmac_f32 v33, v88, v25
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v32, v96, v25 :: v_dual_lshlrev_b32 v25, 16, v8
	v_and_b32_e32 v24, 0xffff0000, v27
	v_and_b32_e32 v8, 0xffff0000, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v33, v84, v24
	v_fmac_f32_e32 v33, v82, v25
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v32, v94, v24
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v33, v80, v8 :: v_dual_fmac_f32 v32, v93, v25
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v32, v91, v8
	v_and_b32_e32 v8, 0xffff0000, v9
	v_lshlrev_b32_e32 v24, 16, v9
	v_lshlrev_b32_e32 v9, 16, v10
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v33, v78, v24
	v_fmac_f32_e32 v33, v76, v8
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v32, v89, v24 :: v_dual_fmac_f32 v33, v39, v9
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v32, v85, v8
	v_and_b32_e32 v8, 0xffff0000, v10
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v32, v83, v9 :: v_dual_fmac_f32 v33, v38, v8
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v32, v81, v8 :: v_dual_lshlrev_b32 v9, 16, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v33, v37, v9 :: v_dual_and_b32 v8, 0xffff0000, v11
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v32, v79, v9 :: v_dual_fmac_f32 v33, v36, v8
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v32, v77, v8
	v_fma_f32 v61, v33, v86, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v65, v32, v87, 0
.LBB0_7:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_wait_loadcnt 0x11
	v_add_co_u32 v24, s5, v106, s34
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v25, null, s35, v107, s5
	s_cmp_lt_i32 s20, s19
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v63, 0
	s_clause 0x1
	global_load_b128 v[8:11], v[24:25], off offset:16
	global_load_b128 v[24:27], v[24:25], off
	v_mov_b32_e32 v64, 0
	s_cselect_b32 s39, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s21, s4, s39
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_saveexec_b32 s5, s21
	s_cbranch_execz .LBB0_9
; %bb.8:
	s_wait_loadcnt 0x11
	v_lshlrev_b32_e32 v34, 16, v17
	v_lshlrev_b32_e32 v32, 16, v16
	v_and_b32_e32 v16, 0xffff0000, v16
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v33, v101, v32, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v33, v99, v16
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v33, v97, v34
	s_wait_dscnt 0xf
	v_fma_f32 v32, v105, v32, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v32, v104, v16
	v_and_b32_e32 v16, 0xffff0000, v17
	v_lshlrev_b32_e32 v17, 16, v18
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v32, v103, v34
	v_fmac_f32_e32 v33, v95, v16
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v32, v102, v16
	v_dual_fmac_f32 v33, v92, v17 :: v_dual_and_b32 v16, 0xffff0000, v18
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v32, v100, v17 :: v_dual_lshlrev_b32 v17, 16, v19
	v_fmac_f32_e32 v33, v90, v16
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v32, v98, v16 :: v_dual_fmac_f32 v33, v88, v17
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v32, v96, v17 :: v_dual_lshlrev_b32 v17, 16, v0
	v_and_b32_e32 v16, 0xffff0000, v19
	v_and_b32_e32 v0, 0xffff0000, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v33, v84, v16
	v_fmac_f32_e32 v33, v82, v17
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v32, v94, v16
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v33, v80, v0 :: v_dual_fmac_f32 v32, v93, v17
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v32, v91, v0
	v_and_b32_e32 v0, 0xffff0000, v1
	v_lshlrev_b32_e32 v16, 16, v1
	v_lshlrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v33, v78, v16
	v_fmac_f32_e32 v33, v76, v0
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v32, v89, v16 :: v_dual_fmac_f32 v33, v39, v1
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v32, v85, v0
	v_and_b32_e32 v0, 0xffff0000, v2
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v32, v83, v1 :: v_dual_fmac_f32 v33, v38, v0
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v32, v81, v0 :: v_dual_lshlrev_b32 v1, 16, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v33, v37, v1 :: v_dual_and_b32 v0, 0xffff0000, v3
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v32, v79, v1 :: v_dual_fmac_f32 v33, v36, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v32, v77, v0
	v_fma_f32 v64, v33, v86, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v63, v32, v87, 0
.LBB0_9:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_wait_loadcnt 0x11
	v_add_co_u32 v16, s5, v106, s30
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v17, null, s31, v107, s5
	s_cmp_lt_i32 s18, s19
	v_mov_b32_e32 v62, 0
	s_cselect_b32 s38, -1, 0
	s_clause 0x1
	global_load_b128 v[0:3], v[16:17], off offset:16
	global_load_b128 v[32:35], v[16:17], off
	s_wait_alu 0xfffe
	s_and_b32 s5, s4, s38
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s5
	s_cbranch_execz .LBB0_11
; %bb.10:
	s_wait_loadcnt 0xd
	v_lshlrev_b32_e32 v16, 16, v20
	v_lshlrev_b32_e32 v19, 16, v21
	v_and_b32_e32 v17, 0xffff0000, v20
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v18, v101, v16, 0
	s_wait_dscnt 0xf
	v_fma_f32 v16, v105, v16, 0
	v_fmac_f32_e32 v18, v99, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v18, v97, v19
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v16, v104, v17
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v16, v103, v19 :: v_dual_and_b32 v17, 0xffff0000, v21
	v_dual_fmac_f32 v18, v95, v17 :: v_dual_lshlrev_b32 v19, 16, v22
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v16, v102, v17 :: v_dual_and_b32 v17, 0xffff0000, v22
	v_fmac_f32_e32 v18, v92, v19
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v16, v100, v19
	v_dual_fmac_f32 v18, v90, v17 :: v_dual_lshlrev_b32 v19, 16, v23
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v16, v98, v17 :: v_dual_and_b32 v17, 0xffff0000, v23
	v_fmac_f32_e32 v18, v88, v19
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v16, v96, v19 :: v_dual_lshlrev_b32 v19, 16, v4
	v_fmac_f32_e32 v18, v84, v17
	v_and_b32_e32 v4, 0xffff0000, v4
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v16, v94, v17
	v_dual_fmac_f32 v18, v82, v19 :: v_dual_lshlrev_b32 v17, 16, v5
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v16, v93, v19
	v_fmac_f32_e32 v18, v80, v4
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v16, v91, v4
	v_and_b32_e32 v4, 0xffff0000, v5
	v_dual_fmac_f32 v18, v78, v17 :: v_dual_lshlrev_b32 v5, 16, v6
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v16, v89, v17
	v_fmac_f32_e32 v18, v76, v4
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v16, v85, v4
	v_and_b32_e32 v4, 0xffff0000, v6
	v_fmac_f32_e32 v18, v39, v5
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v16, v83, v5 :: v_dual_lshlrev_b32 v5, 16, v7
	v_fmac_f32_e32 v18, v38, v4
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v16, v81, v4
	v_and_b32_e32 v4, 0xffff0000, v7
	v_fmac_f32_e32 v18, v37, v5
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v16, v79, v5
	v_fmac_f32_e32 v18, v36, v4
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v16, v77, v4
	v_fma_f32 v60, v18, v86, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v62, v16, v87, 0
.LBB0_11:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_wait_loadcnt 0xe
	v_add_co_u32 v4, s4, v106, s6
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v5, null, s7, v107, s4
	v_and_b32_e32 v6, 7, v74
	s_wait_loadcnt 0xc
	v_lshrrev_b32_e32 v22, 2, v56
	v_lshrrev_b32_e32 v23, 6, v56
	global_load_b128 v[16:19], v[4:5], off offset:16
	s_wait_dscnt 0x10
	global_load_b128 v[36:39], v[4:5], off
	v_and_b32_e32 v4, 7, v75
	v_cvt_f32_ubyte0_e32 v6, v6
	v_and_b32_e32 v21, 15, v56
	v_lshrrev_b32_e32 v76, 10, v56
	s_wait_dscnt 0x0
	v_lshrrev_b32_e32 v77, 14, v56
	v_cvt_f32_ubyte0_e32 v4, v4
	v_lshrrev_b32_e32 v78, 18, v56
	v_lshrrev_b32_e32 v79, 22, v56
	v_lshrrev_b32_e32 v56, 26, v56
	v_mul_f32_e32 v6, 0x3b000000, v6
	v_dual_mul_f32 v4, 0x3b000000, v4 :: v_dual_lshlrev_b32 v21, 2, v21
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v23, 60, v23
	v_and_b32_e32 v82, 15, v57
	v_and_b32_e32 v76, 60, v76
	v_lshrrev_b32_e32 v84, 2, v57
	v_and_b32_e32 v77, 60, v77
	v_and_b32_e32 v56, 60, v56
	v_lshrrev_b32_e32 v86, 6, v57
	v_and_b32_e32 v78, 60, v78
	v_and_b32_e32 v80, 60, v79
	ds_load_b32 v89, v21
	ds_load_b32 v87, v22
	ds_load_b32 v85, v23
	ds_load_b32 v83, v76
	ds_load_b32 v81, v77
	ds_load_b32 v79, v78
	ds_load_b32 v77, v80
	ds_load_b32 v76, v56
	v_lshrrev_b32_e32 v56, 10, v57
	v_lshrrev_b32_e32 v78, 14, v57
	v_lshrrev_b32_e32 v80, 18, v57
	v_lshlrev_b32_e32 v21, 2, v82
	v_lshrrev_b32_e32 v82, 22, v57
	v_lshrrev_b32_e32 v57, 26, v57
	v_and_b32_e32 v22, 60, v84
	s_wait_loadcnt 0xd
	v_and_b32_e32 v93, 15, v54
	v_and_b32_e32 v23, 60, v86
	v_and_b32_e32 v56, 60, v56
	v_lshrrev_b32_e32 v94, 2, v54
	v_and_b32_e32 v78, 60, v78
	v_and_b32_e32 v90, 60, v80
	v_lshrrev_b32_e32 v95, 6, v54
	v_and_b32_e32 v91, 60, v82
	v_and_b32_e32 v92, 60, v57
	ds_load_b32 v88, v21
	ds_load_b32 v86, v22
	ds_load_b32 v84, v23
	ds_load_b32 v82, v56
	ds_load_b32 v80, v78
	ds_load_b32 v78, v90
	ds_load_b32 v57, v91
	ds_load_b32 v56, v92
	v_lshrrev_b32_e32 v90, 10, v54
	v_lshlrev_b32_e32 v21, 2, v93
	v_lshrrev_b32_e32 v91, 14, v54
	v_lshrrev_b32_e32 v92, 18, v54
	v_lshrrev_b32_e32 v93, 22, v54
	v_lshrrev_b32_e32 v54, 26, v54
	v_and_b32_e32 v22, 60, v94
	v_and_b32_e32 v23, 60, v95
	v_and_b32_e32 v94, 15, v55
	v_and_b32_e32 v5, 0x7f, v75
	v_and_b32_e32 v90, 60, v90
	v_lshrrev_b32_e32 v96, 2, v55
	v_and_b32_e32 v91, 60, v91
	v_and_b32_e32 v93, 60, v93
	v_and_b32_e32 v54, 60, v54
	v_lshrrev_b32_e32 v98, 6, v55
	v_and_b32_e32 v92, 60, v92
	ds_load_b32 v103, v21
	ds_load_b32 v102, v22
	ds_load_b32 v101, v23
	ds_load_b32 v99, v90
	ds_load_b32 v97, v91
	ds_load_b32 v95, v92
	ds_load_b32 v93, v93
	ds_load_b32 v91, v54
	v_lshrrev_b32_e32 v54, 10, v55
	v_lshrrev_b32_e32 v90, 14, v55
	v_lshlrev_b32_e32 v21, 2, v94
	v_lshrrev_b32_e32 v92, 18, v55
	v_lshrrev_b32_e32 v94, 22, v55
	v_lshrrev_b32_e32 v55, 26, v55
	v_lshl_add_u32 v7, v5, 20, 0x3c000000
	v_and_b32_e32 v20, 0x7f, v74
	v_and_b32_e32 v22, 60, v96
	v_cmp_lt_u32_e64 s4, 7, v5
	v_and_b32_e32 v23, 60, v98
	v_and_b32_e32 v54, 60, v54
	v_and_b32_e32 v90, 60, v90
	v_and_b32_e32 v105, 60, v92
	v_and_b32_e32 v106, 60, v94
	v_and_b32_e32 v107, 60, v55
	ds_load_b32 v100, v21
	ds_load_b32 v98, v22
	ds_load_b32 v96, v23
	ds_load_b32 v94, v54
	ds_load_b32 v92, v90
	ds_load_b32 v90, v105
	ds_load_b32 v55, v106
	ds_load_b32 v54, v107
	v_lshl_add_u32 v104, v20, 20, 0x3c000000
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v4, v4, v7, s4
	v_cmp_lt_u32_e64 s4, 7, v20
	v_lshlrev_b32_e32 v21, 24, v75
	v_lshlrev_b32_e32 v7, 24, v74
	s_and_b32 s5, s3, s41
	v_cndmask_b32_e64 v6, v6, v104, s4
	v_cmp_ne_u32_e64 s4, 0x7f, v5
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v4, 0x7fc00000, v4, s4
	v_cmp_ne_u32_e64 s4, 0x7f, v20
	v_and_or_b32 v75, 0x80000000, v21, v4
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v5, 0x7fc00000, v6, s4
	v_and_or_b32 v74, 0x80000000, v7, v5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s5
	s_cbranch_execz .LBB0_13
; %bb.12:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v4, 16, v28
	v_lshlrev_b32_e32 v7, 16, v29
	v_and_b32_e32 v5, 0xffff0000, v28
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v6, v89, v4, 0
	s_wait_dscnt 0xf
	v_fma_f32 v4, v103, v4, 0
	v_fmac_f32_e32 v6, v87, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v6, v85, v7
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v4, v102, v5
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v4, v101, v7 :: v_dual_and_b32 v5, 0xffff0000, v29
	v_dual_fmac_f32 v6, v83, v5 :: v_dual_lshlrev_b32 v7, 16, v30
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v99, v5 :: v_dual_and_b32 v5, 0xffff0000, v30
	v_fmac_f32_e32 v6, v81, v7
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v97, v7
	v_dual_fmac_f32 v6, v79, v5 :: v_dual_lshlrev_b32 v7, 16, v31
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v95, v5 :: v_dual_and_b32 v5, 0xffff0000, v31
	v_fmac_f32_e32 v6, v77, v7
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v93, v7 :: v_dual_lshlrev_b32 v7, 16, v12
	v_fmac_f32_e32 v6, v76, v5
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v91, v5 :: v_dual_and_b32 v5, 0xffff0000, v12
	v_fmac_f32_e32 v6, v88, v7
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v100, v7 :: v_dual_lshlrev_b32 v7, 16, v13
	v_fmac_f32_e32 v6, v86, v5
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v98, v5
	v_dual_fmac_f32 v6, v84, v7 :: v_dual_and_b32 v5, 0xffff0000, v13
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v96, v7 :: v_dual_lshlrev_b32 v7, 16, v14
	v_fmac_f32_e32 v6, v82, v5
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v94, v5 :: v_dual_and_b32 v5, 0xffff0000, v14
	v_fmac_f32_e32 v6, v80, v7
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v92, v7
	v_dual_fmac_f32 v6, v78, v5 :: v_dual_lshlrev_b32 v7, 16, v15
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v90, v5 :: v_dual_and_b32 v5, 0xffff0000, v15
	v_fmac_f32_e32 v6, v57, v7
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v55, v7
	v_fmac_f32_e32 v6, v56, v5
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v4, v54, v5
	v_dual_fmac_f32 v67, v6, v75 :: v_dual_fmac_f32 v66, v4, v74
.LBB0_13:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_lshlrev_b32_e32 v4, 5, v73
	s_and_b32 s5, s3, s40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v4, 0, v4, s2
	v_add_co_u32 v73, s4, s8, v4
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v104, null, s9, 0, s4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v4, s4, v73, s36
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v5, null, s37, v104, s4
	s_wait_loadcnt 0x7
	global_load_b128 v[12:15], v[4:5], off offset:16
	s_wait_loadcnt 0x7
	global_load_b128 v[28:31], v[4:5], off
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s5
	s_cbranch_execz .LBB0_15
; %bb.14:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v4, 16, v24
	v_lshlrev_b32_e32 v7, 16, v25
	v_and_b32_e32 v5, 0xffff0000, v24
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v6, v89, v4, 0
	s_wait_dscnt 0xf
	v_fma_f32 v4, v103, v4, 0
	v_fmac_f32_e32 v6, v87, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v6, v85, v7
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v4, v102, v5
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v4, v101, v7 :: v_dual_and_b32 v5, 0xffff0000, v25
	v_dual_fmac_f32 v6, v83, v5 :: v_dual_lshlrev_b32 v7, 16, v26
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v99, v5 :: v_dual_and_b32 v5, 0xffff0000, v26
	v_fmac_f32_e32 v6, v81, v7
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v97, v7
	v_dual_fmac_f32 v6, v79, v5 :: v_dual_lshlrev_b32 v7, 16, v27
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v95, v5 :: v_dual_and_b32 v5, 0xffff0000, v27
	v_fmac_f32_e32 v6, v77, v7
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v93, v7 :: v_dual_lshlrev_b32 v7, 16, v8
	v_fmac_f32_e32 v6, v76, v5
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v91, v5 :: v_dual_and_b32 v5, 0xffff0000, v8
	v_fmac_f32_e32 v6, v88, v7
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v100, v7 :: v_dual_lshlrev_b32 v7, 16, v9
	v_fmac_f32_e32 v6, v86, v5
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v98, v5
	v_dual_fmac_f32 v6, v84, v7 :: v_dual_and_b32 v5, 0xffff0000, v9
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v96, v7 :: v_dual_lshlrev_b32 v7, 16, v10
	v_fmac_f32_e32 v6, v82, v5
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v94, v5 :: v_dual_and_b32 v5, 0xffff0000, v10
	v_fmac_f32_e32 v6, v80, v7
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v92, v7
	v_dual_fmac_f32 v6, v78, v5 :: v_dual_lshlrev_b32 v7, 16, v11
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v90, v5 :: v_dual_and_b32 v5, 0xffff0000, v11
	v_fmac_f32_e32 v6, v57, v7
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v55, v7
	v_fmac_f32_e32 v6, v56, v5
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v54, v5
	v_fmac_f32_e32 v61, v6, v75
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v65, v4, v74
.LBB0_15:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_wait_loadcnt 0x7
	v_add_co_u32 v8, s4, v73, s34
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v9, null, s35, v104, s4
	s_and_b32 s5, s3, s39
	s_clause 0x1
	global_load_b128 v[4:7], v[8:9], off offset:16
	global_load_b128 v[20:23], v[8:9], off
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s5
	s_cbranch_execz .LBB0_17
; %bb.16:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v8, 16, v32
	v_lshlrev_b32_e32 v11, 16, v33
	v_and_b32_e32 v9, 0xffff0000, v32
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v10, v89, v8, 0
	s_wait_dscnt 0xf
	v_fma_f32 v8, v103, v8, 0
	v_fmac_f32_e32 v10, v87, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v10, v85, v11
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v8, v102, v9
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v8, v101, v11 :: v_dual_and_b32 v9, 0xffff0000, v33
	v_dual_fmac_f32 v10, v83, v9 :: v_dual_lshlrev_b32 v11, 16, v34
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v99, v9 :: v_dual_and_b32 v9, 0xffff0000, v34
	v_fmac_f32_e32 v10, v81, v11
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v97, v11
	v_dual_fmac_f32 v10, v79, v9 :: v_dual_lshlrev_b32 v11, 16, v35
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v95, v9 :: v_dual_and_b32 v9, 0xffff0000, v35
	v_fmac_f32_e32 v10, v77, v11
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v93, v11 :: v_dual_lshlrev_b32 v11, 16, v0
	v_fmac_f32_e32 v10, v76, v9
	v_and_b32_e32 v0, 0xffff0000, v0
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v8, v91, v9
	v_dual_fmac_f32 v10, v88, v11 :: v_dual_lshlrev_b32 v9, 16, v1
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v100, v11
	v_fmac_f32_e32 v10, v86, v0
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v8, v98, v0
	v_and_b32_e32 v0, 0xffff0000, v1
	v_dual_fmac_f32 v10, v84, v9 :: v_dual_lshlrev_b32 v1, 16, v2
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v96, v9
	v_fmac_f32_e32 v10, v82, v0
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v8, v94, v0
	v_and_b32_e32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v10, v80, v1
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v92, v1 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v10, v78, v0
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v8, v90, v0
	v_and_b32_e32 v0, 0xffff0000, v3
	v_fmac_f32_e32 v10, v57, v1
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v55, v1
	v_fmac_f32_e32 v10, v56, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v8, v54, v0
	v_dual_fmac_f32 v64, v10, v75 :: v_dual_fmac_f32 v63, v8, v74
.LBB0_17:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_add_co_u32 v8, s4, v73, s30
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v9, null, s31, v104, s4
	s_and_b32 s4, s3, s38
	s_wait_loadcnt 0x7
	s_clause 0x1
	global_load_b128 v[0:3], v[8:9], off offset:16
	global_load_b128 v[24:27], v[8:9], off
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s3, s4
	s_cbranch_execz .LBB0_19
; %bb.18:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v8, 16, v36
	v_lshlrev_b32_e32 v11, 16, v37
	v_and_b32_e32 v9, 0xffff0000, v36
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v10, v89, v8, 0
	s_wait_dscnt 0xf
	v_fma_f32 v8, v103, v8, 0
	v_fmac_f32_e32 v10, v87, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v10, v85, v11
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v8, v102, v9
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v8, v101, v11 :: v_dual_and_b32 v9, 0xffff0000, v37
	v_dual_fmac_f32 v10, v83, v9 :: v_dual_lshlrev_b32 v11, 16, v38
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v99, v9 :: v_dual_and_b32 v9, 0xffff0000, v38
	v_fmac_f32_e32 v10, v81, v11
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v97, v11
	v_dual_fmac_f32 v10, v79, v9 :: v_dual_lshlrev_b32 v11, 16, v39
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v95, v9 :: v_dual_and_b32 v9, 0xffff0000, v39
	v_fmac_f32_e32 v10, v77, v11
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v93, v11 :: v_dual_lshlrev_b32 v11, 16, v16
	v_fmac_f32_e32 v10, v76, v9
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v91, v9 :: v_dual_and_b32 v9, 0xffff0000, v16
	v_fmac_f32_e32 v10, v88, v11
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v100, v11 :: v_dual_lshlrev_b32 v11, 16, v17
	v_fmac_f32_e32 v10, v86, v9
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v98, v9
	v_dual_fmac_f32 v10, v84, v11 :: v_dual_and_b32 v9, 0xffff0000, v17
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v96, v11 :: v_dual_lshlrev_b32 v11, 16, v18
	v_fmac_f32_e32 v10, v82, v9
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v94, v9 :: v_dual_and_b32 v9, 0xffff0000, v18
	v_fmac_f32_e32 v10, v80, v11
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v92, v11
	v_dual_fmac_f32 v10, v78, v9 :: v_dual_lshlrev_b32 v11, 16, v19
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v8, v90, v9 :: v_dual_and_b32 v9, 0xffff0000, v19
	v_fmac_f32_e32 v10, v57, v11
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v55, v11
	v_fmac_f32_e32 v10, v56, v9
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v8, v54, v9
	v_fmac_f32_e32 v60, v10, v75
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v62, v8, v74
.LBB0_19:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_wait_loadcnt 0x7
	v_add_co_u32 v16, s3, v73, s6
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v17, null, s7, v104, s3
	v_and_b32_e32 v32, 7, v72
	v_and_b32_e32 v33, 7, v71
	v_lshrrev_b32_e32 v34, 2, v52
	s_clause 0x1
	global_load_b128 v[8:11], v[16:17], off offset:16
	global_load_b128 v[16:19], v[16:17], off
	v_lshrrev_b32_e32 v35, 6, v52
	v_cvt_f32_ubyte0_e32 v32, v32
	s_wait_loadcnt 0x8
	v_lshrrev_b32_e32 v36, 14, v52
	v_lshrrev_b32_e32 v37, 18, v52
	v_lshrrev_b32_e32 v38, 22, v52
	v_lshrrev_b32_e32 v39, 26, v52
	s_wait_dscnt 0x8
	v_mul_f32_e32 v91, 0x3b000000, v32
	v_cvt_f32_ubyte0_e32 v32, v33
	v_and_b32_e32 v33, 15, v52
	v_and_b32_e32 v56, 15, v53
	v_lshrrev_b32_e32 v73, 2, v53
	v_and_b32_e32 v36, 60, v36
	s_wait_dscnt 0x4
	v_mul_f32_e32 v94, 0x3b000000, v32
	v_lshlrev_b32_e32 v32, 2, v33
	v_and_b32_e32 v33, 60, v34
	v_and_b32_e32 v34, 60, v35
	v_lshrrev_b32_e32 v35, 10, v52
	v_and_b32_e32 v37, 60, v37
	v_and_b32_e32 v38, 60, v38
	v_lshrrev_b32_e32 v75, 6, v53
	v_and_b32_e32 v52, 60, v39
	v_and_b32_e32 v35, 60, v35
	ds_load_b32 v74, v32
	ds_load_b32 v57, v33
	s_wait_dscnt 0x3
	ds_load_b32 v55, v34
	s_wait_dscnt 0x3
	ds_load_b32 v54, v35
	ds_load_b32 v39, v36
	ds_load_b32 v37, v37
	ds_load_b32 v35, v38
	ds_load_b32 v33, v52
	v_lshrrev_b32_e32 v38, 10, v53
	v_lshlrev_b32_e32 v32, 2, v56
	v_and_b32_e32 v34, 60, v73
	v_lshrrev_b32_e32 v52, 14, v53
	v_lshrrev_b32_e32 v56, 18, v53
	v_lshrrev_b32_e32 v73, 22, v53
	v_lshrrev_b32_e32 v53, 26, v53
	v_and_b32_e32 v79, 15, v50
	v_lshrrev_b32_e32 v80, 2, v50
	v_and_b32_e32 v36, 60, v75
	v_lshrrev_b32_e32 v81, 6, v50
	v_and_b32_e32 v38, 60, v38
	v_and_b32_e32 v75, 60, v52
	v_and_b32_e32 v78, 60, v53
	v_and_b32_e32 v76, 60, v56
	v_and_b32_e32 v77, 60, v73
	ds_load_b32 v73, v32
	ds_load_b32 v56, v34
	ds_load_b32 v53, v36
	ds_load_b32 v52, v38
	ds_load_b32 v38, v75
	ds_load_b32 v36, v76
	ds_load_b32 v34, v77
	ds_load_b32 v32, v78
	v_lshrrev_b32_e32 v78, 10, v50
	v_lshlrev_b32_e32 v75, 2, v79
	v_and_b32_e32 v76, 60, v80
	v_lshrrev_b32_e32 v79, 14, v50
	v_lshrrev_b32_e32 v80, 18, v50
	v_and_b32_e32 v77, 60, v81
	v_lshrrev_b32_e32 v81, 22, v50
	v_lshrrev_b32_e32 v50, 26, v50
	v_and_b32_e32 v83, 15, v51
	v_lshrrev_b32_e32 v85, 2, v51
	v_and_b32_e32 v89, 0x7f, v72
	v_and_b32_e32 v78, 60, v78
	v_and_b32_e32 v79, 60, v79
	v_and_b32_e32 v80, 60, v80
	v_lshrrev_b32_e32 v95, 6, v51
	v_and_b32_e32 v81, 60, v81
	v_and_b32_e32 v50, 60, v50
	ds_load_b32 v88, v75
	ds_load_b32 v87, v76
	ds_load_b32 v86, v77
	ds_load_b32 v84, v78
	ds_load_b32 v82, v79
	ds_load_b32 v80, v80
	ds_load_b32 v78, v81
	ds_load_b32 v76, v50
	v_lshrrev_b32_e32 v79, 10, v51
	v_lshrrev_b32_e32 v81, 14, v51
	v_lshlrev_b32_e32 v50, 2, v83
	v_and_b32_e32 v75, 60, v85
	v_lshrrev_b32_e32 v83, 18, v51
	v_lshrrev_b32_e32 v85, 22, v51
	v_lshrrev_b32_e32 v51, 26, v51
	v_lshl_add_u32 v90, v89, 20, 0x3c000000
	v_and_b32_e32 v92, 0x7f, v71
	v_cmp_lt_u32_e64 s3, 7, v89
	v_and_b32_e32 v77, 60, v95
	v_and_b32_e32 v79, 60, v79
	v_and_b32_e32 v95, 60, v81
	v_and_b32_e32 v96, 60, v83
	v_and_b32_e32 v97, 60, v85
	v_and_b32_e32 v98, 60, v51
	ds_load_b32 v85, v50
	ds_load_b32 v83, v75
	ds_load_b32 v81, v77
	ds_load_b32 v79, v79
	ds_load_b32 v77, v95
	ds_load_b32 v75, v96
	ds_load_b32 v51, v97
	ds_load_b32 v50, v98
	v_lshl_add_u32 v93, v92, 20, 0x3c000000
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v90, v91, v90, s3
	v_cmp_lt_u32_e64 s3, 7, v92
	v_lshlrev_b32_e32 v72, 24, v72
	v_lshlrev_b32_e32 v71, 24, v71
	s_and_b32 s4, s2, s41
	v_cndmask_b32_e64 v91, v94, v93, s3
	v_cmp_ne_u32_e64 s3, 0x7f, v89
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v89, 0x7fc00000, v90, s3
	v_cmp_ne_u32_e64 s3, 0x7f, v92
	v_and_or_b32 v72, 0x80000000, v72, v89
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v90, 0x7fc00000, v91, s3
	v_and_or_b32 v71, 0x80000000, v71, v90
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s3, s4
	s_cbranch_execz .LBB0_21
; %bb.20:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v91, 16, v29
	v_lshlrev_b32_e32 v89, 16, v28
	v_and_b32_e32 v28, 0xffff0000, v28
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v90, v74, v89, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v90, v57, v28
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v90, v55, v91
	s_wait_dscnt 0xf
	v_fma_f32 v89, v88, v89, 0
	s_wait_dscnt 0xe
	v_dual_fmac_f32 v89, v87, v28 :: v_dual_and_b32 v28, 0xffff0000, v29
	v_lshlrev_b32_e32 v29, 16, v30
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v89, v86, v91
	v_fmac_f32_e32 v90, v54, v28
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v89, v84, v28 :: v_dual_and_b32 v28, 0xffff0000, v30
	v_fmac_f32_e32 v90, v39, v29
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v89, v82, v29
	v_dual_fmac_f32 v90, v37, v28 :: v_dual_lshlrev_b32 v29, 16, v31
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v89, v80, v28 :: v_dual_and_b32 v28, 0xffff0000, v31
	v_fmac_f32_e32 v90, v35, v29
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v89, v78, v29
	v_lshlrev_b32_e32 v29, 16, v12
	v_fmac_f32_e32 v90, v33, v28
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v89, v76, v28 :: v_dual_fmac_f32 v90, v73, v29
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v89, v85, v29 :: v_dual_and_b32 v12, 0xffff0000, v12
	v_lshlrev_b32_e32 v28, 16, v13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v90, v56, v12
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v89, v83, v12 :: v_dual_and_b32 v12, 0xffff0000, v13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v90, v53, v28 :: v_dual_lshlrev_b32 v13, 16, v14
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v89, v81, v28
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v89, v79, v12
	v_fmac_f32_e32 v90, v52, v12
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v89, v77, v13 :: v_dual_and_b32 v12, 0xffff0000, v14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v90, v38, v13 :: v_dual_lshlrev_b32 v13, 16, v15
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v89, v75, v12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v90, v36, v12
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v89, v51, v13 :: v_dual_and_b32 v12, 0xffff0000, v15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v90, v34, v13
	v_fmac_f32_e32 v90, v32, v12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v90, v72
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v89, v50, v12
	v_fmac_f32_e32 v66, v89, v71
.LBB0_21:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_wait_loadcnt 0x7
	v_lshlrev_b32_e32 v12, 5, v70
	s_and_b32 s4, s2, s40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo
	v_add_co_u32 v70, s3, s8, v12
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v89, null, s9, 0, s3
	s_wait_loadcnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v28, s3, v70, s36
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v29, null, s37, v89, s3
	s_clause 0x1
	global_load_b128 v[12:15], v[28:29], off offset:16
	global_load_b128 v[28:31], v[28:29], off
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s3, s4
	s_cbranch_execz .LBB0_23
; %bb.22:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v90, 16, v20
	v_and_b32_e32 v20, 0xffff0000, v20
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v91, v74, v90, 0
	s_wait_dscnt 0xf
	v_fma_f32 v90, v88, v90, 0
	v_dual_fmac_f32 v91, v57, v20 :: v_dual_lshlrev_b32 v92, 16, v21
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v90, v87, v20
	v_and_b32_e32 v20, 0xffff0000, v21
	v_lshlrev_b32_e32 v21, 16, v22
	v_fmac_f32_e32 v91, v55, v92
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v90, v86, v92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v91, v54, v20
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v90, v84, v20
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v91, v39, v21 :: v_dual_and_b32 v20, 0xffff0000, v22
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v90, v82, v21 :: v_dual_lshlrev_b32 v21, 16, v23
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v91, v37, v20
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v90, v80, v20 :: v_dual_fmac_f32 v91, v35, v21
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v90, v78, v21 :: v_dual_lshlrev_b32 v21, 16, v4
	v_and_b32_e32 v4, 0xffff0000, v4
	v_and_b32_e32 v20, 0xffff0000, v23
	v_fmac_f32_e32 v91, v33, v20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v91, v73, v21
	v_fmac_f32_e32 v91, v56, v4
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v90, v76, v20
	v_lshlrev_b32_e32 v20, 16, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v91, v53, v20
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v90, v85, v21
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v90, v83, v4
	v_and_b32_e32 v4, 0xffff0000, v5
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v90, v81, v20 :: v_dual_lshlrev_b32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v91, v52, v4
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v90, v79, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v91, v38, v5 :: v_dual_and_b32 v4, 0xffff0000, v6
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v90, v77, v5 :: v_dual_lshlrev_b32 v5, 16, v7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v91, v36, v4
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v90, v75, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v91, v34, v5 :: v_dual_and_b32 v4, 0xffff0000, v7
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v90, v51, v5 :: v_dual_fmac_f32 v91, v32, v4
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v90, v50, v4
	v_fmac_f32_e32 v61, v91, v72
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v65, v90, v71
.LBB0_23:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_wait_loadcnt 0x6
	v_add_co_u32 v20, s3, v70, s34
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v21, null, s35, v89, s3
	s_and_b32 s4, s2, s39
	s_clause 0x1
	global_load_b128 v[4:7], v[20:21], off offset:16
	global_load_b128 v[20:23], v[20:21], off
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s3, s4
	s_cbranch_execz .LBB0_25
; %bb.24:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v90, 16, v24
	v_and_b32_e32 v24, 0xffff0000, v24
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v91, v74, v90, 0
	s_wait_dscnt 0xf
	v_fma_f32 v90, v88, v90, 0
	v_dual_fmac_f32 v91, v57, v24 :: v_dual_lshlrev_b32 v92, 16, v25
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v90, v87, v24
	v_and_b32_e32 v24, 0xffff0000, v25
	v_lshlrev_b32_e32 v25, 16, v26
	v_fmac_f32_e32 v91, v55, v92
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v90, v86, v92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v91, v54, v24
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v90, v84, v24
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v91, v39, v25 :: v_dual_and_b32 v24, 0xffff0000, v26
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v90, v82, v25 :: v_dual_lshlrev_b32 v25, 16, v27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v91, v37, v24
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v90, v80, v24 :: v_dual_fmac_f32 v91, v35, v25
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v90, v78, v25 :: v_dual_lshlrev_b32 v25, 16, v0
	v_and_b32_e32 v0, 0xffff0000, v0
	v_and_b32_e32 v24, 0xffff0000, v27
	v_fmac_f32_e32 v91, v33, v24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v91, v73, v25
	v_fmac_f32_e32 v91, v56, v0
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v90, v76, v24
	v_lshlrev_b32_e32 v24, 16, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v91, v53, v24
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v90, v85, v25
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v90, v83, v0
	v_and_b32_e32 v0, 0xffff0000, v1
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v90, v81, v24 :: v_dual_lshlrev_b32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v91, v52, v0
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v90, v79, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v91, v38, v1 :: v_dual_and_b32 v0, 0xffff0000, v2
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v90, v77, v1 :: v_dual_lshlrev_b32 v1, 16, v3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v91, v36, v0
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v90, v75, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v91, v34, v1 :: v_dual_and_b32 v0, 0xffff0000, v3
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v90, v51, v1 :: v_dual_fmac_f32 v91, v32, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v90, v50, v0
	v_dual_fmac_f32 v64, v91, v72 :: v_dual_fmac_f32 v63, v90, v71
.LBB0_25:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_wait_loadcnt 0x6
	v_add_co_u32 v24, s3, v70, s30
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v25, null, s31, v89, s3
	s_and_b32 s3, s2, s38
	s_clause 0x1
	global_load_b128 v[0:3], v[24:25], off offset:16
	global_load_b128 v[24:27], v[24:25], off
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB0_27
; %bb.26:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v90, 16, v16
	v_and_b32_e32 v16, 0xffff0000, v16
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fma_f32 v74, v74, v90, 0
	s_wait_dscnt 0xf
	v_fma_f32 v88, v88, v90, 0
	v_lshlrev_b32_e32 v90, 16, v17
	v_fmac_f32_e32 v74, v57, v16
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v88, v87, v16
	v_and_b32_e32 v16, 0xffff0000, v17
	v_lshlrev_b32_e32 v17, 16, v18
	v_fmac_f32_e32 v74, v55, v90
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v88, v86, v90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v54, v16
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v88, v84, v16
	v_and_b32_e32 v16, 0xffff0000, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v74, v39, v17
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v88, v82, v17 :: v_dual_lshlrev_b32 v17, 16, v19
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v37, v16
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v88, v80, v16
	v_and_b32_e32 v16, 0xffff0000, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v74, v35, v17
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v88, v78, v17 :: v_dual_lshlrev_b32 v17, 16, v8
	v_and_b32_e32 v8, 0xffff0000, v8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v74, v33, v16
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v88, v76, v16
	v_lshlrev_b32_e32 v16, 16, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v74, v73, v17
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v88, v85, v17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v56, v8
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v88, v83, v8
	v_and_b32_e32 v8, 0xffff0000, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v74, v53, v16 :: v_dual_lshlrev_b32 v9, 16, v10
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v88, v81, v16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v52, v8
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v88, v79, v8
	v_and_b32_e32 v8, 0xffff0000, v10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v74, v38, v9
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v88, v77, v9 :: v_dual_lshlrev_b32 v9, 16, v11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v36, v8
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v88, v75, v8
	v_and_b32_e32 v8, 0xffff0000, v11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v74, v34, v9
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v88, v51, v9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v32, v8
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v88, v50, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v60, v74, v72
	v_fmac_f32_e32 v62, v88, v71
.LBB0_27:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_wait_loadcnt 0x6
	v_add_co_u32 v16, s2, v70, s6
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v17, null, s7, v89, s2
	s_wait_dscnt 0x10
	v_and_b32_e32 v32, 7, v69
	v_and_b32_e32 v33, 7, v68
	v_lshrrev_b32_e32 v34, 2, v48
	s_clause 0x1
	global_load_b128 v[8:11], v[16:17], off offset:16
	global_load_b128 v[16:19], v[16:17], off
	v_lshrrev_b32_e32 v35, 6, v48
	v_cvt_f32_ubyte0_e32 v32, v32
	v_lshrrev_b32_e32 v36, 14, v48
	v_lshrrev_b32_e32 v37, 18, v48
	v_lshrrev_b32_e32 v38, 22, v48
	v_lshrrev_b32_e32 v39, 26, v48
	s_wait_dscnt 0xc
	v_mul_f32_e32 v84, 0x3b000000, v32
	v_cvt_f32_ubyte0_e32 v32, v33
	v_and_b32_e32 v33, 15, v48
	v_and_b32_e32 v52, 15, v49
	v_lshrrev_b32_e32 v54, 2, v49
	v_and_b32_e32 v36, 60, v36
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v87, 0x3b000000, v32 :: v_dual_lshlrev_b32 v32, 2, v33
	v_and_b32_e32 v33, 60, v34
	v_and_b32_e32 v34, 60, v35
	v_lshrrev_b32_e32 v35, 10, v48
	v_and_b32_e32 v37, 60, v37
	v_and_b32_e32 v38, 60, v38
	v_lshrrev_b32_e32 v56, 6, v49
	v_and_b32_e32 v48, 60, v39
	v_and_b32_e32 v35, 60, v35
	ds_load_b32 v55, v32
	ds_load_b32 v53, v33
	s_wait_dscnt 0x3
	ds_load_b32 v51, v34
	s_wait_dscnt 0x3
	ds_load_b32 v50, v35
	ds_load_b32 v39, v36
	ds_load_b32 v37, v37
	ds_load_b32 v35, v38
	ds_load_b32 v33, v48
	v_lshrrev_b32_e32 v38, 10, v49
	v_lshlrev_b32_e32 v32, 2, v52
	v_and_b32_e32 v34, 60, v54
	v_lshrrev_b32_e32 v48, 14, v49
	v_lshrrev_b32_e32 v52, 18, v49
	v_lshrrev_b32_e32 v54, 22, v49
	v_lshrrev_b32_e32 v49, 26, v49
	v_and_b32_e32 v73, 15, v46
	v_lshrrev_b32_e32 v74, 2, v46
	v_and_b32_e32 v36, 60, v56
	v_lshrrev_b32_e32 v75, 6, v46
	v_and_b32_e32 v38, 60, v38
	v_and_b32_e32 v56, 60, v48
	v_and_b32_e32 v72, 60, v49
	v_and_b32_e32 v70, 60, v52
	v_and_b32_e32 v71, 60, v54
	ds_load_b32 v54, v32
	ds_load_b32 v52, v34
	ds_load_b32 v49, v36
	ds_load_b32 v48, v38
	ds_load_b32 v38, v56
	ds_load_b32 v36, v70
	ds_load_b32 v34, v71
	ds_load_b32 v32, v72
	v_lshrrev_b32_e32 v72, 10, v46
	v_lshlrev_b32_e32 v56, 2, v73
	v_and_b32_e32 v70, 60, v74
	v_lshrrev_b32_e32 v73, 14, v46
	v_lshrrev_b32_e32 v74, 18, v46
	v_and_b32_e32 v71, 60, v75
	v_lshrrev_b32_e32 v75, 22, v46
	v_lshrrev_b32_e32 v46, 26, v46
	v_and_b32_e32 v77, 15, v47
	v_lshrrev_b32_e32 v79, 2, v47
	v_and_b32_e32 v57, 0x7f, v69
	v_and_b32_e32 v72, 60, v72
	v_and_b32_e32 v73, 60, v73
	v_and_b32_e32 v74, 60, v74
	v_lshrrev_b32_e32 v88, 6, v47
	v_and_b32_e32 v75, 60, v75
	v_and_b32_e32 v46, 60, v46
	ds_load_b32 v82, v56
	ds_load_b32 v81, v70
	ds_load_b32 v80, v71
	ds_load_b32 v78, v72
	ds_load_b32 v76, v73
	ds_load_b32 v74, v74
	ds_load_b32 v72, v75
	ds_load_b32 v70, v46
	v_lshrrev_b32_e32 v73, 10, v47
	v_lshrrev_b32_e32 v75, 14, v47
	v_lshlrev_b32_e32 v46, 2, v77
	v_and_b32_e32 v56, 60, v79
	v_lshrrev_b32_e32 v77, 18, v47
	v_lshrrev_b32_e32 v79, 22, v47
	v_lshrrev_b32_e32 v47, 26, v47
	v_lshl_add_u32 v83, v57, 20, 0x3c000000
	v_and_b32_e32 v85, 0x7f, v68
	v_cmp_lt_u32_e64 s2, 7, v57
	v_and_b32_e32 v71, 60, v88
	v_and_b32_e32 v73, 60, v73
	v_and_b32_e32 v88, 60, v75
	v_and_b32_e32 v89, 60, v77
	v_and_b32_e32 v90, 60, v79
	v_and_b32_e32 v91, 60, v47
	ds_load_b32 v79, v46
	ds_load_b32 v77, v56
	ds_load_b32 v75, v71
	ds_load_b32 v73, v73
	ds_load_b32 v71, v88
	ds_load_b32 v56, v89
	ds_load_b32 v47, v90
	ds_load_b32 v46, v91
	v_lshl_add_u32 v86, v85, 20, 0x3c000000
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v83, v84, v83, s2
	v_cmp_lt_u32_e64 s2, 7, v85
	v_lshlrev_b32_e32 v69, 24, v69
	s_and_b32 s3, vcc_lo, s41
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v84, v87, v86, s2
	v_cmp_ne_u32_e64 s2, 0x7f, v57
	v_lshlrev_b32_e32 v86, 24, v68
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v57, 0x7fc00000, v83, s2
	v_cmp_ne_u32_e64 s2, 0x7f, v85
	v_and_or_b32 v68, 0x80000000, v69, v57
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v83, 0x7fc00000, v84, s2
	v_and_or_b32 v57, 0x80000000, v86, v83
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execnz .LBB0_43
; %bb.28:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_and_b32 s3, vcc_lo, s40
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execnz .LBB0_44
.LBB0_29:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_and_b32 s3, vcc_lo, s39
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execnz .LBB0_45
.LBB0_30:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_and_b32 s3, vcc_lo, s38
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB0_32
.LBB0_31:
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v0, 16, v16
	v_lshlrev_b32_e32 v3, 16, v17
	v_and_b32_e32 v1, 0xffff0000, v16
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v2, v55, v0, 0
	s_wait_dscnt 0xf
	v_fma_f32 v0, v82, v0, 0
	v_fmac_f32_e32 v2, v53, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v2, v51, v3
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v0, v81, v1
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v0, v80, v3 :: v_dual_and_b32 v1, 0xffff0000, v17
	v_dual_fmac_f32 v2, v50, v1 :: v_dual_lshlrev_b32 v3, 16, v18
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v78, v1 :: v_dual_and_b32 v1, 0xffff0000, v18
	v_fmac_f32_e32 v2, v39, v3
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v76, v3
	v_dual_fmac_f32 v2, v37, v1 :: v_dual_lshlrev_b32 v3, 16, v19
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v74, v1 :: v_dual_and_b32 v1, 0xffff0000, v19
	v_fmac_f32_e32 v2, v35, v3
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v72, v3 :: v_dual_lshlrev_b32 v3, 16, v8
	v_fmac_f32_e32 v2, v33, v1
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v70, v1 :: v_dual_and_b32 v1, 0xffff0000, v8
	v_fmac_f32_e32 v2, v54, v3
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v79, v3 :: v_dual_lshlrev_b32 v3, 16, v9
	v_fmac_f32_e32 v2, v52, v1
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v77, v1
	v_dual_fmac_f32 v2, v49, v3 :: v_dual_and_b32 v1, 0xffff0000, v9
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v75, v3 :: v_dual_lshlrev_b32 v3, 16, v10
	v_fmac_f32_e32 v2, v48, v1
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v73, v1 :: v_dual_and_b32 v1, 0xffff0000, v10
	v_fmac_f32_e32 v2, v38, v3
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v71, v3
	v_dual_fmac_f32 v2, v36, v1 :: v_dual_lshlrev_b32 v3, 16, v11
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v56, v1 :: v_dual_and_b32 v1, 0xffff0000, v11
	v_fmac_f32_e32 v2, v34, v3
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v47, v3
	v_fmac_f32_e32 v2, v32, v1
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v46, v1
	v_fmac_f32_e32 v60, v2, v68
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v62, v0, v57
.LBB0_32:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_clause 0x1
	s_load_b64 s[2:3], s[0:1], 0x18
	s_load_b128 s[4:7], s[0:1], 0x30
	s_wait_loadcnt 0x3
	v_or_b32_e32 v0, 0x80, v58
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s33, v0
	s_cbranch_execz .LBB0_47
; %bb.33:
	v_lshlrev_b32_e32 v0, 3, v58
	s_ashr_i32 s25, s24, 31
	s_ashr_i32 s23, s22, 31
	s_ashr_i32 s21, s20, 31
	s_ashr_i32 s19, s18, 31
	v_add_co_u32 v0, vcc_lo, v44, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v45, vcc_lo
	s_mul_u64 s[30:31], s[26:27], s[24:25]
	v_add_co_u32 v2, vcc_lo, 0x400, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v1, vcc_lo
	s_mul_u64 s[34:35], s[26:27], s[22:23]
	v_add_co_u32 v0, vcc_lo, s10, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s11, v3, vcc_lo
	v_add_co_u32 v6, vcc_lo, 0x80, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, 0, v43, vcc_lo
	s_mul_u64 s[36:37], s[26:27], s[20:21]
	v_add_co_u32 v4, vcc_lo, s28, v6
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s29, v7, vcc_lo
	v_add_co_u32 v2, vcc_lo, s12, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo
	v_add_co_u32 v6, vcc_lo, s14, v6
	s_mul_u64 s[26:27], s[26:27], s[18:19]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo
	s_wait_alu 0xfffe
	s_lshl_b64 s[30:31], s[30:31], 1
	s_lshl_b64 s[34:35], s[34:35], 1
	s_lshl_b64 s[36:37], s[36:37], 1
	s_lshl_b64 s[26:27], s[26:27], 1
	s_wait_alu 0xfffe
	s_add_nc_u64 s[30:31], s[8:9], s[30:31]
	s_add_nc_u64 s[34:35], s[8:9], s[34:35]
	s_mov_b64 s[10:11], 0x80
	s_add_nc_u64 s[12:13], s[8:9], s[36:37]
	s_add_nc_u64 s[8:9], s[8:9], s[26:27]
	s_mov_b32 s14, 0
	s_branch .LBB0_35
.LBB0_34:                               ;   in Loop: Header=BB0_35 Depth=1
	s_add_nc_u64 s[10:11], s[10:11], 32
	v_add_co_u32 v0, vcc_lo, 0x100, v0
	s_wait_dscnt 0x10
	s_wait_alu 0xfffe
	v_add_nc_u32_e32 v8, s10, v58
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo
	v_add_co_u32 v4, vcc_lo, v4, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo
	v_add_co_u32 v2, vcc_lo, 0x100, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo
	v_cmp_le_i32_e32 vcc_lo, s33, v8
	v_add_co_u32 v6, s0, v6, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v7, null, 0, v7, s0
	s_add_nc_u64 s[8:9], s[8:9], 0x400
	s_add_nc_u64 s[12:13], s[12:13], 0x400
	s_add_nc_u64 s[34:35], s[34:35], 0x400
	s_or_b32 s14, vcc_lo, s14
	s_add_nc_u64 s[30:31], s[30:31], 0x400
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s14
	s_cbranch_execz .LBB0_46
.LBB0_35:                               ; =>This Inner Loop Header: Depth=1
	v_add_co_u32 v12, vcc_lo, v4, v58
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v13, null, 0, v5, vcc_lo
	v_add_co_u32 v14, vcc_lo, v6, v58
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v15, null, 0, v7, vcc_lo
	s_wait_loadcnt 0x1
	global_load_b64 v[8:9], v[0:1], off th:TH_LOAD_NT
	global_load_b64 v[10:11], v[2:3], off th:TH_LOAD_NT
	s_wait_loadcnt 0x2
	global_load_i8 v17, v[12:13], off
	global_load_i8 v44, v[14:15], off
	s_wait_loadcnt 0x3
	v_lshrrev_b32_e32 v13, 2, v8
	v_lshrrev_b32_e32 v14, 6, v8
	s_wait_loadcnt 0x1
	v_and_b32_e32 v45, 0x7f, v17
	s_wait_loadcnt_dscnt 0x1
	v_and_b32_e32 v47, 7, v44
	v_and_b32_e32 v43, 7, v17
	v_lshrrev_b32_e32 v15, 10, v8
	v_lshrrev_b32_e32 v16, 14, v8
	v_lshl_add_u32 v75, v45, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v47, v47
	v_and_b32_e32 v12, 15, v8
	v_cmp_lt_u32_e32 vcc_lo, 7, v45
	s_wait_dscnt 0x0
	v_and_b32_e32 v46, 0x7f, v44
	v_lshrrev_b32_e32 v18, 18, v8
	v_lshrrev_b32_e32 v19, 22, v8
	v_lshrrev_b32_e32 v8, 26, v8
	v_lshrrev_b32_e32 v30, 10, v10
	v_lshrrev_b32_e32 v32, 18, v10
	v_lshrrev_b32_e32 v21, 2, v9
	v_lshrrev_b32_e32 v22, 6, v9
	v_lshrrev_b32_e32 v23, 10, v9
	v_lshrrev_b32_e32 v24, 14, v9
	v_lshrrev_b32_e32 v25, 18, v9
	v_lshrrev_b32_e32 v26, 22, v9
	v_and_b32_e32 v27, 15, v10
	v_lshrrev_b32_e32 v28, 2, v10
	v_lshrrev_b32_e32 v29, 6, v10
	v_lshrrev_b32_e32 v31, 14, v10
	v_lshrrev_b32_e32 v33, 22, v10
	v_lshrrev_b32_e32 v10, 26, v10
	v_lshrrev_b32_e32 v35, 2, v11
	v_lshrrev_b32_e32 v36, 6, v11
	v_lshrrev_b32_e32 v37, 10, v11
	v_lshrrev_b32_e32 v38, 14, v11
	v_lshrrev_b32_e32 v39, 18, v11
	v_lshrrev_b32_e32 v42, 22, v11
	v_cvt_f32_ubyte0_e32 v76, v43
	v_and_b32_e32 v20, 15, v9
	v_lshrrev_b32_e32 v9, 26, v9
	v_lshl_add_u32 v77, v46, 20, 0x3c000000
	v_mul_f32_e32 v47, 0x3b000000, v47
	v_and_b32_e32 v34, 15, v11
	v_lshrrev_b32_e32 v11, 26, v11
	v_lshlrev_b32_e32 v12, 2, v12
	v_and_b32_e32 v13, 60, v13
	v_and_b32_e32 v14, 60, v14
	v_and_b32_e32 v15, 60, v15
	v_and_b32_e32 v16, 60, v16
	v_and_b32_e32 v18, 60, v18
	v_and_b32_e32 v8, 60, v8
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v32, 60, v32
	v_and_b32_e32 v19, 60, v19
	v_lshlrev_b32_e32 v20, 2, v20
	v_and_b32_e32 v48, 60, v21
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v49, 60, v23
	v_and_b32_e32 v24, 60, v24
	v_and_b32_e32 v50, 60, v25
	v_and_b32_e32 v26, 60, v26
	v_and_b32_e32 v51, 60, v9
	v_lshlrev_b32_e32 v52, 2, v27
	v_and_b32_e32 v28, 60, v28
	v_and_b32_e32 v53, 60, v29
	v_and_b32_e32 v54, 60, v31
	v_and_b32_e32 v55, 60, v33
	v_and_b32_e32 v56, 60, v10
	v_lshlrev_b32_e32 v57, 2, v34
	v_and_b32_e32 v68, 60, v35
	v_and_b32_e32 v69, 60, v36
	v_and_b32_e32 v70, 60, v37
	v_and_b32_e32 v71, 60, v38
	v_and_b32_e32 v72, 60, v39
	v_and_b32_e32 v73, 60, v42
	v_and_b32_e32 v74, 60, v11
	ds_load_b32 v37, v12
	ds_load_b32 v35, v13
	ds_load_b32 v33, v14
	ds_load_b32 v31, v15
	ds_load_b32 v29, v16
	ds_load_b32 v27, v18
	ds_load_b32 v25, v19
	ds_load_b32 v23, v8
	ds_load_b32 v21, v20
	ds_load_b32 v18, v48
	ds_load_b32 v15, v22
	ds_load_b32 v12, v49
	ds_load_b32 v11, v24
	ds_load_b32 v10, v50
	ds_load_b32 v9, v26
	ds_load_b32 v8, v51
	ds_load_b32 v43, v52
	ds_load_b32 v42, v28
	ds_load_b32 v39, v53
	ds_load_b32 v38, v30
	ds_load_b32 v36, v54
	ds_load_b32 v34, v32
	ds_load_b32 v32, v55
	ds_load_b32 v30, v56
	v_mul_f32_e32 v19, 0x3b000000, v76
	ds_load_b32 v28, v57
	ds_load_b32 v26, v68
	ds_load_b32 v24, v69
	ds_load_b32 v22, v70
	ds_load_b32 v20, v71
	ds_load_b32 v16, v72
	ds_load_b32 v14, v73
	ds_load_b32 v13, v74
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v19, v19, v75, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v46
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v47, v47, v77, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v19, 0x7fc00000, v19, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_and_or_b32 v19, 0x80000000, v17, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v45, 0x7fc00000, v47, vcc_lo
	s_and_not1_b32 vcc_lo, exec_lo, s41
	v_and_or_b32 v17, 0x80000000, v44, v45
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_39
; %bb.36:                               ;   in Loop: Header=BB0_35 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s40
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_40
.LBB0_37:                               ;   in Loop: Header=BB0_35 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s39
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_41
.LBB0_38:                               ;   in Loop: Header=BB0_35 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s38
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_34
	s_branch .LBB0_42
.LBB0_39:                               ;   in Loop: Header=BB0_35 Depth=1
	v_add_co_u32 v48, s0, s30, v59
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v49, null, s31, 0, s0
	s_clause 0x1
	global_load_b128 v[44:47], v[48:49], off offset:4096
	global_load_b128 v[48:51], v[48:49], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v54, 16, v45
	v_lshlrev_b32_e32 v52, 16, v44
	v_and_b32_e32 v44, 0xffff0000, v44
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v53, v37, v52, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v53, v35, v44
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v33, v54
	s_wait_dscnt 0xf
	v_fma_f32 v52, v43, v52, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v52, v42, v44
	v_and_b32_e32 v44, 0xffff0000, v45
	v_lshlrev_b32_e32 v45, 16, v46
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v39, v54
	v_fmac_f32_e32 v53, v31, v44
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v38, v44
	v_dual_fmac_f32 v53, v29, v45 :: v_dual_and_b32 v44, 0xffff0000, v46
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v36, v45 :: v_dual_lshlrev_b32 v45, 16, v47
	v_fmac_f32_e32 v53, v27, v44
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v34, v44
	v_dual_fmac_f32 v53, v25, v45 :: v_dual_and_b32 v44, 0xffff0000, v47
	s_wait_loadcnt_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v52, v32, v45 :: v_dual_lshlrev_b32 v45, 16, v48
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v52, v30, v44
	v_fmac_f32_e32 v53, v23, v44
	v_and_b32_e32 v44, 0xffff0000, v48
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v28, v45
	v_fmac_f32_e32 v53, v21, v45
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v26, v44 :: v_dual_lshlrev_b32 v45, 16, v49
	v_dual_fmac_f32 v53, v18, v44 :: v_dual_and_b32 v44, 0xffff0000, v49
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v24, v45
	v_fmac_f32_e32 v53, v15, v45
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v22, v44 :: v_dual_lshlrev_b32 v45, 16, v50
	v_dual_fmac_f32 v53, v12, v44 :: v_dual_and_b32 v44, 0xffff0000, v50
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v53, v11, v45
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v52, v20, v45 :: v_dual_lshlrev_b32 v45, 16, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v53, v10, v44
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v52, v16, v44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v53, v9, v45 :: v_dual_and_b32 v44, 0xffff0000, v51
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v52, v14, v45 :: v_dual_fmac_f32 v53, v8, v44
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v52, v13, v44
	v_dual_fmac_f32 v67, v53, v19 :: v_dual_fmac_f32 v66, v52, v17
	s_and_not1_b32 vcc_lo, exec_lo, s40
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_37
.LBB0_40:                               ;   in Loop: Header=BB0_35 Depth=1
	v_add_co_u32 v48, s0, s34, v59
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v49, null, s35, 0, s0
	s_clause 0x1
	global_load_b128 v[44:47], v[48:49], off offset:4096
	global_load_b128 v[48:51], v[48:49], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v54, 16, v45
	v_lshlrev_b32_e32 v52, 16, v44
	v_and_b32_e32 v44, 0xffff0000, v44
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v53, v37, v52, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v53, v35, v44
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v33, v54
	s_wait_dscnt 0xf
	v_fma_f32 v52, v43, v52, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v52, v42, v44
	v_and_b32_e32 v44, 0xffff0000, v45
	v_lshlrev_b32_e32 v45, 16, v46
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v39, v54
	v_fmac_f32_e32 v53, v31, v44
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v38, v44
	v_dual_fmac_f32 v53, v29, v45 :: v_dual_and_b32 v44, 0xffff0000, v46
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v36, v45 :: v_dual_lshlrev_b32 v45, 16, v47
	v_fmac_f32_e32 v53, v27, v44
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v34, v44
	v_dual_fmac_f32 v53, v25, v45 :: v_dual_and_b32 v44, 0xffff0000, v47
	s_wait_loadcnt_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v52, v32, v45 :: v_dual_lshlrev_b32 v45, 16, v48
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v52, v30, v44
	v_fmac_f32_e32 v53, v23, v44
	v_and_b32_e32 v44, 0xffff0000, v48
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v28, v45
	v_fmac_f32_e32 v53, v21, v45
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v26, v44 :: v_dual_lshlrev_b32 v45, 16, v49
	v_dual_fmac_f32 v53, v18, v44 :: v_dual_and_b32 v44, 0xffff0000, v49
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v24, v45
	v_fmac_f32_e32 v53, v15, v45
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v22, v44 :: v_dual_lshlrev_b32 v45, 16, v50
	v_dual_fmac_f32 v53, v12, v44 :: v_dual_and_b32 v44, 0xffff0000, v50
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v53, v11, v45
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v52, v20, v45 :: v_dual_lshlrev_b32 v45, 16, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v53, v10, v44
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v52, v16, v44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v53, v9, v45 :: v_dual_and_b32 v44, 0xffff0000, v51
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v52, v14, v45
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v52, v13, v44
	v_fmac_f32_e32 v65, v52, v17
	v_fmac_f32_e32 v53, v8, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v61, v53, v19
	s_and_not1_b32 vcc_lo, exec_lo, s39
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_38
.LBB0_41:                               ;   in Loop: Header=BB0_35 Depth=1
	v_add_co_u32 v48, s0, s12, v59
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v49, null, s13, 0, s0
	s_clause 0x1
	global_load_b128 v[44:47], v[48:49], off offset:4096
	global_load_b128 v[48:51], v[48:49], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v54, 16, v45
	v_lshlrev_b32_e32 v52, 16, v44
	v_and_b32_e32 v44, 0xffff0000, v44
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v53, v37, v52, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v53, v35, v44
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v33, v54
	s_wait_dscnt 0xf
	v_fma_f32 v52, v43, v52, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v52, v42, v44
	v_and_b32_e32 v44, 0xffff0000, v45
	v_lshlrev_b32_e32 v45, 16, v46
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v39, v54
	v_fmac_f32_e32 v53, v31, v44
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v38, v44
	v_dual_fmac_f32 v53, v29, v45 :: v_dual_and_b32 v44, 0xffff0000, v46
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v36, v45 :: v_dual_lshlrev_b32 v45, 16, v47
	v_fmac_f32_e32 v53, v27, v44
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v34, v44
	v_dual_fmac_f32 v53, v25, v45 :: v_dual_and_b32 v44, 0xffff0000, v47
	s_wait_loadcnt_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v52, v32, v45 :: v_dual_lshlrev_b32 v45, 16, v48
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v52, v30, v44
	v_fmac_f32_e32 v53, v23, v44
	v_and_b32_e32 v44, 0xffff0000, v48
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v28, v45
	v_fmac_f32_e32 v53, v21, v45
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v26, v44 :: v_dual_lshlrev_b32 v45, 16, v49
	v_dual_fmac_f32 v53, v18, v44 :: v_dual_and_b32 v44, 0xffff0000, v49
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v24, v45
	v_fmac_f32_e32 v53, v15, v45
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v52, v22, v44 :: v_dual_lshlrev_b32 v45, 16, v50
	v_dual_fmac_f32 v53, v12, v44 :: v_dual_and_b32 v44, 0xffff0000, v50
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v53, v11, v45
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v52, v20, v45 :: v_dual_lshlrev_b32 v45, 16, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v53, v10, v44
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v52, v16, v44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v53, v9, v45 :: v_dual_and_b32 v44, 0xffff0000, v51
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v52, v14, v45
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v52, v13, v44
	v_fmac_f32_e32 v63, v52, v17
	v_fmac_f32_e32 v53, v8, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v64, v53, v19
	s_and_not1_b32 vcc_lo, exec_lo, s38
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_34
.LBB0_42:                               ;   in Loop: Header=BB0_35 Depth=1
	v_add_co_u32 v48, s0, s8, v59
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v49, null, s9, 0, s0
	s_clause 0x1
	global_load_b128 v[44:47], v[48:49], off offset:4096
	global_load_b128 v[48:51], v[48:49], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v52, 16, v44
	v_and_b32_e32 v44, 0xffff0000, v44
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v37, v37, v52, 0
	s_wait_dscnt 0xf
	v_fma_f32 v43, v43, v52, 0
	v_dual_fmac_f32 v37, v35, v44 :: v_dual_lshlrev_b32 v52, 16, v45
	v_and_b32_e32 v35, 0xffff0000, v45
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v43, v42, v44
	v_fmac_f32_e32 v37, v33, v52
	v_lshlrev_b32_e32 v33, 16, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v37, v31, v35
	v_and_b32_e32 v31, 0xffff0000, v46
	v_fmac_f32_e32 v37, v29, v33
	v_lshlrev_b32_e32 v29, 16, v47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v37, v27, v31
	v_and_b32_e32 v27, 0xffff0000, v47
	v_fmac_f32_e32 v37, v25, v29
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v25, 16, v48
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v37, v23, v27
	v_and_b32_e32 v23, 0xffff0000, v48
	v_fmac_f32_e32 v37, v21, v25
	v_lshlrev_b32_e32 v21, 16, v49
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v37, v18, v23 :: v_dual_and_b32 v18, 0xffff0000, v49
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v43, v39, v52
	v_fmac_f32_e32 v37, v15, v21
	v_lshlrev_b32_e32 v15, 16, v50
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v37, v12, v18
	v_dual_fmac_f32 v37, v11, v15 :: v_dual_and_b32 v12, 0xffff0000, v50
	v_lshlrev_b32_e32 v11, 16, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v37, v10, v12 :: v_dual_and_b32 v10, 0xffff0000, v51
	v_fmac_f32_e32 v37, v9, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v37, v8, v10
	v_fmac_f32_e32 v60, v37, v19
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v43, v38, v35
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v36, v33
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v43, v34, v31
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v32, v29
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v43, v30, v27
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v28, v25
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v43, v26, v23
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v24, v21
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v43, v22, v18
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v20, v15
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v43, v16, v12
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v14, v11
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v43, v13, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v62, v43, v17
	s_branch .LBB0_34
.LBB0_43:
	s_wait_loadcnt 0x6
	v_lshlrev_b32_e32 v69, 16, v28
	v_and_b32_e32 v28, 0xffff0000, v28
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v83, v55, v69, 0
	s_wait_dscnt 0xf
	v_fma_f32 v69, v82, v69, 0
	v_dual_fmac_f32 v83, v53, v28 :: v_dual_lshlrev_b32 v84, 16, v29
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v69, v81, v28 :: v_dual_and_b32 v28, 0xffff0000, v29
	v_lshlrev_b32_e32 v29, 16, v30
	v_fmac_f32_e32 v83, v51, v84
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v69, v80, v84
	v_fmac_f32_e32 v83, v50, v28
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v69, v78, v28 :: v_dual_and_b32 v28, 0xffff0000, v30
	v_fmac_f32_e32 v83, v39, v29
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v69, v76, v29
	v_lshlrev_b32_e32 v29, 16, v31
	v_fmac_f32_e32 v83, v37, v28
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v69, v74, v28 :: v_dual_and_b32 v28, 0xffff0000, v31
	v_fmac_f32_e32 v83, v35, v29
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v69, v72, v29
	v_lshlrev_b32_e32 v29, 16, v12
	v_and_b32_e32 v12, 0xffff0000, v12
	v_fmac_f32_e32 v83, v33, v28
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v69, v70, v28 :: v_dual_lshlrev_b32 v28, 16, v13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v83, v54, v29
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v69, v79, v29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v83, v52, v12
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v69, v77, v12 :: v_dual_and_b32 v12, 0xffff0000, v13
	v_lshlrev_b32_e32 v13, 16, v14
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v83, v49, v28
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v69, v75, v28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v83, v48, v12
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v69, v73, v12 :: v_dual_and_b32 v12, 0xffff0000, v14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v83, v38, v13
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v69, v71, v13
	v_lshlrev_b32_e32 v13, 16, v15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v83, v36, v12
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v69, v56, v12 :: v_dual_and_b32 v12, 0xffff0000, v15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v83, v34, v13
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v69, v47, v13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v83, v32, v12
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v69, v46, v12
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v67, v83, v68 :: v_dual_fmac_f32 v66, v69, v57
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_and_b32 s3, vcc_lo, s40
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB0_29
.LBB0_44:
	s_wait_loadcnt 0x4
	v_lshlrev_b32_e32 v12, 16, v20
	v_lshlrev_b32_e32 v15, 16, v21
	v_and_b32_e32 v13, 0xffff0000, v20
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v14, v55, v12, 0
	s_wait_dscnt 0xf
	v_fma_f32 v12, v82, v12, 0
	v_fmac_f32_e32 v14, v53, v13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v14, v51, v15
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v12, v81, v13
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v12, v80, v15 :: v_dual_and_b32 v13, 0xffff0000, v21
	v_dual_fmac_f32 v14, v50, v13 :: v_dual_lshlrev_b32 v15, 16, v22
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v12, v78, v13 :: v_dual_and_b32 v13, 0xffff0000, v22
	v_fmac_f32_e32 v14, v39, v15
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v12, v76, v15
	v_dual_fmac_f32 v14, v37, v13 :: v_dual_lshlrev_b32 v15, 16, v23
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v12, v74, v13 :: v_dual_and_b32 v13, 0xffff0000, v23
	v_fmac_f32_e32 v14, v35, v15
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v12, v72, v15 :: v_dual_lshlrev_b32 v15, 16, v4
	v_fmac_f32_e32 v14, v33, v13
	v_and_b32_e32 v4, 0xffff0000, v4
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v12, v70, v13
	v_dual_fmac_f32 v14, v54, v15 :: v_dual_lshlrev_b32 v13, 16, v5
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v12, v79, v15
	v_fmac_f32_e32 v14, v52, v4
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v12, v77, v4
	v_and_b32_e32 v4, 0xffff0000, v5
	v_dual_fmac_f32 v14, v49, v13 :: v_dual_lshlrev_b32 v5, 16, v6
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v12, v75, v13
	v_fmac_f32_e32 v14, v48, v4
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v12, v73, v4
	v_and_b32_e32 v4, 0xffff0000, v6
	v_fmac_f32_e32 v14, v38, v5
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v12, v71, v5 :: v_dual_lshlrev_b32 v5, 16, v7
	v_fmac_f32_e32 v14, v36, v4
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v12, v56, v4
	v_and_b32_e32 v4, 0xffff0000, v7
	v_fmac_f32_e32 v14, v34, v5
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v12, v47, v5
	v_fmac_f32_e32 v14, v32, v4
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v12, v46, v4
	v_fmac_f32_e32 v61, v14, v68
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v65, v12, v57
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_and_b32 s3, vcc_lo, s39
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB0_30
.LBB0_45:
	s_wait_loadcnt 0x2
	v_lshlrev_b32_e32 v4, 16, v24
	v_lshlrev_b32_e32 v7, 16, v25
	v_and_b32_e32 v5, 0xffff0000, v24
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v6, v55, v4, 0
	s_wait_dscnt 0xf
	v_fma_f32 v4, v82, v4, 0
	v_fmac_f32_e32 v6, v53, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v6, v51, v7
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v4, v81, v5
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v4, v80, v7 :: v_dual_and_b32 v5, 0xffff0000, v25
	v_dual_fmac_f32 v6, v50, v5 :: v_dual_lshlrev_b32 v7, 16, v26
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v78, v5 :: v_dual_and_b32 v5, 0xffff0000, v26
	v_fmac_f32_e32 v6, v39, v7
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v76, v7
	v_dual_fmac_f32 v6, v37, v5 :: v_dual_lshlrev_b32 v7, 16, v27
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v74, v5 :: v_dual_and_b32 v5, 0xffff0000, v27
	v_fmac_f32_e32 v6, v35, v7
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v72, v7 :: v_dual_lshlrev_b32 v7, 16, v0
	v_fmac_f32_e32 v6, v33, v5
	v_and_b32_e32 v0, 0xffff0000, v0
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v4, v70, v5
	v_dual_fmac_f32 v6, v54, v7 :: v_dual_lshlrev_b32 v5, 16, v1
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v79, v7
	v_fmac_f32_e32 v6, v52, v0
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v4, v77, v0
	v_and_b32_e32 v0, 0xffff0000, v1
	v_dual_fmac_f32 v6, v49, v5 :: v_dual_lshlrev_b32 v1, 16, v2
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v75, v5
	v_fmac_f32_e32 v6, v48, v0
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v4, v73, v0
	v_and_b32_e32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v6, v38, v1
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v71, v1 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v6, v36, v0
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v4, v56, v0
	v_and_b32_e32 v0, 0xffff0000, v3
	v_fmac_f32_e32 v6, v34, v1
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v47, v1
	v_fmac_f32_e32 v6, v32, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v4, v46, v0
	v_dual_fmac_f32 v64, v6, v68 :: v_dual_fmac_f32 v63, v4, v57
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_and_b32 s3, vcc_lo, s38
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execnz .LBB0_31
	s_branch .LBB0_32
.LBB0_46:
	s_or_b32 exec_lo, exec_lo, s14
.LBB0_47:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s1
	s_wait_kmcnt 0x0
	s_load_b32 s2, s[2:3], 0x0
	s_load_b32 s1, s[4:5], 0x0
	v_lshlrev_b64_e32 v[0:1], 1, v[40:41]
	v_cmp_eq_u32_e64 s0, 0, v58
	v_mbcnt_lo_u32_b32 v2, -1, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_add_co_u32 v0, vcc_lo, s6, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo
	s_and_b32 vcc_lo, exec_lo, s41
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_52
; %bb.48:
	s_and_not1_b32 vcc_lo, exec_lo, s40
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_67
.LBB0_49:
	s_and_not1_b32 vcc_lo, exec_lo, s39
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_82
.LBB0_50:
	s_and_not1_b32 vcc_lo, exec_lo, s38
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_97
.LBB0_51:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
.LBB0_52:
	v_xor_b32_e32 v3, 16, v2
	v_xor_b32_e32 v5, 8, v2
	v_xor_b32_e32 v6, 4, v2
	s_wait_loadcnt 0x1
	v_xor_b32_e32 v9, 1, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v2, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v2, v5, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v6, v2, v6 :: v_dual_lshlrev_b32 v5, 2, v5
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v4, 2, v3
	ds_bpermute_b32 v3, v4, v67
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v67, v3
	ds_bpermute_b32 v7, v5, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v7
	v_xor_b32_e32 v7, 2, v2
	ds_bpermute_b32 v8, v6, v3
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v2, v7, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v7, 2, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, v2, v9, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v8
	ds_bpermute_b32 v8, v7, v3
	s_wait_dscnt 0x0
	v_dual_add_f32 v3, v3, v8 :: v_dual_lshlrev_b32 v8, 2, v9
	ds_bpermute_b32 v9, v8, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v9
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v9, s2, v3
	v_and_b32_e32 v3, 0x7fffffff, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.53:
	v_bfe_u32 v3, v9, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v9, v3, 0x7fff
                                        ; implicit-def: $vgpr9
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.54:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.55:
	v_lshrrev_b32_e32 v3, 16, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.56:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v4, v4, v66
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v66, v4
	ds_bpermute_b32 v5, v5, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v6, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v7, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v8, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v5, s1, v4
	v_and_b32_e32 v4, 0x7fffffff, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execnz .LBB0_60
; %bb.57:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execnz .LBB0_61
.LBB0_58:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execnz .LBB0_62
.LBB0_59:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s40
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_49
	s_branch .LBB0_67
.LBB0_60:
	v_bfe_u32 v4, v5, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v5, v4, 0x7fff
                                        ; implicit-def: $vgpr5
	v_lshrrev_b32_e32 v4, 16, v4
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execz .LBB0_58
.LBB0_61:
	v_lshrrev_b32_e32 v4, 16, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execz .LBB0_59
.LBB0_62:
	v_lshlrev_b32_e32 v3, 16, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v5, 0xbfb8aa3b, v3 :: v_dual_lshlrev_b32 v4, 16, v4
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v3
	v_fma_f32 v6, 0xbfb8aa3b, v3, -v5
	v_rndne_f32_e32 v7, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v6, v3, 0xb2a5705f, v6 :: v_dual_sub_f32 v5, v5, v7
	v_add_f32_e32 v5, v5, v6
	v_cvt_i32_f32_e32 v6, v7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v5, v5
	v_ldexp_f32 v5, v5, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, 0x7f800000, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v5, 1.0, v5
	v_div_scale_f32 v6, null, v5, v5, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v7, v6
	v_fma_f32 v8, -v6, v7, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v7, v8, v7
	v_div_scale_f32 v8, vcc_lo, v3, v5, v3
	v_mul_f32_e32 v9, v8, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v10, -v6, v9, v8
	v_fmac_f32_e32 v9, v10, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v6, -v6, v9, v8
	s_wait_alu 0xfffd
	v_div_fmas_f32 v6, v6, v7, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v3, v6, v5, v3
	v_mul_f32_e32 v4, v3, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v3, 0x7fffffff, v4
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s4, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s4, exec_lo, s4
; %bb.63:
	v_bfe_u32 v3, v4, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v4, v3, 0x7fff
                                        ; implicit-def: $vgpr4
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.64:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s4, s4
; %bb.65:
	v_lshrrev_b32_e32 v3, 16, v4
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.66:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_ashr_i32 s25, s24, 31
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mul_u64 s[4:5], s[16:17], s[24:25]
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v0, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo
	global_store_b16 v[4:5], v3, off
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s40
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_49
.LBB0_67:
	v_xor_b32_e32 v3, 16, v2
	v_xor_b32_e32 v5, 8, v2
	v_xor_b32_e32 v6, 4, v2
	s_wait_loadcnt 0x1
	v_xor_b32_e32 v9, 1, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v2, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v2, v5, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v6, v2, v6 :: v_dual_lshlrev_b32 v5, 2, v5
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v4, 2, v3
	ds_bpermute_b32 v3, v4, v61
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v61, v3
	ds_bpermute_b32 v7, v5, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v7
	v_xor_b32_e32 v7, 2, v2
	ds_bpermute_b32 v8, v6, v3
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v2, v7, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v7, 2, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, v2, v9, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v8
	ds_bpermute_b32 v8, v7, v3
	s_wait_dscnt 0x0
	v_dual_add_f32 v3, v3, v8 :: v_dual_lshlrev_b32 v8, 2, v9
	ds_bpermute_b32 v9, v8, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v9
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v9, s2, v3
	v_and_b32_e32 v3, 0x7fffffff, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.68:
	v_bfe_u32 v3, v9, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v9, v3, 0x7fff
                                        ; implicit-def: $vgpr9
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.69:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.70:
	v_lshrrev_b32_e32 v3, 16, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.71:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v4, v4, v65
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v65, v4
	ds_bpermute_b32 v5, v5, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v6, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v7, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v8, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v5, s1, v4
	v_and_b32_e32 v4, 0x7fffffff, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execnz .LBB0_75
; %bb.72:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execnz .LBB0_76
.LBB0_73:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execnz .LBB0_77
.LBB0_74:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s39
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_50
	s_branch .LBB0_82
.LBB0_75:
	v_bfe_u32 v4, v5, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v5, v4, 0x7fff
                                        ; implicit-def: $vgpr5
	v_lshrrev_b32_e32 v4, 16, v4
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execz .LBB0_73
.LBB0_76:
	v_lshrrev_b32_e32 v4, 16, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execz .LBB0_74
.LBB0_77:
	v_lshlrev_b32_e32 v3, 16, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v5, 0xbfb8aa3b, v3 :: v_dual_lshlrev_b32 v4, 16, v4
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v3
	v_fma_f32 v6, 0xbfb8aa3b, v3, -v5
	v_rndne_f32_e32 v7, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v6, v3, 0xb2a5705f, v6 :: v_dual_sub_f32 v5, v5, v7
	v_add_f32_e32 v5, v5, v6
	v_cvt_i32_f32_e32 v6, v7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v5, v5
	v_ldexp_f32 v5, v5, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, 0x7f800000, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v5, 1.0, v5
	v_div_scale_f32 v6, null, v5, v5, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v7, v6
	v_fma_f32 v8, -v6, v7, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v7, v8, v7
	v_div_scale_f32 v8, vcc_lo, v3, v5, v3
	v_mul_f32_e32 v9, v8, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v10, -v6, v9, v8
	v_fmac_f32_e32 v9, v10, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v6, -v6, v9, v8
	s_wait_alu 0xfffd
	v_div_fmas_f32 v6, v6, v7, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v3, v6, v5, v3
	v_mul_f32_e32 v4, v3, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v3, 0x7fffffff, v4
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s4, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s4, exec_lo, s4
; %bb.78:
	v_bfe_u32 v3, v4, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v4, v3, 0x7fff
                                        ; implicit-def: $vgpr4
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.79:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s4, s4
; %bb.80:
	v_lshrrev_b32_e32 v3, 16, v4
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.81:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_ashr_i32 s23, s22, 31
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mul_u64 s[4:5], s[16:17], s[22:23]
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v0, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo
	global_store_b16 v[4:5], v3, off
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s39
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_50
.LBB0_82:
	v_xor_b32_e32 v3, 16, v2
	v_xor_b32_e32 v5, 8, v2
	v_xor_b32_e32 v6, 4, v2
	s_wait_loadcnt 0x1
	v_xor_b32_e32 v9, 1, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v2, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v2, v5, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v6, v2, v6 :: v_dual_lshlrev_b32 v5, 2, v5
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v4, 2, v3
	ds_bpermute_b32 v3, v4, v64
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v64, v3
	ds_bpermute_b32 v7, v5, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v7
	v_xor_b32_e32 v7, 2, v2
	ds_bpermute_b32 v8, v6, v3
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v2, v7, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v9
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v7, 2, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, v2, v9, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v8
	ds_bpermute_b32 v8, v7, v3
	s_wait_dscnt 0x0
	v_dual_add_f32 v3, v3, v8 :: v_dual_lshlrev_b32 v8, 2, v9
	ds_bpermute_b32 v9, v8, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v9
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v9, s2, v3
	v_and_b32_e32 v3, 0x7fffffff, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.83:
	v_bfe_u32 v3, v9, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v9, v3, 0x7fff
                                        ; implicit-def: $vgpr9
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.84:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.85:
	v_lshrrev_b32_e32 v3, 16, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.86:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v4, v4, v63
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v63, v4
	ds_bpermute_b32 v5, v5, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v6, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v7, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	ds_bpermute_b32 v5, v8, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v5, s1, v4
	v_and_b32_e32 v4, 0x7fffffff, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execnz .LBB0_90
; %bb.87:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execnz .LBB0_91
.LBB0_88:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execnz .LBB0_92
.LBB0_89:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s38
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_51
	s_branch .LBB0_97
.LBB0_90:
	v_bfe_u32 v4, v5, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v5, v4, 0x7fff
                                        ; implicit-def: $vgpr5
	v_lshrrev_b32_e32 v4, 16, v4
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execz .LBB0_88
.LBB0_91:
	v_lshrrev_b32_e32 v4, 16, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execz .LBB0_89
.LBB0_92:
	v_lshlrev_b32_e32 v3, 16, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v5, 0xbfb8aa3b, v3 :: v_dual_lshlrev_b32 v4, 16, v4
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v3
	v_fma_f32 v6, 0xbfb8aa3b, v3, -v5
	v_rndne_f32_e32 v7, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v6, v3, 0xb2a5705f, v6 :: v_dual_sub_f32 v5, v5, v7
	v_add_f32_e32 v5, v5, v6
	v_cvt_i32_f32_e32 v6, v7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v5, v5
	v_ldexp_f32 v5, v5, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, 0x7f800000, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v5, 1.0, v5
	v_div_scale_f32 v6, null, v5, v5, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v7, v6
	v_fma_f32 v8, -v6, v7, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v7, v8, v7
	v_div_scale_f32 v8, vcc_lo, v3, v5, v3
	v_mul_f32_e32 v9, v8, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v10, -v6, v9, v8
	v_fmac_f32_e32 v9, v10, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v6, -v6, v9, v8
	s_wait_alu 0xfffd
	v_div_fmas_f32 v6, v6, v7, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v3, v6, v5, v3
	v_mul_f32_e32 v4, v3, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v3, 0x7fffffff, v4
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s4, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s4, exec_lo, s4
; %bb.93:
	v_bfe_u32 v3, v4, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v4, v3, 0x7fff
                                        ; implicit-def: $vgpr4
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.94:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s4, s4
; %bb.95:
	v_lshrrev_b32_e32 v3, 16, v4
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.96:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_ashr_i32 s21, s20, 31
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mul_u64 s[4:5], s[16:17], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v0, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo
	global_store_b16 v[4:5], v3, off
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s38
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_51
.LBB0_97:
	v_xor_b32_e32 v3, 16, v2
	v_xor_b32_e32 v4, 8, v2
	s_wait_loadcnt 0x1
	v_xor_b32_e32 v9, 1, v2
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v2, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v2, v4, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v3, 2, v3
	ds_bpermute_b32 v5, v3, v60
	s_wait_dscnt 0x0
	v_add_f32_e32 v6, v60, v5
	v_xor_b32_e32 v5, 4, v2
	ds_bpermute_b32 v7, v4, v6
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v2, v5, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v6, v7
	v_xor_b32_e32 v6, 2, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v2, v6, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v9
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v2, v9, vcc_lo
	ds_bpermute_b32 v8, v5, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v6, v7
	s_wait_dscnt 0x0
	v_dual_add_f32 v8, v7, v8 :: v_dual_lshlrev_b32 v7, 2, v2
	ds_bpermute_b32 v2, v7, v8
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v8, v2
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v8, s2, v2
	v_and_b32_e32 v2, 0x7fffffff, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s2, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s2, exec_lo, s2
; %bb.98:
	v_bfe_u32 v2, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v8, v2, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.99:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s2, s2
; %bb.100:
	v_lshrrev_b32_e32 v2, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.101:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	ds_bpermute_b32 v3, v3, v62
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v62, v3
	ds_bpermute_b32 v4, v4, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v4
	ds_bpermute_b32 v4, v5, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v4
	ds_bpermute_b32 v4, v6, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v4
	ds_bpermute_b32 v4, v7, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v4, s1, v3
	v_and_b32_e32 v3, 0x7fffffff, v4
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s1, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s1, exec_lo, s1
	s_cbranch_execnz .LBB0_104
; %bb.102:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
	s_cbranch_execnz .LBB0_105
.LBB0_103:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 exec_lo, exec_lo, s0
	s_cbranch_execz .LBB0_51
	s_branch .LBB0_106
.LBB0_104:
	v_bfe_u32 v3, v4, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v4, v3, 0x7fff
                                        ; implicit-def: $vgpr4
	v_lshrrev_b32_e32 v3, 16, v3
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
	s_cbranch_execz .LBB0_103
.LBB0_105:
	v_lshrrev_b32_e32 v3, 16, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	v_or_b32_e32 v3, 64, v3
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_and_b32 exec_lo, exec_lo, s0
	s_cbranch_execz .LBB0_51
.LBB0_106:
	v_lshlrev_b32_e32 v2, 16, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v4, 0xbfb8aa3b, v2 :: v_dual_lshlrev_b32 v3, 16, v3
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v2
	v_fma_f32 v5, 0xbfb8aa3b, v2, -v4
	v_rndne_f32_e32 v6, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v5, v2, 0xb2a5705f, v5 :: v_dual_sub_f32 v4, v4, v6
	v_add_f32_e32 v4, v4, v5
	v_cvt_i32_f32_e32 v5, v6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v4, v4
	v_ldexp_f32 v4, v4, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, 0x7f800000, v4, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v4, 1.0, v4
	v_div_scale_f32 v5, null, v4, v4, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v6, v5
	v_fma_f32 v7, -v5, v6, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v6
	v_div_scale_f32 v7, vcc_lo, v2, v4, v2
	v_mul_f32_e32 v8, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v9, -v5, v8, v7
	v_fmac_f32_e32 v8, v9, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v5, v8, v7
	s_wait_alu 0xfffd
	v_div_fmas_f32 v5, v5, v6, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v2, v5, v4, v2
	v_mul_f32_e32 v3, v2, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.107:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.108:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.109:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.110:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_ashr_i32 s19, s18, 31
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mul_u64 s[0:1], s[16:17], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[0:1], s[0:1], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v0, vcc_lo, v0, s0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo
	global_store_b16 v[0:1], v2, off
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili
		.amdhsa_group_segment_fixed_size 64
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 84
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 114
		.amdhsa_next_free_sgpr 42
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 145
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili,"axG",@progbits,_ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili,comdat
.Lfunc_end0:
