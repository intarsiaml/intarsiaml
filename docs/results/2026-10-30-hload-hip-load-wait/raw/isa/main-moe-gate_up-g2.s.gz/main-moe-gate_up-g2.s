_ZN12_GLOBAL__N_121moe_gate_up_g2_kernelILi2EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iiii: ; @_ZN12_GLOBAL__N_121moe_gate_up_g2_kernelILi2EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iiii
; %bb.0:
	s_load_b64 s[2:3], s[0:1], 0x30
	s_mov_b32 s4, exec_lo
	v_cmpx_gt_u32_e32 16, v0
	s_cbranch_execz .LBB90_2
; %bb.1:
	v_and_b32_e32 v1, 7, v0
	v_lshlrev_b32_e32 v3, 28, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v2, v1, 22, 0.5
	v_cmp_ne_u32_e32 vcc_lo, 1, v1
	v_cndmask_b32_e32 v2, 0.5, v2, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v1, 0, v2 :: v_dual_lshlrev_b32 v2, 2, v0
	v_and_or_b32 v1, 0x80000000, v3, v1
	ds_store_b32 v2, v1
.LBB90_2:
	s_or_b32 exec_lo, exec_lo, s4
	s_load_b128 s[4:7], s[0:1], 0x40
	s_wait_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_wait_kmcnt 0x0
	s_ashr_i32 s9, s4, 31
	s_mov_b32 s8, s4
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_lshl_b64 s[8:9], s[8:9], 2
	s_add_nc_u64 s[8:9], s[2:3], s[8:9]
	s_load_b32 s4, s[8:9], 0x0
	s_wait_kmcnt 0x0
	s_cmp_ge_i32 ttmp9, s4
	s_cbranch_scc1 .LBB90_425
; %bb.3:
	v_lshrrev_b32_e32 v1, 4, v0
	s_lshl_b32 s4, ttmp7, 4
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)
	v_and_or_b32 v1, v1, 14, s4
	s_mov_b32 s4, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s6, v1
	s_cbranch_execz .LBB90_425
; %bb.4:
	s_mov_b32 s8, ttmp9
	s_ashr_i32 s9, ttmp9, 31
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_lshl_b64 s[8:9], s[8:9], 2
	s_add_nc_u64 s[2:3], s[2:3], s[8:9]
	s_load_b32 s2, s[2:3], 0x0
	s_load_b64 s[8:9], s[0:1], 0x28
	s_wait_kmcnt 0x0
	s_ashr_i32 s3, s2, 31
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_lshl_b64 s[10:11], s[2:3], 2
	s_add_nc_u64 s[8:9], s[8:9], s[10:11]
	s_load_b64 s[16:17], s[8:9], 0x0
	s_wait_kmcnt 0x0
	s_sub_co_i32 s17, s17, s16
	s_delay_alu instid0(SALU_CYCLE_1)
	s_cmp_lt_i32 s17, 1
	s_cbranch_scc1 .LBB90_425
; %bb.5:
	s_load_b256 s[8:15], s[0:1], 0x0
	s_add_co_i32 s18, s6, -1
	s_ashr_i32 s21, s6, 31
	v_min_i32_e32 v2, s18, v1
	s_mov_b32 s20, s6
	v_or_b32_e32 v32, 1, v1
	s_mul_u64 s[22:23], s[2:3], s[20:21]
	s_ashr_i32 s19, s5, 31
	v_ashrrev_i32_e32 v5, 31, v2
	s_lshl_b64 s[22:23], s[22:23], 1
	s_wait_alu 0xfffe
	s_lshr_b32 s4, s19, 28
	s_add_nc_u64 s[26:27], s[22:23], s[20:21]
	v_add_co_u32 v24, vcc_lo, s22, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s23, v5, vcc_lo
	v_add_co_u32 v27, vcc_lo, s26, v2
	v_min_i32_e32 v10, s18, v32
	s_wait_alu 0xfffe
	s_add_co_i32 s4, s5, s4
	s_lshr_b32 s24, s5, 31
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s27, v5, vcc_lo
	s_add_co_i32 s3, s5, s24
	s_wait_alu 0xfffe
	s_ashr_i32 s33, s4, 4
	s_ashr_i32 s24, s3, 1
	s_ashr_i32 s4, s33, 31
	v_ashrrev_i32_e32 v12, 31, v10
	v_mul_lo_u32 v26, v7, s24
	v_mul_lo_u32 v34, v2, s24
	s_wait_alu 0xfffe
	v_mul_lo_u32 v9, v24, s4
	v_mul_lo_u32 v11, v7, s33
	s_wait_kmcnt 0x0
	v_mad_co_u64_u32 v[7:8], null, v24, s33, s[12:13]
	v_mul_lo_u32 v2, v2, s33
	v_mul_lo_u32 v13, v27, s4
	v_mad_co_u64_u32 v[30:31], null, v27, s33, s[12:13]
	v_add_co_u32 v35, vcc_lo, s22, v10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v14, null, s23, v12, vcc_lo
	v_add_co_u32 v41, vcc_lo, s26, v10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, s27, v12, vcc_lo
	s_clause 0x1
	s_load_b64 s[26:27], s[0:1], 0x38
	s_load_b64 s[22:23], s[0:1], 0x20
	v_add3_u32 v45, v11, v8, v9
	v_add3_u32 v31, v2, v31, v13
	v_mul_lo_u32 v2, v14, s33
	v_mul_lo_u32 v8, v35, s4
	v_mad_co_u64_u32 v[36:37], null, v35, s33, s[12:13]
	s_ashr_i32 s3, s24, 31
	v_mad_co_u64_u32 v[3:4], null, v24, s24, s[10:11]
	v_mul_lo_u32 v25, v24, s3
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v72, 31, v0
	v_add3_u32 v37, v2, v37, v8
	v_ashrrev_i32_e32 v2, 31, v1
	v_mad_co_u64_u32 v[5:6], null, v27, s24, s[10:11]
	v_mul_lo_u32 v33, v27, s3
	s_mul_i32 s0, s2, 3
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[0:1], 1, v[1:2]
	v_mul_lo_u32 v44, v10, s24
	v_mul_lo_u32 v9, v10, s33
	v_mul_lo_u32 v10, v41, s4
	v_mad_co_u64_u32 v[38:39], null, v41, s33, s[12:13]
	s_ashr_i32 s1, s0, 31
	v_or_b32_e32 v8, 0x80, v72
	v_lshlrev_b32_e32 v28, 3, v72
	s_lshl_b64 s[0:1], s[0:1], 2
	s_abs_i32 s58, s7
	v_mad_co_u64_u32 v[16:17], null, v35, s24, s[10:11]
	v_mul_lo_u32 v40, v14, s24
	v_mul_lo_u32 v42, v35, s3
	v_add3_u32 v4, v26, v4, v25
	s_add_nc_u64 s[0:1], s[14:15], s[0:1]
	s_wait_kmcnt 0x0
	v_add_co_u32 v73, vcc_lo, s26, v0
	v_or_b32_e32 v0, 32, v72
	s_cvt_f32_u32 s4, s58
	v_mad_co_u64_u32 v[18:19], null, v41, s24, s[10:11]
	v_mul_lo_u32 v43, v41, s3
	v_add3_u32 v6, v34, v6, v33
	s_load_b64 s[12:13], s[0:1], 0x0
	v_cmp_gt_i32_e64 s0, s33, v8
	v_add_co_ci_u32_e64 v74, null, s27, v1, vcc_lo
	v_add_co_u32 v8, vcc_lo, v3, v28
	v_or_b32_e32 v1, 64, v72
	v_add3_u32 v39, v9, v39, v10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo
	v_add_co_u32 v10, vcc_lo, v5, v28
	v_rcp_iflag_f32_e32 v3, s4
	v_cmp_gt_i32_e64 s3, s33, v0
	v_lshlrev_b32_e32 v0, 5, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo
	v_add_co_u32 v12, vcc_lo, v7, v72
	v_add3_u32 v17, v40, v17, v42
	v_lshlrev_b32_e32 v75, 5, v72
	v_cmp_gt_i32_e64 s4, s33, v1
	v_lshlrev_b32_e32 v1, 5, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v13, null, 0, v45, vcc_lo
	v_add_co_u32 v14, vcc_lo, v30, v72
	v_add3_u32 v19, v44, v19, v43
	v_or_b32_e32 v2, 0x60, v72
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v15, null, 0, v31, vcc_lo
	v_add_co_u32 v16, vcc_lo, v16, v28
	v_add_co_u32 v78, s25, s8, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo
	v_add_co_u32 v18, vcc_lo, v18, v28
	v_add_co_u32 v76, s14, s8, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v79, null, s9, 0, s25
	v_add_co_u32 v80, s25, s8, v1
	v_mad_co_u64_u32 v[0:1], null, v24, s24, v[28:29]
	s_mov_b32 s18, s5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v19, null, 0, v19, vcc_lo
	v_add_co_u32 v20, vcc_lo, v36, v72
	v_cmp_gt_i32_e64 s5, s33, v2
	v_add_co_ci_u32_e64 v77, null, s9, 0, s14
	v_readfirstlane_b32 s14, v3
	v_lshlrev_b32_e32 v4, 5, v2
	v_mad_co_u64_u32 v[2:3], null, v27, s24, v[28:29]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v21, null, 0, v37, vcc_lo
	v_add_co_u32 v22, vcc_lo, v38, v72
	v_cmp_eq_u32_e64 s1, 0, v72
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v23, null, 0, v39, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s6, v32
	v_add3_u32 v1, v26, v1, v25
	v_add3_u32 v3, v34, v3, v33
	s_mul_f32 s14, s14, 0x4f7ffffe
	v_cmp_gt_i32_e64 s2, s33, v72
	s_and_b32 s59, s1, vcc_lo
	v_add_co_u32 v0, vcc_lo, s10, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s11, v1, vcc_lo
	v_add_co_u32 v2, vcc_lo, s10, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo
	v_add_co_u32 v24, vcc_lo, 0x400, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v25, null, 0, v1, vcc_lo
	v_add_co_u32 v26, vcc_lo, 0x400, v2
	v_mad_co_u64_u32 v[0:1], null, v35, s24, v[28:29]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v27, null, 0, v3, vcc_lo
	v_mad_co_u64_u32 v[2:3], null, v41, s24, v[28:29]
	v_add_co_u32 v28, vcc_lo, 0x80, v7
	s_delay_alu instid0(VALU_DEP_4)
	v_add3_u32 v1, v40, v1, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v29, null, 0, v45, vcc_lo
	v_add_co_u32 v30, vcc_lo, 0x80, v30
	v_add3_u32 v3, v44, v3, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v31, null, 0, v31, vcc_lo
	v_add_co_u32 v0, vcc_lo, s10, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s11, v1, vcc_lo
	v_add_co_u32 v2, vcc_lo, s10, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo
	v_add_co_u32 v32, vcc_lo, 0x400, v0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v33, null, 0, v1, vcc_lo
	v_add_co_u32 v34, vcc_lo, 0x400, v2
	s_wait_alu 0xfffe
	s_cvt_u32_f32 s6, s14
	v_add_co_u32 v82, s14, s8, v4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo
	v_add_co_u32 v36, vcc_lo, 0x80, v36
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v83, null, s9, 0, s14
	s_sub_co_i32 s14, 0, s58
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v37, null, 0, v37, vcc_lo
	v_add_co_u32 v38, vcc_lo, 0x80, v38
	s_wait_alu 0xfffe
	s_mul_i32 s14, s14, s6
	v_add_co_ci_u32_e64 v81, null, s9, 0, s25
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v39, null, 0, v39, vcc_lo
	v_mbcnt_lo_u32_b32 v84, -1, 0
	s_mov_b32 s15, 0
	s_ashr_i32 s60, s7, 31
	s_wait_alu 0xfffe
	s_mul_hi_u32 s7, s6, s14
	s_mov_b32 s61, 0
	s_wait_alu 0xfffe
	s_add_co_i32 s6, s6, s7
	s_mov_b32 s7, s15
	s_branch .LBB90_9
.LBB90_6:                               ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	s_ashr_i32 s11, s10, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[10:11], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v1, vcc_lo, v73, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s11, v74, vcc_lo
	global_store_b16 v[1:2], v0, off offset:2
.LBB90_7:                               ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
.LBB90_8:                               ;   in Loop: Header=BB90_9 Depth=1
	s_add_co_i32 s61, s61, 8
	s_delay_alu instid0(SALU_CYCLE_1)
	s_cmp_lt_i32 s61, s17
	s_cbranch_scc0 .LBB90_425
.LBB90_9:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB90_90 Depth 2
	s_wait_kmcnt 0x0
	s_sub_co_i32 s10, s17, s61
	s_add_co_i32 s40, s61, s16
	s_wait_alu 0xfffe
	s_cmp_gt_i32 s10, 0
	s_mov_b32 s38, 0
	s_cselect_b32 s37, -1, 0
	s_cmp_lt_i32 s10, 1
	s_cbranch_scc1 .LBB90_11
; %bb.10:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[24:25], s[22:23], s[24:25]
	s_load_b32 s38, s[24:25], 0x0
.LBB90_11:                              ;   in Loop: Header=BB90_9 Depth=1
	s_cmp_gt_i32 s10, 1
	s_mov_b32 s34, 0
	s_cselect_b32 s42, -1, 0
	s_cmp_lt_i32 s10, 2
	s_mov_b32 s36, 0
	s_cbranch_scc1 .LBB90_13
; %bb.12:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[24:25], s[22:23], s[24:25]
	s_load_b32 s36, s[24:25], 0x4
.LBB90_13:                              ;   in Loop: Header=BB90_9 Depth=1
	s_cmp_gt_i32 s10, 2
	s_cselect_b32 s35, -1, 0
	s_cmp_lt_i32 s10, 3
	s_cbranch_scc1 .LBB90_15
; %bb.14:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[24:25], s[22:23], s[24:25]
	s_load_b32 s34, s[24:25], 0x8
.LBB90_15:                              ;   in Loop: Header=BB90_9 Depth=1
	s_cmp_gt_i32 s10, 3
	s_mov_b32 s28, 0
	s_cselect_b32 s31, -1, 0
	s_cmp_lt_i32 s10, 4
	s_mov_b32 s30, 0
	s_cbranch_scc1 .LBB90_17
; %bb.16:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[24:25], s[22:23], s[24:25]
	s_load_b32 s30, s[24:25], 0xc
.LBB90_17:                              ;   in Loop: Header=BB90_9 Depth=1
	s_cmp_gt_i32 s10, 4
	s_cselect_b32 s29, -1, 0
	s_cmp_lt_i32 s10, 5
	s_cbranch_scc1 .LBB90_19
; %bb.18:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[24:25], s[22:23], s[24:25]
	s_load_b32 s28, s[24:25], 0x10
.LBB90_19:                              ;   in Loop: Header=BB90_9 Depth=1
	s_cmp_gt_i32 s10, 5
	s_mov_b32 s24, 0
	s_cselect_b32 s27, -1, 0
	s_cmp_lt_i32 s10, 6
	s_mov_b32 s26, 0
	s_cbranch_scc1 .LBB90_21
; %bb.20:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[44:45], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[44:45], s[22:23], s[44:45]
	s_load_b32 s26, s[44:45], 0x14
.LBB90_21:                              ;   in Loop: Header=BB90_9 Depth=1
	s_cmp_gt_i32 s10, 6
	s_cselect_b32 s25, -1, 0
	s_cmp_lt_i32 s10, 7
	s_cbranch_scc1 .LBB90_23
; %bb.22:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[44:45], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[44:45], s[22:23], s[44:45]
	s_load_b32 s24, s[44:45], 0x18
.LBB90_23:                              ;   in Loop: Header=BB90_9 Depth=1
	s_cmp_gt_i32 s10, 7
	s_cselect_b32 s11, -1, 0
	s_cmp_lt_i32 s10, 8
	s_mov_b32 s10, 0
	s_cbranch_scc1 .LBB90_25
; %bb.24:                               ;   in Loop: Header=BB90_9 Depth=1
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[40:41], s[22:23], s[40:41]
	s_load_b32 s10, s[40:41], 0x1c
.LBB90_25:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_loadcnt 0x3
	v_mov_b32_e32 v66, 0
	v_mov_b32_e32 v70, 0
	s_wait_loadcnt 0x1
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v131, 0
	v_dual_mov_b32 v162, 0 :: v_dual_mov_b32 v67, 0
	v_mov_b32_e32 v71, 0
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v130, 0
	s_and_saveexec_b32 s14, s2
	s_cbranch_execz .LBB90_27
; %bb.26:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[70:71], v[8:9], off th:TH_LOAD_NT
	global_load_b64 v[68:69], v[10:11], off th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v131, v[12:13], off
	global_load_u8 v130, v[14:15], off
.LBB90_27:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v163, 0
	v_mov_b32_e32 v65, 0
	s_and_saveexec_b32 s14, s2
	s_cbranch_execz .LBB90_29
; %bb.28:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[66:67], v[16:17], off th:TH_LOAD_NT
	global_load_b64 v[64:65], v[18:19], off th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v162, v[20:21], off
	global_load_u8 v163, v[22:23], off
.LBB90_29:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_mov_b32_e32 v58, 0
	v_mov_b32_e32 v62, 0
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v129, 0
	v_dual_mov_b32 v126, 0 :: v_dual_mov_b32 v59, 0
	v_mov_b32_e32 v63, 0
	v_mov_b32_e32 v61, 0
	v_mov_b32_e32 v127, 0
	s_and_saveexec_b32 s14, s3
	s_cbranch_execz .LBB90_31
; %bb.30:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[62:63], v[8:9], off offset:256 th:TH_LOAD_NT
	global_load_b64 v[60:61], v[10:11], off offset:256 th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v129, v[12:13], off offset:32
	global_load_u8 v127, v[14:15], off offset:32
.LBB90_31:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_mov_b32_e32 v56, 0
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v128, 0
	s_and_saveexec_b32 s14, s3
	s_cbranch_execz .LBB90_33
; %bb.32:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[58:59], v[16:17], off offset:256 th:TH_LOAD_NT
	global_load_b64 v[56:57], v[18:19], off offset:256 th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v126, v[20:21], off offset:32
	global_load_u8 v128, v[22:23], off offset:32
.LBB90_33:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_mov_b32_e32 v50, 0
	v_mov_b32_e32 v54, 0
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v125, 0
	v_dual_mov_b32 v122, 0 :: v_dual_mov_b32 v51, 0
	v_mov_b32_e32 v55, 0
	v_mov_b32_e32 v53, 0
	v_mov_b32_e32 v123, 0
	s_and_saveexec_b32 s14, s4
	s_cbranch_execz .LBB90_35
; %bb.34:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[54:55], v[8:9], off offset:512 th:TH_LOAD_NT
	global_load_b64 v[52:53], v[10:11], off offset:512 th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v125, v[12:13], off offset:64
	global_load_u8 v123, v[14:15], off offset:64
.LBB90_35:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_mov_b32_e32 v48, 0
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v124, 0
	s_and_saveexec_b32 s14, s4
	s_cbranch_execz .LBB90_37
; %bb.36:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[50:51], v[16:17], off offset:512 th:TH_LOAD_NT
	global_load_b64 v[48:49], v[18:19], off offset:512 th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v122, v[20:21], off offset:64
	global_load_u8 v124, v[22:23], off offset:64
.LBB90_37:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_mov_b32_e32 v42, 0
	v_mov_b32_e32 v46, 0
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v121, 0
	v_dual_mov_b32 v118, 0 :: v_dual_mov_b32 v43, 0
	v_mov_b32_e32 v47, 0
	v_mov_b32_e32 v45, 0
	v_mov_b32_e32 v119, 0
	s_and_saveexec_b32 s14, s5
	s_cbranch_execz .LBB90_39
; %bb.38:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[46:47], v[8:9], off offset:768 th:TH_LOAD_NT
	global_load_b64 v[44:45], v[10:11], off offset:768 th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v121, v[12:13], off offset:96
	global_load_u8 v119, v[14:15], off offset:96
.LBB90_39:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_mov_b32_e32 v40, 0
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v120, 0
	s_and_saveexec_b32 s14, s5
	s_cbranch_execz .LBB90_41
; %bb.40:                               ;   in Loop: Header=BB90_9 Depth=1
	s_clause 0x1
	global_load_b64 v[42:43], v[16:17], off offset:768 th:TH_LOAD_NT
	global_load_b64 v[40:41], v[18:19], off offset:768 th:TH_LOAD_NT
	s_clause 0x1
	global_load_u8 v118, v[20:21], off offset:96
	global_load_u8 v120, v[22:23], off offset:96
.LBB90_41:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v94, 0
	v_cndmask_b32_e64 v99, 0, 1, s42
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v106, 0
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v110, 0
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v90, 0
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v98, 0
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v104, 0
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v116, 0
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v112, 0
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v108, 0
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v96, 0
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v92, 0
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v88, 0
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v109, 0
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v91, 0
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v93, 0
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v86, 0
	s_and_saveexec_b32 s39, s2
	s_cbranch_execnz .LBB90_46
; %bb.42:                               ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s3
	s_cbranch_execnz .LBB90_61
.LBB90_43:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s4
	s_cbranch_execnz .LBB90_70
.LBB90_44:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s5
	s_cbranch_execnz .LBB90_79
.LBB90_45:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s0
	s_cbranch_execnz .LBB90_88
	s_branch .LBB90_105
.LBB90_46:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_kmcnt 0x0
	s_abs_i32 s14, s38
	s_wait_loadcnt 0x1
	v_and_b32_e32 v85, 7, v131
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s38, 31
	s_wait_alu 0xfffe
	s_mul_i32 s43, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s43
	s_add_co_i32 s43, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s44, s14, s58
	s_cmp_ge_u32 s14, s58
	v_cvt_f32_ubyte0_e32 v85, v85
	s_cselect_b32 s41, s43, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s44, s14
	s_add_co_i32 s43, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	v_mul_f32_e32 v85, 0x3b000000, v85
	s_cselect_b32 s14, s43, s41
	v_and_b32_e32 v86, 0x7f, v131
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_loadcnt 0x0
	v_and_b32_e32 v87, 7, v130
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	v_dual_mov_b32 v112, 0 :: v_dual_and_b32 v89, 0x7f, v130
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	v_lshl_add_u32 v88, v86, 20, 0x3c000000
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	v_cvt_f32_ubyte0_e32 v87, v87
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	v_lshrrev_b32_e32 v90, 2, v70
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s41, v77, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v86
	v_mul_f32_e32 v87, 0x3b000000, v87
	s_clause 0x1
	global_load_b128 v[0:3], v[4:5], off offset:16
	global_load_b128 v[4:7], v[4:5], off
	v_lshrrev_b32_e32 v91, 6, v70
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v85, v85, v88, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v86
	v_lshl_add_u32 v88, v89, 20, 0x3c000000
	v_lshrrev_b32_e32 v92, 10, v70
	v_lshrrev_b32_e32 v93, 14, v70
	v_lshrrev_b32_e32 v94, 18, v70
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v85, 0x7fc00000, v85, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v89
	v_lshrrev_b32_e32 v95, 22, v70
	v_and_b32_e32 v90, 60, v90
	v_and_b32_e32 v91, 60, v91
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v87, v87, v88 :: v_dual_and_b32 v96, 15, v71
	v_and_b32_e32 v88, 15, v70
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v89
	v_lshrrev_b32_e32 v70, 26, v70
	v_and_b32_e32 v92, 60, v92
	v_lshrrev_b32_e32 v97, 2, v71
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v87, 0x7fc00000, v87 :: v_dual_lshlrev_b32 v88, 2, v88
	v_and_b32_e32 v93, 60, v93
	v_lshrrev_b32_e32 v98, 6, v71
	v_dual_mov_b32 v110, 0 :: v_dual_lshlrev_b32 v89, 24, v130
	v_and_b32_e32 v94, 60, v94
	v_and_b32_e32 v95, 60, v95
	v_and_b32_e32 v70, 60, v70
	ds_load_b32 v155, v88
	ds_load_b32 v139, v90
	ds_load_b32 v137, v91
	ds_load_b32 v136, v92
	ds_load_b32 v135, v93
	ds_load_b32 v134, v94
	ds_load_b32 v132, v95
	ds_load_b32 v130, v70
	v_lshrrev_b32_e32 v91, 10, v71
	v_lshrrev_b32_e32 v92, 14, v71
	v_dual_mov_b32 v109, 0 :: v_dual_lshlrev_b32 v70, 2, v96
	v_lshrrev_b32_e32 v93, 18, v71
	v_lshrrev_b32_e32 v94, 22, v71
	v_lshrrev_b32_e32 v71, 26, v71
	v_dual_mov_b32 v113, 0 :: v_dual_and_b32 v88, 60, v97
	v_and_b32_e32 v90, 60, v98
	v_and_b32_e32 v96, 15, v68
	v_and_b32_e32 v91, 60, v91
	v_lshrrev_b32_e32 v97, 2, v68
	v_and_b32_e32 v92, 60, v92
	v_lshrrev_b32_e32 v98, 6, v68
	v_lshlrev_b32_e32 v86, 24, v131
	v_and_b32_e32 v93, 60, v93
	v_and_b32_e32 v94, 60, v94
	v_and_b32_e32 v95, 60, v71
	ds_load_b32 v133, v70
	ds_load_b32 v131, v88
	ds_load_b32 v117, v90
	ds_load_b32 v116, v91
	ds_load_b32 v115, v92
	ds_load_b32 v114, v93
	ds_load_b32 v71, v94
	ds_load_b32 v70, v95
	v_lshrrev_b32_e32 v92, 10, v68
	v_lshrrev_b32_e32 v93, 14, v68
	v_lshlrev_b32_e32 v88, 2, v96
	v_lshrrev_b32_e32 v94, 18, v68
	v_lshrrev_b32_e32 v95, 22, v68
	v_lshrrev_b32_e32 v68, 26, v68
	v_and_b32_e32 v90, 60, v97
	v_and_b32_e32 v91, 60, v98
	v_and_b32_e32 v92, 60, v92
	v_and_b32_e32 v93, 60, v93
	v_and_b32_e32 v94, 60, v94
	v_and_b32_e32 v95, 60, v95
	v_and_b32_e32 v68, 60, v68
	ds_load_b32 v173, v88
	ds_load_b32 v151, v90
	ds_load_b32 v150, v91
	ds_load_b32 v149, v92
	ds_load_b32 v147, v93
	ds_load_b32 v145, v94
	ds_load_b32 v143, v95
	ds_load_b32 v141, v68
	v_and_b32_e32 v93, 7, v162
	v_lshrrev_b32_e32 v97, 2, v69
	v_and_b32_e32 v95, 0x7f, v162
	v_and_b32_e32 v96, 15, v69
	v_and_b32_e32 v98, 7, v163
	v_cvt_f32_ubyte0_e32 v93, v93
	v_and_b32_e32 v91, 60, v97
	v_lshl_add_u32 v97, v95, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v95
	v_lshrrev_b32_e32 v68, 6, v69
	v_mul_f32_e32 v93, 0x3b000000, v93
	v_lshrrev_b32_e32 v90, 10, v69
	v_lshrrev_b32_e32 v92, 14, v69
	v_lshrrev_b32_e32 v94, 18, v69
	v_lshlrev_b32_e32 v88, 2, v96
	v_lshrrev_b32_e32 v96, 22, v69
	v_lshrrev_b32_e32 v69, 26, v69
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v93, v97, vcc_lo
	v_and_b32_e32 v97, 0x7f, v163
	v_cvt_f32_ubyte0_e32 v98, v98
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v95
	v_and_b32_e32 v68, 60, v68
	v_and_b32_e32 v90, 60, v90
	v_and_b32_e32 v92, 60, v92
	v_and_b32_e32 v94, 60, v94
	v_and_b32_e32 v96, 60, v96
	v_and_b32_e32 v100, 60, v69
	ds_load_b32 v148, v88
	ds_load_b32 v146, v91
	ds_load_b32 v144, v68
	ds_load_b32 v142, v90
	ds_load_b32 v140, v92
	ds_load_b32 v138, v94
	ds_load_b32 v69, v96
	ds_load_b32 v68, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v88, 0x7fc00000, v93, vcc_lo
	v_lshl_add_u32 v90, v97, 20, 0x3c000000
	v_mul_f32_e32 v91, 0x3b000000, v98
	v_and_b32_e32 v92, 15, v66
	v_lshrrev_b32_e32 v93, 2, v66
	v_lshrrev_b32_e32 v94, 6, v66
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	v_lshrrev_b32_e32 v95, 14, v66
	v_lshrrev_b32_e32 v96, 18, v66
	v_lshrrev_b32_e32 v98, 22, v66
	v_and_b32_e32 v100, 15, v67
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v90, v91, v90 :: v_dual_lshlrev_b32 v91, 2, v92
	v_and_b32_e32 v92, 60, v93
	v_and_b32_e32 v93, 60, v94
	v_lshrrev_b32_e32 v94, 10, v66
	v_lshrrev_b32_e32 v66, 26, v66
	v_lshrrev_b32_e32 v101, 2, v67
	v_and_b32_e32 v95, 60, v95
	v_lshrrev_b32_e32 v102, 6, v67
	v_and_b32_e32 v94, 60, v94
	v_and_b32_e32 v96, 60, v96
	v_and_b32_e32 v98, 60, v98
	v_and_b32_e32 v66, 60, v66
	ds_load_b32 v174, v91
	ds_load_b32 v172, v92
	ds_load_b32 v170, v93
	ds_load_b32 v168, v94
	ds_load_b32 v166, v95
	ds_load_b32 v161, v96
	ds_load_b32 v159, v98
	ds_load_b32 v157, v66
	v_lshrrev_b32_e32 v93, 10, v67
	v_lshrrev_b32_e32 v94, 14, v67
	v_lshlrev_b32_e32 v66, 2, v100
	v_lshrrev_b32_e32 v95, 18, v67
	v_lshrrev_b32_e32 v96, 22, v67
	v_lshrrev_b32_e32 v67, 26, v67
	v_and_b32_e32 v91, 60, v101
	v_and_b32_e32 v92, 60, v102
	v_and_b32_e32 v100, 15, v64
	v_and_b32_e32 v93, 60, v93
	v_lshrrev_b32_e32 v101, 2, v64
	v_and_b32_e32 v94, 60, v94
	v_lshrrev_b32_e32 v102, 6, v64
	v_and_b32_e32 v95, 60, v95
	v_and_b32_e32 v96, 60, v96
	v_and_b32_e32 v98, 60, v67
	ds_load_b32 v160, v66
	ds_load_b32 v158, v91
	ds_load_b32 v156, v92
	ds_load_b32 v154, v93
	ds_load_b32 v153, v94
	ds_load_b32 v152, v95
	ds_load_b32 v67, v96
	ds_load_b32 v66, v98
	v_lshrrev_b32_e32 v94, 10, v64
	v_lshrrev_b32_e32 v95, 14, v64
	v_lshlrev_b32_e32 v91, 2, v100
	v_lshrrev_b32_e32 v96, 18, v64
	v_lshrrev_b32_e32 v98, 22, v64
	v_lshrrev_b32_e32 v64, 26, v64
	v_and_b32_e32 v92, 60, v101
	v_and_b32_e32 v93, 60, v102
	v_and_b32_e32 v100, 15, v65
	v_and_b32_e32 v94, 60, v94
	v_lshrrev_b32_e32 v101, 2, v65
	v_and_b32_e32 v95, 60, v95
	v_lshrrev_b32_e32 v102, 6, v65
	v_and_b32_e32 v96, 60, v96
	v_and_b32_e32 v98, 60, v98
	v_and_b32_e32 v64, 60, v64
	ds_load_b32 v185, v91
	ds_load_b32 v184, v92
	ds_load_b32 v183, v93
	ds_load_b32 v182, v94
	ds_load_b32 v181, v95
	ds_load_b32 v180, v96
	ds_load_b32 v178, v98
	ds_load_b32 v176, v64
	v_lshrrev_b32_e32 v93, 10, v65
	v_lshrrev_b32_e32 v94, 14, v65
	v_lshlrev_b32_e32 v64, 2, v100
	v_lshrrev_b32_e32 v95, 18, v65
	v_lshrrev_b32_e32 v96, 22, v65
	v_lshrrev_b32_e32 v65, 26, v65
	v_and_b32_e32 v91, 60, v101
	v_and_b32_e32 v92, 60, v102
	v_and_b32_e32 v93, 60, v93
	v_and_b32_e32 v94, 60, v94
	v_and_b32_e32 v95, 60, v95
	v_and_b32_e32 v96, 60, v96
	v_and_b32_e32 v65, 60, v65
	ds_load_b32 v179, v64
	ds_load_b32 v177, v91
	ds_load_b32 v175, v92
	ds_load_b32 v171, v93
	ds_load_b32 v169, v94
	ds_load_b32 v167, v95
	ds_load_b32 v165, v96
	ds_load_b32 v64, v65
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_lshlrev_b32_e32 v91, 24, v162
	v_lshlrev_b32_e32 v92, 24, v163
	v_and_or_b32 v65, 0x80000000, v86, v85
	v_and_or_b32 v162, 0x80000000, v89, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v90, 0x7fc00000, v90, vcc_lo
	v_and_or_b32 v163, 0x80000000, v91, v88
	v_mov_b32_e32 v100, 0
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v164, 0x80000000, v92, v90
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_48
; %bb.47:                               ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s36
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s36, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v89, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v90, null, s41, v77, vcc_lo
	s_clause 0x1
	global_load_b128 v[85:88], v[89:90], off
	global_load_b128 v[89:92], v[89:90], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v93, 16, v85
	v_and_b32_e32 v85, 0xffff0000, v85
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v95, v173, v93, 0
	v_fma_f32 v94, v155, v93, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v96, v174, v93, 0
	s_wait_dscnt 0xf
	v_fma_f32 v93, v185, v93, 0
	v_lshlrev_b32_e32 v97, 16, v86
	v_fmac_f32_e32 v95, v151, v85
	v_fmac_f32_e32 v94, v139, v85
	v_fmac_f32_e32 v96, v172, v85
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v93, v184, v85
	v_and_b32_e32 v85, 0xffff0000, v86
	v_dual_fmac_f32 v95, v150, v97 :: v_dual_lshlrev_b32 v86, 16, v87
	v_fmac_f32_e32 v94, v137, v97
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v93, v183, v97
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v95, v149, v85
	v_fmac_f32_e32 v96, v170, v97
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v93, v182, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v94, v136, v85 :: v_dual_fmac_f32 v95, v147, v86
	v_dual_fmac_f32 v96, v168, v85 :: v_dual_and_b32 v85, 0xffff0000, v87
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v93, v181, v86
	v_fmac_f32_e32 v94, v135, v86
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v96, v166, v86
	v_dual_fmac_f32 v95, v145, v85 :: v_dual_lshlrev_b32 v86, 16, v88
	v_fmac_f32_e32 v94, v134, v85
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v93, v180, v85
	v_dual_fmac_f32 v96, v161, v85 :: v_dual_and_b32 v85, 0xffff0000, v88
	v_fmac_f32_e32 v95, v143, v86
	v_fmac_f32_e32 v94, v132, v86
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v93, v178, v86
	v_fmac_f32_e32 v96, v159, v86
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v86, 16, v89
	v_fmac_f32_e32 v95, v141, v85
	v_fmac_f32_e32 v94, v130, v85
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v93, v176, v85
	v_fmac_f32_e32 v96, v157, v85
	v_and_b32_e32 v85, 0xffff0000, v89
	v_fmac_f32_e32 v95, v148, v86
	v_fmac_f32_e32 v94, v133, v86
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v93, v179, v86
	v_fmac_f32_e32 v96, v160, v86
	v_dual_fmac_f32 v95, v146, v85 :: v_dual_lshlrev_b32 v86, 16, v90
	v_fmac_f32_e32 v94, v131, v85
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v93, v177, v85
	v_dual_fmac_f32 v96, v158, v85 :: v_dual_and_b32 v85, 0xffff0000, v90
	v_fmac_f32_e32 v95, v144, v86
	v_fmac_f32_e32 v94, v117, v86
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v93, v175, v86
	v_fmac_f32_e32 v96, v156, v86
	v_dual_fmac_f32 v95, v142, v85 :: v_dual_lshlrev_b32 v86, 16, v91
	v_fmac_f32_e32 v94, v116, v85
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v93, v171, v85
	v_dual_fmac_f32 v96, v154, v85 :: v_dual_and_b32 v85, 0xffff0000, v91
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v94, v115, v86
	v_fmac_f32_e32 v95, v140, v86
	v_fmac_f32_e32 v96, v153, v86
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v93, v169, v86 :: v_dual_lshlrev_b32 v86, 16, v92
	v_fmac_f32_e32 v94, v114, v85
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v96, v152, v85
	v_fmac_f32_e32 v95, v138, v85
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v93, v167, v85
	v_dual_fmac_f32 v94, v71, v86 :: v_dual_and_b32 v85, 0xffff0000, v92
	v_fmac_f32_e32 v96, v67, v86
	v_fmac_f32_e32 v95, v69, v86
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v93, v165, v86 :: v_dual_fmac_f32 v94, v70, v85
	v_fmac_f32_e32 v96, v66, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v95, v68, v85
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v64, v85
	v_fma_f32 v113, v94, v65, 0
	v_fma_f32 v110, v96, v163, 0
	v_fma_f32 v112, v95, v162, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v109, v93, v164, 0
.LBB90_48:                              ;   in Loop: Header=BB90_9 Depth=1
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v111, 0
	v_mov_b32_e32 v106, 0
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_50
; %bb.49:                               ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s34
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s34, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v89, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v90, null, s41, v77, vcc_lo
	s_clause 0x1
	global_load_b128 v[85:88], v[89:90], off
	global_load_b128 v[89:92], v[89:90], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v93, 16, v85
	v_and_b32_e32 v85, 0xffff0000, v85
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v95, v173, v93, 0
	v_fma_f32 v94, v155, v93, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v96, v174, v93, 0
	s_wait_dscnt 0xf
	v_fma_f32 v93, v185, v93, 0
	v_lshlrev_b32_e32 v97, 16, v86
	v_fmac_f32_e32 v95, v151, v85
	v_fmac_f32_e32 v94, v139, v85
	v_fmac_f32_e32 v96, v172, v85
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v93, v184, v85
	v_and_b32_e32 v85, 0xffff0000, v86
	v_dual_fmac_f32 v95, v150, v97 :: v_dual_lshlrev_b32 v86, 16, v87
	v_fmac_f32_e32 v94, v137, v97
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v93, v183, v97
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v95, v149, v85
	v_fmac_f32_e32 v96, v170, v97
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v93, v182, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v94, v136, v85 :: v_dual_fmac_f32 v95, v147, v86
	v_dual_fmac_f32 v96, v168, v85 :: v_dual_and_b32 v85, 0xffff0000, v87
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v93, v181, v86
	v_fmac_f32_e32 v94, v135, v86
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v96, v166, v86
	v_dual_fmac_f32 v95, v145, v85 :: v_dual_lshlrev_b32 v86, 16, v88
	v_fmac_f32_e32 v94, v134, v85
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v93, v180, v85
	v_dual_fmac_f32 v96, v161, v85 :: v_dual_and_b32 v85, 0xffff0000, v88
	v_fmac_f32_e32 v95, v143, v86
	v_fmac_f32_e32 v94, v132, v86
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v93, v178, v86
	v_fmac_f32_e32 v96, v159, v86
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v86, 16, v89
	v_fmac_f32_e32 v95, v141, v85
	v_fmac_f32_e32 v94, v130, v85
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v93, v176, v85
	v_fmac_f32_e32 v96, v157, v85
	v_and_b32_e32 v85, 0xffff0000, v89
	v_fmac_f32_e32 v95, v148, v86
	v_fmac_f32_e32 v94, v133, v86
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v93, v179, v86
	v_fmac_f32_e32 v96, v160, v86
	v_dual_fmac_f32 v95, v146, v85 :: v_dual_lshlrev_b32 v86, 16, v90
	v_fmac_f32_e32 v94, v131, v85
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v93, v177, v85
	v_dual_fmac_f32 v96, v158, v85 :: v_dual_and_b32 v85, 0xffff0000, v90
	v_fmac_f32_e32 v95, v144, v86
	v_fmac_f32_e32 v94, v117, v86
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v93, v175, v86
	v_fmac_f32_e32 v96, v156, v86
	v_dual_fmac_f32 v95, v142, v85 :: v_dual_lshlrev_b32 v86, 16, v91
	v_fmac_f32_e32 v94, v116, v85
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v93, v171, v85
	v_dual_fmac_f32 v96, v154, v85 :: v_dual_and_b32 v85, 0xffff0000, v91
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v94, v115, v86
	v_fmac_f32_e32 v95, v140, v86
	v_fmac_f32_e32 v96, v153, v86
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v93, v169, v86 :: v_dual_lshlrev_b32 v86, 16, v92
	v_fmac_f32_e32 v94, v114, v85
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v96, v152, v85
	v_fmac_f32_e32 v95, v138, v85
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v93, v167, v85
	v_dual_fmac_f32 v94, v71, v86 :: v_dual_and_b32 v85, 0xffff0000, v92
	v_fmac_f32_e32 v96, v67, v86
	v_fmac_f32_e32 v95, v69, v86
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v93, v165, v86 :: v_dual_fmac_f32 v94, v70, v85
	v_fmac_f32_e32 v96, v66, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v95, v68, v85
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v64, v85
	v_fma_f32 v111, v94, v65, 0
	v_fma_f32 v106, v96, v163, 0
	v_fma_f32 v108, v95, v162, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v100, v93, v164, 0
.LBB90_50:                              ;   in Loop: Header=BB90_9 Depth=1
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v102, 0
	v_mov_b32_e32 v105, 0
	v_mov_b32_e32 v107, 0
	v_mov_b32_e32 v103, 0
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_52
; %bb.51:                               ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s30
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s30, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v89, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v90, null, s41, v77, vcc_lo
	s_clause 0x1
	global_load_b128 v[85:88], v[89:90], off
	global_load_b128 v[92:95], v[89:90], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v98, 16, v86
	v_lshlrev_b32_e32 v89, 16, v85
	v_and_b32_e32 v85, 0xffff0000, v85
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v90, v155, v89, 0
	v_fmac_f32_e32 v90, v139, v85
	s_wait_dscnt 0x3d
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v90, v137, v98
	s_wait_dscnt 0x2f
	v_fma_f32 v96, v173, v89, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v97, v174, v89, 0
	s_wait_dscnt 0xf
	v_fma_f32 v89, v185, v89, 0
	v_fmac_f32_e32 v96, v151, v85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v96, v150, v98 :: v_dual_fmac_f32 v97, v172, v85
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v89, v184, v85
	v_and_b32_e32 v85, 0xffff0000, v86
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v97, v170, v98 :: v_dual_lshlrev_b32 v86, 16, v87
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v89, v183, v98 :: v_dual_fmac_f32 v90, v136, v85
	v_fmac_f32_e32 v96, v149, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v97, v168, v85
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v89, v182, v85
	v_dual_fmac_f32 v90, v135, v86 :: v_dual_and_b32 v85, 0xffff0000, v87
	v_fmac_f32_e32 v96, v147, v86
	v_fmac_f32_e32 v97, v166, v86
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v89, v181, v86 :: v_dual_lshlrev_b32 v86, 16, v88
	v_fmac_f32_e32 v90, v134, v85
	v_fmac_f32_e32 v96, v145, v85
	v_fmac_f32_e32 v97, v161, v85
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v89, v180, v85
	v_dual_fmac_f32 v90, v132, v86 :: v_dual_and_b32 v85, 0xffff0000, v88
	v_fmac_f32_e32 v96, v143, v86
	v_fmac_f32_e32 v97, v159, v86
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v89, v178, v86 :: v_dual_lshlrev_b32 v86, 16, v92
	v_fmac_f32_e32 v90, v130, v85
	v_fmac_f32_e32 v96, v141, v85
	v_fmac_f32_e32 v97, v157, v85
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v89, v176, v85
	v_dual_fmac_f32 v90, v133, v86 :: v_dual_and_b32 v85, 0xffff0000, v92
	v_fmac_f32_e32 v96, v148, v86
	v_fmac_f32_e32 v97, v160, v86
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v89, v179, v86 :: v_dual_lshlrev_b32 v86, 16, v93
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v96, v146, v85
	v_fmac_f32_e32 v97, v158, v85
	v_fmac_f32_e32 v90, v131, v85
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v89, v177, v85 :: v_dual_fmac_f32 v96, v144, v86
	v_fmac_f32_e32 v97, v156, v86
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v90, v117, v86
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v89, v175, v86
	v_lshlrev_b32_e32 v86, 16, v94
	v_and_b32_e32 v85, 0xffff0000, v93
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v90, v116, v85
	v_fmac_f32_e32 v90, v115, v86
	v_fmac_f32_e32 v96, v142, v85
	v_fmac_f32_e32 v97, v154, v85
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v89, v171, v85
	v_and_b32_e32 v85, 0xffff0000, v94
	v_fmac_f32_e32 v96, v140, v86
	v_fmac_f32_e32 v97, v153, v86
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v89, v169, v86 :: v_dual_fmac_f32 v90, v114, v85
	v_lshlrev_b32_e32 v86, 16, v95
	v_fmac_f32_e32 v96, v138, v85
	v_fmac_f32_e32 v97, v152, v85
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v89, v167, v85
	v_dual_fmac_f32 v90, v71, v86 :: v_dual_and_b32 v85, 0xffff0000, v95
	v_fmac_f32_e32 v96, v69, v86
	v_fmac_f32_e32 v97, v67, v86
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v89, v165, v86 :: v_dual_fmac_f32 v90, v70, v85
	v_fmac_f32_e32 v96, v68, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v97, v66, v85
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v89, v64, v85
	v_fma_f32 v107, v90, v65, 0
	v_fma_f32 v105, v96, v162, 0
	v_fma_f32 v103, v97, v163, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v102, v89, v164, 0
.LBB90_52:                              ;   in Loop: Header=BB90_9 Depth=1
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v104, 0
	v_mov_b32_e32 v97, 0
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_54
; %bb.53:                               ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s28
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s28, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v89, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v90, null, s41, v77, vcc_lo
	s_clause 0x1
	global_load_b128 v[85:88], v[89:90], off
	global_load_b128 v[89:92], v[89:90], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v93, 16, v85
	v_and_b32_e32 v85, 0xffff0000, v85
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v95, v173, v93, 0
	v_fma_f32 v94, v155, v93, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v96, v174, v93, 0
	s_wait_dscnt 0xf
	v_fma_f32 v93, v185, v93, 0
	v_lshlrev_b32_e32 v97, 16, v86
	v_fmac_f32_e32 v95, v151, v85
	v_fmac_f32_e32 v94, v139, v85
	v_fmac_f32_e32 v96, v172, v85
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v93, v184, v85
	v_and_b32_e32 v85, 0xffff0000, v86
	v_dual_fmac_f32 v95, v150, v97 :: v_dual_lshlrev_b32 v86, 16, v87
	v_fmac_f32_e32 v94, v137, v97
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v93, v183, v97
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v95, v149, v85
	v_fmac_f32_e32 v96, v170, v97
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v93, v182, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v94, v136, v85 :: v_dual_fmac_f32 v95, v147, v86
	v_dual_fmac_f32 v96, v168, v85 :: v_dual_and_b32 v85, 0xffff0000, v87
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v93, v181, v86
	v_fmac_f32_e32 v94, v135, v86
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v96, v166, v86
	v_dual_fmac_f32 v95, v145, v85 :: v_dual_lshlrev_b32 v86, 16, v88
	v_fmac_f32_e32 v94, v134, v85
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v93, v180, v85
	v_dual_fmac_f32 v96, v161, v85 :: v_dual_and_b32 v85, 0xffff0000, v88
	v_fmac_f32_e32 v95, v143, v86
	v_fmac_f32_e32 v94, v132, v86
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v93, v178, v86
	v_fmac_f32_e32 v96, v159, v86
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v86, 16, v89
	v_fmac_f32_e32 v95, v141, v85
	v_fmac_f32_e32 v94, v130, v85
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v93, v176, v85
	v_fmac_f32_e32 v96, v157, v85
	v_and_b32_e32 v85, 0xffff0000, v89
	v_fmac_f32_e32 v95, v148, v86
	v_fmac_f32_e32 v94, v133, v86
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v93, v179, v86
	v_fmac_f32_e32 v96, v160, v86
	v_dual_fmac_f32 v95, v146, v85 :: v_dual_lshlrev_b32 v86, 16, v90
	v_fmac_f32_e32 v94, v131, v85
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v93, v177, v85
	v_dual_fmac_f32 v96, v158, v85 :: v_dual_and_b32 v85, 0xffff0000, v90
	v_fmac_f32_e32 v95, v144, v86
	v_fmac_f32_e32 v94, v117, v86
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v93, v175, v86
	v_fmac_f32_e32 v96, v156, v86
	v_dual_fmac_f32 v95, v142, v85 :: v_dual_lshlrev_b32 v86, 16, v91
	v_fmac_f32_e32 v94, v116, v85
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v93, v171, v85
	v_dual_fmac_f32 v96, v154, v85 :: v_dual_and_b32 v85, 0xffff0000, v91
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v94, v115, v86
	v_fmac_f32_e32 v95, v140, v86
	v_fmac_f32_e32 v96, v153, v86
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v93, v169, v86 :: v_dual_lshlrev_b32 v86, 16, v92
	v_fmac_f32_e32 v94, v114, v85
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v96, v152, v85
	v_fmac_f32_e32 v95, v138, v85
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v93, v167, v85
	v_dual_fmac_f32 v94, v71, v86 :: v_dual_and_b32 v85, 0xffff0000, v92
	v_fmac_f32_e32 v96, v67, v86
	v_fmac_f32_e32 v95, v69, v86
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v93, v165, v86 :: v_dual_fmac_f32 v94, v70, v85
	v_fmac_f32_e32 v96, v66, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v95, v68, v85
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v93, v64, v85
	v_fma_f32 v104, v94, v65, 0
	v_fma_f32 v97, v96, v163, 0
	v_fma_f32 v101, v95, v162, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v91, v93, v164, 0
.LBB90_54:                              ;   in Loop: Header=BB90_9 Depth=1
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v96, 0
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v98, 0
	v_mov_b32_e32 v94, 0
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_56
; %bb.55:                               ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s26
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s26, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v92, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v93, null, s41, v77, vcc_lo
	s_clause 0x1
	global_load_b128 v[86:89], v[92:93], off
	global_load_b128 v[92:95], v[92:93], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v90, 16, v86
	v_and_b32_e32 v86, 0xffff0000, v86
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v96, v155, v90, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v186, v173, v90, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v187, v174, v90, 0
	s_wait_dscnt 0xf
	v_fma_f32 v90, v185, v90, 0
	v_lshlrev_b32_e32 v98, 16, v87
	v_fmac_f32_e32 v96, v139, v86
	v_fmac_f32_e32 v186, v151, v86
	v_fmac_f32_e32 v187, v172, v86
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v90, v184, v86
	v_and_b32_e32 v86, 0xffff0000, v87
	v_dual_fmac_f32 v96, v137, v98 :: v_dual_lshlrev_b32 v87, 16, v88
	v_fmac_f32_e32 v186, v150, v98
	v_fmac_f32_e32 v187, v170, v98
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v90, v183, v98
	v_fmac_f32_e32 v96, v136, v86
	v_fmac_f32_e32 v186, v149, v86
	v_fmac_f32_e32 v187, v168, v86
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v90, v182, v86
	v_and_b32_e32 v86, 0xffff0000, v88
	v_fmac_f32_e32 v186, v147, v87
	v_fmac_f32_e32 v187, v166, v87
	v_fmac_f32_e32 v96, v135, v87
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v90, v181, v87 :: v_dual_lshlrev_b32 v87, 16, v89
	v_fmac_f32_e32 v186, v145, v86
	v_fmac_f32_e32 v187, v161, v86
	v_fmac_f32_e32 v96, v134, v86
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v90, v180, v86
	v_and_b32_e32 v86, 0xffff0000, v89
	v_fmac_f32_e32 v186, v143, v87
	v_fmac_f32_e32 v187, v159, v87
	v_fmac_f32_e32 v96, v132, v87
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v90, v178, v87 :: v_dual_lshlrev_b32 v87, 16, v92
	v_fmac_f32_e32 v186, v141, v86
	v_fmac_f32_e32 v187, v157, v86
	v_fmac_f32_e32 v96, v130, v86
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v90, v176, v86
	v_and_b32_e32 v86, 0xffff0000, v92
	v_fmac_f32_e32 v186, v148, v87
	v_fmac_f32_e32 v187, v160, v87
	v_fmac_f32_e32 v96, v133, v87
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v90, v179, v87 :: v_dual_lshlrev_b32 v87, 16, v93
	v_fmac_f32_e32 v186, v146, v86
	v_fmac_f32_e32 v187, v158, v86
	v_fmac_f32_e32 v96, v131, v86
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v90, v177, v86
	v_and_b32_e32 v86, 0xffff0000, v93
	v_fmac_f32_e32 v186, v144, v87
	v_fmac_f32_e32 v187, v156, v87
	v_fmac_f32_e32 v96, v117, v87
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v90, v175, v87 :: v_dual_lshlrev_b32 v87, 16, v94
	v_fmac_f32_e32 v186, v142, v86
	v_fmac_f32_e32 v187, v154, v86
	v_fmac_f32_e32 v96, v116, v86
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v90, v171, v86
	v_and_b32_e32 v86, 0xffff0000, v94
	v_fmac_f32_e32 v186, v140, v87
	v_fmac_f32_e32 v187, v153, v87
	v_fmac_f32_e32 v96, v115, v87
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v90, v169, v87
	v_dual_fmac_f32 v186, v138, v86 :: v_dual_lshlrev_b32 v87, 16, v95
	v_fmac_f32_e32 v187, v152, v86
	v_fmac_f32_e32 v96, v114, v86
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v90, v167, v86
	v_and_b32_e32 v86, 0xffff0000, v95
	v_fmac_f32_e32 v186, v69, v87
	v_fmac_f32_e32 v187, v67, v87
	v_fmac_f32_e32 v96, v71, v87
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v90, v165, v87
	v_fmac_f32_e32 v186, v68, v86
	v_fmac_f32_e32 v187, v66, v86
	v_fmac_f32_e32 v96, v70, v86
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v90, v64, v86
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v94, v187, v163, 0
	v_fma_f32 v98, v96, v65, 0
	v_fma_f32 v96, v186, v162, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v93, v90, v164, 0
.LBB90_56:                              ;   in Loop: Header=BB90_9 Depth=1
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v95, 0
	v_mov_b32_e32 v89, 0
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_58
; %bb.57:                               ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s24
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s24, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v89, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v90, null, s41, v77, vcc_lo
	s_clause 0x1
	global_load_b128 v[85:88], v[89:90], off
	global_load_b128 v[186:189], v[89:90], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v89, 16, v85
	v_and_b32_e32 v85, 0xffff0000, v85
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v190, v174, v89, 0
	v_fma_f32 v90, v155, v89, 0
	v_fma_f32 v92, v173, v89, 0
	s_wait_dscnt 0xf
	v_fma_f32 v191, v185, v89, 0
	v_dual_fmac_f32 v190, v172, v85 :: v_dual_lshlrev_b32 v89, 16, v86
	v_fmac_f32_e32 v90, v139, v85
	v_fmac_f32_e32 v92, v151, v85
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v191, v184, v85
	v_dual_fmac_f32 v190, v170, v89 :: v_dual_and_b32 v85, 0xffff0000, v86
	v_lshlrev_b32_e32 v86, 16, v87
	v_fmac_f32_e32 v90, v137, v89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v190, v168, v85
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v191, v183, v89
	v_fmac_f32_e32 v90, v136, v85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v190, v166, v86
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v191, v182, v85
	v_fmac_f32_e32 v92, v150, v89
	v_fmac_f32_e32 v90, v135, v86
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v191, v181, v86
	v_dual_fmac_f32 v92, v149, v85 :: v_dual_and_b32 v85, 0xffff0000, v87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v92, v147, v86
	v_lshlrev_b32_e32 v86, 16, v88
	v_fmac_f32_e32 v90, v134, v85
	v_fmac_f32_e32 v190, v161, v85
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v92, v145, v85
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v191, v180, v85
	v_dual_fmac_f32 v90, v132, v86 :: v_dual_and_b32 v85, 0xffff0000, v88
	v_fmac_f32_e32 v92, v143, v86
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v191, v178, v86
	v_fmac_f32_e32 v190, v159, v86
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v86, 16, v186
	v_fmac_f32_e32 v90, v130, v85
	v_fmac_f32_e32 v92, v141, v85
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v191, v176, v85
	v_dual_fmac_f32 v190, v157, v85 :: v_dual_and_b32 v85, 0xffff0000, v186
	v_fmac_f32_e32 v90, v133, v86
	v_fmac_f32_e32 v92, v148, v86
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v191, v179, v86
	v_fmac_f32_e32 v190, v160, v86
	v_lshlrev_b32_e32 v86, 16, v187
	v_fmac_f32_e32 v90, v131, v85
	v_fmac_f32_e32 v92, v146, v85
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v191, v177, v85
	v_dual_fmac_f32 v190, v158, v85 :: v_dual_and_b32 v85, 0xffff0000, v187
	v_fmac_f32_e32 v90, v117, v86
	v_fmac_f32_e32 v92, v144, v86
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v191, v175, v86
	v_fmac_f32_e32 v190, v156, v86
	v_lshlrev_b32_e32 v86, 16, v188
	v_fmac_f32_e32 v90, v116, v85
	v_fmac_f32_e32 v92, v142, v85
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v191, v171, v85
	v_dual_fmac_f32 v190, v154, v85 :: v_dual_and_b32 v85, 0xffff0000, v188
	v_fmac_f32_e32 v90, v115, v86
	v_fmac_f32_e32 v92, v140, v86
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v191, v169, v86
	v_fmac_f32_e32 v190, v153, v86
	v_lshlrev_b32_e32 v86, 16, v189
	v_fmac_f32_e32 v90, v114, v85
	v_fmac_f32_e32 v92, v138, v85
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v191, v167, v85
	v_fmac_f32_e32 v190, v152, v85
	v_dual_fmac_f32 v90, v71, v86 :: v_dual_and_b32 v85, 0xffff0000, v189
	v_fmac_f32_e32 v92, v69, v86
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v191, v165, v86
	v_fmac_f32_e32 v190, v67, v86
	v_fmac_f32_e32 v90, v70, v85
	v_fmac_f32_e32 v92, v68, v85
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v191, v64, v85
	v_fmac_f32_e32 v190, v66, v85
	v_fma_f32 v95, v90, v65, 0
	v_fma_f32 v92, v92, v162, 0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v85, v191, v164, 0
	v_fma_f32 v89, v190, v163, 0
.LBB90_58:                              ;   in Loop: Header=BB90_9 Depth=1
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v90, 0
	v_mov_b32_e32 v88, 0
	v_mov_b32_e32 v86, 0
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_60
; %bb.59:                               ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s10
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s10, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v86, vcc_lo, v76, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v87, null, s41, v77, vcc_lo
	s_clause 0x1
	global_load_b128 v[186:189], v[86:87], off
	global_load_b128 v[190:193], v[86:87], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v86, 16, v186
	v_and_b32_e32 v87, 0xffff0000, v186
	v_lshlrev_b32_e32 v90, 16, v187
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_3)
	v_fma_f32 v88, v155, v86, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v186, v173, v86, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v194, v174, v86, 0
	s_wait_dscnt 0xf
	v_fma_f32 v86, v185, v86, 0
	v_fmac_f32_e32 v88, v139, v87
	v_fmac_f32_e32 v186, v151, v87
	v_fmac_f32_e32 v194, v172, v87
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v86, v184, v87
	v_dual_fmac_f32 v88, v137, v90 :: v_dual_and_b32 v87, 0xffff0000, v187
	v_fmac_f32_e32 v186, v150, v90
	v_fmac_f32_e32 v194, v170, v90
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v86, v183, v90
	v_lshlrev_b32_e32 v90, 16, v188
	v_fmac_f32_e32 v88, v136, v87
	v_fmac_f32_e32 v186, v149, v87
	v_fmac_f32_e32 v194, v168, v87
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v86, v182, v87 :: v_dual_and_b32 v87, 0xffff0000, v188
	v_fmac_f32_e32 v88, v135, v90
	v_fmac_f32_e32 v186, v147, v90
	v_fmac_f32_e32 v194, v166, v90
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v86, v181, v90
	v_lshlrev_b32_e32 v90, 16, v189
	v_fmac_f32_e32 v88, v134, v87
	v_fmac_f32_e32 v186, v145, v87
	v_fmac_f32_e32 v194, v161, v87
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v86, v180, v87 :: v_dual_and_b32 v87, 0xffff0000, v189
	v_fmac_f32_e32 v88, v132, v90
	v_fmac_f32_e32 v186, v143, v90
	v_fmac_f32_e32 v194, v159, v90
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v86, v178, v90
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v90, 16, v190
	v_fmac_f32_e32 v88, v130, v87
	v_fmac_f32_e32 v186, v141, v87
	v_fmac_f32_e32 v194, v157, v87
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v86, v176, v87 :: v_dual_and_b32 v87, 0xffff0000, v190
	v_fmac_f32_e32 v88, v133, v90
	v_fmac_f32_e32 v186, v148, v90
	v_fmac_f32_e32 v194, v160, v90
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v86, v179, v90
	v_lshlrev_b32_e32 v90, 16, v191
	v_fmac_f32_e32 v88, v131, v87
	v_fmac_f32_e32 v186, v146, v87
	v_fmac_f32_e32 v194, v158, v87
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v86, v177, v87
	v_dual_fmac_f32 v88, v117, v90 :: v_dual_and_b32 v87, 0xffff0000, v191
	v_fmac_f32_e32 v186, v144, v90
	v_fmac_f32_e32 v194, v156, v90
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v86, v175, v90
	v_lshlrev_b32_e32 v90, 16, v192
	v_fmac_f32_e32 v88, v116, v87
	v_fmac_f32_e32 v186, v142, v87
	v_fmac_f32_e32 v194, v154, v87
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v86, v171, v87 :: v_dual_and_b32 v87, 0xffff0000, v192
	v_fmac_f32_e32 v88, v115, v90
	v_fmac_f32_e32 v186, v140, v90
	v_fmac_f32_e32 v194, v153, v90
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v86, v169, v90
	v_lshlrev_b32_e32 v90, 16, v193
	v_fmac_f32_e32 v88, v114, v87
	v_fmac_f32_e32 v186, v138, v87
	v_fmac_f32_e32 v194, v152, v87
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v86, v167, v87 :: v_dual_and_b32 v87, 0xffff0000, v193
	v_fmac_f32_e32 v88, v71, v90
	v_fmac_f32_e32 v186, v69, v90
	v_fmac_f32_e32 v194, v67, v90
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v86, v165, v90
	v_fmac_f32_e32 v88, v70, v87
	v_fmac_f32_e32 v186, v68, v87
	v_fmac_f32_e32 v194, v66, v87
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v86, v64, v87
	v_fma_f32 v90, v88, v65, 0
	v_fma_f32 v88, v186, v162, 0
	v_fma_f32 v87, v194, v163, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v86, v86, v164, 0
.LBB90_60:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v186, 16, v4
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v155, v155, v186, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v173, v173, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v174, v174, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v185, v185, v186, 0
	v_lshlrev_b32_e32 v186, 16, v5
	v_and_b32_e32 v4, 0xffff0000, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v139, v4
	v_fmac_f32_e32 v155, v137, v186
	v_fmac_f32_e32 v173, v151, v4
	v_fmac_f32_e32 v174, v172, v4
	s_wait_dscnt 0xe
	v_dual_fmac_f32 v185, v184, v4 :: v_dual_and_b32 v4, 0xffff0000, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v173, v150, v186
	v_fmac_f32_e32 v174, v170, v186
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v185, v183, v186
	v_fmac_f32_e32 v155, v136, v4
	v_fmac_f32_e32 v174, v168, v4
	v_fmac_f32_e32 v173, v149, v4
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v185, v182, v4 :: v_dual_and_b32 v4, 0xffff0000, v6
	v_lshlrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v174, v166, v5
	v_dual_fmac_f32 v174, v161, v4 :: v_dual_fmac_f32 v155, v135, v5
	v_fmac_f32_e32 v173, v147, v5
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v185, v181, v5
	v_lshlrev_b32_e32 v5, 16, v7
	v_fmac_f32_e32 v155, v134, v4
	v_fmac_f32_e32 v173, v145, v4
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v185, v180, v4 :: v_dual_and_b32 v4, 0xffff0000, v7
	v_fmac_f32_e32 v174, v159, v5
	v_fmac_f32_e32 v155, v132, v5
	v_fmac_f32_e32 v173, v143, v5
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v185, v178, v5
	v_lshlrev_b32_e32 v5, 16, v0
	v_fmac_f32_e32 v174, v157, v4
	v_fmac_f32_e32 v155, v130, v4
	v_fmac_f32_e32 v173, v141, v4
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v185, v176, v4
	v_and_b32_e32 v0, 0xffff0000, v0
	v_fmac_f32_e32 v174, v160, v5
	v_fmac_f32_e32 v155, v133, v5
	v_fmac_f32_e32 v173, v148, v5
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v185, v179, v5
	v_lshlrev_b32_e32 v4, 16, v1
	v_fmac_f32_e32 v174, v158, v0
	v_fmac_f32_e32 v155, v131, v0
	v_fmac_f32_e32 v173, v146, v0
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v185, v177, v0 :: v_dual_and_b32 v0, 0xffff0000, v1
	v_fmac_f32_e32 v174, v156, v4
	v_fmac_f32_e32 v155, v117, v4
	v_fmac_f32_e32 v173, v144, v4
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v185, v175, v4
	v_dual_fmac_f32 v174, v154, v0 :: v_dual_lshlrev_b32 v1, 16, v2
	v_fmac_f32_e32 v155, v116, v0
	v_fmac_f32_e32 v173, v142, v0
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v185, v171, v0 :: v_dual_and_b32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v174, v153, v1
	v_fmac_f32_e32 v155, v115, v1
	v_fmac_f32_e32 v173, v140, v1
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v185, v169, v1
	v_dual_fmac_f32 v174, v152, v0 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v155, v114, v0
	v_fmac_f32_e32 v173, v138, v0
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v185, v167, v0 :: v_dual_and_b32 v0, 0xffff0000, v3
	v_fmac_f32_e32 v174, v67, v1
	v_fmac_f32_e32 v155, v71, v1
	v_fmac_f32_e32 v173, v69, v1
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v185, v165, v1 :: v_dual_fmac_f32 v174, v66, v0
	v_fmac_f32_e32 v155, v70, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v173, v68, v0
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v185, v64, v0
	v_fma_f32 v115, v174, v163, 0
	v_fma_f32 v117, v155, v65, 0
	v_fma_f32 v116, v173, v162, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v114, v185, v164, 0
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s3
	s_cbranch_execz .LBB90_43
.LBB90_61:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_kmcnt 0x0
	s_abs_i32 s14, s38
	s_wait_loadcnt 0x1
	v_and_b32_e32 v64, 7, v129
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s38, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	v_cvt_f32_ubyte0_e32 v64, v64
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	v_mul_f32_e32 v64, 0x3b000000, v64
	s_cselect_b32 s14, s42, s41
	v_and_b32_e32 v65, 0x7f, v129
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	v_and_b32_e32 v180, 0x7f, v126
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_loadcnt 0x0
	v_and_b32_e32 v183, 0x7f, v128
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	v_lshl_add_u32 v67, v65, 20, 0x3c000000
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	v_lshl_add_u32 v181, v180, 20, 0x3c000000
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	v_and_b32_e32 v68, 0x7f, v127
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s41, v79, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	v_lshl_add_u32 v184, v183, 20, 0x3c000000
	v_lshrrev_b32_e32 v70, 22, v62
	s_clause 0x1
	global_load_b128 v[0:3], v[4:5], off offset:16
	global_load_b128 v[4:7], v[4:5], off
	v_lshrrev_b32_e32 v69, 18, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_and_b32_e32 v66, 7, v127
	v_lshl_add_u32 v67, v68, 20, 0x3c000000
	v_and_b32_e32 v65, 15, v62
	v_and_b32_e32 v71, 15, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v159, 0x7fc00000, v64, vcc_lo
	v_cvt_f32_ubyte0_e32 v66, v66
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_lshrrev_b32_e32 v132, 2, v63
	v_and_b32_e32 v70, 60, v70
	v_lshrrev_b32_e32 v134, 6, v63
	v_dual_mul_f32 v66, 0x3b000000, v66 :: v_dual_and_b32 v69, 60, v69
	v_and_b32_e32 v138, 15, v60
	v_lshrrev_b32_e32 v140, 6, v60
	v_lshrrev_b32_e32 v139, 2, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v66, v67, vcc_lo
	v_lshrrev_b32_e32 v66, 2, v62
	v_lshrrev_b32_e32 v67, 6, v62
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	v_lshlrev_b32_e32 v178, 24, v129
	v_lshrrev_b32_e32 v68, 14, v62
	v_and_b32_e32 v141, 15, v61
	v_lshrrev_b32_e32 v147, 2, v61
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v179, 0x7fc00000, v64 :: v_dual_lshlrev_b32 v64, 2, v65
	v_and_b32_e32 v65, 60, v66
	v_and_b32_e32 v66, 60, v67
	v_lshrrev_b32_e32 v67, 10, v62
	v_lshrrev_b32_e32 v62, 26, v62
	v_and_b32_e32 v68, 60, v68
	v_lshrrev_b32_e32 v148, 6, v61
	v_and_b32_e32 v153, 7, v128
	v_and_b32_e32 v67, 60, v67
	v_and_b32_e32 v62, 60, v62
	ds_load_b32 v152, v64
	ds_load_b32 v135, v65
	ds_load_b32 v133, v66
	ds_load_b32 v131, v67
	ds_load_b32 v130, v68
	ds_load_b32 v129, v69
	ds_load_b32 v70, v70
	ds_load_b32 v68, v62
	v_lshrrev_b32_e32 v66, 10, v63
	v_lshlrev_b32_e32 v62, 2, v71
	v_lshrrev_b32_e32 v67, 14, v63
	v_lshrrev_b32_e32 v69, 18, v63
	v_lshrrev_b32_e32 v71, 22, v63
	v_lshrrev_b32_e32 v63, 26, v63
	v_and_b32_e32 v64, 60, v132
	v_and_b32_e32 v65, 60, v134
	v_and_b32_e32 v66, 60, v66
	v_and_b32_e32 v132, 60, v67
	v_and_b32_e32 v137, 60, v63
	v_and_b32_e32 v134, 60, v69
	v_and_b32_e32 v136, 60, v71
	ds_load_b32 v71, v62
	ds_load_b32 v69, v64
	ds_load_b32 v67, v65
	ds_load_b32 v66, v66
	ds_load_b32 v65, v132
	ds_load_b32 v64, v134
	ds_load_b32 v63, v136
	ds_load_b32 v62, v137
	v_lshrrev_b32_e32 v137, 10, v60
	v_lshlrev_b32_e32 v132, 2, v138
	v_and_b32_e32 v136, 60, v140
	v_lshrrev_b32_e32 v138, 14, v60
	v_lshrrev_b32_e32 v140, 22, v60
	v_and_b32_e32 v134, 60, v139
	v_lshrrev_b32_e32 v139, 18, v60
	v_lshrrev_b32_e32 v60, 26, v60
	v_and_b32_e32 v137, 60, v137
	v_and_b32_e32 v138, 60, v138
	v_and_b32_e32 v140, 60, v140
	v_and_b32_e32 v139, 60, v139
	v_and_b32_e32 v60, 60, v60
	ds_load_b32 v169, v132
	ds_load_b32 v146, v134
	ds_load_b32 v145, v136
	ds_load_b32 v144, v137
	ds_load_b32 v143, v138
	ds_load_b32 v142, v139
	ds_load_b32 v140, v140
	ds_load_b32 v138, v60
	v_lshrrev_b32_e32 v137, 14, v61
	v_lshrrev_b32_e32 v60, 10, v61
	v_lshlrev_b32_e32 v132, 2, v141
	v_lshrrev_b32_e32 v139, 18, v61
	v_lshrrev_b32_e32 v141, 22, v61
	v_lshrrev_b32_e32 v61, 26, v61
	v_and_b32_e32 v134, 60, v147
	v_and_b32_e32 v147, 60, v137
	v_and_b32_e32 v137, 7, v126
	v_and_b32_e32 v136, 60, v148
	v_and_b32_e32 v60, 60, v60
	v_and_b32_e32 v148, 60, v139
	v_and_b32_e32 v149, 60, v141
	v_and_b32_e32 v150, 60, v61
	v_cvt_f32_ubyte0_e32 v151, v137
	ds_load_b32 v141, v132
	ds_load_b32 v139, v134
	ds_load_b32 v137, v136
	ds_load_b32 v136, v60
	ds_load_b32 v134, v147
	ds_load_b32 v132, v148
	ds_load_b32 v61, v149
	ds_load_b32 v60, v150
	v_cvt_f32_ubyte0_e32 v147, v153
	v_and_b32_e32 v148, 15, v58
	v_lshrrev_b32_e32 v149, 2, v58
	v_lshrrev_b32_e32 v150, 6, v58
	v_mul_f32_e32 v182, 0x3b000000, v151
	v_mul_f32_e32 v185, 0x3b000000, v147
	v_lshlrev_b32_e32 v147, 2, v148
	v_and_b32_e32 v148, 60, v149
	v_and_b32_e32 v149, 60, v150
	v_lshrrev_b32_e32 v150, 10, v58
	v_lshrrev_b32_e32 v151, 14, v58
	v_lshrrev_b32_e32 v154, 22, v58
	v_lshrrev_b32_e32 v153, 18, v58
	v_lshrrev_b32_e32 v58, 26, v58
	v_and_b32_e32 v155, 15, v59
	v_and_b32_e32 v150, 60, v150
	v_lshrrev_b32_e32 v158, 2, v59
	v_and_b32_e32 v151, 60, v151
	v_and_b32_e32 v154, 60, v154
	v_lshrrev_b32_e32 v161, 6, v59
	v_and_b32_e32 v153, 60, v153
	v_and_b32_e32 v58, 60, v58
	ds_load_b32 v165, v147
	ds_load_b32 v164, v148
	ds_load_b32 v162, v149
	ds_load_b32 v160, v150
	ds_load_b32 v157, v151
	ds_load_b32 v156, v153
	ds_load_b32 v154, v154
	ds_load_b32 v151, v58
	v_lshrrev_b32_e32 v149, 10, v59
	v_lshlrev_b32_e32 v58, 2, v155
	v_lshrrev_b32_e32 v150, 14, v59
	v_lshrrev_b32_e32 v153, 18, v59
	v_lshrrev_b32_e32 v155, 22, v59
	v_lshrrev_b32_e32 v59, 26, v59
	v_and_b32_e32 v147, 60, v158
	v_and_b32_e32 v167, 15, v56
	v_lshrrev_b32_e32 v170, 6, v56
	v_and_b32_e32 v148, 60, v161
	v_lshrrev_b32_e32 v168, 2, v56
	v_and_b32_e32 v149, 60, v149
	v_and_b32_e32 v158, 60, v150
	v_and_b32_e32 v166, 60, v59
	v_and_b32_e32 v161, 60, v153
	v_and_b32_e32 v163, 60, v155
	ds_load_b32 v155, v58
	ds_load_b32 v153, v147
	ds_load_b32 v150, v148
	ds_load_b32 v149, v149
	ds_load_b32 v148, v158
	ds_load_b32 v147, v161
	ds_load_b32 v59, v163
	ds_load_b32 v58, v166
	v_lshrrev_b32_e32 v166, 10, v56
	v_lshlrev_b32_e32 v158, 2, v167
	v_and_b32_e32 v163, 60, v170
	v_lshrrev_b32_e32 v167, 14, v56
	v_lshrrev_b32_e32 v170, 22, v56
	v_and_b32_e32 v161, 60, v168
	v_lshrrev_b32_e32 v168, 18, v56
	v_lshrrev_b32_e32 v56, 26, v56
	v_and_b32_e32 v171, 15, v57
	v_and_b32_e32 v166, 60, v166
	v_lshrrev_b32_e32 v186, 2, v57
	v_and_b32_e32 v167, 60, v167
	v_and_b32_e32 v170, 60, v170
	v_lshrrev_b32_e32 v187, 6, v57
	v_and_b32_e32 v168, 60, v168
	v_and_b32_e32 v56, 60, v56
	ds_load_b32 v177, v158
	ds_load_b32 v176, v161
	ds_load_b32 v175, v163
	ds_load_b32 v174, v166
	ds_load_b32 v173, v167
	ds_load_b32 v172, v168
	ds_load_b32 v170, v170
	ds_load_b32 v167, v56
	v_lshrrev_b32_e32 v163, 10, v57
	v_lshrrev_b32_e32 v166, 14, v57
	v_lshlrev_b32_e32 v56, 2, v171
	v_lshrrev_b32_e32 v168, 18, v57
	v_lshrrev_b32_e32 v171, 22, v57
	v_lshrrev_b32_e32 v57, 26, v57
	v_and_b32_e32 v158, 60, v186
	v_cmp_lt_u32_e32 vcc_lo, 7, v180
	v_and_b32_e32 v161, 60, v187
	v_and_b32_e32 v163, 60, v163
	v_and_b32_e32 v186, 60, v166
	v_and_b32_e32 v187, 60, v168
	v_and_b32_e32 v188, 60, v171
	v_and_b32_e32 v189, 60, v57
	ds_load_b32 v171, v56
	ds_load_b32 v168, v158
	ds_load_b32 v166, v161
	ds_load_b32 v163, v163
	ds_load_b32 v161, v186
	ds_load_b32 v158, v187
	ds_load_b32 v57, v188
	ds_load_b32 v56, v189
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v181, v182, v181, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v183
	v_lshlrev_b32_e32 v182, 24, v127
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v127, v185, v184 :: v_dual_lshlrev_b32 v126, 24, v126
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v180, 0x7fc00000, v181, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v183
	v_lshlrev_b32_e32 v183, 24, v128
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v128, 0x80000000, v126, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v181, 0x7fc00000, v127, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 1, v99
	v_and_or_b32 v127, 0x80000000, v178, v159
	v_and_or_b32 v159, 0x80000000, v182, v179
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v126, 0x80000000, v183, v181
	s_cbranch_vccz .LBB90_161
; %bb.62:                               ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_162
.LBB90_63:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_163
.LBB90_64:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_164
.LBB90_65:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_165
.LBB90_66:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_166
.LBB90_67:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_69
.LBB90_68:                              ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s10
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s10, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v182, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v183, null, s41, v79, vcc_lo
	s_clause 0x1
	global_load_b128 v[178:181], v[182:183], off
	global_load_b128 v[182:185], v[182:183], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v186, 16, v178
	v_and_b32_e32 v178, 0xffff0000, v178
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v188, v169, v186, 0
	v_fma_f32 v187, v152, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v189, v165, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v186, v177, v186, 0
	v_lshlrev_b32_e32 v190, 16, v179
	v_fmac_f32_e32 v188, v146, v178
	v_fmac_f32_e32 v187, v135, v178
	v_fmac_f32_e32 v189, v164, v178
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v186, v176, v178
	v_and_b32_e32 v178, 0xffff0000, v179
	v_dual_fmac_f32 v188, v145, v190 :: v_dual_lshlrev_b32 v179, 16, v180
	v_fmac_f32_e32 v187, v133, v190
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v186, v175, v190
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v188, v144, v178
	v_fmac_f32_e32 v189, v162, v190
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v186, v174, v178
	v_fmac_f32_e32 v187, v131, v178
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v188, v143, v179 :: v_dual_fmac_f32 v189, v160, v178
	v_and_b32_e32 v178, 0xffff0000, v180
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v186, v173, v179
	v_fmac_f32_e32 v187, v130, v179
	v_fmac_f32_e32 v189, v157, v179
	v_dual_fmac_f32 v188, v142, v178 :: v_dual_lshlrev_b32 v179, 16, v181
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v129, v178
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v186, v172, v178
	v_dual_fmac_f32 v189, v156, v178 :: v_dual_and_b32 v178, 0xffff0000, v181
	v_fmac_f32_e32 v188, v140, v179
	v_fmac_f32_e32 v187, v70, v179
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v186, v170, v179
	v_fmac_f32_e32 v189, v154, v179
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v179, 16, v182
	v_fmac_f32_e32 v188, v138, v178
	v_fmac_f32_e32 v187, v68, v178
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v186, v167, v178
	v_fmac_f32_e32 v189, v151, v178
	v_and_b32_e32 v178, 0xffff0000, v182
	v_fmac_f32_e32 v188, v141, v179
	v_fmac_f32_e32 v187, v71, v179
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v186, v171, v179
	v_fmac_f32_e32 v189, v155, v179
	v_dual_fmac_f32 v188, v139, v178 :: v_dual_lshlrev_b32 v179, 16, v183
	v_fmac_f32_e32 v187, v69, v178
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v186, v168, v178
	v_dual_fmac_f32 v189, v153, v178 :: v_dual_and_b32 v178, 0xffff0000, v183
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v67, v179
	v_fmac_f32_e32 v188, v137, v179
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v186, v166, v179
	v_fmac_f32_e32 v189, v150, v179
	v_lshlrev_b32_e32 v179, 16, v184
	v_fmac_f32_e32 v187, v66, v178
	v_fmac_f32_e32 v188, v136, v178
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v186, v163, v178
	v_dual_fmac_f32 v189, v149, v178 :: v_dual_and_b32 v178, 0xffff0000, v184
	v_fmac_f32_e32 v187, v65, v179
	v_fmac_f32_e32 v188, v134, v179
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v189, v148, v179
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v186, v161, v179 :: v_dual_lshlrev_b32 v179, 16, v185
	v_fmac_f32_e32 v187, v64, v178
	v_fmac_f32_e32 v189, v147, v178
	v_fmac_f32_e32 v188, v132, v178
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v186, v158, v178
	v_dual_fmac_f32 v187, v63, v179 :: v_dual_and_b32 v178, 0xffff0000, v185
	v_fmac_f32_e32 v189, v59, v179
	v_fmac_f32_e32 v188, v61, v179
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v186, v57, v179 :: v_dual_fmac_f32 v187, v62, v178
	v_fmac_f32_e32 v189, v58, v178
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v188, v60, v178
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v186, v56, v178
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v90, v187, v127 :: v_dual_fmac_f32 v87, v189, v128
	v_fmac_f32_e32 v88, v188, v159
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v86, v186, v126
.LBB90_69:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v178, 16, v4
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v152, v152, v178, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v169, v169, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v165, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v177, v177, v178, 0
	v_lshlrev_b32_e32 v178, 16, v5
	v_and_b32_e32 v4, 0xffff0000, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v169, v146, v4
	v_fmac_f32_e32 v169, v145, v178
	v_fmac_f32_e32 v165, v164, v4
	v_fmac_f32_e32 v152, v135, v4
	s_wait_dscnt 0xe
	v_dual_fmac_f32 v177, v176, v4 :: v_dual_and_b32 v4, 0xffff0000, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v162, v178
	v_fmac_f32_e32 v152, v133, v178
	v_lshlrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v169, v144, v4
	v_fmac_f32_e32 v165, v160, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v152, v131, v4
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v177, v175, v178
	v_fmac_f32_e32 v165, v157, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v152, v130, v5
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v177, v174, v4 :: v_dual_and_b32 v4, 0xffff0000, v6
	v_fmac_f32_e32 v169, v143, v5
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v177, v173, v5
	v_dual_fmac_f32 v152, v129, v4 :: v_dual_lshlrev_b32 v5, 16, v7
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v169, v142, v4
	v_fmac_f32_e32 v165, v156, v4
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v177, v172, v4 :: v_dual_and_b32 v4, 0xffff0000, v7
	v_fmac_f32_e32 v152, v70, v5
	v_fmac_f32_e32 v169, v140, v5
	v_fmac_f32_e32 v165, v154, v5
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v177, v170, v5
	v_lshlrev_b32_e32 v5, 16, v0
	v_fmac_f32_e32 v152, v68, v4
	v_and_b32_e32 v0, 0xffff0000, v0
	v_fmac_f32_e32 v165, v151, v4
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v177, v167, v4
	v_fmac_f32_e32 v152, v71, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v165, v155, v5
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v177, v171, v5 :: v_dual_fmac_f32 v152, v69, v0
	v_dual_fmac_f32 v169, v138, v4 :: v_dual_lshlrev_b32 v4, 16, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v153, v0
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v177, v168, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v152, v67, v4 :: v_dual_fmac_f32 v169, v141, v5
	v_fmac_f32_e32 v165, v150, v4
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v177, v166, v4
	v_dual_fmac_f32 v169, v139, v0 :: v_dual_and_b32 v0, 0xffff0000, v1
	v_lshlrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v169, v137, v4
	v_fmac_f32_e32 v152, v66, v0
	v_fmac_f32_e32 v165, v149, v0
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v177, v163, v0
	v_dual_fmac_f32 v169, v136, v0 :: v_dual_and_b32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v152, v65, v1
	v_fmac_f32_e32 v165, v148, v1
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v177, v161, v1
	v_fmac_f32_e32 v169, v134, v1
	v_dual_fmac_f32 v152, v64, v0 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v165, v147, v0
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v177, v158, v0
	v_dual_fmac_f32 v169, v132, v0 :: v_dual_and_b32 v0, 0xffff0000, v3
	v_fmac_f32_e32 v152, v63, v1
	v_fmac_f32_e32 v165, v59, v1
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v177, v57, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v169, v61, v1 :: v_dual_fmac_f32 v152, v62, v0
	v_fmac_f32_e32 v165, v58, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v177, v56, v0
	v_fmac_f32_e32 v169, v60, v0
	v_fmac_f32_e32 v117, v152, v127
	v_fmac_f32_e32 v115, v165, v128
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v114, v177, v126
	v_fmac_f32_e32 v116, v169, v159
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s4
	s_cbranch_execz .LBB90_44
.LBB90_70:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_kmcnt 0x0
	s_abs_i32 s14, s38
	s_wait_loadcnt 0x1
	v_and_b32_e32 v56, 7, v125
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s38, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	v_cvt_f32_ubyte0_e32 v56, v56
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	v_mul_f32_e32 v56, 0x3b000000, v56
	s_cselect_b32 s14, s42, s41
	v_and_b32_e32 v57, 0x7f, v125
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	v_and_b32_e32 v168, 0x7f, v122
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_loadcnt 0x0
	v_and_b32_e32 v171, 0x7f, v124
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	v_lshl_add_u32 v59, v57, 20, 0x3c000000
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	v_lshl_add_u32 v169, v168, 20, 0x3c000000
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	v_and_b32_e32 v60, 0x7f, v123
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s41, v81, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v57
	v_lshl_add_u32 v172, v171, 20, 0x3c000000
	v_lshrrev_b32_e32 v62, 22, v54
	s_clause 0x1
	global_load_b128 v[0:3], v[4:5], off offset:16
	global_load_b128 v[4:7], v[4:5], off
	v_lshrrev_b32_e32 v61, 18, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, v56, v59, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v57
	v_and_b32_e32 v58, 7, v123
	v_lshl_add_u32 v59, v60, 20, 0x3c000000
	v_and_b32_e32 v57, 15, v54
	v_and_b32_e32 v63, 15, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v147, 0x7fc00000, v56, vcc_lo
	v_cvt_f32_ubyte0_e32 v58, v58
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	v_lshrrev_b32_e32 v67, 2, v55
	v_and_b32_e32 v62, 60, v62
	v_lshrrev_b32_e32 v69, 6, v55
	v_dual_mul_f32 v58, 0x3b000000, v58 :: v_dual_and_b32 v61, 60, v61
	v_and_b32_e32 v126, 15, v52
	v_lshrrev_b32_e32 v128, 6, v52
	v_lshrrev_b32_e32 v127, 2, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, v58, v59, vcc_lo
	v_lshrrev_b32_e32 v58, 2, v54
	v_lshrrev_b32_e32 v59, 6, v54
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	v_lshlrev_b32_e32 v166, 24, v125
	v_lshrrev_b32_e32 v60, 14, v54
	v_and_b32_e32 v129, 15, v53
	v_lshrrev_b32_e32 v135, 2, v53
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v167, 0x7fc00000, v56 :: v_dual_lshlrev_b32 v56, 2, v57
	v_and_b32_e32 v57, 60, v58
	v_and_b32_e32 v58, 60, v59
	v_lshrrev_b32_e32 v59, 10, v54
	v_lshrrev_b32_e32 v54, 26, v54
	v_and_b32_e32 v60, 60, v60
	v_lshrrev_b32_e32 v136, 6, v53
	v_and_b32_e32 v141, 7, v124
	v_and_b32_e32 v59, 60, v59
	v_and_b32_e32 v54, 60, v54
	ds_load_b32 v140, v56
	ds_load_b32 v70, v57
	ds_load_b32 v68, v58
	ds_load_b32 v66, v59
	ds_load_b32 v65, v60
	ds_load_b32 v64, v61
	ds_load_b32 v62, v62
	ds_load_b32 v60, v54
	v_lshrrev_b32_e32 v58, 10, v55
	v_lshlrev_b32_e32 v54, 2, v63
	v_lshrrev_b32_e32 v59, 14, v55
	v_lshrrev_b32_e32 v61, 18, v55
	v_lshrrev_b32_e32 v63, 22, v55
	v_lshrrev_b32_e32 v55, 26, v55
	v_and_b32_e32 v56, 60, v67
	v_and_b32_e32 v57, 60, v69
	v_and_b32_e32 v58, 60, v58
	v_and_b32_e32 v67, 60, v59
	v_and_b32_e32 v125, 60, v55
	v_and_b32_e32 v69, 60, v61
	v_and_b32_e32 v71, 60, v63
	ds_load_b32 v63, v54
	ds_load_b32 v61, v56
	ds_load_b32 v59, v57
	ds_load_b32 v58, v58
	ds_load_b32 v57, v67
	ds_load_b32 v56, v69
	ds_load_b32 v55, v71
	ds_load_b32 v54, v125
	v_lshrrev_b32_e32 v125, 10, v52
	v_lshlrev_b32_e32 v67, 2, v126
	v_and_b32_e32 v71, 60, v128
	v_lshrrev_b32_e32 v126, 14, v52
	v_lshrrev_b32_e32 v128, 22, v52
	v_and_b32_e32 v69, 60, v127
	v_lshrrev_b32_e32 v127, 18, v52
	v_lshrrev_b32_e32 v52, 26, v52
	v_and_b32_e32 v125, 60, v125
	v_and_b32_e32 v126, 60, v126
	v_and_b32_e32 v128, 60, v128
	v_and_b32_e32 v127, 60, v127
	v_and_b32_e32 v52, 60, v52
	ds_load_b32 v157, v67
	ds_load_b32 v134, v69
	ds_load_b32 v133, v71
	ds_load_b32 v132, v125
	ds_load_b32 v131, v126
	ds_load_b32 v130, v127
	ds_load_b32 v128, v128
	ds_load_b32 v126, v52
	v_lshrrev_b32_e32 v125, 14, v53
	v_lshrrev_b32_e32 v52, 10, v53
	v_lshlrev_b32_e32 v67, 2, v129
	v_lshrrev_b32_e32 v127, 18, v53
	v_lshrrev_b32_e32 v129, 22, v53
	v_lshrrev_b32_e32 v53, 26, v53
	v_and_b32_e32 v69, 60, v135
	v_and_b32_e32 v135, 60, v125
	v_and_b32_e32 v125, 7, v122
	v_and_b32_e32 v71, 60, v136
	v_and_b32_e32 v52, 60, v52
	v_and_b32_e32 v136, 60, v127
	v_and_b32_e32 v137, 60, v129
	v_and_b32_e32 v138, 60, v53
	v_cvt_f32_ubyte0_e32 v139, v125
	ds_load_b32 v129, v67
	ds_load_b32 v127, v69
	ds_load_b32 v125, v71
	ds_load_b32 v71, v52
	ds_load_b32 v69, v135
	ds_load_b32 v67, v136
	ds_load_b32 v53, v137
	ds_load_b32 v52, v138
	v_cvt_f32_ubyte0_e32 v135, v141
	v_and_b32_e32 v136, 15, v50
	v_lshrrev_b32_e32 v137, 2, v50
	v_lshrrev_b32_e32 v138, 6, v50
	v_mul_f32_e32 v170, 0x3b000000, v139
	v_mul_f32_e32 v173, 0x3b000000, v135
	v_lshlrev_b32_e32 v135, 2, v136
	v_and_b32_e32 v136, 60, v137
	v_and_b32_e32 v137, 60, v138
	v_lshrrev_b32_e32 v138, 10, v50
	v_lshrrev_b32_e32 v139, 14, v50
	v_lshrrev_b32_e32 v142, 22, v50
	v_lshrrev_b32_e32 v141, 18, v50
	v_lshrrev_b32_e32 v50, 26, v50
	v_and_b32_e32 v143, 15, v51
	v_and_b32_e32 v138, 60, v138
	v_lshrrev_b32_e32 v146, 2, v51
	v_and_b32_e32 v139, 60, v139
	v_and_b32_e32 v142, 60, v142
	v_lshrrev_b32_e32 v149, 6, v51
	v_and_b32_e32 v141, 60, v141
	v_and_b32_e32 v50, 60, v50
	ds_load_b32 v153, v135
	ds_load_b32 v152, v136
	ds_load_b32 v150, v137
	ds_load_b32 v148, v138
	ds_load_b32 v145, v139
	ds_load_b32 v144, v141
	ds_load_b32 v142, v142
	ds_load_b32 v139, v50
	v_lshrrev_b32_e32 v137, 10, v51
	v_lshlrev_b32_e32 v50, 2, v143
	v_lshrrev_b32_e32 v138, 14, v51
	v_lshrrev_b32_e32 v141, 18, v51
	v_lshrrev_b32_e32 v143, 22, v51
	v_lshrrev_b32_e32 v51, 26, v51
	v_and_b32_e32 v135, 60, v146
	v_and_b32_e32 v155, 15, v48
	v_lshrrev_b32_e32 v158, 6, v48
	v_and_b32_e32 v136, 60, v149
	v_lshrrev_b32_e32 v156, 2, v48
	v_and_b32_e32 v137, 60, v137
	v_and_b32_e32 v146, 60, v138
	v_and_b32_e32 v154, 60, v51
	v_and_b32_e32 v149, 60, v141
	v_and_b32_e32 v151, 60, v143
	ds_load_b32 v143, v50
	ds_load_b32 v141, v135
	ds_load_b32 v138, v136
	ds_load_b32 v137, v137
	ds_load_b32 v136, v146
	ds_load_b32 v135, v149
	ds_load_b32 v51, v151
	ds_load_b32 v50, v154
	v_lshrrev_b32_e32 v154, 10, v48
	v_lshlrev_b32_e32 v146, 2, v155
	v_and_b32_e32 v151, 60, v158
	v_lshrrev_b32_e32 v155, 14, v48
	v_lshrrev_b32_e32 v158, 22, v48
	v_and_b32_e32 v149, 60, v156
	v_lshrrev_b32_e32 v156, 18, v48
	v_lshrrev_b32_e32 v48, 26, v48
	v_and_b32_e32 v159, 15, v49
	v_and_b32_e32 v154, 60, v154
	v_lshrrev_b32_e32 v174, 2, v49
	v_and_b32_e32 v155, 60, v155
	v_and_b32_e32 v158, 60, v158
	v_lshrrev_b32_e32 v175, 6, v49
	v_and_b32_e32 v156, 60, v156
	v_and_b32_e32 v48, 60, v48
	ds_load_b32 v165, v146
	ds_load_b32 v164, v149
	ds_load_b32 v163, v151
	ds_load_b32 v162, v154
	ds_load_b32 v161, v155
	ds_load_b32 v160, v156
	ds_load_b32 v158, v158
	ds_load_b32 v155, v48
	v_lshrrev_b32_e32 v151, 10, v49
	v_lshrrev_b32_e32 v154, 14, v49
	v_lshlrev_b32_e32 v48, 2, v159
	v_lshrrev_b32_e32 v156, 18, v49
	v_lshrrev_b32_e32 v159, 22, v49
	v_lshrrev_b32_e32 v49, 26, v49
	v_and_b32_e32 v146, 60, v174
	v_cmp_lt_u32_e32 vcc_lo, 7, v168
	v_and_b32_e32 v149, 60, v175
	v_and_b32_e32 v151, 60, v151
	v_and_b32_e32 v174, 60, v154
	v_and_b32_e32 v175, 60, v156
	v_and_b32_e32 v176, 60, v159
	v_and_b32_e32 v177, 60, v49
	ds_load_b32 v159, v48
	ds_load_b32 v156, v146
	ds_load_b32 v154, v149
	ds_load_b32 v151, v151
	ds_load_b32 v149, v174
	ds_load_b32 v146, v175
	ds_load_b32 v49, v176
	ds_load_b32 v48, v177
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, v170, v169, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v171
	v_lshlrev_b32_e32 v170, 24, v123
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v123, v173, v172 :: v_dual_lshlrev_b32 v122, 24, v122
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v168
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v168, 0x7fc00000, v169, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v171
	v_lshlrev_b32_e32 v171, 24, v124
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v124, 0x80000000, v122, v168
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, 0x7fc00000, v123, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 1, v99
	v_and_or_b32 v123, 0x80000000, v166, v147
	v_and_or_b32 v147, 0x80000000, v170, v167
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v122, 0x80000000, v171, v169
	s_cbranch_vccz .LBB90_167
; %bb.71:                               ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_168
.LBB90_72:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_169
.LBB90_73:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_170
.LBB90_74:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_171
.LBB90_75:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_172
.LBB90_76:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_78
.LBB90_77:                              ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s10
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s10, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v170, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v171, null, s41, v81, vcc_lo
	s_clause 0x1
	global_load_b128 v[166:169], v[170:171], off
	global_load_b128 v[170:173], v[170:171], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v174, 16, v166
	v_and_b32_e32 v166, 0xffff0000, v166
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v175, v140, v174, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v176, v157, v174, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v177, v153, v174, 0
	s_wait_dscnt 0xf
	v_fma_f32 v174, v165, v174, 0
	v_dual_fmac_f32 v175, v70, v166 :: v_dual_lshlrev_b32 v178, 16, v167
	v_fmac_f32_e32 v176, v134, v166
	v_fmac_f32_e32 v177, v152, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v174, v164, v166
	v_dual_fmac_f32 v175, v68, v178 :: v_dual_and_b32 v166, 0xffff0000, v167
	v_dual_fmac_f32 v176, v133, v178 :: v_dual_lshlrev_b32 v167, 16, v168
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v163, v178
	v_fmac_f32_e32 v176, v132, v166
	v_fmac_f32_e32 v177, v150, v178
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v162, v166
	v_dual_fmac_f32 v175, v66, v166 :: v_dual_fmac_f32 v176, v131, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v177, v148, v166 :: v_dual_and_b32 v166, 0xffff0000, v168
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v174, v161, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v65, v167
	v_fmac_f32_e32 v177, v145, v167
	v_dual_fmac_f32 v176, v130, v166 :: v_dual_lshlrev_b32 v167, 16, v169
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v174, v160, v166
	v_fmac_f32_e32 v175, v64, v166
	v_dual_fmac_f32 v177, v144, v166 :: v_dual_and_b32 v166, 0xffff0000, v169
	v_fmac_f32_e32 v176, v128, v167
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v174, v158, v167
	v_fmac_f32_e32 v175, v62, v167
	v_fmac_f32_e32 v177, v142, v167
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v167, 16, v170
	v_fmac_f32_e32 v176, v126, v166
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v174, v155, v166
	v_fmac_f32_e32 v175, v60, v166
	v_fmac_f32_e32 v177, v139, v166
	v_and_b32_e32 v166, 0xffff0000, v170
	v_fmac_f32_e32 v176, v129, v167
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v174, v159, v167
	v_fmac_f32_e32 v175, v63, v167
	v_fmac_f32_e32 v177, v143, v167
	v_dual_fmac_f32 v176, v127, v166 :: v_dual_lshlrev_b32 v167, 16, v171
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v174, v156, v166
	v_fmac_f32_e32 v175, v61, v166
	v_dual_fmac_f32 v177, v141, v166 :: v_dual_and_b32 v166, 0xffff0000, v171
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v154, v167
	v_fmac_f32_e32 v175, v59, v167
	v_fmac_f32_e32 v176, v125, v167
	v_fmac_f32_e32 v177, v138, v167
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v174, v151, v166 :: v_dual_lshlrev_b32 v167, 16, v172
	v_fmac_f32_e32 v175, v58, v166
	v_fmac_f32_e32 v176, v71, v166
	v_dual_fmac_f32 v177, v137, v166 :: v_dual_and_b32 v166, 0xffff0000, v172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v57, v167
	v_fmac_f32_e32 v176, v69, v167
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v177, v136, v167
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v174, v149, v167 :: v_dual_lshlrev_b32 v167, 16, v173
	v_fmac_f32_e32 v175, v56, v166
	v_fmac_f32_e32 v176, v67, v166
	v_fmac_f32_e32 v177, v135, v166
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v174, v146, v166
	v_dual_fmac_f32 v175, v55, v167 :: v_dual_and_b32 v166, 0xffff0000, v173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v176, v53, v167 :: v_dual_fmac_f32 v175, v54, v166
	v_dual_fmac_f32 v177, v51, v167 :: v_dual_fmac_f32 v176, v52, v166
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v174, v49, v167
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v90, v175, v123 :: v_dual_fmac_f32 v177, v50, v166
	v_fmac_f32_e32 v88, v176, v147
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v174, v48, v166 :: v_dual_fmac_f32 v87, v177, v124
	v_fmac_f32_e32 v86, v174, v122
.LBB90_78:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v166, 16, v4
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v140, v140, v166, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v157, v157, v166, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v153, v153, v166, 0
	s_wait_dscnt 0xf
	v_fma_f32 v165, v165, v166, 0
	v_lshlrev_b32_e32 v166, 16, v5
	v_and_b32_e32 v4, 0xffff0000, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v157, v134, v4
	v_fmac_f32_e32 v157, v133, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v165, v164, v4
	v_fmac_f32_e32 v140, v70, v4
	v_dual_fmac_f32 v153, v152, v4 :: v_dual_and_b32 v4, 0xffff0000, v5
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v163, v166
	v_fmac_f32_e32 v140, v68, v166
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v157, v132, v4
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v165, v162, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v140, v66, v4 :: v_dual_lshlrev_b32 v5, 16, v6
	v_fmac_f32_e32 v153, v150, v166
	v_fmac_f32_e32 v157, v131, v5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v140, v65, v5 :: v_dual_fmac_f32 v153, v148, v4
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v165, v161, v5 :: v_dual_and_b32 v4, 0xffff0000, v6
	v_dual_fmac_f32 v153, v145, v5 :: v_dual_fmac_f32 v140, v64, v4
	v_lshlrev_b32_e32 v5, 16, v7
	v_fmac_f32_e32 v157, v130, v4
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v165, v160, v4
	v_dual_fmac_f32 v153, v144, v4 :: v_dual_and_b32 v4, 0xffff0000, v7
	v_fmac_f32_e32 v140, v62, v5
	v_fmac_f32_e32 v157, v128, v5
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v165, v158, v5
	v_fmac_f32_e32 v153, v142, v5
	v_lshlrev_b32_e32 v5, 16, v0
	v_fmac_f32_e32 v140, v60, v4
	v_and_b32_e32 v0, 0xffff0000, v0
	v_fmac_f32_e32 v157, v126, v4
	v_fmac_f32_e32 v153, v139, v4
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v165, v155, v4
	v_fmac_f32_e32 v140, v63, v5
	v_lshlrev_b32_e32 v4, 16, v1
	v_fmac_f32_e32 v153, v143, v5
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v165, v159, v5 :: v_dual_fmac_f32 v140, v61, v0
	v_fmac_f32_e32 v153, v141, v0
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v156, v0
	v_dual_fmac_f32 v140, v59, v4 :: v_dual_fmac_f32 v157, v129, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v153, v138, v4
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v165, v154, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v157, v127, v0 :: v_dual_and_b32 v0, 0xffff0000, v1
	v_lshlrev_b32_e32 v1, 16, v2
	v_fmac_f32_e32 v157, v125, v4
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v140, v58, v0
	v_fmac_f32_e32 v153, v137, v0
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v165, v151, v0
	v_dual_fmac_f32 v157, v71, v0 :: v_dual_and_b32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v140, v57, v1
	v_fmac_f32_e32 v153, v136, v1
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v165, v149, v1
	v_fmac_f32_e32 v157, v69, v1
	v_dual_fmac_f32 v140, v56, v0 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v153, v135, v0
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v165, v146, v0
	v_dual_fmac_f32 v157, v67, v0 :: v_dual_and_b32 v0, 0xffff0000, v3
	v_fmac_f32_e32 v140, v55, v1
	v_fmac_f32_e32 v153, v51, v1
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v165, v49, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v157, v53, v1 :: v_dual_fmac_f32 v140, v54, v0
	v_fmac_f32_e32 v153, v50, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v48, v0
	v_fmac_f32_e32 v157, v52, v0
	v_fmac_f32_e32 v117, v140, v123
	v_fmac_f32_e32 v115, v153, v124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v114, v165, v122
	v_fmac_f32_e32 v116, v157, v147
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s5
	s_cbranch_execz .LBB90_45
.LBB90_79:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_kmcnt 0x0
	s_abs_i32 s14, s38
	s_wait_loadcnt 0x1
	v_and_b32_e32 v48, 7, v121
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s38, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	v_cvt_f32_ubyte0_e32 v48, v48
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	v_mul_f32_e32 v48, 0x3b000000, v48
	s_cselect_b32 s14, s42, s41
	v_and_b32_e32 v49, 0x7f, v121
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	v_and_b32_e32 v156, 0x7f, v118
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_loadcnt 0x0
	v_and_b32_e32 v159, 0x7f, v120
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	v_lshl_add_u32 v51, v49, 20, 0x3c000000
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	v_lshl_add_u32 v157, v156, 20, 0x3c000000
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	v_and_b32_e32 v52, 0x7f, v119
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s41, v83, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v49
	v_lshl_add_u32 v160, v159, 20, 0x3c000000
	v_lshrrev_b32_e32 v54, 22, v46
	s_clause 0x1
	global_load_b128 v[0:3], v[4:5], off offset:16
	global_load_b128 v[4:7], v[4:5], off
	v_lshrrev_b32_e32 v53, 18, v46
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v48, v51, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v49
	v_and_b32_e32 v50, 7, v119
	v_lshl_add_u32 v51, v52, 20, 0x3c000000
	v_and_b32_e32 v49, 15, v46
	v_and_b32_e32 v55, 15, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, 0x7fc00000, v48, vcc_lo
	v_cvt_f32_ubyte0_e32 v50, v50
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	v_lshrrev_b32_e32 v59, 2, v47
	v_and_b32_e32 v54, 60, v54
	v_lshrrev_b32_e32 v61, 6, v47
	v_dual_mul_f32 v50, 0x3b000000, v50 :: v_dual_and_b32 v53, 60, v53
	v_and_b32_e32 v65, 15, v44
	v_lshrrev_b32_e32 v67, 6, v44
	v_lshrrev_b32_e32 v66, 2, v44
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v50, v51, vcc_lo
	v_lshrrev_b32_e32 v50, 2, v46
	v_lshrrev_b32_e32 v51, 6, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_lshlrev_b32_e32 v154, 24, v121
	v_lshrrev_b32_e32 v52, 14, v46
	v_and_b32_e32 v68, 15, v45
	v_lshrrev_b32_e32 v123, 2, v45
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v155, 0x7fc00000, v48 :: v_dual_lshlrev_b32 v48, 2, v49
	v_and_b32_e32 v49, 60, v50
	v_and_b32_e32 v50, 60, v51
	v_lshrrev_b32_e32 v51, 10, v46
	v_lshrrev_b32_e32 v46, 26, v46
	v_and_b32_e32 v52, 60, v52
	v_lshrrev_b32_e32 v124, 6, v45
	v_and_b32_e32 v129, 7, v120
	v_and_b32_e32 v51, 60, v51
	v_and_b32_e32 v46, 60, v46
	ds_load_b32 v128, v48
	ds_load_b32 v62, v49
	ds_load_b32 v60, v50
	ds_load_b32 v58, v51
	ds_load_b32 v57, v52
	ds_load_b32 v56, v53
	ds_load_b32 v54, v54
	ds_load_b32 v52, v46
	v_lshrrev_b32_e32 v50, 10, v47
	v_lshlrev_b32_e32 v46, 2, v55
	v_lshrrev_b32_e32 v51, 14, v47
	v_lshrrev_b32_e32 v53, 18, v47
	v_lshrrev_b32_e32 v55, 22, v47
	v_lshrrev_b32_e32 v47, 26, v47
	v_and_b32_e32 v48, 60, v59
	v_and_b32_e32 v49, 60, v61
	v_and_b32_e32 v50, 60, v50
	v_and_b32_e32 v59, 60, v51
	v_and_b32_e32 v64, 60, v47
	v_and_b32_e32 v61, 60, v53
	v_and_b32_e32 v63, 60, v55
	ds_load_b32 v55, v46
	ds_load_b32 v53, v48
	ds_load_b32 v51, v49
	ds_load_b32 v50, v50
	ds_load_b32 v49, v59
	ds_load_b32 v48, v61
	ds_load_b32 v47, v63
	ds_load_b32 v46, v64
	v_lshrrev_b32_e32 v64, 10, v44
	v_lshlrev_b32_e32 v59, 2, v65
	v_and_b32_e32 v63, 60, v67
	v_lshrrev_b32_e32 v65, 14, v44
	v_lshrrev_b32_e32 v67, 22, v44
	v_and_b32_e32 v61, 60, v66
	v_lshrrev_b32_e32 v66, 18, v44
	v_lshrrev_b32_e32 v44, 26, v44
	v_and_b32_e32 v64, 60, v64
	v_and_b32_e32 v65, 60, v65
	v_and_b32_e32 v67, 60, v67
	v_and_b32_e32 v66, 60, v66
	v_and_b32_e32 v44, 60, v44
	ds_load_b32 v145, v59
	ds_load_b32 v122, v61
	ds_load_b32 v121, v63
	ds_load_b32 v71, v64
	ds_load_b32 v70, v65
	ds_load_b32 v69, v66
	ds_load_b32 v67, v67
	ds_load_b32 v65, v44
	v_lshrrev_b32_e32 v64, 14, v45
	v_lshrrev_b32_e32 v44, 10, v45
	v_lshlrev_b32_e32 v59, 2, v68
	v_lshrrev_b32_e32 v66, 18, v45
	v_lshrrev_b32_e32 v68, 22, v45
	v_lshrrev_b32_e32 v45, 26, v45
	v_and_b32_e32 v61, 60, v123
	v_and_b32_e32 v123, 60, v64
	v_and_b32_e32 v64, 7, v118
	v_and_b32_e32 v63, 60, v124
	v_and_b32_e32 v44, 60, v44
	v_and_b32_e32 v124, 60, v66
	v_and_b32_e32 v125, 60, v68
	v_and_b32_e32 v126, 60, v45
	v_cvt_f32_ubyte0_e32 v127, v64
	ds_load_b32 v68, v59
	ds_load_b32 v66, v61
	ds_load_b32 v64, v63
	ds_load_b32 v63, v44
	ds_load_b32 v61, v123
	ds_load_b32 v59, v124
	ds_load_b32 v45, v125
	ds_load_b32 v44, v126
	v_cvt_f32_ubyte0_e32 v123, v129
	v_and_b32_e32 v124, 15, v42
	v_lshrrev_b32_e32 v125, 2, v42
	v_lshrrev_b32_e32 v126, 6, v42
	v_mul_f32_e32 v158, 0x3b000000, v127
	v_mul_f32_e32 v161, 0x3b000000, v123
	v_lshlrev_b32_e32 v123, 2, v124
	v_and_b32_e32 v124, 60, v125
	v_and_b32_e32 v125, 60, v126
	v_lshrrev_b32_e32 v126, 10, v42
	v_lshrrev_b32_e32 v127, 14, v42
	v_lshrrev_b32_e32 v130, 22, v42
	v_lshrrev_b32_e32 v129, 18, v42
	v_lshrrev_b32_e32 v42, 26, v42
	v_and_b32_e32 v131, 15, v43
	v_and_b32_e32 v126, 60, v126
	v_lshrrev_b32_e32 v134, 2, v43
	v_and_b32_e32 v127, 60, v127
	v_and_b32_e32 v130, 60, v130
	v_lshrrev_b32_e32 v137, 6, v43
	v_and_b32_e32 v129, 60, v129
	v_and_b32_e32 v42, 60, v42
	ds_load_b32 v141, v123
	ds_load_b32 v140, v124
	ds_load_b32 v138, v125
	ds_load_b32 v136, v126
	ds_load_b32 v133, v127
	ds_load_b32 v132, v129
	ds_load_b32 v130, v130
	ds_load_b32 v127, v42
	v_lshrrev_b32_e32 v125, 10, v43
	v_lshlrev_b32_e32 v42, 2, v131
	v_lshrrev_b32_e32 v126, 14, v43
	v_lshrrev_b32_e32 v129, 18, v43
	v_lshrrev_b32_e32 v131, 22, v43
	v_lshrrev_b32_e32 v43, 26, v43
	v_and_b32_e32 v123, 60, v134
	v_and_b32_e32 v143, 15, v40
	v_lshrrev_b32_e32 v146, 6, v40
	v_and_b32_e32 v124, 60, v137
	v_lshrrev_b32_e32 v144, 2, v40
	v_and_b32_e32 v125, 60, v125
	v_and_b32_e32 v134, 60, v126
	v_and_b32_e32 v142, 60, v43
	v_and_b32_e32 v137, 60, v129
	v_and_b32_e32 v139, 60, v131
	ds_load_b32 v131, v42
	ds_load_b32 v129, v123
	ds_load_b32 v126, v124
	ds_load_b32 v125, v125
	ds_load_b32 v124, v134
	ds_load_b32 v123, v137
	ds_load_b32 v43, v139
	ds_load_b32 v42, v142
	v_lshrrev_b32_e32 v142, 10, v40
	v_lshlrev_b32_e32 v134, 2, v143
	v_and_b32_e32 v139, 60, v146
	v_lshrrev_b32_e32 v143, 14, v40
	v_lshrrev_b32_e32 v146, 22, v40
	v_and_b32_e32 v137, 60, v144
	v_lshrrev_b32_e32 v144, 18, v40
	v_lshrrev_b32_e32 v40, 26, v40
	v_and_b32_e32 v147, 15, v41
	v_and_b32_e32 v142, 60, v142
	v_lshrrev_b32_e32 v162, 2, v41
	v_and_b32_e32 v143, 60, v143
	v_and_b32_e32 v146, 60, v146
	v_lshrrev_b32_e32 v163, 6, v41
	v_and_b32_e32 v144, 60, v144
	v_and_b32_e32 v40, 60, v40
	ds_load_b32 v153, v134
	ds_load_b32 v152, v137
	ds_load_b32 v151, v139
	ds_load_b32 v150, v142
	ds_load_b32 v149, v143
	ds_load_b32 v148, v144
	ds_load_b32 v146, v146
	ds_load_b32 v143, v40
	v_lshrrev_b32_e32 v139, 10, v41
	v_lshrrev_b32_e32 v142, 14, v41
	v_lshlrev_b32_e32 v40, 2, v147
	v_lshrrev_b32_e32 v144, 18, v41
	v_lshrrev_b32_e32 v147, 22, v41
	v_lshrrev_b32_e32 v41, 26, v41
	v_and_b32_e32 v134, 60, v162
	v_cmp_lt_u32_e32 vcc_lo, 7, v156
	v_and_b32_e32 v137, 60, v163
	v_and_b32_e32 v139, 60, v139
	v_and_b32_e32 v162, 60, v142
	v_and_b32_e32 v163, 60, v144
	v_and_b32_e32 v164, 60, v147
	v_and_b32_e32 v165, 60, v41
	ds_load_b32 v147, v40
	ds_load_b32 v144, v134
	ds_load_b32 v142, v137
	ds_load_b32 v139, v139
	ds_load_b32 v137, v162
	ds_load_b32 v134, v163
	ds_load_b32 v41, v164
	ds_load_b32 v40, v165
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v157, v158, v157, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v159
	v_lshlrev_b32_e32 v158, 24, v119
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v119, v161, v160 :: v_dual_lshlrev_b32 v118, 24, v118
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v156
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v156, 0x7fc00000, v157, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v159
	v_lshlrev_b32_e32 v159, 24, v120
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v120, 0x80000000, v118, v156
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v157, 0x7fc00000, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 1, v99
	v_and_or_b32 v119, 0x80000000, v154, v135
	v_and_or_b32 v135, 0x80000000, v158, v155
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v118, 0x80000000, v159, v157
	s_cbranch_vccz .LBB90_173
; %bb.80:                               ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_174
.LBB90_81:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_175
.LBB90_82:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_176
.LBB90_83:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_177
.LBB90_84:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_178
.LBB90_85:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_87
.LBB90_86:                              ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s10
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s10, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v158, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v159, null, s41, v83, vcc_lo
	s_clause 0x1
	global_load_b128 v[154:157], v[158:159], off
	global_load_b128 v[158:161], v[158:159], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v162, 16, v154
	v_and_b32_e32 v154, 0xffff0000, v154
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v163, v128, v162, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v164, v145, v162, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v141, v162, 0
	s_wait_dscnt 0xf
	v_fma_f32 v162, v153, v162, 0
	v_dual_fmac_f32 v163, v62, v154 :: v_dual_lshlrev_b32 v166, 16, v155
	v_fmac_f32_e32 v164, v122, v154
	v_fmac_f32_e32 v165, v140, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v162, v152, v154
	v_dual_fmac_f32 v163, v60, v166 :: v_dual_and_b32 v154, 0xffff0000, v155
	v_dual_fmac_f32 v164, v121, v166 :: v_dual_lshlrev_b32 v155, 16, v156
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v151, v166
	v_fmac_f32_e32 v163, v58, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v164, v71, v154
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v162, v150, v154
	v_fmac_f32_e32 v165, v138, v166
	v_fmac_f32_e32 v163, v57, v155
	v_fmac_f32_e32 v164, v70, v155
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v162, v149, v155 :: v_dual_fmac_f32 v165, v136, v154
	v_dual_fmac_f32 v165, v133, v155 :: v_dual_and_b32 v154, 0xffff0000, v156
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v164, v69, v154 :: v_dual_lshlrev_b32 v155, 16, v157
	v_fmac_f32_e32 v163, v56, v154
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v162, v148, v154
	v_dual_fmac_f32 v165, v132, v154 :: v_dual_and_b32 v154, 0xffff0000, v157
	v_fmac_f32_e32 v164, v67, v155
	v_fmac_f32_e32 v163, v54, v155
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v162, v146, v155
	v_fmac_f32_e32 v165, v130, v155
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v155, 16, v158
	v_fmac_f32_e32 v164, v65, v154
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v162, v143, v154
	v_fmac_f32_e32 v163, v52, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v165, v127, v154 :: v_dual_fmac_f32 v164, v68, v155
	v_and_b32_e32 v154, 0xffff0000, v158
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v162, v147, v155
	v_fmac_f32_e32 v163, v55, v155
	v_fmac_f32_e32 v165, v131, v155
	v_dual_fmac_f32 v164, v66, v154 :: v_dual_lshlrev_b32 v155, 16, v159
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v162, v144, v154
	v_fmac_f32_e32 v163, v53, v154
	v_dual_fmac_f32 v165, v129, v154 :: v_dual_and_b32 v154, 0xffff0000, v159
	v_fmac_f32_e32 v164, v64, v155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v163, v51, v155
	v_fmac_f32_e32 v165, v126, v155
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v162, v142, v155 :: v_dual_lshlrev_b32 v155, 16, v160
	v_fmac_f32_e32 v164, v63, v154
	v_fmac_f32_e32 v163, v50, v154
	v_fmac_f32_e32 v165, v125, v154
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v162, v139, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v163, v49, v155 :: v_dual_and_b32 v154, 0xffff0000, v160
	v_fmac_f32_e32 v164, v61, v155
	v_fmac_f32_e32 v165, v124, v155
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v162, v137, v155 :: v_dual_lshlrev_b32 v155, 16, v161
	v_fmac_f32_e32 v163, v48, v154
	v_fmac_f32_e32 v164, v59, v154
	v_fmac_f32_e32 v165, v123, v154
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v162, v134, v154
	v_dual_fmac_f32 v163, v47, v155 :: v_dual_and_b32 v154, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v43, v155
	v_fmac_f32_e32 v164, v45, v155
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v162, v41, v155 :: v_dual_fmac_f32 v163, v46, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v42, v154
	v_fmac_f32_e32 v164, v44, v154
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v40, v154
	v_dual_fmac_f32 v90, v163, v119 :: v_dual_fmac_f32 v87, v165, v120
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v88, v164, v135
	v_fmac_f32_e32 v86, v162, v118
.LBB90_87:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v154, 16, v4
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v128, v128, v154, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v145, v145, v154, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v141, v141, v154, 0
	s_wait_dscnt 0xf
	v_fma_f32 v153, v153, v154, 0
	v_lshlrev_b32_e32 v154, 16, v5
	v_and_b32_e32 v4, 0xffff0000, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v145, v122, v4
	v_fmac_f32_e32 v145, v121, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v153, v152, v4
	v_fmac_f32_e32 v128, v62, v4
	v_dual_fmac_f32 v141, v140, v4 :: v_dual_and_b32 v4, 0xffff0000, v5
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v153, v151, v154
	v_dual_fmac_f32 v128, v60, v154 :: v_dual_fmac_f32 v145, v71, v4
	v_lshlrev_b32_e32 v5, 16, v6
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v153, v150, v4
	v_fmac_f32_e32 v128, v58, v4
	v_fmac_f32_e32 v141, v138, v154
	v_fmac_f32_e32 v145, v70, v5
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v153, v149, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v128, v57, v5 :: v_dual_fmac_f32 v141, v136, v4
	v_dual_fmac_f32 v141, v133, v5 :: v_dual_and_b32 v4, 0xffff0000, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v128, v56, v4 :: v_dual_lshlrev_b32 v5, 16, v7
	v_fmac_f32_e32 v145, v69, v4
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v153, v148, v4
	v_dual_fmac_f32 v141, v132, v4 :: v_dual_and_b32 v4, 0xffff0000, v7
	v_fmac_f32_e32 v128, v54, v5
	v_fmac_f32_e32 v145, v67, v5
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v153, v146, v5
	v_fmac_f32_e32 v141, v130, v5
	v_lshlrev_b32_e32 v5, 16, v0
	v_fmac_f32_e32 v128, v52, v4
	v_and_b32_e32 v0, 0xffff0000, v0
	v_fmac_f32_e32 v145, v65, v4
	v_fmac_f32_e32 v141, v127, v4
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v153, v143, v4
	v_fmac_f32_e32 v128, v55, v5
	v_lshlrev_b32_e32 v4, 16, v1
	v_fmac_f32_e32 v141, v131, v5
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v153, v147, v5 :: v_dual_fmac_f32 v128, v53, v0
	v_fmac_f32_e32 v141, v129, v0
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v153, v144, v0
	v_dual_fmac_f32 v128, v51, v4 :: v_dual_fmac_f32 v145, v68, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v141, v126, v4
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v153, v142, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v145, v66, v0 :: v_dual_and_b32 v0, 0xffff0000, v1
	v_lshlrev_b32_e32 v1, 16, v2
	v_fmac_f32_e32 v145, v64, v4
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v128, v50, v0
	v_fmac_f32_e32 v141, v125, v0
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v153, v139, v0
	v_dual_fmac_f32 v145, v63, v0 :: v_dual_and_b32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v128, v49, v1
	v_fmac_f32_e32 v141, v124, v1
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v153, v137, v1
	v_fmac_f32_e32 v145, v61, v1
	v_dual_fmac_f32 v128, v48, v0 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v141, v123, v0
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v153, v134, v0
	v_dual_fmac_f32 v145, v59, v0 :: v_dual_and_b32 v0, 0xffff0000, v3
	v_fmac_f32_e32 v128, v47, v1
	v_fmac_f32_e32 v141, v43, v1
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v153, v41, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v145, v45, v1 :: v_dual_fmac_f32 v128, v46, v0
	v_fmac_f32_e32 v141, v42, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v153, v40, v0
	v_fmac_f32_e32 v145, v44, v0
	v_fmac_f32_e32 v117, v128, v119
	v_fmac_f32_e32 v115, v141, v120
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v114, v153, v118
	v_fmac_f32_e32 v116, v145, v135
	s_or_b32 exec_lo, exec_lo, s39
	s_and_saveexec_b32 s39, s0
	s_cbranch_execz .LBB90_105
.LBB90_88:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_kmcnt 0x0
	s_abs_i32 s14, s38
	s_wait_loadcnt 0x2
	v_dual_mov_b32 v41, v39 :: v_dual_mov_b32 v40, v38
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s38, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s43, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s40, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s42, s14, s58
	s_cmp_ge_u32 s14, s58
	v_dual_mov_b32 v43, v37 :: v_dual_mov_b32 v42, v36
	s_cselect_b32 s40, s40, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s42, s14
	s_add_co_i32 s41, s40, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	v_dual_mov_b32 v45, v35 :: v_dual_mov_b32 v44, v34
	s_cselect_b32 s40, s41, s40
	s_abs_i32 s14, s36
	s_wait_alu 0xfffe
	s_xor_b32 s42, s40, s43
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_sub_co_i32 s42, s42, s43
	s_mul_i32 s44, s41, s58
	s_wait_alu 0xfffe
	s_ashr_i32 s43, s42, 31
	s_ashr_i32 s40, s36, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[42:43], s[42:43], s[18:19]
	s_sub_co_i32 s14, s14, s44
	s_xor_b32 s45, s40, s60
	s_add_co_i32 s40, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s44, s14, s58
	s_lshl_b64 s[42:43], s[42:43], 1
	s_cmp_ge_u32 s14, s58
	v_dual_mov_b32 v47, v33 :: v_dual_mov_b32 v46, v32
	s_cselect_b32 s40, s40, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s44, s14
	s_add_co_i32 s41, s40, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	v_dual_mov_b32 v49, v31 :: v_dual_mov_b32 v48, v30
	s_cselect_b32 s40, s41, s40
	s_abs_i32 s14, s34
	s_wait_alu 0xfffe
	s_xor_b32 s44, s40, s45
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_sub_co_i32 s44, s44, s45
	s_mul_i32 s46, s41, s58
	s_wait_alu 0xfffe
	s_ashr_i32 s45, s44, 31
	s_ashr_i32 s40, s34, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[44:45], s[44:45], s[18:19]
	s_sub_co_i32 s14, s14, s46
	s_xor_b32 s47, s40, s60
	s_add_co_i32 s40, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s46, s14, s58
	s_lshl_b64 s[44:45], s[44:45], 1
	s_cmp_ge_u32 s14, s58
	v_dual_mov_b32 v51, v29 :: v_dual_mov_b32 v50, v28
	s_cselect_b32 s40, s40, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s46, s14
	s_add_co_i32 s41, s40, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	v_dual_mov_b32 v53, v27 :: v_dual_mov_b32 v52, v26
	s_cselect_b32 s40, s41, s40
	s_abs_i32 s14, s30
	s_wait_alu 0xfffe
	s_xor_b32 s46, s40, s47
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_sub_co_i32 s46, s46, s47
	s_mul_i32 s48, s41, s58
	s_wait_alu 0xfffe
	s_ashr_i32 s47, s46, 31
	s_ashr_i32 s40, s30, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[46:47], s[46:47], s[18:19]
	s_sub_co_i32 s14, s14, s48
	s_xor_b32 s49, s40, s60
	s_add_co_i32 s40, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s48, s14, s58
	s_lshl_b64 s[46:47], s[46:47], 1
	s_cmp_ge_u32 s14, s58
	v_dual_mov_b32 v55, v25 :: v_dual_mov_b32 v54, v24
	s_cselect_b32 s40, s40, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s48, s14
	s_add_co_i32 s41, s40, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_add_nc_u64 s[42:43], s[8:9], s[42:43]
	s_cselect_b32 s40, s41, s40
	s_abs_i32 s14, s28
	s_wait_alu 0xfffe
	s_xor_b32 s48, s40, s49
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_sub_co_i32 s48, s48, s49
	s_mul_i32 s50, s41, s58
	s_wait_alu 0xfffe
	s_ashr_i32 s49, s48, 31
	s_ashr_i32 s40, s28, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[48:49], s[48:49], s[18:19]
	s_sub_co_i32 s14, s14, s50
	s_xor_b32 s51, s40, s60
	s_add_co_i32 s40, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s50, s14, s58
	s_lshl_b64 s[48:49], s[48:49], 1
	s_cmp_ge_u32 s14, s58
	s_add_nc_u64 s[44:45], s[8:9], s[44:45]
	s_cselect_b32 s40, s40, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s50, s14
	s_add_co_i32 s41, s40, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_add_nc_u64 s[46:47], s[8:9], s[46:47]
	s_cselect_b32 s40, s41, s40
	s_abs_i32 s14, s26
	s_wait_alu 0xfffe
	s_xor_b32 s50, s40, s51
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_sub_co_i32 s50, s50, s51
	s_mul_i32 s52, s41, s58
	s_wait_alu 0xfffe
	s_ashr_i32 s51, s50, 31
	s_ashr_i32 s40, s26, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[50:51], s[50:51], s[18:19]
	s_sub_co_i32 s14, s14, s52
	s_xor_b32 s54, s40, s60
	s_add_co_i32 s40, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s52, s14, s58
	s_lshl_b64 s[50:51], s[50:51], 1
	s_cmp_ge_u32 s14, s58
	s_add_nc_u64 s[48:49], s[8:9], s[48:49]
	s_cselect_b32 s53, s40, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s52, s14
	s_add_co_i32 s52, s53, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_mov_b64 s[40:41], 0x80
	s_cselect_b32 s52, s52, s53
	s_abs_i32 s14, s24
	s_wait_alu 0xfffe
	s_xor_b32 s55, s52, s54
	s_mul_u64 s[52:53], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_sub_co_i32 s54, s55, s54
	s_mul_i32 s56, s53, s58
	s_wait_alu 0xfffe
	s_ashr_i32 s55, s54, 31
	s_ashr_i32 s52, s24, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[54:55], s[54:55], s[18:19]
	s_sub_co_i32 s14, s14, s56
	s_xor_b32 s57, s52, s60
	s_add_co_i32 s52, s53, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s56, s14, s58
	s_lshl_b64 s[54:55], s[54:55], 1
	s_cmp_ge_u32 s14, s58
	s_add_nc_u64 s[50:51], s[8:9], s[50:51]
	s_cselect_b32 s52, s52, s53
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s56, s14
	s_add_co_i32 s53, s52, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s52, s53, s52
	s_abs_i32 s14, s10
	s_wait_alu 0xfffe
	s_xor_b32 s56, s52, s57
	s_mul_u64 s[52:53], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_sub_co_i32 s56, s56, s57
	s_mul_i32 s62, s53, s58
	s_wait_alu 0xfffe
	s_ashr_i32 s57, s56, 31
	s_ashr_i32 s52, s10, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[56:57], s[56:57], s[18:19]
	s_sub_co_i32 s14, s14, s62
	s_xor_b32 s52, s52, s60
	s_add_co_i32 s62, s53, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s63, s14, s58
	s_lshl_b64 s[56:57], s[56:57], 1
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s53, s62, s53
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s63, s14
	s_add_co_i32 s62, s53, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s62, s53
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s52
	s_wait_alu 0xfffe
	s_sub_co_i32 s52, s14, s52
	s_mov_b32 s14, 0
	s_wait_alu 0xfffe
	s_ashr_i32 s53, s52, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[62:63], s[52:53], s[18:19]
	s_add_nc_u64 s[52:53], s[8:9], s[54:55]
	s_wait_alu 0xfffe
	s_lshl_b64 s[62:63], s[62:63], 1
	s_add_nc_u64 s[54:55], s[8:9], s[56:57]
	s_wait_alu 0xfffe
	s_add_nc_u64 s[56:57], s[8:9], s[62:63]
	s_branch .LBB90_90
.LBB90_89:                              ;   in Loop: Header=BB90_90 Depth=2
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v170, 16, v4
	v_add_co_u32 v54, vcc_lo, 0x100, v54
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v55, null, 0, v55, vcc_lo
	s_wait_dscnt 0x3e
	v_fma_f32 v168, v168, v170, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v169, v169, v170, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v164, v164, v170, 0
	s_wait_dscnt 0xf
	v_fma_f32 v167, v167, v170, 0
	v_lshlrev_b32_e32 v170, 16, v5
	v_and_b32_e32 v4, 0xffff0000, v4
	v_add_co_u32 v52, vcc_lo, 0x100, v52
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v53, null, 0, v53, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v169, v155, v4
	v_add_co_u32 v50, vcc_lo, v50, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v51, null, 0, v51, vcc_lo
	v_dual_fmac_f32 v169, v152, v170 :: v_dual_fmac_f32 v164, v162, v4
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v167, v166, v4
	v_fmac_f32_e32 v168, v148, v4
	v_and_b32_e32 v4, 0xffff0000, v5
	v_lshlrev_b32_e32 v5, 16, v6
	v_add_co_u32 v48, vcc_lo, v48, 32
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v167, v165, v170
	v_dual_fmac_f32 v168, v144, v170 :: v_dual_fmac_f32 v169, v149, v4
	v_fmac_f32_e32 v164, v160, v170
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v49, null, 0, v49, vcc_lo
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v167, v163, v4
	v_fmac_f32_e32 v168, v140, v4
	v_dual_fmac_f32 v164, v158, v4 :: v_dual_fmac_f32 v169, v145, v5
	v_add_co_u32 v46, vcc_lo, 0x100, v46
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v167, v161, v5
	v_fmac_f32_e32 v168, v136, v5
	v_dual_fmac_f32 v164, v156, v5 :: v_dual_lshlrev_b32 v5, 16, v7
	v_and_b32_e32 v4, 0xffff0000, v6
	s_add_nc_u64 s[40:41], s[40:41], 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v47, null, 0, v47, vcc_lo
	v_add_co_u32 v44, vcc_lo, 0x100, v44
	v_fmac_f32_e32 v169, v141, v4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v45, null, 0, v45, vcc_lo
	v_add_co_u32 v42, vcc_lo, v42, 32
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v169, v137, v5
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v167, v159, v4
	v_fmac_f32_e32 v168, v128, v4
	v_fmac_f32_e32 v164, v153, v4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v43, null, 0, v43, vcc_lo
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v167, v157, v5
	v_fmac_f32_e32 v168, v124, v5
	v_dual_fmac_f32 v164, v150, v5 :: v_dual_lshlrev_b32 v5, 16, v0
	v_and_b32_e32 v4, 0xffff0000, v7
	v_and_b32_e32 v0, 0xffff0000, v0
	v_add_co_u32 v40, vcc_lo, v40, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v41, null, 0, v41, vcc_lo
	v_fmac_f32_e32 v169, v133, v4
	s_add_nc_u64 s[42:43], s[42:43], 0x400
	s_add_nc_u64 s[44:45], s[44:45], 0x400
	s_add_nc_u64 s[46:47], s[46:47], 0x400
	s_add_nc_u64 s[48:49], s[48:49], 0x400
	v_dual_fmac_f32 v169, v125, v5 :: v_dual_fmac_f32 v168, v120, v4
	v_fmac_f32_e32 v164, v146, v4
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v167, v154, v4
	s_add_nc_u64 s[50:51], s[50:51], 0x400
	v_dual_fmac_f32 v169, v121, v0 :: v_dual_fmac_f32 v168, v71, v5
	v_fmac_f32_e32 v164, v142, v5
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v167, v151, v5
	v_lshlrev_b32_e32 v4, 16, v1
	s_add_nc_u64 s[52:53], s[52:53], 0x400
	v_fmac_f32_e32 v168, v67, v0
	v_fmac_f32_e32 v164, v138, v0
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v167, v147, v0 :: v_dual_and_b32 v0, 0xffff0000, v1
	v_fmac_f32_e32 v169, v118, v4
	v_fmac_f32_e32 v168, v65, v4
	v_fmac_f32_e32 v164, v134, v4
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v167, v143, v4
	v_lshlrev_b32_e32 v1, 16, v2
	s_add_nc_u64 s[54:55], s[54:55], 0x400
	v_fmac_f32_e32 v168, v62, v0
	v_fmac_f32_e32 v164, v126, v0
	v_fmac_f32_e32 v169, v68, v0
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v167, v139, v0 :: v_dual_and_b32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v168, v60, v1
	v_fmac_f32_e32 v164, v122, v1
	v_fmac_f32_e32 v169, v66, v1
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v167, v135, v1
	v_dual_fmac_f32 v168, v59, v0 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v164, v119, v0
	v_fmac_f32_e32 v169, v64, v0
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v167, v127, v0 :: v_dual_and_b32 v0, 0xffff0000, v3
	v_fmac_f32_e32 v168, v57, v1
	s_add_nc_u64 s[56:57], s[56:57], 0x400
	v_fmac_f32_e32 v169, v61, v1
	v_fmac_f32_e32 v164, v69, v1
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v167, v123, v1 :: v_dual_fmac_f32 v168, v56, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v169, v58, v0
	v_fmac_f32_e32 v164, v63, v0
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v167, v70, v0
	s_wait_alu 0xfffe
	v_dual_fmac_f32 v117, v168, v129 :: v_dual_add_nc_u32 v0, s40, v72
	v_dual_fmac_f32 v116, v169, v130 :: v_dual_fmac_f32 v115, v164, v131
	v_fmac_f32_e32 v114, v167, v132
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_le_i32_e32 vcc_lo, s33, v0
	s_or_b32 s14, vcc_lo, s14
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s14
	s_cbranch_execz .LBB90_104
.LBB90_90:                              ;   Parent Loop BB90_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_co_u32 v0, vcc_lo, v50, v72
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v51, vcc_lo
	v_add_co_u32 v2, vcc_lo, v48, v72
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v49, vcc_lo
	global_load_b64 v[56:57], v[54:55], off th:TH_LOAD_NT
	global_load_b64 v[58:59], v[52:53], off th:TH_LOAD_NT
	global_load_b64 v[60:61], v[46:47], off th:TH_LOAD_NT
	global_load_b64 v[62:63], v[44:45], off th:TH_LOAD_NT
	s_wait_loadcnt 0x5
	global_load_i8 v129, v[0:1], off
	s_wait_loadcnt 0x5
	global_load_i8 v130, v[2:3], off
	v_add_co_u32 v0, vcc_lo, v42, v72
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v43, vcc_lo
	v_add_co_u32 v2, vcc_lo, v40, v72
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v41, vcc_lo
	global_load_i8 v131, v[0:1], off
	global_load_i8 v132, v[2:3], off
	v_add_co_u32 v4, s62, s42, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v5, null, s43, 0, s62
	s_clause 0x1
	global_load_b128 v[0:3], v[4:5], off offset:4112
	global_load_b128 v[4:7], v[4:5], off offset:4096
	s_wait_loadcnt 0x9
	v_lshrrev_b32_e32 v65, 2, v56
	v_lshrrev_b32_e32 v66, 6, v56
	v_lshrrev_b32_e32 v67, 10, v56
	v_lshrrev_b32_e32 v68, 14, v56
	s_wait_loadcnt 0x5
	v_and_b32_e32 v171, 7, v129
	s_wait_loadcnt 0x4
	v_and_b32_e32 v173, 7, v130
	v_lshrrev_b32_e32 v69, 18, v56
	v_lshrrev_b32_e32 v70, 22, v56
	v_lshrrev_b32_e32 v118, 2, v57
	v_cvt_f32_ubyte0_e32 v171, v171
	v_and_b32_e32 v64, 15, v56
	v_cvt_f32_ubyte0_e32 v173, v173
	v_and_b32_e32 v124, 15, v58
	v_lshrrev_b32_e32 v56, 26, v56
	v_mul_f32_e32 v171, 0x3b000000, v171
	v_and_b32_e32 v170, 0x7f, v129
	v_mul_f32_e32 v173, 0x3b000000, v173
	v_and_b32_e32 v172, 0x7f, v130
	s_wait_loadcnt 0x3
	v_and_b32_e32 v183, 0x7f, v131
	v_lshrrev_b32_e32 v119, 6, v57
	v_lshl_add_u32 v211, v170, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v170
	v_lshl_add_u32 v212, v172, 20, 0x3c000000
	v_lshrrev_b32_e32 v120, 10, v57
	v_lshrrev_b32_e32 v121, 14, v57
	v_lshrrev_b32_e32 v122, 18, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v171, v171, v211, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v172
	v_lshrrev_b32_e32 v123, 22, v57
	v_lshrrev_b32_e32 v125, 2, v58
	v_lshrrev_b32_e32 v126, 6, v58
	v_lshrrev_b32_e32 v127, 10, v58
	v_lshrrev_b32_e32 v128, 14, v58
	v_lshrrev_b32_e32 v133, 18, v58
	v_lshrrev_b32_e32 v134, 22, v58
	v_lshrrev_b32_e32 v58, 26, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v173, v173, v212, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v183
	v_and_b32_e32 v71, 15, v57
	v_lshrrev_b32_e32 v57, 26, v57
	v_and_b32_e32 v135, 15, v59
	v_lshrrev_b32_e32 v136, 2, v59
	v_lshrrev_b32_e32 v137, 6, v59
	v_lshrrev_b32_e32 v138, 10, v59
	v_lshrrev_b32_e32 v139, 14, v59
	v_lshrrev_b32_e32 v140, 18, v59
	v_lshrrev_b32_e32 v141, 22, v59
	v_lshrrev_b32_e32 v59, 26, v59
	v_and_b32_e32 v142, 15, v60
	v_lshrrev_b32_e32 v143, 2, v60
	v_lshrrev_b32_e32 v144, 6, v60
	v_lshrrev_b32_e32 v145, 10, v60
	v_lshrrev_b32_e32 v146, 14, v60
	v_lshrrev_b32_e32 v147, 18, v60
	v_lshrrev_b32_e32 v148, 22, v60
	v_lshrrev_b32_e32 v60, 26, v60
	v_and_b32_e32 v149, 15, v61
	v_lshrrev_b32_e32 v150, 2, v61
	v_lshrrev_b32_e32 v151, 6, v61
	v_lshrrev_b32_e32 v152, 10, v61
	v_lshrrev_b32_e32 v153, 14, v61
	v_lshrrev_b32_e32 v154, 18, v61
	v_lshrrev_b32_e32 v155, 22, v61
	v_lshrrev_b32_e32 v61, 26, v61
	v_and_b32_e32 v156, 15, v62
	v_lshrrev_b32_e32 v157, 2, v62
	v_lshrrev_b32_e32 v158, 6, v62
	v_lshrrev_b32_e32 v159, 10, v62
	v_lshrrev_b32_e32 v160, 14, v62
	v_lshrrev_b32_e32 v161, 18, v62
	v_lshrrev_b32_e32 v162, 22, v62
	v_lshrrev_b32_e32 v62, 26, v62
	v_lshrrev_b32_e32 v168, 18, v63
	v_lshrrev_b32_e32 v169, 22, v63
	v_lshlrev_b32_e32 v64, 2, v64
	v_and_b32_e32 v184, 7, v131
	v_and_b32_e32 v65, 60, v65
	v_and_b32_e32 v66, 60, v66
	v_and_b32_e32 v67, 60, v67
	v_and_b32_e32 v68, 60, v68
	v_and_b32_e32 v56, 60, v56
	v_lshlrev_b32_e32 v71, 2, v71
	v_and_b32_e32 v118, 60, v118
	v_and_b32_e32 v121, 60, v121
	v_and_b32_e32 v175, 60, v57
	v_and_b32_e32 v125, 60, v125
	v_and_b32_e32 v133, 60, v133
	v_and_b32_e32 v58, 60, v58
	v_and_b32_e32 v69, 60, v69
	v_and_b32_e32 v70, 60, v70
	v_and_b32_e32 v119, 60, v119
	v_and_b32_e32 v174, 60, v120
	v_and_b32_e32 v122, 60, v122
	v_and_b32_e32 v123, 60, v123
	v_lshlrev_b32_e32 v176, 2, v124
	v_and_b32_e32 v126, 60, v126
	v_and_b32_e32 v127, 60, v127
	v_and_b32_e32 v177, 60, v128
	v_and_b32_e32 v134, 60, v134
	v_lshlrev_b32_e32 v135, 2, v135
	v_and_b32_e32 v178, 60, v136
	v_and_b32_e32 v179, 60, v137
	v_and_b32_e32 v138, 60, v138
	v_and_b32_e32 v139, 60, v139
	v_and_b32_e32 v180, 60, v140
	v_and_b32_e32 v181, 60, v141
	v_and_b32_e32 v182, 60, v59
	s_wait_loadcnt 0x2
	v_and_b32_e32 v186, 7, v132
	v_and_b32_e32 v187, 60, v144
	v_and_b32_e32 v188, 60, v145
	v_and_b32_e32 v189, 60, v148
	v_and_b32_e32 v190, 60, v60
	v_lshlrev_b32_e32 v191, 2, v149
	v_and_b32_e32 v193, 60, v152
	v_and_b32_e32 v195, 60, v155
	v_and_b32_e32 v196, 60, v61
	v_and_b32_e32 v202, 60, v62
	v_and_b32_e32 v208, 60, v168
	v_and_b32_e32 v209, 60, v169
	ds_load_b32 v168, v64
	ds_load_b32 v148, v65
	ds_load_b32 v144, v66
	ds_load_b32 v140, v67
	ds_load_b32 v136, v68
	ds_load_b32 v128, v69
	ds_load_b32 v124, v70
	ds_load_b32 v120, v56
	ds_load_b32 v71, v71
	ds_load_b32 v67, v118
	ds_load_b32 v65, v119
	ds_load_b32 v62, v174
	ds_load_b32 v60, v121
	ds_load_b32 v59, v122
	ds_load_b32 v57, v123
	ds_load_b32 v56, v175
	ds_load_b32 v169, v176
	ds_load_b32 v155, v125
	ds_load_b32 v152, v126
	ds_load_b32 v149, v127
	ds_load_b32 v145, v177
	ds_load_b32 v141, v133
	ds_load_b32 v137, v134
	ds_load_b32 v133, v58
	ds_load_b32 v125, v135
	ds_load_b32 v121, v178
	ds_load_b32 v118, v179
	ds_load_b32 v68, v138
	ds_load_b32 v66, v139
	ds_load_b32 v64, v180
	ds_load_b32 v61, v181
	ds_load_b32 v58, v182
	v_cvt_f32_ubyte0_e32 v175, v184
	v_and_b32_e32 v163, 15, v63
	v_lshrrev_b32_e32 v164, 2, v63
	v_lshrrev_b32_e32 v165, 6, v63
	v_lshrrev_b32_e32 v166, 10, v63
	v_lshrrev_b32_e32 v167, 14, v63
	v_lshrrev_b32_e32 v63, 26, v63
	v_cvt_f32_ubyte0_e32 v177, v186
	v_dual_mul_f32 v175, 0x3b000000, v175 :: v_dual_lshlrev_b32 v142, 2, v142
	v_and_b32_e32 v143, 60, v143
	v_and_b32_e32 v146, 60, v146
	v_and_b32_e32 v147, 60, v147
	v_and_b32_e32 v151, 60, v151
	v_and_b32_e32 v154, 60, v154
	v_and_b32_e32 v157, 60, v157
	v_and_b32_e32 v159, 60, v159
	v_and_b32_e32 v192, 60, v150
	v_and_b32_e32 v194, 60, v153
	v_and_b32_e32 v198, 60, v158
	v_and_b32_e32 v199, 60, v160
	v_and_b32_e32 v200, 60, v161
	v_and_b32_e32 v201, 60, v162
	v_lshlrev_b32_e32 v203, 2, v163
	v_and_b32_e32 v204, 60, v164
	v_and_b32_e32 v205, 60, v165
	v_and_b32_e32 v206, 60, v166
	v_and_b32_e32 v207, 60, v167
	v_dual_mul_f32 v177, 0x3b000000, v177 :: v_dual_and_b32 v210, 60, v63
	v_lshlrev_b32_e32 v197, 2, v156
	ds_load_b32 v164, v142
	ds_load_b32 v162, v143
	ds_load_b32 v160, v187
	ds_load_b32 v158, v188
	ds_load_b32 v156, v146
	ds_load_b32 v153, v147
	ds_load_b32 v150, v189
	ds_load_b32 v146, v190
	ds_load_b32 v142, v191
	ds_load_b32 v138, v192
	ds_load_b32 v134, v151
	ds_load_b32 v126, v193
	ds_load_b32 v122, v194
	ds_load_b32 v119, v154
	ds_load_b32 v69, v195
	ds_load_b32 v63, v196
	ds_load_b32 v167, v197
	ds_load_b32 v166, v157
	ds_load_b32 v165, v198
	ds_load_b32 v163, v159
	ds_load_b32 v161, v199
	ds_load_b32 v159, v200
	ds_load_b32 v157, v201
	ds_load_b32 v154, v202
	ds_load_b32 v151, v203
	ds_load_b32 v147, v204
	ds_load_b32 v143, v205
	ds_load_b32 v139, v206
	ds_load_b32 v135, v207
	ds_load_b32 v127, v208
	ds_load_b32 v123, v209
	ds_load_b32 v70, v210
	v_and_b32_e32 v185, 0x7f, v132
	v_lshl_add_u32 v174, v183, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v176, v185, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v174, v175, v174, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v185
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v175, v177, v176, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v170
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v170, 0x7fc00000, v171, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v172
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v129, 0x80000000, v129, v170
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v171, 0x7fc00000, v173, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v183
	v_and_or_b32 v130, 0x80000000, v130, v171
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v172, 0x7fc00000, v174, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v185
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v131, 0x80000000, v131, v172
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v173, 0x7fc00000, v175, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 1, v99
	v_and_or_b32 v132, 0x80000000, v132, v173
	s_cbranch_vccz .LBB90_97
; %bb.91:                               ;   in Loop: Header=BB90_90 Depth=2
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_98
.LBB90_92:                              ;   in Loop: Header=BB90_90 Depth=2
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_99
.LBB90_93:                              ;   in Loop: Header=BB90_90 Depth=2
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_100
.LBB90_94:                              ;   in Loop: Header=BB90_90 Depth=2
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_101
.LBB90_95:                              ;   in Loop: Header=BB90_90 Depth=2
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_102
.LBB90_96:                              ;   in Loop: Header=BB90_90 Depth=2
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_89
	s_branch .LBB90_103
.LBB90_97:                              ;   in Loop: Header=BB90_90 Depth=2
	v_add_co_u32 v174, s62, s44, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v175, null, s45, 0, s62
	s_clause 0x1
	global_load_b128 v[170:173], v[174:175], off offset:4096
	global_load_b128 v[174:177], v[174:175], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v178, 16, v170
	v_and_b32_e32 v170, 0xffff0000, v170
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v179, v168, v178, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v180, v169, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v181, v164, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v178, v167, v178, 0
	v_dual_fmac_f32 v179, v148, v170 :: v_dual_lshlrev_b32 v182, 16, v171
	v_fmac_f32_e32 v180, v155, v170
	v_fmac_f32_e32 v181, v162, v170
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v178, v166, v170
	v_dual_fmac_f32 v179, v144, v182 :: v_dual_and_b32 v170, 0xffff0000, v171
	v_dual_fmac_f32 v180, v152, v182 :: v_dual_lshlrev_b32 v171, 16, v172
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v178, v165, v182
	v_fmac_f32_e32 v180, v149, v170
	v_fmac_f32_e32 v181, v160, v182
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v163, v170
	v_dual_fmac_f32 v179, v140, v170 :: v_dual_fmac_f32 v180, v145, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v181, v158, v170 :: v_dual_and_b32 v170, 0xffff0000, v172
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v178, v161, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v136, v171
	v_fmac_f32_e32 v181, v156, v171
	v_dual_fmac_f32 v180, v141, v170 :: v_dual_lshlrev_b32 v171, 16, v173
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v128, v170
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v178, v159, v170
	v_dual_fmac_f32 v181, v153, v170 :: v_dual_and_b32 v170, 0xffff0000, v173
	v_fmac_f32_e32 v180, v137, v171
	v_fmac_f32_e32 v179, v124, v171
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v178, v157, v171
	v_fmac_f32_e32 v181, v150, v171
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v171, 16, v174
	v_fmac_f32_e32 v180, v133, v170
	v_fmac_f32_e32 v179, v120, v170
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v178, v154, v170
	v_fmac_f32_e32 v181, v146, v170
	v_and_b32_e32 v170, 0xffff0000, v174
	v_fmac_f32_e32 v180, v125, v171
	v_fmac_f32_e32 v179, v71, v171
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v178, v151, v171
	v_fmac_f32_e32 v181, v142, v171
	v_dual_fmac_f32 v180, v121, v170 :: v_dual_lshlrev_b32 v171, 16, v175
	v_fmac_f32_e32 v179, v67, v170
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v178, v147, v170
	v_dual_fmac_f32 v181, v138, v170 :: v_dual_and_b32 v170, 0xffff0000, v175
	v_fmac_f32_e32 v180, v118, v171
	v_fmac_f32_e32 v179, v65, v171
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v178, v143, v171
	v_fmac_f32_e32 v181, v134, v171
	v_dual_fmac_f32 v180, v68, v170 :: v_dual_lshlrev_b32 v171, 16, v176
	v_fmac_f32_e32 v179, v62, v170
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v178, v139, v170
	v_dual_fmac_f32 v181, v126, v170 :: v_dual_and_b32 v170, 0xffff0000, v176
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v60, v171
	v_fmac_f32_e32 v180, v66, v171
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v178, v135, v171
	v_fmac_f32_e32 v181, v122, v171
	v_lshlrev_b32_e32 v171, 16, v177
	v_fmac_f32_e32 v179, v59, v170
	v_fmac_f32_e32 v180, v64, v170
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v178, v127, v170
	v_dual_fmac_f32 v181, v119, v170 :: v_dual_and_b32 v170, 0xffff0000, v177
	v_fmac_f32_e32 v179, v57, v171
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v123, v171
	v_fmac_f32_e32 v181, v69, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v56, v170
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v178, v70, v170
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v181, v63, v170
	v_dual_fmac_f32 v113, v179, v129 :: v_dual_fmac_f32 v180, v61, v171
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v109, v178, v132 :: v_dual_fmac_f32 v110, v181, v131
	v_fmac_f32_e32 v180, v58, v170
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v112, v180, v130
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_92
.LBB90_98:                              ;   in Loop: Header=BB90_90 Depth=2
	v_add_co_u32 v174, s62, s46, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v175, null, s47, 0, s62
	s_clause 0x1
	global_load_b128 v[170:173], v[174:175], off offset:4096
	global_load_b128 v[174:177], v[174:175], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v178, 16, v170
	v_and_b32_e32 v170, 0xffff0000, v170
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v179, v168, v178, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v180, v169, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v181, v164, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v178, v167, v178, 0
	v_dual_fmac_f32 v179, v148, v170 :: v_dual_lshlrev_b32 v182, 16, v171
	v_fmac_f32_e32 v180, v155, v170
	v_fmac_f32_e32 v181, v162, v170
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v178, v166, v170
	v_dual_fmac_f32 v179, v144, v182 :: v_dual_and_b32 v170, 0xffff0000, v171
	v_dual_fmac_f32 v180, v152, v182 :: v_dual_lshlrev_b32 v171, 16, v172
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v178, v165, v182
	v_fmac_f32_e32 v180, v149, v170
	v_fmac_f32_e32 v181, v160, v182
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v163, v170
	v_dual_fmac_f32 v179, v140, v170 :: v_dual_fmac_f32 v180, v145, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v181, v158, v170 :: v_dual_and_b32 v170, 0xffff0000, v172
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v178, v161, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v136, v171
	v_fmac_f32_e32 v181, v156, v171
	v_dual_fmac_f32 v180, v141, v170 :: v_dual_lshlrev_b32 v171, 16, v173
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v128, v170
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v178, v159, v170
	v_dual_fmac_f32 v181, v153, v170 :: v_dual_and_b32 v170, 0xffff0000, v173
	v_fmac_f32_e32 v180, v137, v171
	v_fmac_f32_e32 v179, v124, v171
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v178, v157, v171
	v_fmac_f32_e32 v181, v150, v171
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v171, 16, v174
	v_fmac_f32_e32 v180, v133, v170
	v_fmac_f32_e32 v179, v120, v170
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v178, v154, v170
	v_fmac_f32_e32 v181, v146, v170
	v_and_b32_e32 v170, 0xffff0000, v174
	v_fmac_f32_e32 v180, v125, v171
	v_fmac_f32_e32 v179, v71, v171
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v178, v151, v171
	v_fmac_f32_e32 v181, v142, v171
	v_dual_fmac_f32 v180, v121, v170 :: v_dual_lshlrev_b32 v171, 16, v175
	v_fmac_f32_e32 v179, v67, v170
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v178, v147, v170
	v_dual_fmac_f32 v181, v138, v170 :: v_dual_and_b32 v170, 0xffff0000, v175
	v_fmac_f32_e32 v180, v118, v171
	v_fmac_f32_e32 v179, v65, v171
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v178, v143, v171
	v_fmac_f32_e32 v181, v134, v171
	v_dual_fmac_f32 v180, v68, v170 :: v_dual_lshlrev_b32 v171, 16, v176
	v_fmac_f32_e32 v179, v62, v170
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v178, v139, v170
	v_dual_fmac_f32 v181, v126, v170 :: v_dual_and_b32 v170, 0xffff0000, v176
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v60, v171
	v_fmac_f32_e32 v180, v66, v171
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v178, v135, v171
	v_fmac_f32_e32 v181, v122, v171
	v_lshlrev_b32_e32 v171, 16, v177
	v_fmac_f32_e32 v179, v59, v170
	v_fmac_f32_e32 v180, v64, v170
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v178, v127, v170
	v_dual_fmac_f32 v181, v119, v170 :: v_dual_and_b32 v170, 0xffff0000, v177
	v_fmac_f32_e32 v179, v57, v171
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v123, v171
	v_fmac_f32_e32 v181, v69, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v56, v170
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v178, v70, v170
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v181, v63, v170
	v_dual_fmac_f32 v111, v179, v129 :: v_dual_fmac_f32 v180, v61, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v100, v178, v132
	v_fmac_f32_e32 v106, v181, v131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v180, v58, v170
	v_fmac_f32_e32 v108, v180, v130
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_93
.LBB90_99:                              ;   in Loop: Header=BB90_90 Depth=2
	v_add_co_u32 v174, s62, s48, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v175, null, s49, 0, s62
	s_clause 0x1
	global_load_b128 v[170:173], v[174:175], off offset:4096
	global_load_b128 v[174:177], v[174:175], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v178, 16, v170
	v_and_b32_e32 v170, 0xffff0000, v170
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v179, v168, v178, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v180, v169, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v181, v164, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v178, v167, v178, 0
	v_dual_fmac_f32 v179, v148, v170 :: v_dual_lshlrev_b32 v182, 16, v171
	v_fmac_f32_e32 v180, v155, v170
	v_fmac_f32_e32 v181, v162, v170
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v178, v166, v170
	v_dual_fmac_f32 v179, v144, v182 :: v_dual_and_b32 v170, 0xffff0000, v171
	v_dual_fmac_f32 v180, v152, v182 :: v_dual_lshlrev_b32 v171, 16, v172
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v178, v165, v182
	v_fmac_f32_e32 v180, v149, v170
	v_fmac_f32_e32 v181, v160, v182
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v163, v170
	v_dual_fmac_f32 v179, v140, v170 :: v_dual_fmac_f32 v180, v145, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v181, v158, v170 :: v_dual_and_b32 v170, 0xffff0000, v172
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v178, v161, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v136, v171
	v_fmac_f32_e32 v181, v156, v171
	v_dual_fmac_f32 v180, v141, v170 :: v_dual_lshlrev_b32 v171, 16, v173
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v128, v170
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v178, v159, v170
	v_dual_fmac_f32 v181, v153, v170 :: v_dual_and_b32 v170, 0xffff0000, v173
	v_fmac_f32_e32 v180, v137, v171
	v_fmac_f32_e32 v179, v124, v171
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v178, v157, v171
	v_fmac_f32_e32 v181, v150, v171
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v171, 16, v174
	v_fmac_f32_e32 v180, v133, v170
	v_fmac_f32_e32 v179, v120, v170
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v178, v154, v170
	v_fmac_f32_e32 v181, v146, v170
	v_and_b32_e32 v170, 0xffff0000, v174
	v_fmac_f32_e32 v180, v125, v171
	v_fmac_f32_e32 v179, v71, v171
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v178, v151, v171
	v_fmac_f32_e32 v181, v142, v171
	v_dual_fmac_f32 v180, v121, v170 :: v_dual_lshlrev_b32 v171, 16, v175
	v_fmac_f32_e32 v179, v67, v170
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v178, v147, v170
	v_dual_fmac_f32 v181, v138, v170 :: v_dual_and_b32 v170, 0xffff0000, v175
	v_fmac_f32_e32 v180, v118, v171
	v_fmac_f32_e32 v179, v65, v171
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v178, v143, v171
	v_fmac_f32_e32 v181, v134, v171
	v_dual_fmac_f32 v180, v68, v170 :: v_dual_lshlrev_b32 v171, 16, v176
	v_fmac_f32_e32 v179, v62, v170
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v178, v139, v170
	v_dual_fmac_f32 v181, v126, v170 :: v_dual_and_b32 v170, 0xffff0000, v176
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v60, v171
	v_fmac_f32_e32 v180, v66, v171
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v178, v135, v171
	v_fmac_f32_e32 v181, v122, v171
	v_lshlrev_b32_e32 v171, 16, v177
	v_fmac_f32_e32 v179, v59, v170
	v_fmac_f32_e32 v180, v64, v170
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v178, v127, v170
	v_dual_fmac_f32 v181, v119, v170 :: v_dual_and_b32 v170, 0xffff0000, v177
	v_fmac_f32_e32 v179, v57, v171
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v181, v69, v171
	v_fmac_f32_e32 v179, v56, v170
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v181, v63, v170
	v_dual_fmac_f32 v107, v179, v129 :: v_dual_fmac_f32 v180, v61, v171
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v103, v181, v131 :: v_dual_fmac_f32 v180, v58, v170
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v178, v123, v171 :: v_dual_fmac_f32 v105, v180, v130
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v178, v70, v170
	v_fmac_f32_e32 v102, v178, v132
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_94
.LBB90_100:                             ;   in Loop: Header=BB90_90 Depth=2
	v_add_co_u32 v174, s62, s50, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v175, null, s51, 0, s62
	s_clause 0x1
	global_load_b128 v[170:173], v[174:175], off offset:4096
	global_load_b128 v[174:177], v[174:175], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v178, 16, v170
	v_and_b32_e32 v170, 0xffff0000, v170
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v180, v169, v178, 0
	v_fma_f32 v179, v168, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v181, v164, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v178, v167, v178, 0
	v_lshlrev_b32_e32 v182, 16, v171
	v_fmac_f32_e32 v180, v155, v170
	v_fmac_f32_e32 v179, v148, v170
	v_fmac_f32_e32 v181, v162, v170
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v178, v166, v170
	v_and_b32_e32 v170, 0xffff0000, v171
	v_dual_fmac_f32 v180, v152, v182 :: v_dual_lshlrev_b32 v171, 16, v172
	v_fmac_f32_e32 v179, v144, v182
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v178, v165, v182
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v180, v149, v170
	v_fmac_f32_e32 v181, v160, v182
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v178, v163, v170
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v179, v140, v170 :: v_dual_fmac_f32 v180, v145, v171
	v_dual_fmac_f32 v181, v158, v170 :: v_dual_and_b32 v170, 0xffff0000, v172
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v161, v171
	v_fmac_f32_e32 v179, v136, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v181, v156, v171
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v178, v159, v170 :: v_dual_lshlrev_b32 v171, 16, v173
	v_fmac_f32_e32 v180, v141, v170
	v_fmac_f32_e32 v179, v128, v170
	v_dual_fmac_f32 v181, v153, v170 :: v_dual_and_b32 v170, 0xffff0000, v173
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v178, v157, v171
	v_fmac_f32_e32 v180, v137, v171
	v_fmac_f32_e32 v179, v124, v171
	v_fmac_f32_e32 v181, v150, v171
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v171, 16, v174
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v178, v154, v170
	v_fmac_f32_e32 v180, v133, v170
	v_fmac_f32_e32 v179, v120, v170
	v_fmac_f32_e32 v181, v146, v170
	v_and_b32_e32 v170, 0xffff0000, v174
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v178, v151, v171
	v_fmac_f32_e32 v180, v125, v171
	v_fmac_f32_e32 v179, v71, v171
	v_fmac_f32_e32 v181, v142, v171
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v178, v147, v170 :: v_dual_lshlrev_b32 v171, 16, v175
	v_fmac_f32_e32 v180, v121, v170
	v_fmac_f32_e32 v179, v67, v170
	v_dual_fmac_f32 v181, v138, v170 :: v_dual_and_b32 v170, 0xffff0000, v175
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v178, v143, v171
	v_fmac_f32_e32 v180, v118, v171
	v_fmac_f32_e32 v179, v65, v171
	v_fmac_f32_e32 v181, v134, v171
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v178, v139, v170 :: v_dual_lshlrev_b32 v171, 16, v176
	v_fmac_f32_e32 v180, v68, v170
	v_fmac_f32_e32 v179, v62, v170
	v_dual_fmac_f32 v181, v126, v170 :: v_dual_and_b32 v170, 0xffff0000, v176
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v178, v135, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v60, v171
	v_fmac_f32_e32 v181, v122, v171
	v_dual_fmac_f32 v180, v66, v171 :: v_dual_lshlrev_b32 v171, 16, v177
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v178, v127, v170
	v_fmac_f32_e32 v179, v59, v170
	v_fmac_f32_e32 v181, v119, v170
	v_fmac_f32_e32 v180, v64, v170
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v179, v57, v171 :: v_dual_and_b32 v170, 0xffff0000, v177
	v_fmac_f32_e32 v181, v69, v171
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v179, v56, v170
	v_fmac_f32_e32 v181, v63, v170
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v97, v181, v131
	v_fmac_f32_e32 v180, v61, v171
	v_fmac_f32_e32 v180, v58, v170
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v178, v123, v171 :: v_dual_fmac_f32 v101, v180, v130
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v178, v70, v170
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v104, v179, v129 :: v_dual_fmac_f32 v91, v178, v132
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_95
.LBB90_101:                             ;   in Loop: Header=BB90_90 Depth=2
	v_add_co_u32 v174, s62, s52, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v175, null, s53, 0, s62
	s_clause 0x1
	global_load_b128 v[170:173], v[174:175], off offset:4096
	global_load_b128 v[174:177], v[174:175], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v178, 16, v170
	v_and_b32_e32 v170, 0xffff0000, v170
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v179, v168, v178, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v180, v169, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v181, v164, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v178, v167, v178, 0
	v_dual_fmac_f32 v179, v148, v170 :: v_dual_lshlrev_b32 v182, 16, v171
	v_fmac_f32_e32 v180, v155, v170
	v_fmac_f32_e32 v181, v162, v170
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v178, v166, v170
	v_and_b32_e32 v170, 0xffff0000, v171
	v_dual_fmac_f32 v180, v152, v182 :: v_dual_lshlrev_b32 v171, 16, v172
	v_fmac_f32_e32 v179, v144, v182
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v178, v165, v182
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v180, v149, v170
	v_fmac_f32_e32 v181, v160, v182
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v178, v163, v170
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v179, v140, v170 :: v_dual_fmac_f32 v180, v145, v171
	v_dual_fmac_f32 v181, v158, v170 :: v_dual_and_b32 v170, 0xffff0000, v172
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v161, v171
	v_fmac_f32_e32 v179, v136, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v181, v156, v171
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v178, v159, v170 :: v_dual_lshlrev_b32 v171, 16, v173
	v_fmac_f32_e32 v180, v141, v170
	v_fmac_f32_e32 v179, v128, v170
	v_dual_fmac_f32 v181, v153, v170 :: v_dual_and_b32 v170, 0xffff0000, v173
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v178, v157, v171
	v_fmac_f32_e32 v180, v137, v171
	v_fmac_f32_e32 v179, v124, v171
	v_fmac_f32_e32 v181, v150, v171
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v171, 16, v174
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v178, v154, v170
	v_fmac_f32_e32 v180, v133, v170
	v_fmac_f32_e32 v179, v120, v170
	v_fmac_f32_e32 v181, v146, v170
	v_and_b32_e32 v170, 0xffff0000, v174
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v178, v151, v171
	v_fmac_f32_e32 v180, v125, v171
	v_fmac_f32_e32 v179, v71, v171
	v_fmac_f32_e32 v181, v142, v171
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v178, v147, v170 :: v_dual_lshlrev_b32 v171, 16, v175
	v_fmac_f32_e32 v180, v121, v170
	v_fmac_f32_e32 v179, v67, v170
	v_dual_fmac_f32 v181, v138, v170 :: v_dual_and_b32 v170, 0xffff0000, v175
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v178, v143, v171
	v_fmac_f32_e32 v180, v118, v171
	v_fmac_f32_e32 v179, v65, v171
	v_fmac_f32_e32 v181, v134, v171
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v178, v139, v170 :: v_dual_lshlrev_b32 v171, 16, v176
	v_fmac_f32_e32 v180, v68, v170
	v_fmac_f32_e32 v179, v62, v170
	v_dual_fmac_f32 v181, v126, v170 :: v_dual_and_b32 v170, 0xffff0000, v176
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v178, v135, v171
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v60, v171
	v_fmac_f32_e32 v180, v66, v171
	v_fmac_f32_e32 v181, v122, v171
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v178, v127, v170 :: v_dual_lshlrev_b32 v171, 16, v177
	v_fmac_f32_e32 v179, v59, v170
	v_fmac_f32_e32 v180, v64, v170
	v_dual_fmac_f32 v181, v119, v170 :: v_dual_and_b32 v170, 0xffff0000, v177
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v178, v123, v171
	v_fmac_f32_e32 v179, v57, v171
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v181, v69, v171 :: v_dual_fmac_f32 v178, v70, v170
	v_fmac_f32_e32 v179, v56, v170
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v181, v63, v170
	v_dual_fmac_f32 v93, v178, v132 :: v_dual_fmac_f32 v180, v61, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v98, v179, v129
	v_fmac_f32_e32 v94, v181, v131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v180, v58, v170
	v_fmac_f32_e32 v96, v180, v130
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_96
.LBB90_102:                             ;   in Loop: Header=BB90_90 Depth=2
	v_add_co_u32 v174, s62, s54, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v175, null, s55, 0, s62
	s_clause 0x1
	global_load_b128 v[170:173], v[174:175], off offset:4096
	global_load_b128 v[174:177], v[174:175], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v178, 16, v170
	v_and_b32_e32 v170, 0xffff0000, v170
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v179, v168, v178, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v180, v169, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v181, v164, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v178, v167, v178, 0
	v_dual_fmac_f32 v179, v148, v170 :: v_dual_lshlrev_b32 v182, 16, v171
	v_fmac_f32_e32 v180, v155, v170
	v_fmac_f32_e32 v181, v162, v170
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v178, v166, v170
	v_dual_fmac_f32 v179, v144, v182 :: v_dual_and_b32 v170, 0xffff0000, v171
	v_dual_fmac_f32 v180, v152, v182 :: v_dual_lshlrev_b32 v171, 16, v172
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v178, v165, v182
	v_fmac_f32_e32 v180, v149, v170
	v_fmac_f32_e32 v181, v160, v182
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v163, v170
	v_dual_fmac_f32 v179, v140, v170 :: v_dual_fmac_f32 v180, v145, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v181, v158, v170 :: v_dual_and_b32 v170, 0xffff0000, v172
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v178, v161, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v136, v171
	v_fmac_f32_e32 v181, v156, v171
	v_dual_fmac_f32 v180, v141, v170 :: v_dual_lshlrev_b32 v171, 16, v173
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v128, v170
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v178, v159, v170
	v_dual_fmac_f32 v181, v153, v170 :: v_dual_and_b32 v170, 0xffff0000, v173
	v_fmac_f32_e32 v180, v137, v171
	v_fmac_f32_e32 v179, v124, v171
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v178, v157, v171
	v_fmac_f32_e32 v181, v150, v171
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v171, 16, v174
	v_fmac_f32_e32 v180, v133, v170
	v_fmac_f32_e32 v179, v120, v170
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v178, v154, v170
	v_fmac_f32_e32 v181, v146, v170
	v_and_b32_e32 v170, 0xffff0000, v174
	v_fmac_f32_e32 v180, v125, v171
	v_fmac_f32_e32 v179, v71, v171
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v178, v151, v171
	v_fmac_f32_e32 v181, v142, v171
	v_dual_fmac_f32 v180, v121, v170 :: v_dual_lshlrev_b32 v171, 16, v175
	v_fmac_f32_e32 v179, v67, v170
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v178, v147, v170
	v_dual_fmac_f32 v181, v138, v170 :: v_dual_and_b32 v170, 0xffff0000, v175
	v_fmac_f32_e32 v180, v118, v171
	v_fmac_f32_e32 v179, v65, v171
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v178, v143, v171
	v_fmac_f32_e32 v181, v134, v171
	v_dual_fmac_f32 v180, v68, v170 :: v_dual_lshlrev_b32 v171, 16, v176
	v_fmac_f32_e32 v179, v62, v170
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v178, v139, v170
	v_dual_fmac_f32 v181, v126, v170 :: v_dual_and_b32 v170, 0xffff0000, v176
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v179, v60, v171
	v_fmac_f32_e32 v180, v66, v171
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v178, v135, v171
	v_fmac_f32_e32 v181, v122, v171
	v_lshlrev_b32_e32 v171, 16, v177
	v_fmac_f32_e32 v179, v59, v170
	v_fmac_f32_e32 v180, v64, v170
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v178, v127, v170
	v_dual_fmac_f32 v181, v119, v170 :: v_dual_and_b32 v170, 0xffff0000, v177
	v_fmac_f32_e32 v179, v57, v171
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v181, v69, v171
	v_fmac_f32_e32 v179, v56, v170
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v181, v63, v170
	v_dual_fmac_f32 v95, v179, v129 :: v_dual_fmac_f32 v180, v61, v171
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v89, v181, v131
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v178, v123, v171
	v_fmac_f32_e32 v180, v58, v170
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v178, v70, v170
	v_dual_fmac_f32 v92, v180, v130 :: v_dual_fmac_f32 v85, v178, v132
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_89
.LBB90_103:                             ;   in Loop: Header=BB90_90 Depth=2
	v_add_co_u32 v174, s62, s56, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v175, null, s57, 0, s62
	s_clause 0x1
	global_load_b128 v[170:173], v[174:175], off offset:4096
	global_load_b128 v[174:177], v[174:175], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v178, 16, v170
	v_and_b32_e32 v170, 0xffff0000, v170
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v180, v169, v178, 0
	v_fma_f32 v179, v168, v178, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v181, v164, v178, 0
	s_wait_dscnt 0xf
	v_fma_f32 v178, v167, v178, 0
	v_lshlrev_b32_e32 v182, 16, v171
	v_fmac_f32_e32 v180, v155, v170
	v_fmac_f32_e32 v179, v148, v170
	v_fmac_f32_e32 v181, v162, v170
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v178, v166, v170
	v_and_b32_e32 v170, 0xffff0000, v171
	v_dual_fmac_f32 v180, v152, v182 :: v_dual_lshlrev_b32 v171, 16, v172
	v_fmac_f32_e32 v179, v144, v182
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v178, v165, v182
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v180, v149, v170
	v_fmac_f32_e32 v181, v160, v182
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v178, v163, v170
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v179, v140, v170 :: v_dual_fmac_f32 v180, v145, v171
	v_dual_fmac_f32 v181, v158, v170 :: v_dual_and_b32 v170, 0xffff0000, v172
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v178, v161, v171
	v_fmac_f32_e32 v179, v136, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v181, v156, v171
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v178, v159, v170 :: v_dual_lshlrev_b32 v171, 16, v173
	v_fmac_f32_e32 v180, v141, v170
	v_fmac_f32_e32 v179, v128, v170
	v_dual_fmac_f32 v181, v153, v170 :: v_dual_and_b32 v170, 0xffff0000, v173
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v178, v157, v171
	v_fmac_f32_e32 v180, v137, v171
	v_fmac_f32_e32 v179, v124, v171
	v_fmac_f32_e32 v181, v150, v171
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v171, 16, v174
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v178, v154, v170
	v_fmac_f32_e32 v180, v133, v170
	v_fmac_f32_e32 v179, v120, v170
	v_fmac_f32_e32 v181, v146, v170
	v_and_b32_e32 v170, 0xffff0000, v174
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v178, v151, v171
	v_fmac_f32_e32 v180, v125, v171
	v_fmac_f32_e32 v179, v71, v171
	v_fmac_f32_e32 v181, v142, v171
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v178, v147, v170 :: v_dual_lshlrev_b32 v171, 16, v175
	v_fmac_f32_e32 v180, v121, v170
	v_fmac_f32_e32 v179, v67, v170
	v_dual_fmac_f32 v181, v138, v170 :: v_dual_and_b32 v170, 0xffff0000, v175
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v178, v143, v171
	v_fmac_f32_e32 v180, v118, v171
	v_fmac_f32_e32 v179, v65, v171
	v_fmac_f32_e32 v181, v134, v171
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v178, v139, v170 :: v_dual_lshlrev_b32 v171, 16, v176
	v_fmac_f32_e32 v180, v68, v170
	v_fmac_f32_e32 v179, v62, v170
	v_dual_fmac_f32 v181, v126, v170 :: v_dual_and_b32 v170, 0xffff0000, v176
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v178, v135, v171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v179, v60, v171
	v_fmac_f32_e32 v181, v122, v171
	v_dual_fmac_f32 v180, v66, v171 :: v_dual_lshlrev_b32 v171, 16, v177
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v178, v127, v170
	v_fmac_f32_e32 v179, v59, v170
	v_fmac_f32_e32 v181, v119, v170
	v_fmac_f32_e32 v180, v64, v170
	v_and_b32_e32 v170, 0xffff0000, v177
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v178, v123, v171
	v_fmac_f32_e32 v179, v57, v171
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v181, v69, v171 :: v_dual_fmac_f32 v178, v70, v170
	v_fmac_f32_e32 v179, v56, v170
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v181, v63, v170 :: v_dual_fmac_f32 v86, v178, v132
	v_dual_fmac_f32 v90, v179, v129 :: v_dual_fmac_f32 v87, v181, v131
	v_fmac_f32_e32 v180, v61, v171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v180, v58, v170
	v_fmac_f32_e32 v88, v180, v130
	s_branch .LBB90_89
.LBB90_104:                             ;   in Loop: Header=BB90_9 Depth=1
	s_or_b32 exec_lo, exec_lo, s14
.LBB90_105:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s39
	v_xor_b32_e32 v4, 16, v84
	v_xor_b32_e32 v3, 8, v84
	v_xor_b32_e32 v2, 4, v84
	v_xor_b32_e32 v1, 2, v84
	v_xor_b32_e32 v0, 1, v84
	s_and_b32 vcc_lo, exec_lo, s37
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_143
; %bb.106:                              ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v7, v5, v117
	s_wait_loadcnt_dscnt 0x200
	s_wait_alu 0xfffd
	v_dual_add_f32 v40, v117, v7 :: v_dual_cndmask_b32 v7, v84, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	ds_bpermute_b32 v41, v6, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v41, v40, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v40, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v42, v7, v41
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v41, v42
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v42, v42, v43 :: v_dual_cndmask_b32 v41, v84, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v41, 2, v41
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_wait_kmcnt 0x0
	v_mul_f32_e32 v42, s12, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v42
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.107:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v42, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v42, v43, 0x7fff
	v_lshrrev_b32_e32 v43, 16, v42
                                        ; implicit-def: $vgpr42
; %bb.108:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.109:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v42
; %bb.110:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v116
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v116, v42
	ds_bpermute_b32 v44, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, s13, v42
	v_and_b32_e32 v42, 0x7fffffff, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.111:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v44, v42, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.112:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.113:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.114:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43
	v_fma_f32 v45, 0xbfb8aa3b, v43, -v44
	v_rndne_f32_e32 v46, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v44, v44, v46
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43
	v_fmac_f32_e32 v45, 0xb2a5705f, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v44, v44, v45
	v_cvt_i32_f32_e32 v45, v46
	v_exp_f32_e32 v44, v44
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v44, v44, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo
	v_add_f32_e32 v44, 1.0, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v45, null, v44, v44, v43
	v_rcp_f32_e32 v46, v45
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v47, -v45, v46, 1.0
	v_fmac_f32_e32 v46, v47, v46
	v_div_scale_f32 v47, vcc_lo, v43, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v48, v47, v46
	v_fma_f32 v49, -v45, v48, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v48, v49, v46
	v_fma_f32 v45, -v45, v48, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v45, v45, v46, v48
	v_div_fixup_f32 v44, v45, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v44
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_117
; %bb.115:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_118
.LBB90_116:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_119
	s_branch .LBB90_124
.LBB90_117:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v43, v44, v43, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v43, 16, v43
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_116
.LBB90_118:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v43, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v43
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_124
.LBB90_119:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v43
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s37, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s37, exec_lo, s37
; %bb.120:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.121:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s37, s37
; %bb.122:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.123:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s37
	s_ashr_i32 s39, s38, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[38:39], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v43, vcc_lo, v73, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v44, null, s41, v74, vcc_lo
	global_store_b16 v[43:44], v42, off
.LBB90_124:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v115
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v115, v42
	ds_bpermute_b32 v43, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, s12, v42
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.125:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.126:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.127:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.128:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v5, v114
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v114, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v40, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v41, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.129:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.130:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.131:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.132:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v6, 16, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_135
; %bb.133:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_136
.LBB90_134:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execnz .LBB90_137
	s_branch .LBB90_142
.LBB90_135:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_134
.LBB90_136:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_142
.LBB90_137:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s37, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s37, exec_lo, s37
; %bb.138:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.139:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s37, s37
; %bb.140:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.141:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s37
	s_ashr_i32 s39, s38, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[38:39], s[38:39], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s39, v74, vcc_lo
	global_store_b16 v[6:7], v5, off offset:2
.LBB90_142:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
.LBB90_143:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_ne_u32_e32 vcc_lo, 1, v99
	s_cbranch_vccz .LBB90_150
; %bb.144:                              ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_205
.LBB90_145:                             ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_242
.LBB90_146:                             ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_279
.LBB90_147:                             ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_316
.LBB90_148:                             ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_353
.LBB90_149:                             ;   in Loop: Header=BB90_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_8
	s_branch .LBB90_390
.LBB90_150:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v7, v5, v113
	s_wait_loadcnt_dscnt 0x200
	s_wait_alu 0xfffd
	v_dual_add_f32 v40, v113, v7 :: v_dual_cndmask_b32 v7, v84, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	ds_bpermute_b32 v41, v6, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v41, v40, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v40, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v42, v7, v41
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v41, v42
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v42, v42, v43 :: v_dual_cndmask_b32 v41, v84, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v41, 2, v41
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_wait_kmcnt 0x0
	v_mul_f32_e32 v42, s12, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v42
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.151:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v42, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v42, v43, 0x7fff
	v_lshrrev_b32_e32 v43, 16, v42
                                        ; implicit-def: $vgpr42
; %bb.152:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.153:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v42
; %bb.154:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v112
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v112, v42
	ds_bpermute_b32 v44, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, s13, v42
	v_and_b32_e32 v42, 0x7fffffff, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.155:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v44, v42, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.156:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.157:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.158:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43
	v_fma_f32 v45, 0xbfb8aa3b, v43, -v44
	v_rndne_f32_e32 v46, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v44, v44, v46
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43
	v_fmac_f32_e32 v45, 0xb2a5705f, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v44, v44, v45
	v_cvt_i32_f32_e32 v45, v46
	v_exp_f32_e32 v44, v44
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v44, v44, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo
	v_add_f32_e32 v44, 1.0, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v45, null, v44, v44, v43
	v_rcp_f32_e32 v46, v45
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v47, -v45, v46, 1.0
	v_fmac_f32_e32 v46, v47, v46
	v_div_scale_f32 v47, vcc_lo, v43, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v48, v47, v46
	v_fma_f32 v49, -v45, v48, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v48, v49, v46
	v_fma_f32 v45, -v45, v48, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v45, v45, v46, v48
	v_div_fixup_f32 v44, v45, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v44
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_179
; %bb.159:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_180
.LBB90_160:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_181
	s_branch .LBB90_186
.LBB90_161:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s36
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s36, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v182, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v183, null, s41, v79, vcc_lo
	s_clause 0x1
	global_load_b128 v[178:181], v[182:183], off
	global_load_b128 v[182:185], v[182:183], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v186, 16, v178
	v_and_b32_e32 v178, 0xffff0000, v178
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v187, v152, v186, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v188, v169, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v189, v165, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v186, v177, v186, 0
	v_dual_fmac_f32 v187, v135, v178 :: v_dual_lshlrev_b32 v190, 16, v179
	v_fmac_f32_e32 v188, v146, v178
	v_fmac_f32_e32 v189, v164, v178
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v186, v176, v178
	v_dual_fmac_f32 v187, v133, v190 :: v_dual_and_b32 v178, 0xffff0000, v179
	v_dual_fmac_f32 v188, v145, v190 :: v_dual_lshlrev_b32 v179, 16, v180
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v186, v175, v190
	v_fmac_f32_e32 v188, v144, v178
	v_fmac_f32_e32 v189, v162, v190
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v186, v174, v178
	v_fmac_f32_e32 v187, v131, v178
	v_dual_fmac_f32 v188, v143, v179 :: v_dual_fmac_f32 v189, v160, v178
	v_and_b32_e32 v178, 0xffff0000, v180
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v186, v173, v179
	v_fmac_f32_e32 v187, v130, v179
	v_fmac_f32_e32 v189, v157, v179
	v_dual_fmac_f32 v188, v142, v178 :: v_dual_lshlrev_b32 v179, 16, v181
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v129, v178
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v186, v172, v178
	v_dual_fmac_f32 v189, v156, v178 :: v_dual_and_b32 v178, 0xffff0000, v181
	v_fmac_f32_e32 v188, v140, v179
	v_fmac_f32_e32 v187, v70, v179
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v186, v170, v179
	v_fmac_f32_e32 v189, v154, v179
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v179, 16, v182
	v_fmac_f32_e32 v188, v138, v178
	v_fmac_f32_e32 v187, v68, v178
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v186, v167, v178
	v_fmac_f32_e32 v189, v151, v178
	v_and_b32_e32 v178, 0xffff0000, v182
	v_fmac_f32_e32 v188, v141, v179
	v_fmac_f32_e32 v187, v71, v179
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v186, v171, v179
	v_fmac_f32_e32 v189, v155, v179
	v_dual_fmac_f32 v188, v139, v178 :: v_dual_lshlrev_b32 v179, 16, v183
	v_fmac_f32_e32 v187, v69, v178
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v186, v168, v178
	v_dual_fmac_f32 v189, v153, v178 :: v_dual_and_b32 v178, 0xffff0000, v183
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v67, v179
	v_fmac_f32_e32 v188, v137, v179
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v186, v166, v179
	v_fmac_f32_e32 v189, v150, v179
	v_lshlrev_b32_e32 v179, 16, v184
	v_fmac_f32_e32 v187, v66, v178
	v_fmac_f32_e32 v188, v136, v178
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v186, v163, v178
	v_dual_fmac_f32 v189, v149, v178 :: v_dual_and_b32 v178, 0xffff0000, v184
	v_fmac_f32_e32 v187, v65, v179
	v_fmac_f32_e32 v188, v134, v179
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v189, v148, v179
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v186, v161, v179 :: v_dual_lshlrev_b32 v179, 16, v185
	v_fmac_f32_e32 v187, v64, v178
	v_fmac_f32_e32 v189, v147, v178
	v_fmac_f32_e32 v188, v132, v178
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v186, v158, v178
	v_dual_fmac_f32 v187, v63, v179 :: v_dual_and_b32 v178, 0xffff0000, v185
	v_fmac_f32_e32 v189, v59, v179
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v188, v61, v179 :: v_dual_fmac_f32 v187, v62, v178
	v_fmac_f32_e32 v113, v187, v127
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v186, v57, v179
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v186, v56, v178
	v_fmac_f32_e32 v109, v186, v126
	v_fmac_f32_e32 v188, v60, v178
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v189, v58, v178 :: v_dual_fmac_f32 v112, v188, v159
	v_fmac_f32_e32 v110, v189, v128
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_63
.LBB90_162:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s34
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s34, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v182, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v183, null, s41, v79, vcc_lo
	s_clause 0x1
	global_load_b128 v[178:181], v[182:183], off
	global_load_b128 v[182:185], v[182:183], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v186, 16, v178
	v_and_b32_e32 v178, 0xffff0000, v178
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v187, v152, v186, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v188, v169, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v189, v165, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v186, v177, v186, 0
	v_dual_fmac_f32 v187, v135, v178 :: v_dual_lshlrev_b32 v190, 16, v179
	v_fmac_f32_e32 v188, v146, v178
	v_fmac_f32_e32 v189, v164, v178
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v186, v176, v178
	v_dual_fmac_f32 v187, v133, v190 :: v_dual_and_b32 v178, 0xffff0000, v179
	v_dual_fmac_f32 v188, v145, v190 :: v_dual_lshlrev_b32 v179, 16, v180
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v186, v175, v190
	v_fmac_f32_e32 v188, v144, v178
	v_fmac_f32_e32 v189, v162, v190
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v186, v174, v178
	v_fmac_f32_e32 v187, v131, v178
	v_dual_fmac_f32 v188, v143, v179 :: v_dual_fmac_f32 v189, v160, v178
	v_and_b32_e32 v178, 0xffff0000, v180
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v186, v173, v179
	v_fmac_f32_e32 v187, v130, v179
	v_fmac_f32_e32 v189, v157, v179
	v_dual_fmac_f32 v188, v142, v178 :: v_dual_lshlrev_b32 v179, 16, v181
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v129, v178
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v186, v172, v178
	v_dual_fmac_f32 v189, v156, v178 :: v_dual_and_b32 v178, 0xffff0000, v181
	v_fmac_f32_e32 v188, v140, v179
	v_fmac_f32_e32 v187, v70, v179
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v186, v170, v179
	v_fmac_f32_e32 v189, v154, v179
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v179, 16, v182
	v_fmac_f32_e32 v188, v138, v178
	v_fmac_f32_e32 v187, v68, v178
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v186, v167, v178
	v_fmac_f32_e32 v189, v151, v178
	v_and_b32_e32 v178, 0xffff0000, v182
	v_fmac_f32_e32 v188, v141, v179
	v_fmac_f32_e32 v187, v71, v179
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v186, v171, v179
	v_fmac_f32_e32 v189, v155, v179
	v_dual_fmac_f32 v188, v139, v178 :: v_dual_lshlrev_b32 v179, 16, v183
	v_fmac_f32_e32 v187, v69, v178
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v186, v168, v178
	v_dual_fmac_f32 v189, v153, v178 :: v_dual_and_b32 v178, 0xffff0000, v183
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v67, v179
	v_fmac_f32_e32 v188, v137, v179
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v186, v166, v179
	v_fmac_f32_e32 v189, v150, v179
	v_lshlrev_b32_e32 v179, 16, v184
	v_fmac_f32_e32 v187, v66, v178
	v_fmac_f32_e32 v188, v136, v178
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v186, v163, v178
	v_dual_fmac_f32 v189, v149, v178 :: v_dual_and_b32 v178, 0xffff0000, v184
	v_fmac_f32_e32 v187, v65, v179
	v_fmac_f32_e32 v188, v134, v179
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v189, v148, v179
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v186, v161, v179 :: v_dual_lshlrev_b32 v179, 16, v185
	v_fmac_f32_e32 v187, v64, v178
	v_fmac_f32_e32 v189, v147, v178
	v_fmac_f32_e32 v188, v132, v178
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v186, v158, v178
	v_dual_fmac_f32 v187, v63, v179 :: v_dual_and_b32 v178, 0xffff0000, v185
	v_fmac_f32_e32 v189, v59, v179
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v188, v61, v179 :: v_dual_fmac_f32 v187, v62, v178
	v_fmac_f32_e32 v189, v58, v178
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v188, v60, v178 :: v_dual_fmac_f32 v111, v187, v127
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v186, v57, v179
	v_fmac_f32_e32 v108, v188, v159
	v_fmac_f32_e32 v106, v189, v128
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v186, v56, v178
	v_fmac_f32_e32 v100, v186, v126
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_64
.LBB90_163:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s30
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s30, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v182, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v183, null, s41, v79, vcc_lo
	s_clause 0x1
	global_load_b128 v[178:181], v[182:183], off
	global_load_b128 v[182:185], v[182:183], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v186, 16, v178
	v_and_b32_e32 v178, 0xffff0000, v178
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v188, v169, v186, 0
	v_fma_f32 v187, v152, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v189, v165, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v186, v177, v186, 0
	v_lshlrev_b32_e32 v190, 16, v179
	v_fmac_f32_e32 v188, v146, v178
	v_fmac_f32_e32 v187, v135, v178
	v_fmac_f32_e32 v189, v164, v178
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v186, v176, v178
	v_and_b32_e32 v178, 0xffff0000, v179
	v_dual_fmac_f32 v188, v145, v190 :: v_dual_lshlrev_b32 v179, 16, v180
	v_fmac_f32_e32 v187, v133, v190
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v186, v175, v190
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v188, v144, v178
	v_fmac_f32_e32 v189, v162, v190
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v186, v174, v178
	v_fmac_f32_e32 v187, v131, v178
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v188, v143, v179 :: v_dual_fmac_f32 v189, v160, v178
	v_and_b32_e32 v178, 0xffff0000, v180
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v186, v173, v179
	v_fmac_f32_e32 v187, v130, v179
	v_fmac_f32_e32 v189, v157, v179
	v_dual_fmac_f32 v188, v142, v178 :: v_dual_lshlrev_b32 v179, 16, v181
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v129, v178
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v186, v172, v178
	v_dual_fmac_f32 v189, v156, v178 :: v_dual_and_b32 v178, 0xffff0000, v181
	v_fmac_f32_e32 v188, v140, v179
	v_fmac_f32_e32 v187, v70, v179
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v186, v170, v179
	v_fmac_f32_e32 v189, v154, v179
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v179, 16, v182
	v_fmac_f32_e32 v188, v138, v178
	v_fmac_f32_e32 v187, v68, v178
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v186, v167, v178
	v_fmac_f32_e32 v189, v151, v178
	v_and_b32_e32 v178, 0xffff0000, v182
	v_fmac_f32_e32 v188, v141, v179
	v_fmac_f32_e32 v187, v71, v179
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v186, v171, v179
	v_fmac_f32_e32 v189, v155, v179
	v_dual_fmac_f32 v188, v139, v178 :: v_dual_lshlrev_b32 v179, 16, v183
	v_fmac_f32_e32 v187, v69, v178
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v186, v168, v178
	v_dual_fmac_f32 v189, v153, v178 :: v_dual_and_b32 v178, 0xffff0000, v183
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v187, v67, v179
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v186, v166, v179
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v189, v150, v179
	v_dual_fmac_f32 v188, v137, v179 :: v_dual_lshlrev_b32 v179, 16, v184
	v_fmac_f32_e32 v187, v66, v178
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v186, v163, v178
	v_fmac_f32_e32 v189, v149, v178
	v_fmac_f32_e32 v188, v136, v178
	v_dual_fmac_f32 v187, v65, v179 :: v_dual_and_b32 v178, 0xffff0000, v184
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v189, v148, v179
	v_fmac_f32_e32 v188, v134, v179
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v186, v161, v179 :: v_dual_lshlrev_b32 v179, 16, v185
	v_fmac_f32_e32 v187, v64, v178
	v_fmac_f32_e32 v189, v147, v178
	v_fmac_f32_e32 v188, v132, v178
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v186, v158, v178
	v_dual_fmac_f32 v187, v63, v179 :: v_dual_and_b32 v178, 0xffff0000, v185
	v_fmac_f32_e32 v189, v59, v179
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v189, v58, v178
	v_fmac_f32_e32 v103, v189, v128
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v188, v61, v179 :: v_dual_fmac_f32 v187, v62, v178
	v_dual_fmac_f32 v188, v60, v178 :: v_dual_fmac_f32 v107, v187, v127
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v186, v57, v179
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v105, v188, v159
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v186, v56, v178
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v102, v186, v126
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_65
.LBB90_164:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s28
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s28, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v182, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v183, null, s41, v79, vcc_lo
	s_clause 0x1
	global_load_b128 v[178:181], v[182:183], off
	global_load_b128 v[182:185], v[182:183], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v186, 16, v178
	v_and_b32_e32 v178, 0xffff0000, v178
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v188, v169, v186, 0
	v_fma_f32 v187, v152, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v189, v165, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v186, v177, v186, 0
	v_lshlrev_b32_e32 v190, 16, v179
	v_fmac_f32_e32 v188, v146, v178
	v_fmac_f32_e32 v187, v135, v178
	v_fmac_f32_e32 v189, v164, v178
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v186, v176, v178
	v_and_b32_e32 v178, 0xffff0000, v179
	v_dual_fmac_f32 v188, v145, v190 :: v_dual_lshlrev_b32 v179, 16, v180
	v_fmac_f32_e32 v187, v133, v190
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v186, v175, v190
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v188, v144, v178
	v_fmac_f32_e32 v189, v162, v190
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v186, v174, v178
	v_fmac_f32_e32 v187, v131, v178
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v188, v143, v179 :: v_dual_fmac_f32 v189, v160, v178
	v_and_b32_e32 v178, 0xffff0000, v180
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v186, v173, v179
	v_fmac_f32_e32 v187, v130, v179
	v_fmac_f32_e32 v189, v157, v179
	v_dual_fmac_f32 v188, v142, v178 :: v_dual_lshlrev_b32 v179, 16, v181
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v129, v178
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v186, v172, v178
	v_dual_fmac_f32 v189, v156, v178 :: v_dual_and_b32 v178, 0xffff0000, v181
	v_fmac_f32_e32 v188, v140, v179
	v_fmac_f32_e32 v187, v70, v179
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v186, v170, v179
	v_fmac_f32_e32 v189, v154, v179
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v179, 16, v182
	v_fmac_f32_e32 v188, v138, v178
	v_fmac_f32_e32 v187, v68, v178
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v186, v167, v178
	v_fmac_f32_e32 v189, v151, v178
	v_and_b32_e32 v178, 0xffff0000, v182
	v_fmac_f32_e32 v188, v141, v179
	v_fmac_f32_e32 v187, v71, v179
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v186, v171, v179
	v_fmac_f32_e32 v189, v155, v179
	v_dual_fmac_f32 v188, v139, v178 :: v_dual_lshlrev_b32 v179, 16, v183
	v_fmac_f32_e32 v187, v69, v178
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v186, v168, v178
	v_dual_fmac_f32 v189, v153, v178 :: v_dual_and_b32 v178, 0xffff0000, v183
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v187, v67, v179
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v186, v166, v179
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v189, v150, v179
	v_dual_fmac_f32 v188, v137, v179 :: v_dual_lshlrev_b32 v179, 16, v184
	v_fmac_f32_e32 v187, v66, v178
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v186, v163, v178
	v_fmac_f32_e32 v189, v149, v178
	v_fmac_f32_e32 v188, v136, v178
	v_dual_fmac_f32 v187, v65, v179 :: v_dual_and_b32 v178, 0xffff0000, v184
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v189, v148, v179
	v_fmac_f32_e32 v188, v134, v179
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v186, v161, v179 :: v_dual_lshlrev_b32 v179, 16, v185
	v_fmac_f32_e32 v187, v64, v178
	v_fmac_f32_e32 v189, v147, v178
	v_fmac_f32_e32 v188, v132, v178
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v186, v158, v178
	v_dual_fmac_f32 v187, v63, v179 :: v_dual_and_b32 v178, 0xffff0000, v185
	v_fmac_f32_e32 v189, v59, v179
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v189, v58, v178
	v_fmac_f32_e32 v97, v189, v128
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v186, v57, v179
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v186, v56, v178
	v_dual_fmac_f32 v91, v186, v126 :: v_dual_fmac_f32 v188, v61, v179
	v_fmac_f32_e32 v187, v62, v178
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v188, v60, v178
	v_fmac_f32_e32 v104, v187, v127
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v101, v188, v159
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_66
.LBB90_165:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s26
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s26, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v182, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v183, null, s41, v79, vcc_lo
	s_clause 0x1
	global_load_b128 v[178:181], v[182:183], off
	global_load_b128 v[182:185], v[182:183], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v186, 16, v178
	v_and_b32_e32 v178, 0xffff0000, v178
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v188, v169, v186, 0
	v_fma_f32 v187, v152, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v189, v165, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v186, v177, v186, 0
	v_lshlrev_b32_e32 v190, 16, v179
	v_fmac_f32_e32 v188, v146, v178
	v_fmac_f32_e32 v187, v135, v178
	v_fmac_f32_e32 v189, v164, v178
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v186, v176, v178
	v_and_b32_e32 v178, 0xffff0000, v179
	v_dual_fmac_f32 v188, v145, v190 :: v_dual_lshlrev_b32 v179, 16, v180
	v_fmac_f32_e32 v187, v133, v190
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v186, v175, v190
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v188, v144, v178
	v_fmac_f32_e32 v189, v162, v190
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v186, v174, v178
	v_fmac_f32_e32 v187, v131, v178
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v188, v143, v179 :: v_dual_fmac_f32 v189, v160, v178
	v_and_b32_e32 v178, 0xffff0000, v180
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v186, v173, v179
	v_fmac_f32_e32 v187, v130, v179
	v_fmac_f32_e32 v189, v157, v179
	v_dual_fmac_f32 v188, v142, v178 :: v_dual_lshlrev_b32 v179, 16, v181
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v129, v178
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v186, v172, v178
	v_dual_fmac_f32 v189, v156, v178 :: v_dual_and_b32 v178, 0xffff0000, v181
	v_fmac_f32_e32 v188, v140, v179
	v_fmac_f32_e32 v187, v70, v179
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v186, v170, v179
	v_fmac_f32_e32 v189, v154, v179
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v179, 16, v182
	v_fmac_f32_e32 v188, v138, v178
	v_fmac_f32_e32 v187, v68, v178
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v186, v167, v178
	v_fmac_f32_e32 v189, v151, v178
	v_and_b32_e32 v178, 0xffff0000, v182
	v_fmac_f32_e32 v188, v141, v179
	v_fmac_f32_e32 v187, v71, v179
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v186, v171, v179
	v_fmac_f32_e32 v189, v155, v179
	v_dual_fmac_f32 v188, v139, v178 :: v_dual_lshlrev_b32 v179, 16, v183
	v_fmac_f32_e32 v187, v69, v178
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v186, v168, v178
	v_dual_fmac_f32 v189, v153, v178 :: v_dual_and_b32 v178, 0xffff0000, v183
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v187, v67, v179
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v186, v166, v179
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v189, v150, v179
	v_dual_fmac_f32 v188, v137, v179 :: v_dual_lshlrev_b32 v179, 16, v184
	v_fmac_f32_e32 v187, v66, v178
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v186, v163, v178
	v_fmac_f32_e32 v189, v149, v178
	v_fmac_f32_e32 v188, v136, v178
	v_dual_fmac_f32 v187, v65, v179 :: v_dual_and_b32 v178, 0xffff0000, v184
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v189, v148, v179
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v186, v161, v179
	v_dual_fmac_f32 v188, v134, v179 :: v_dual_fmac_f32 v187, v64, v178
	v_lshlrev_b32_e32 v179, 16, v185
	v_fmac_f32_e32 v189, v147, v178
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v186, v158, v178
	v_fmac_f32_e32 v188, v132, v178
	v_dual_fmac_f32 v187, v63, v179 :: v_dual_and_b32 v178, 0xffff0000, v185
	v_fmac_f32_e32 v189, v59, v179
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v186, v57, v179
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v186, v56, v178
	v_dual_fmac_f32 v93, v186, v126 :: v_dual_fmac_f32 v188, v61, v179
	v_fmac_f32_e32 v187, v62, v178
	v_fmac_f32_e32 v189, v58, v178
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v188, v60, v178
	v_fmac_f32_e32 v98, v187, v127
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v94, v189, v128
	v_fmac_f32_e32 v96, v188, v159
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_67
.LBB90_166:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s24
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s24, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v182, vcc_lo, v78, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v183, null, s41, v79, vcc_lo
	s_clause 0x1
	global_load_b128 v[178:181], v[182:183], off
	global_load_b128 v[182:185], v[182:183], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v186, 16, v178
	v_and_b32_e32 v178, 0xffff0000, v178
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v187, v152, v186, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v188, v169, v186, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v189, v165, v186, 0
	s_wait_dscnt 0xf
	v_fma_f32 v186, v177, v186, 0
	v_dual_fmac_f32 v187, v135, v178 :: v_dual_lshlrev_b32 v190, 16, v179
	v_fmac_f32_e32 v188, v146, v178
	v_fmac_f32_e32 v189, v164, v178
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v186, v176, v178
	v_dual_fmac_f32 v187, v133, v190 :: v_dual_and_b32 v178, 0xffff0000, v179
	v_dual_fmac_f32 v188, v145, v190 :: v_dual_lshlrev_b32 v179, 16, v180
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v186, v175, v190
	v_fmac_f32_e32 v188, v144, v178
	v_fmac_f32_e32 v189, v162, v190
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v186, v174, v178
	v_fmac_f32_e32 v187, v131, v178
	v_dual_fmac_f32 v188, v143, v179 :: v_dual_fmac_f32 v189, v160, v178
	v_and_b32_e32 v178, 0xffff0000, v180
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v186, v173, v179
	v_fmac_f32_e32 v187, v130, v179
	v_fmac_f32_e32 v189, v157, v179
	v_dual_fmac_f32 v188, v142, v178 :: v_dual_lshlrev_b32 v179, 16, v181
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v129, v178
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v186, v172, v178
	v_dual_fmac_f32 v189, v156, v178 :: v_dual_and_b32 v178, 0xffff0000, v181
	v_fmac_f32_e32 v188, v140, v179
	v_fmac_f32_e32 v187, v70, v179
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v186, v170, v179
	v_fmac_f32_e32 v189, v154, v179
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v179, 16, v182
	v_fmac_f32_e32 v188, v138, v178
	v_fmac_f32_e32 v187, v68, v178
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v186, v167, v178
	v_fmac_f32_e32 v189, v151, v178
	v_and_b32_e32 v178, 0xffff0000, v182
	v_fmac_f32_e32 v188, v141, v179
	v_fmac_f32_e32 v187, v71, v179
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v186, v171, v179
	v_fmac_f32_e32 v189, v155, v179
	v_dual_fmac_f32 v188, v139, v178 :: v_dual_lshlrev_b32 v179, 16, v183
	v_fmac_f32_e32 v187, v69, v178
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v186, v168, v178
	v_dual_fmac_f32 v189, v153, v178 :: v_dual_and_b32 v178, 0xffff0000, v183
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v187, v67, v179
	v_fmac_f32_e32 v188, v137, v179
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v186, v166, v179
	v_fmac_f32_e32 v189, v150, v179
	v_lshlrev_b32_e32 v179, 16, v184
	v_fmac_f32_e32 v187, v66, v178
	v_fmac_f32_e32 v188, v136, v178
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v186, v163, v178
	v_dual_fmac_f32 v189, v149, v178 :: v_dual_and_b32 v178, 0xffff0000, v184
	v_fmac_f32_e32 v187, v65, v179
	v_fmac_f32_e32 v188, v134, v179
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v189, v148, v179
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v186, v161, v179 :: v_dual_lshlrev_b32 v179, 16, v185
	v_fmac_f32_e32 v187, v64, v178
	v_fmac_f32_e32 v189, v147, v178
	v_fmac_f32_e32 v188, v132, v178
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v186, v158, v178
	v_dual_fmac_f32 v187, v63, v179 :: v_dual_and_b32 v178, 0xffff0000, v185
	v_fmac_f32_e32 v189, v59, v179
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v188, v61, v179 :: v_dual_fmac_f32 v187, v62, v178
	v_fmac_f32_e32 v95, v187, v127
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v186, v57, v179
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v186, v56, v178
	v_fmac_f32_e32 v85, v186, v126
	v_fmac_f32_e32 v188, v60, v178
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v189, v58, v178 :: v_dual_fmac_f32 v92, v188, v159
	v_fmac_f32_e32 v89, v189, v128
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_68
	s_branch .LBB90_69
.LBB90_167:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s36
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s36, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v170, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v171, null, s41, v81, vcc_lo
	s_clause 0x1
	global_load_b128 v[166:169], v[170:171], off
	global_load_b128 v[170:173], v[170:171], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v174, 16, v166
	v_and_b32_e32 v166, 0xffff0000, v166
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v175, v140, v174, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v176, v157, v174, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v177, v153, v174, 0
	s_wait_dscnt 0xf
	v_fma_f32 v174, v165, v174, 0
	v_dual_fmac_f32 v175, v70, v166 :: v_dual_lshlrev_b32 v178, 16, v167
	v_fmac_f32_e32 v176, v134, v166
	v_fmac_f32_e32 v177, v152, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v174, v164, v166
	v_dual_fmac_f32 v175, v68, v178 :: v_dual_and_b32 v166, 0xffff0000, v167
	v_dual_fmac_f32 v176, v133, v178 :: v_dual_lshlrev_b32 v167, 16, v168
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v163, v178
	v_fmac_f32_e32 v176, v132, v166
	v_fmac_f32_e32 v177, v150, v178
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v162, v166
	v_dual_fmac_f32 v175, v66, v166 :: v_dual_fmac_f32 v176, v131, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v177, v148, v166 :: v_dual_and_b32 v166, 0xffff0000, v168
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v174, v161, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v65, v167
	v_fmac_f32_e32 v177, v145, v167
	v_dual_fmac_f32 v176, v130, v166 :: v_dual_lshlrev_b32 v167, 16, v169
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v174, v160, v166
	v_fmac_f32_e32 v175, v64, v166
	v_dual_fmac_f32 v177, v144, v166 :: v_dual_and_b32 v166, 0xffff0000, v169
	v_fmac_f32_e32 v176, v128, v167
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v174, v158, v167
	v_fmac_f32_e32 v175, v62, v167
	v_fmac_f32_e32 v177, v142, v167
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v167, 16, v170
	v_fmac_f32_e32 v176, v126, v166
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v174, v155, v166
	v_fmac_f32_e32 v175, v60, v166
	v_fmac_f32_e32 v177, v139, v166
	v_and_b32_e32 v166, 0xffff0000, v170
	v_fmac_f32_e32 v176, v129, v167
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v174, v159, v167
	v_fmac_f32_e32 v175, v63, v167
	v_fmac_f32_e32 v177, v143, v167
	v_dual_fmac_f32 v176, v127, v166 :: v_dual_lshlrev_b32 v167, 16, v171
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v174, v156, v166
	v_fmac_f32_e32 v175, v61, v166
	v_dual_fmac_f32 v177, v141, v166 :: v_dual_and_b32 v166, 0xffff0000, v171
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v154, v167
	v_fmac_f32_e32 v175, v59, v167
	v_fmac_f32_e32 v176, v125, v167
	v_fmac_f32_e32 v177, v138, v167
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v174, v151, v166 :: v_dual_lshlrev_b32 v167, 16, v172
	v_fmac_f32_e32 v175, v58, v166
	v_fmac_f32_e32 v176, v71, v166
	v_dual_fmac_f32 v177, v137, v166 :: v_dual_and_b32 v166, 0xffff0000, v172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v57, v167
	v_fmac_f32_e32 v176, v69, v167
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v177, v136, v167
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v174, v149, v167 :: v_dual_lshlrev_b32 v167, 16, v173
	v_fmac_f32_e32 v175, v56, v166
	v_fmac_f32_e32 v176, v67, v166
	v_fmac_f32_e32 v177, v135, v166
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v174, v146, v166
	v_dual_fmac_f32 v175, v55, v167 :: v_dual_and_b32 v166, 0xffff0000, v173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v176, v53, v167 :: v_dual_fmac_f32 v175, v54, v166
	v_dual_fmac_f32 v177, v51, v167 :: v_dual_fmac_f32 v176, v52, v166
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v174, v49, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v113, v175, v123
	v_fmac_f32_e32 v177, v50, v166
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v48, v166
	v_fmac_f32_e32 v112, v176, v147
	v_dual_fmac_f32 v110, v177, v124 :: v_dual_fmac_f32 v109, v174, v122
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_72
.LBB90_168:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s34
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s34, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v170, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v171, null, s41, v81, vcc_lo
	s_clause 0x1
	global_load_b128 v[166:169], v[170:171], off
	global_load_b128 v[170:173], v[170:171], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v174, 16, v166
	v_and_b32_e32 v166, 0xffff0000, v166
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v175, v140, v174, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v176, v157, v174, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v177, v153, v174, 0
	s_wait_dscnt 0xf
	v_fma_f32 v174, v165, v174, 0
	v_dual_fmac_f32 v175, v70, v166 :: v_dual_lshlrev_b32 v178, 16, v167
	v_fmac_f32_e32 v176, v134, v166
	v_fmac_f32_e32 v177, v152, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v174, v164, v166
	v_dual_fmac_f32 v175, v68, v178 :: v_dual_and_b32 v166, 0xffff0000, v167
	v_dual_fmac_f32 v176, v133, v178 :: v_dual_lshlrev_b32 v167, 16, v168
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v163, v178
	v_fmac_f32_e32 v176, v132, v166
	v_fmac_f32_e32 v177, v150, v178
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v162, v166
	v_dual_fmac_f32 v175, v66, v166 :: v_dual_fmac_f32 v176, v131, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v177, v148, v166 :: v_dual_and_b32 v166, 0xffff0000, v168
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v174, v161, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v65, v167
	v_fmac_f32_e32 v177, v145, v167
	v_dual_fmac_f32 v176, v130, v166 :: v_dual_lshlrev_b32 v167, 16, v169
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v174, v160, v166
	v_fmac_f32_e32 v175, v64, v166
	v_dual_fmac_f32 v177, v144, v166 :: v_dual_and_b32 v166, 0xffff0000, v169
	v_fmac_f32_e32 v176, v128, v167
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v174, v158, v167
	v_fmac_f32_e32 v175, v62, v167
	v_fmac_f32_e32 v177, v142, v167
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v167, 16, v170
	v_fmac_f32_e32 v176, v126, v166
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v174, v155, v166
	v_fmac_f32_e32 v175, v60, v166
	v_fmac_f32_e32 v177, v139, v166
	v_and_b32_e32 v166, 0xffff0000, v170
	v_fmac_f32_e32 v176, v129, v167
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v174, v159, v167
	v_fmac_f32_e32 v175, v63, v167
	v_fmac_f32_e32 v177, v143, v167
	v_dual_fmac_f32 v176, v127, v166 :: v_dual_lshlrev_b32 v167, 16, v171
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v174, v156, v166
	v_fmac_f32_e32 v175, v61, v166
	v_dual_fmac_f32 v177, v141, v166 :: v_dual_and_b32 v166, 0xffff0000, v171
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v154, v167
	v_fmac_f32_e32 v175, v59, v167
	v_fmac_f32_e32 v176, v125, v167
	v_fmac_f32_e32 v177, v138, v167
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v174, v151, v166 :: v_dual_lshlrev_b32 v167, 16, v172
	v_fmac_f32_e32 v175, v58, v166
	v_fmac_f32_e32 v176, v71, v166
	v_dual_fmac_f32 v177, v137, v166 :: v_dual_and_b32 v166, 0xffff0000, v172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v57, v167
	v_fmac_f32_e32 v176, v69, v167
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v177, v136, v167
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v174, v149, v167 :: v_dual_lshlrev_b32 v167, 16, v173
	v_fmac_f32_e32 v175, v56, v166
	v_fmac_f32_e32 v176, v67, v166
	v_fmac_f32_e32 v177, v135, v166
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v174, v146, v166
	v_dual_fmac_f32 v175, v55, v167 :: v_dual_and_b32 v166, 0xffff0000, v173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v176, v53, v167 :: v_dual_fmac_f32 v175, v54, v166
	v_dual_fmac_f32 v177, v51, v167 :: v_dual_fmac_f32 v176, v52, v166
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v174, v49, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v111, v175, v123
	v_dual_fmac_f32 v177, v50, v166 :: v_dual_fmac_f32 v108, v176, v147
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v48, v166
	v_fmac_f32_e32 v106, v177, v124
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v100, v174, v122
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_73
.LBB90_169:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s30
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s30, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v170, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v171, null, s41, v81, vcc_lo
	s_clause 0x1
	global_load_b128 v[166:169], v[170:171], off
	global_load_b128 v[170:173], v[170:171], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v174, 16, v166
	v_and_b32_e32 v166, 0xffff0000, v166
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v175, v140, v174, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v176, v157, v174, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v177, v153, v174, 0
	s_wait_dscnt 0xf
	v_fma_f32 v174, v165, v174, 0
	v_dual_fmac_f32 v175, v70, v166 :: v_dual_lshlrev_b32 v178, 16, v167
	v_fmac_f32_e32 v176, v134, v166
	v_fmac_f32_e32 v177, v152, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v174, v164, v166
	v_dual_fmac_f32 v175, v68, v178 :: v_dual_and_b32 v166, 0xffff0000, v167
	v_dual_fmac_f32 v176, v133, v178 :: v_dual_lshlrev_b32 v167, 16, v168
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v163, v178
	v_fmac_f32_e32 v176, v132, v166
	v_fmac_f32_e32 v177, v150, v178
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v162, v166
	v_dual_fmac_f32 v175, v66, v166 :: v_dual_fmac_f32 v176, v131, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v177, v148, v166 :: v_dual_and_b32 v166, 0xffff0000, v168
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v174, v161, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v65, v167
	v_fmac_f32_e32 v177, v145, v167
	v_dual_fmac_f32 v176, v130, v166 :: v_dual_lshlrev_b32 v167, 16, v169
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v174, v160, v166
	v_fmac_f32_e32 v175, v64, v166
	v_dual_fmac_f32 v177, v144, v166 :: v_dual_and_b32 v166, 0xffff0000, v169
	v_fmac_f32_e32 v176, v128, v167
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v174, v158, v167
	v_fmac_f32_e32 v175, v62, v167
	v_fmac_f32_e32 v177, v142, v167
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v167, 16, v170
	v_fmac_f32_e32 v176, v126, v166
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v174, v155, v166
	v_fmac_f32_e32 v175, v60, v166
	v_fmac_f32_e32 v177, v139, v166
	v_and_b32_e32 v166, 0xffff0000, v170
	v_fmac_f32_e32 v176, v129, v167
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v174, v159, v167
	v_fmac_f32_e32 v175, v63, v167
	v_fmac_f32_e32 v177, v143, v167
	v_dual_fmac_f32 v176, v127, v166 :: v_dual_lshlrev_b32 v167, 16, v171
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v174, v156, v166
	v_fmac_f32_e32 v175, v61, v166
	v_dual_fmac_f32 v177, v141, v166 :: v_dual_and_b32 v166, 0xffff0000, v171
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v154, v167
	v_fmac_f32_e32 v175, v59, v167
	v_fmac_f32_e32 v176, v125, v167
	v_fmac_f32_e32 v177, v138, v167
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v174, v151, v166 :: v_dual_lshlrev_b32 v167, 16, v172
	v_fmac_f32_e32 v175, v58, v166
	v_fmac_f32_e32 v176, v71, v166
	v_dual_fmac_f32 v177, v137, v166 :: v_dual_and_b32 v166, 0xffff0000, v172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v57, v167
	v_fmac_f32_e32 v176, v69, v167
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v177, v136, v167
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v174, v149, v167 :: v_dual_lshlrev_b32 v167, 16, v173
	v_fmac_f32_e32 v175, v56, v166
	v_fmac_f32_e32 v176, v67, v166
	v_fmac_f32_e32 v177, v135, v166
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v174, v146, v166
	v_dual_fmac_f32 v175, v55, v167 :: v_dual_and_b32 v166, 0xffff0000, v173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v176, v53, v167 :: v_dual_fmac_f32 v175, v54, v166
	v_dual_fmac_f32 v177, v51, v167 :: v_dual_fmac_f32 v176, v52, v166
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v174, v49, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v107, v175, v123
	v_fmac_f32_e32 v177, v50, v166
	v_fmac_f32_e32 v105, v176, v147
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v174, v48, v166 :: v_dual_fmac_f32 v103, v177, v124
	v_fmac_f32_e32 v102, v174, v122
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_74
.LBB90_170:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s28
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s28, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v170, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v171, null, s41, v81, vcc_lo
	s_clause 0x1
	global_load_b128 v[166:169], v[170:171], off
	global_load_b128 v[170:173], v[170:171], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v174, 16, v166
	v_and_b32_e32 v166, 0xffff0000, v166
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v175, v140, v174, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v176, v157, v174, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v177, v153, v174, 0
	s_wait_dscnt 0xf
	v_fma_f32 v174, v165, v174, 0
	v_dual_fmac_f32 v175, v70, v166 :: v_dual_lshlrev_b32 v178, 16, v167
	v_fmac_f32_e32 v176, v134, v166
	v_fmac_f32_e32 v177, v152, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v174, v164, v166
	v_dual_fmac_f32 v175, v68, v178 :: v_dual_and_b32 v166, 0xffff0000, v167
	v_dual_fmac_f32 v176, v133, v178 :: v_dual_lshlrev_b32 v167, 16, v168
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v163, v178
	v_fmac_f32_e32 v176, v132, v166
	v_fmac_f32_e32 v177, v150, v178
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v162, v166
	v_dual_fmac_f32 v175, v66, v166 :: v_dual_fmac_f32 v176, v131, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v177, v148, v166 :: v_dual_and_b32 v166, 0xffff0000, v168
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v174, v161, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v65, v167
	v_fmac_f32_e32 v177, v145, v167
	v_dual_fmac_f32 v176, v130, v166 :: v_dual_lshlrev_b32 v167, 16, v169
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v174, v160, v166
	v_fmac_f32_e32 v175, v64, v166
	v_dual_fmac_f32 v177, v144, v166 :: v_dual_and_b32 v166, 0xffff0000, v169
	v_fmac_f32_e32 v176, v128, v167
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v174, v158, v167
	v_fmac_f32_e32 v175, v62, v167
	v_fmac_f32_e32 v177, v142, v167
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v167, 16, v170
	v_fmac_f32_e32 v176, v126, v166
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v174, v155, v166
	v_fmac_f32_e32 v175, v60, v166
	v_fmac_f32_e32 v177, v139, v166
	v_and_b32_e32 v166, 0xffff0000, v170
	v_fmac_f32_e32 v176, v129, v167
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v174, v159, v167
	v_fmac_f32_e32 v175, v63, v167
	v_fmac_f32_e32 v177, v143, v167
	v_dual_fmac_f32 v176, v127, v166 :: v_dual_lshlrev_b32 v167, 16, v171
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v174, v156, v166
	v_fmac_f32_e32 v175, v61, v166
	v_dual_fmac_f32 v177, v141, v166 :: v_dual_and_b32 v166, 0xffff0000, v171
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v154, v167
	v_fmac_f32_e32 v175, v59, v167
	v_fmac_f32_e32 v176, v125, v167
	v_fmac_f32_e32 v177, v138, v167
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v174, v151, v166 :: v_dual_lshlrev_b32 v167, 16, v172
	v_fmac_f32_e32 v175, v58, v166
	v_fmac_f32_e32 v176, v71, v166
	v_dual_fmac_f32 v177, v137, v166 :: v_dual_and_b32 v166, 0xffff0000, v172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v57, v167
	v_fmac_f32_e32 v176, v69, v167
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v177, v136, v167
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v174, v149, v167 :: v_dual_lshlrev_b32 v167, 16, v173
	v_fmac_f32_e32 v175, v56, v166
	v_fmac_f32_e32 v176, v67, v166
	v_fmac_f32_e32 v177, v135, v166
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v174, v146, v166
	v_dual_fmac_f32 v175, v55, v167 :: v_dual_and_b32 v166, 0xffff0000, v173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v176, v53, v167 :: v_dual_fmac_f32 v175, v54, v166
	v_dual_fmac_f32 v177, v51, v167 :: v_dual_fmac_f32 v176, v52, v166
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v174, v49, v167 :: v_dual_fmac_f32 v177, v50, v166
	v_fmac_f32_e32 v101, v176, v147
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v48, v166
	v_dual_fmac_f32 v104, v175, v123 :: v_dual_fmac_f32 v97, v177, v124
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v91, v174, v122
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_75
.LBB90_171:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s26
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s26, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v170, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v171, null, s41, v81, vcc_lo
	s_clause 0x1
	global_load_b128 v[166:169], v[170:171], off
	global_load_b128 v[170:173], v[170:171], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v174, 16, v166
	v_and_b32_e32 v166, 0xffff0000, v166
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v175, v140, v174, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v176, v157, v174, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v177, v153, v174, 0
	s_wait_dscnt 0xf
	v_fma_f32 v174, v165, v174, 0
	v_dual_fmac_f32 v175, v70, v166 :: v_dual_lshlrev_b32 v178, 16, v167
	v_fmac_f32_e32 v176, v134, v166
	v_fmac_f32_e32 v177, v152, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v174, v164, v166
	v_dual_fmac_f32 v175, v68, v178 :: v_dual_and_b32 v166, 0xffff0000, v167
	v_dual_fmac_f32 v176, v133, v178 :: v_dual_lshlrev_b32 v167, 16, v168
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v163, v178
	v_fmac_f32_e32 v176, v132, v166
	v_fmac_f32_e32 v177, v150, v178
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v162, v166
	v_dual_fmac_f32 v175, v66, v166 :: v_dual_fmac_f32 v176, v131, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v177, v148, v166 :: v_dual_and_b32 v166, 0xffff0000, v168
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v174, v161, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v65, v167
	v_fmac_f32_e32 v177, v145, v167
	v_dual_fmac_f32 v176, v130, v166 :: v_dual_lshlrev_b32 v167, 16, v169
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v174, v160, v166
	v_fmac_f32_e32 v175, v64, v166
	v_dual_fmac_f32 v177, v144, v166 :: v_dual_and_b32 v166, 0xffff0000, v169
	v_fmac_f32_e32 v176, v128, v167
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v174, v158, v167
	v_fmac_f32_e32 v175, v62, v167
	v_fmac_f32_e32 v177, v142, v167
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v167, 16, v170
	v_fmac_f32_e32 v176, v126, v166
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v174, v155, v166
	v_fmac_f32_e32 v175, v60, v166
	v_fmac_f32_e32 v177, v139, v166
	v_and_b32_e32 v166, 0xffff0000, v170
	v_fmac_f32_e32 v176, v129, v167
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v174, v159, v167
	v_fmac_f32_e32 v175, v63, v167
	v_fmac_f32_e32 v177, v143, v167
	v_dual_fmac_f32 v176, v127, v166 :: v_dual_lshlrev_b32 v167, 16, v171
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v174, v156, v166
	v_fmac_f32_e32 v175, v61, v166
	v_dual_fmac_f32 v177, v141, v166 :: v_dual_and_b32 v166, 0xffff0000, v171
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v154, v167
	v_fmac_f32_e32 v175, v59, v167
	v_fmac_f32_e32 v176, v125, v167
	v_fmac_f32_e32 v177, v138, v167
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v174, v151, v166 :: v_dual_lshlrev_b32 v167, 16, v172
	v_fmac_f32_e32 v175, v58, v166
	v_fmac_f32_e32 v176, v71, v166
	v_dual_fmac_f32 v177, v137, v166 :: v_dual_and_b32 v166, 0xffff0000, v172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v57, v167
	v_fmac_f32_e32 v176, v69, v167
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v177, v136, v167
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v174, v149, v167 :: v_dual_lshlrev_b32 v167, 16, v173
	v_fmac_f32_e32 v175, v56, v166
	v_fmac_f32_e32 v176, v67, v166
	v_fmac_f32_e32 v177, v135, v166
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v174, v146, v166
	v_dual_fmac_f32 v175, v55, v167 :: v_dual_and_b32 v166, 0xffff0000, v173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v176, v53, v167 :: v_dual_fmac_f32 v175, v54, v166
	v_dual_fmac_f32 v177, v51, v167 :: v_dual_fmac_f32 v176, v52, v166
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v174, v49, v167 :: v_dual_fmac_f32 v177, v50, v166
	v_fmac_f32_e32 v96, v176, v147
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v48, v166
	v_fmac_f32_e32 v98, v175, v123
	v_dual_fmac_f32 v94, v177, v124 :: v_dual_fmac_f32 v93, v174, v122
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_76
.LBB90_172:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s24
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s24, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v170, vcc_lo, v80, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v171, null, s41, v81, vcc_lo
	s_clause 0x1
	global_load_b128 v[166:169], v[170:171], off
	global_load_b128 v[170:173], v[170:171], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v174, 16, v166
	v_and_b32_e32 v166, 0xffff0000, v166
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v175, v140, v174, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v176, v157, v174, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v177, v153, v174, 0
	s_wait_dscnt 0xf
	v_fma_f32 v174, v165, v174, 0
	v_dual_fmac_f32 v175, v70, v166 :: v_dual_lshlrev_b32 v178, 16, v167
	v_fmac_f32_e32 v176, v134, v166
	v_fmac_f32_e32 v177, v152, v166
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v174, v164, v166
	v_dual_fmac_f32 v175, v68, v178 :: v_dual_and_b32 v166, 0xffff0000, v167
	v_dual_fmac_f32 v176, v133, v178 :: v_dual_lshlrev_b32 v167, 16, v168
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v163, v178
	v_fmac_f32_e32 v176, v132, v166
	v_fmac_f32_e32 v177, v150, v178
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v162, v166
	v_dual_fmac_f32 v175, v66, v166 :: v_dual_fmac_f32 v176, v131, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v177, v148, v166 :: v_dual_and_b32 v166, 0xffff0000, v168
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v174, v161, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v65, v167
	v_fmac_f32_e32 v177, v145, v167
	v_dual_fmac_f32 v176, v130, v166 :: v_dual_lshlrev_b32 v167, 16, v169
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v174, v160, v166
	v_fmac_f32_e32 v175, v64, v166
	v_dual_fmac_f32 v177, v144, v166 :: v_dual_and_b32 v166, 0xffff0000, v169
	v_fmac_f32_e32 v176, v128, v167
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v174, v158, v167
	v_fmac_f32_e32 v175, v62, v167
	v_fmac_f32_e32 v177, v142, v167
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v167, 16, v170
	v_fmac_f32_e32 v176, v126, v166
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v174, v155, v166
	v_fmac_f32_e32 v175, v60, v166
	v_fmac_f32_e32 v177, v139, v166
	v_and_b32_e32 v166, 0xffff0000, v170
	v_fmac_f32_e32 v176, v129, v167
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v174, v159, v167
	v_fmac_f32_e32 v175, v63, v167
	v_fmac_f32_e32 v177, v143, v167
	v_dual_fmac_f32 v176, v127, v166 :: v_dual_lshlrev_b32 v167, 16, v171
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v174, v156, v166
	v_fmac_f32_e32 v175, v61, v166
	v_dual_fmac_f32 v177, v141, v166 :: v_dual_and_b32 v166, 0xffff0000, v171
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v174, v154, v167
	v_fmac_f32_e32 v175, v59, v167
	v_fmac_f32_e32 v176, v125, v167
	v_fmac_f32_e32 v177, v138, v167
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v174, v151, v166 :: v_dual_lshlrev_b32 v167, 16, v172
	v_fmac_f32_e32 v175, v58, v166
	v_fmac_f32_e32 v176, v71, v166
	v_dual_fmac_f32 v177, v137, v166 :: v_dual_and_b32 v166, 0xffff0000, v172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v175, v57, v167
	v_fmac_f32_e32 v176, v69, v167
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v177, v136, v167
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v174, v149, v167 :: v_dual_lshlrev_b32 v167, 16, v173
	v_fmac_f32_e32 v175, v56, v166
	v_fmac_f32_e32 v176, v67, v166
	v_fmac_f32_e32 v177, v135, v166
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v174, v146, v166
	v_dual_fmac_f32 v175, v55, v167 :: v_dual_and_b32 v166, 0xffff0000, v173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v176, v53, v167 :: v_dual_fmac_f32 v175, v54, v166
	v_dual_fmac_f32 v177, v51, v167 :: v_dual_fmac_f32 v176, v52, v166
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v174, v49, v167
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v95, v175, v123
	v_fmac_f32_e32 v177, v50, v166
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v174, v48, v166
	v_dual_fmac_f32 v92, v176, v147 :: v_dual_fmac_f32 v89, v177, v124
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v85, v174, v122
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_77
	s_branch .LBB90_78
.LBB90_173:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s36
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s36, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v158, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v159, null, s41, v83, vcc_lo
	s_clause 0x1
	global_load_b128 v[154:157], v[158:159], off
	global_load_b128 v[158:161], v[158:159], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v162, 16, v154
	v_and_b32_e32 v154, 0xffff0000, v154
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v163, v128, v162, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v164, v145, v162, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v141, v162, 0
	s_wait_dscnt 0xf
	v_fma_f32 v162, v153, v162, 0
	v_dual_fmac_f32 v163, v62, v154 :: v_dual_lshlrev_b32 v166, 16, v155
	v_fmac_f32_e32 v164, v122, v154
	v_fmac_f32_e32 v165, v140, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v162, v152, v154
	v_dual_fmac_f32 v163, v60, v166 :: v_dual_and_b32 v154, 0xffff0000, v155
	v_dual_fmac_f32 v164, v121, v166 :: v_dual_lshlrev_b32 v155, 16, v156
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v151, v166
	v_fmac_f32_e32 v163, v58, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v164, v71, v154
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v162, v150, v154
	v_fmac_f32_e32 v165, v138, v166
	v_fmac_f32_e32 v163, v57, v155
	v_fmac_f32_e32 v164, v70, v155
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v162, v149, v155 :: v_dual_fmac_f32 v165, v136, v154
	v_dual_fmac_f32 v165, v133, v155 :: v_dual_and_b32 v154, 0xffff0000, v156
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v164, v69, v154 :: v_dual_lshlrev_b32 v155, 16, v157
	v_fmac_f32_e32 v163, v56, v154
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v162, v148, v154
	v_dual_fmac_f32 v165, v132, v154 :: v_dual_and_b32 v154, 0xffff0000, v157
	v_fmac_f32_e32 v164, v67, v155
	v_fmac_f32_e32 v163, v54, v155
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v162, v146, v155
	v_fmac_f32_e32 v165, v130, v155
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v155, 16, v158
	v_fmac_f32_e32 v164, v65, v154
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v162, v143, v154
	v_fmac_f32_e32 v163, v52, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v165, v127, v154 :: v_dual_fmac_f32 v164, v68, v155
	v_and_b32_e32 v154, 0xffff0000, v158
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v162, v147, v155
	v_fmac_f32_e32 v163, v55, v155
	v_fmac_f32_e32 v165, v131, v155
	v_dual_fmac_f32 v164, v66, v154 :: v_dual_lshlrev_b32 v155, 16, v159
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v162, v144, v154
	v_fmac_f32_e32 v163, v53, v154
	v_dual_fmac_f32 v165, v129, v154 :: v_dual_and_b32 v154, 0xffff0000, v159
	v_fmac_f32_e32 v164, v64, v155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v163, v51, v155
	v_fmac_f32_e32 v165, v126, v155
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v162, v142, v155 :: v_dual_lshlrev_b32 v155, 16, v160
	v_fmac_f32_e32 v164, v63, v154
	v_fmac_f32_e32 v163, v50, v154
	v_fmac_f32_e32 v165, v125, v154
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v162, v139, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v163, v49, v155 :: v_dual_and_b32 v154, 0xffff0000, v160
	v_fmac_f32_e32 v164, v61, v155
	v_fmac_f32_e32 v165, v124, v155
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v162, v137, v155 :: v_dual_lshlrev_b32 v155, 16, v161
	v_fmac_f32_e32 v163, v48, v154
	v_fmac_f32_e32 v164, v59, v154
	v_fmac_f32_e32 v165, v123, v154
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v162, v134, v154
	v_dual_fmac_f32 v163, v47, v155 :: v_dual_and_b32 v154, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v43, v155
	v_fmac_f32_e32 v164, v45, v155
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v162, v41, v155 :: v_dual_fmac_f32 v163, v46, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v42, v154
	v_fmac_f32_e32 v164, v44, v154
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v162, v40, v154 :: v_dual_fmac_f32 v113, v163, v119
	v_fmac_f32_e32 v110, v165, v120
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_fmac_f32 v112, v164, v135 :: v_dual_fmac_f32 v109, v162, v118
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_81
.LBB90_174:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s34
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s34, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v158, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v159, null, s41, v83, vcc_lo
	s_clause 0x1
	global_load_b128 v[154:157], v[158:159], off
	global_load_b128 v[158:161], v[158:159], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v162, 16, v154
	v_and_b32_e32 v154, 0xffff0000, v154
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v163, v128, v162, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v164, v145, v162, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v141, v162, 0
	s_wait_dscnt 0xf
	v_fma_f32 v162, v153, v162, 0
	v_dual_fmac_f32 v163, v62, v154 :: v_dual_lshlrev_b32 v166, 16, v155
	v_fmac_f32_e32 v164, v122, v154
	v_fmac_f32_e32 v165, v140, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v162, v152, v154
	v_dual_fmac_f32 v163, v60, v166 :: v_dual_and_b32 v154, 0xffff0000, v155
	v_dual_fmac_f32 v164, v121, v166 :: v_dual_lshlrev_b32 v155, 16, v156
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v151, v166
	v_fmac_f32_e32 v163, v58, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v164, v71, v154
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v162, v150, v154
	v_fmac_f32_e32 v165, v138, v166
	v_fmac_f32_e32 v163, v57, v155
	v_fmac_f32_e32 v164, v70, v155
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v162, v149, v155 :: v_dual_fmac_f32 v165, v136, v154
	v_dual_fmac_f32 v165, v133, v155 :: v_dual_and_b32 v154, 0xffff0000, v156
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v164, v69, v154 :: v_dual_lshlrev_b32 v155, 16, v157
	v_fmac_f32_e32 v163, v56, v154
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v162, v148, v154
	v_dual_fmac_f32 v165, v132, v154 :: v_dual_and_b32 v154, 0xffff0000, v157
	v_fmac_f32_e32 v164, v67, v155
	v_fmac_f32_e32 v163, v54, v155
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v162, v146, v155
	v_fmac_f32_e32 v165, v130, v155
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v155, 16, v158
	v_fmac_f32_e32 v164, v65, v154
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v162, v143, v154
	v_fmac_f32_e32 v163, v52, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v165, v127, v154 :: v_dual_fmac_f32 v164, v68, v155
	v_and_b32_e32 v154, 0xffff0000, v158
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v162, v147, v155
	v_fmac_f32_e32 v163, v55, v155
	v_fmac_f32_e32 v165, v131, v155
	v_dual_fmac_f32 v164, v66, v154 :: v_dual_lshlrev_b32 v155, 16, v159
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v162, v144, v154
	v_fmac_f32_e32 v163, v53, v154
	v_dual_fmac_f32 v165, v129, v154 :: v_dual_and_b32 v154, 0xffff0000, v159
	v_fmac_f32_e32 v164, v64, v155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v163, v51, v155
	v_fmac_f32_e32 v165, v126, v155
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v162, v142, v155 :: v_dual_lshlrev_b32 v155, 16, v160
	v_fmac_f32_e32 v164, v63, v154
	v_fmac_f32_e32 v163, v50, v154
	v_fmac_f32_e32 v165, v125, v154
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v162, v139, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v163, v49, v155 :: v_dual_and_b32 v154, 0xffff0000, v160
	v_fmac_f32_e32 v164, v61, v155
	v_fmac_f32_e32 v165, v124, v155
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v162, v137, v155 :: v_dual_lshlrev_b32 v155, 16, v161
	v_fmac_f32_e32 v163, v48, v154
	v_fmac_f32_e32 v164, v59, v154
	v_fmac_f32_e32 v165, v123, v154
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v162, v134, v154
	v_dual_fmac_f32 v163, v47, v155 :: v_dual_and_b32 v154, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v43, v155
	v_fmac_f32_e32 v164, v45, v155
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v162, v41, v155 :: v_dual_fmac_f32 v163, v46, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v42, v154
	v_fmac_f32_e32 v164, v44, v154
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v162, v40, v154 :: v_dual_fmac_f32 v111, v163, v119
	v_fmac_f32_e32 v106, v165, v120
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v108, v164, v135
	v_fmac_f32_e32 v100, v162, v118
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_82
.LBB90_175:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s30
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s30, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v158, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v159, null, s41, v83, vcc_lo
	s_clause 0x1
	global_load_b128 v[154:157], v[158:159], off
	global_load_b128 v[158:161], v[158:159], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v162, 16, v154
	v_and_b32_e32 v154, 0xffff0000, v154
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v163, v128, v162, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v164, v145, v162, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v141, v162, 0
	s_wait_dscnt 0xf
	v_fma_f32 v162, v153, v162, 0
	v_dual_fmac_f32 v163, v62, v154 :: v_dual_lshlrev_b32 v166, 16, v155
	v_fmac_f32_e32 v164, v122, v154
	v_fmac_f32_e32 v165, v140, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v162, v152, v154
	v_dual_fmac_f32 v163, v60, v166 :: v_dual_and_b32 v154, 0xffff0000, v155
	v_dual_fmac_f32 v164, v121, v166 :: v_dual_lshlrev_b32 v155, 16, v156
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v151, v166
	v_fmac_f32_e32 v163, v58, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v164, v71, v154
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v162, v150, v154
	v_fmac_f32_e32 v165, v138, v166
	v_fmac_f32_e32 v163, v57, v155
	v_fmac_f32_e32 v164, v70, v155
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v162, v149, v155 :: v_dual_fmac_f32 v165, v136, v154
	v_dual_fmac_f32 v165, v133, v155 :: v_dual_and_b32 v154, 0xffff0000, v156
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v164, v69, v154 :: v_dual_lshlrev_b32 v155, 16, v157
	v_fmac_f32_e32 v163, v56, v154
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v162, v148, v154
	v_dual_fmac_f32 v165, v132, v154 :: v_dual_and_b32 v154, 0xffff0000, v157
	v_fmac_f32_e32 v164, v67, v155
	v_fmac_f32_e32 v163, v54, v155
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v162, v146, v155
	v_fmac_f32_e32 v165, v130, v155
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v155, 16, v158
	v_fmac_f32_e32 v164, v65, v154
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v162, v143, v154
	v_fmac_f32_e32 v163, v52, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v165, v127, v154 :: v_dual_fmac_f32 v164, v68, v155
	v_and_b32_e32 v154, 0xffff0000, v158
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v162, v147, v155
	v_fmac_f32_e32 v163, v55, v155
	v_fmac_f32_e32 v165, v131, v155
	v_dual_fmac_f32 v164, v66, v154 :: v_dual_lshlrev_b32 v155, 16, v159
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v162, v144, v154
	v_fmac_f32_e32 v163, v53, v154
	v_dual_fmac_f32 v165, v129, v154 :: v_dual_and_b32 v154, 0xffff0000, v159
	v_fmac_f32_e32 v164, v64, v155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v163, v51, v155
	v_fmac_f32_e32 v165, v126, v155
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v162, v142, v155 :: v_dual_lshlrev_b32 v155, 16, v160
	v_fmac_f32_e32 v164, v63, v154
	v_fmac_f32_e32 v163, v50, v154
	v_fmac_f32_e32 v165, v125, v154
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v162, v139, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v163, v49, v155 :: v_dual_and_b32 v154, 0xffff0000, v160
	v_fmac_f32_e32 v164, v61, v155
	v_fmac_f32_e32 v165, v124, v155
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v162, v137, v155 :: v_dual_lshlrev_b32 v155, 16, v161
	v_fmac_f32_e32 v163, v48, v154
	v_fmac_f32_e32 v164, v59, v154
	v_fmac_f32_e32 v165, v123, v154
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v162, v134, v154
	v_dual_fmac_f32 v163, v47, v155 :: v_dual_and_b32 v154, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v43, v155
	v_fmac_f32_e32 v164, v45, v155
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v162, v41, v155 :: v_dual_fmac_f32 v163, v46, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v42, v154
	v_fmac_f32_e32 v164, v44, v154
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v162, v40, v154 :: v_dual_fmac_f32 v107, v163, v119
	v_fmac_f32_e32 v103, v165, v120
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_fmac_f32 v105, v164, v135 :: v_dual_fmac_f32 v102, v162, v118
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_83
.LBB90_176:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s28
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s28, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v158, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v159, null, s41, v83, vcc_lo
	s_clause 0x1
	global_load_b128 v[154:157], v[158:159], off
	global_load_b128 v[158:161], v[158:159], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v162, 16, v154
	v_and_b32_e32 v154, 0xffff0000, v154
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v163, v128, v162, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v164, v145, v162, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v141, v162, 0
	s_wait_dscnt 0xf
	v_fma_f32 v162, v153, v162, 0
	v_dual_fmac_f32 v163, v62, v154 :: v_dual_lshlrev_b32 v166, 16, v155
	v_fmac_f32_e32 v164, v122, v154
	v_fmac_f32_e32 v165, v140, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v162, v152, v154
	v_dual_fmac_f32 v163, v60, v166 :: v_dual_and_b32 v154, 0xffff0000, v155
	v_dual_fmac_f32 v164, v121, v166 :: v_dual_lshlrev_b32 v155, 16, v156
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v151, v166
	v_fmac_f32_e32 v163, v58, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v164, v71, v154
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v162, v150, v154
	v_fmac_f32_e32 v165, v138, v166
	v_fmac_f32_e32 v163, v57, v155
	v_fmac_f32_e32 v164, v70, v155
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v162, v149, v155 :: v_dual_fmac_f32 v165, v136, v154
	v_dual_fmac_f32 v165, v133, v155 :: v_dual_and_b32 v154, 0xffff0000, v156
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v164, v69, v154 :: v_dual_lshlrev_b32 v155, 16, v157
	v_fmac_f32_e32 v163, v56, v154
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v162, v148, v154
	v_dual_fmac_f32 v165, v132, v154 :: v_dual_and_b32 v154, 0xffff0000, v157
	v_fmac_f32_e32 v164, v67, v155
	v_fmac_f32_e32 v163, v54, v155
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v162, v146, v155
	v_fmac_f32_e32 v165, v130, v155
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v155, 16, v158
	v_fmac_f32_e32 v164, v65, v154
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v162, v143, v154
	v_fmac_f32_e32 v163, v52, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v165, v127, v154 :: v_dual_fmac_f32 v164, v68, v155
	v_and_b32_e32 v154, 0xffff0000, v158
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v162, v147, v155
	v_fmac_f32_e32 v163, v55, v155
	v_fmac_f32_e32 v165, v131, v155
	v_dual_fmac_f32 v164, v66, v154 :: v_dual_lshlrev_b32 v155, 16, v159
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v162, v144, v154
	v_fmac_f32_e32 v163, v53, v154
	v_dual_fmac_f32 v165, v129, v154 :: v_dual_and_b32 v154, 0xffff0000, v159
	v_fmac_f32_e32 v164, v64, v155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v163, v51, v155
	v_fmac_f32_e32 v165, v126, v155
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v162, v142, v155 :: v_dual_lshlrev_b32 v155, 16, v160
	v_fmac_f32_e32 v164, v63, v154
	v_fmac_f32_e32 v163, v50, v154
	v_fmac_f32_e32 v165, v125, v154
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v162, v139, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v163, v49, v155 :: v_dual_and_b32 v154, 0xffff0000, v160
	v_fmac_f32_e32 v164, v61, v155
	v_fmac_f32_e32 v165, v124, v155
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v162, v137, v155 :: v_dual_lshlrev_b32 v155, 16, v161
	v_fmac_f32_e32 v163, v48, v154
	v_fmac_f32_e32 v164, v59, v154
	v_fmac_f32_e32 v165, v123, v154
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v162, v134, v154
	v_dual_fmac_f32 v163, v47, v155 :: v_dual_and_b32 v154, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v43, v155
	v_fmac_f32_e32 v164, v45, v155
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v162, v41, v155 :: v_dual_fmac_f32 v163, v46, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v42, v154
	v_fmac_f32_e32 v164, v44, v154
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v40, v154
	v_dual_fmac_f32 v104, v163, v119 :: v_dual_fmac_f32 v97, v165, v120
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v101, v164, v135
	v_fmac_f32_e32 v91, v162, v118
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_84
.LBB90_177:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s26
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s26, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v158, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v159, null, s41, v83, vcc_lo
	s_clause 0x1
	global_load_b128 v[154:157], v[158:159], off
	global_load_b128 v[158:161], v[158:159], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v162, 16, v154
	v_and_b32_e32 v154, 0xffff0000, v154
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v163, v128, v162, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v164, v145, v162, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v141, v162, 0
	s_wait_dscnt 0xf
	v_fma_f32 v162, v153, v162, 0
	v_dual_fmac_f32 v163, v62, v154 :: v_dual_lshlrev_b32 v166, 16, v155
	v_fmac_f32_e32 v164, v122, v154
	v_fmac_f32_e32 v165, v140, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v162, v152, v154
	v_dual_fmac_f32 v163, v60, v166 :: v_dual_and_b32 v154, 0xffff0000, v155
	v_dual_fmac_f32 v164, v121, v166 :: v_dual_lshlrev_b32 v155, 16, v156
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v151, v166
	v_fmac_f32_e32 v163, v58, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v164, v71, v154
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v162, v150, v154
	v_fmac_f32_e32 v165, v138, v166
	v_fmac_f32_e32 v163, v57, v155
	v_fmac_f32_e32 v164, v70, v155
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v162, v149, v155 :: v_dual_fmac_f32 v165, v136, v154
	v_dual_fmac_f32 v165, v133, v155 :: v_dual_and_b32 v154, 0xffff0000, v156
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v164, v69, v154 :: v_dual_lshlrev_b32 v155, 16, v157
	v_fmac_f32_e32 v163, v56, v154
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v162, v148, v154
	v_dual_fmac_f32 v165, v132, v154 :: v_dual_and_b32 v154, 0xffff0000, v157
	v_fmac_f32_e32 v164, v67, v155
	v_fmac_f32_e32 v163, v54, v155
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v162, v146, v155
	v_fmac_f32_e32 v165, v130, v155
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v155, 16, v158
	v_fmac_f32_e32 v164, v65, v154
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v162, v143, v154
	v_fmac_f32_e32 v163, v52, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v165, v127, v154 :: v_dual_fmac_f32 v164, v68, v155
	v_and_b32_e32 v154, 0xffff0000, v158
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v162, v147, v155
	v_fmac_f32_e32 v163, v55, v155
	v_fmac_f32_e32 v165, v131, v155
	v_dual_fmac_f32 v164, v66, v154 :: v_dual_lshlrev_b32 v155, 16, v159
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v162, v144, v154
	v_fmac_f32_e32 v163, v53, v154
	v_dual_fmac_f32 v165, v129, v154 :: v_dual_and_b32 v154, 0xffff0000, v159
	v_fmac_f32_e32 v164, v64, v155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v163, v51, v155
	v_fmac_f32_e32 v165, v126, v155
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v162, v142, v155 :: v_dual_lshlrev_b32 v155, 16, v160
	v_fmac_f32_e32 v164, v63, v154
	v_fmac_f32_e32 v163, v50, v154
	v_fmac_f32_e32 v165, v125, v154
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v162, v139, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v163, v49, v155 :: v_dual_and_b32 v154, 0xffff0000, v160
	v_fmac_f32_e32 v164, v61, v155
	v_fmac_f32_e32 v165, v124, v155
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v162, v137, v155 :: v_dual_lshlrev_b32 v155, 16, v161
	v_fmac_f32_e32 v163, v48, v154
	v_fmac_f32_e32 v164, v59, v154
	v_fmac_f32_e32 v165, v123, v154
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v162, v134, v154
	v_dual_fmac_f32 v163, v47, v155 :: v_dual_and_b32 v154, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v43, v155
	v_fmac_f32_e32 v164, v45, v155
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v162, v41, v155 :: v_dual_fmac_f32 v163, v46, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v42, v154
	v_fmac_f32_e32 v164, v44, v154
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v40, v154
	v_fmac_f32_e32 v98, v163, v119
	v_fmac_f32_e32 v94, v165, v120
	v_dual_fmac_f32 v96, v164, v135 :: v_dual_fmac_f32 v93, v162, v118
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_85
.LBB90_178:                             ;   in Loop: Header=BB90_9 Depth=1
	s_abs_i32 s14, s24
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_ashr_i32 s40, s24, 31
	s_wait_alu 0xfffe
	s_mul_i32 s42, s41, s58
	s_xor_b32 s40, s40, s60
	s_wait_alu 0xfffe
	s_sub_co_i32 s14, s14, s42
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_sub_co_i32 s43, s14, s58
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s41, s42, s41
	s_wait_alu 0xfffe
	s_cselect_b32 s14, s43, s14
	s_add_co_i32 s42, s41, 1
	s_wait_alu 0xfffe
	s_cmp_ge_u32 s14, s58
	s_cselect_b32 s14, s42, s41
	s_wait_alu 0xfffe
	s_xor_b32 s14, s14, s40
	s_wait_alu 0xfffe
	s_sub_co_i32 s40, s14, s40
	s_wait_alu 0xfffe
	s_ashr_i32 s41, s40, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[40:41], s[40:41], s[18:19]
	s_wait_alu 0xfffe
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v158, vcc_lo, v82, s40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v159, null, s41, v83, vcc_lo
	s_clause 0x1
	global_load_b128 v[154:157], v[158:159], off
	global_load_b128 v[158:161], v[158:159], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v162, 16, v154
	v_and_b32_e32 v154, 0xffff0000, v154
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v163, v128, v162, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v164, v145, v162, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v165, v141, v162, 0
	s_wait_dscnt 0xf
	v_fma_f32 v162, v153, v162, 0
	v_dual_fmac_f32 v163, v62, v154 :: v_dual_lshlrev_b32 v166, 16, v155
	v_fmac_f32_e32 v164, v122, v154
	v_fmac_f32_e32 v165, v140, v154
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v162, v152, v154
	v_dual_fmac_f32 v163, v60, v166 :: v_dual_and_b32 v154, 0xffff0000, v155
	v_dual_fmac_f32 v164, v121, v166 :: v_dual_lshlrev_b32 v155, 16, v156
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v162, v151, v166
	v_fmac_f32_e32 v163, v58, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v164, v71, v154
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v162, v150, v154
	v_fmac_f32_e32 v165, v138, v166
	v_fmac_f32_e32 v163, v57, v155
	v_fmac_f32_e32 v164, v70, v155
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v162, v149, v155 :: v_dual_fmac_f32 v165, v136, v154
	v_dual_fmac_f32 v165, v133, v155 :: v_dual_and_b32 v154, 0xffff0000, v156
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v164, v69, v154 :: v_dual_lshlrev_b32 v155, 16, v157
	v_fmac_f32_e32 v163, v56, v154
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v162, v148, v154
	v_dual_fmac_f32 v165, v132, v154 :: v_dual_and_b32 v154, 0xffff0000, v157
	v_fmac_f32_e32 v164, v67, v155
	v_fmac_f32_e32 v163, v54, v155
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v162, v146, v155
	v_fmac_f32_e32 v165, v130, v155
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v155, 16, v158
	v_fmac_f32_e32 v164, v65, v154
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v162, v143, v154
	v_fmac_f32_e32 v163, v52, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v165, v127, v154 :: v_dual_fmac_f32 v164, v68, v155
	v_and_b32_e32 v154, 0xffff0000, v158
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v162, v147, v155
	v_fmac_f32_e32 v163, v55, v155
	v_fmac_f32_e32 v165, v131, v155
	v_dual_fmac_f32 v164, v66, v154 :: v_dual_lshlrev_b32 v155, 16, v159
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v162, v144, v154
	v_fmac_f32_e32 v163, v53, v154
	v_dual_fmac_f32 v165, v129, v154 :: v_dual_and_b32 v154, 0xffff0000, v159
	v_fmac_f32_e32 v164, v64, v155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v163, v51, v155
	v_fmac_f32_e32 v165, v126, v155
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v162, v142, v155 :: v_dual_lshlrev_b32 v155, 16, v160
	v_fmac_f32_e32 v164, v63, v154
	v_fmac_f32_e32 v163, v50, v154
	v_fmac_f32_e32 v165, v125, v154
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v162, v139, v154
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v163, v49, v155 :: v_dual_and_b32 v154, 0xffff0000, v160
	v_fmac_f32_e32 v164, v61, v155
	v_fmac_f32_e32 v165, v124, v155
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v162, v137, v155 :: v_dual_lshlrev_b32 v155, 16, v161
	v_fmac_f32_e32 v163, v48, v154
	v_fmac_f32_e32 v164, v59, v154
	v_fmac_f32_e32 v165, v123, v154
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v162, v134, v154
	v_dual_fmac_f32 v163, v47, v155 :: v_dual_and_b32 v154, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v43, v155
	v_fmac_f32_e32 v164, v45, v155
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v162, v41, v155 :: v_dual_fmac_f32 v163, v46, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v165, v42, v154
	v_fmac_f32_e32 v164, v44, v154
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v162, v40, v154 :: v_dual_fmac_f32 v95, v163, v119
	v_dual_fmac_f32 v89, v165, v120 :: v_dual_fmac_f32 v92, v164, v135
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v85, v162, v118
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB90_86
	s_branch .LBB90_87
.LBB90_179:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v43, v44, v43, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v43, 16, v43
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_160
.LBB90_180:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v43, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v43
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_186
.LBB90_181:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v43
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s37, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s37, exec_lo, s37
; %bb.182:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.183:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s37, s37
; %bb.184:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.185:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s37
	s_ashr_i32 s37, s36, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[38:39], s[36:37], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v43, vcc_lo, v73, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v44, null, s39, v74, vcc_lo
	global_store_b16 v[43:44], v42, off
.LBB90_186:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v110
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v110, v42
	ds_bpermute_b32 v43, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, s12, v42
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.187:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.188:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.189:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.190:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v5, v109
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v109, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v40, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v41, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.191:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.192:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.193:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.194:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v6, 16, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_198
; %bb.195:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_199
.LBB90_196:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execnz .LBB90_200
.LBB90_197:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_145
	s_branch .LBB90_205
.LBB90_198:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_196
.LBB90_199:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_197
.LBB90_200:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s37, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s37, exec_lo, s37
; %bb.201:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.202:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s37, s37
; %bb.203:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.204:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s37
	s_ashr_i32 s37, s36, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[36:37], s[36:37], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[36:37], s[36:37], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s36
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s37, v74, vcc_lo
	global_store_b16 v[6:7], v5, off offset:2
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_145
.LBB90_205:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v7, v5, v111
	s_wait_loadcnt_dscnt 0x200
	s_wait_alu 0xfffd
	v_dual_add_f32 v40, v111, v7 :: v_dual_cndmask_b32 v7, v84, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	ds_bpermute_b32 v41, v6, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v41, v40, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v40, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v42, v7, v41
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v41, v42
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v42, v42, v43 :: v_dual_cndmask_b32 v41, v84, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v41, 2, v41
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_wait_kmcnt 0x0
	v_mul_f32_e32 v42, s12, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v42
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.206:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v42, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v42, v43, 0x7fff
	v_lshrrev_b32_e32 v43, 16, v42
                                        ; implicit-def: $vgpr42
; %bb.207:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.208:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v42
; %bb.209:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v108
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v108, v42
	ds_bpermute_b32 v44, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, s13, v42
	v_and_b32_e32 v42, 0x7fffffff, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.210:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v44, v42, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.211:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.212:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.213:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43
	v_fma_f32 v45, 0xbfb8aa3b, v43, -v44
	v_rndne_f32_e32 v46, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v44, v44, v46
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43
	v_fmac_f32_e32 v45, 0xb2a5705f, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v44, v44, v45
	v_cvt_i32_f32_e32 v45, v46
	v_exp_f32_e32 v44, v44
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v44, v44, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo
	v_add_f32_e32 v44, 1.0, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v45, null, v44, v44, v43
	v_rcp_f32_e32 v46, v45
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v47, -v45, v46, 1.0
	v_fmac_f32_e32 v46, v47, v46
	v_div_scale_f32 v47, vcc_lo, v43, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v48, v47, v46
	v_fma_f32 v49, -v45, v48, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v48, v49, v46
	v_fma_f32 v45, -v45, v48, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v45, v45, v46, v48
	v_div_fixup_f32 v44, v45, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v44
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_216
; %bb.214:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_217
.LBB90_215:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_218
	s_branch .LBB90_223
.LBB90_216:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v43, v44, v43, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v43, 16, v43
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_215
.LBB90_217:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v43, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v43
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_223
.LBB90_218:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v43
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s35, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s35, exec_lo, s35
; %bb.219:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.220:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s35, s35
; %bb.221:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.222:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s35
	s_ashr_i32 s35, s34, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[36:37], s[34:35], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[36:37], s[36:37], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v43, vcc_lo, v73, s36
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v44, null, s37, v74, vcc_lo
	global_store_b16 v[43:44], v42, off
.LBB90_223:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v106
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v106, v42
	ds_bpermute_b32 v43, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, s12, v42
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.224:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.225:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.226:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.227:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v5, v100
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v100, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v40, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v41, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.228:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.229:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.230:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.231:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v6, 16, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_235
; %bb.232:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_236
.LBB90_233:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execnz .LBB90_237
.LBB90_234:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_146
	s_branch .LBB90_242
.LBB90_235:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_233
.LBB90_236:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_234
.LBB90_237:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s35, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s35, exec_lo, s35
; %bb.238:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.239:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s35, s35
; %bb.240:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.241:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s35
	s_ashr_i32 s35, s34, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[34:35], s[34:35], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[34:35], s[34:35], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s34
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s35, v74, vcc_lo
	global_store_b16 v[6:7], v5, off offset:2
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s31
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_146
.LBB90_242:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v7, v5, v107
	s_wait_loadcnt_dscnt 0x200
	s_wait_alu 0xfffd
	v_dual_add_f32 v40, v107, v7 :: v_dual_cndmask_b32 v7, v84, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	ds_bpermute_b32 v41, v6, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v41, v40, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v40, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v42, v7, v41
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v41, v42
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v42, v42, v43 :: v_dual_cndmask_b32 v41, v84, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v41, 2, v41
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_wait_kmcnt 0x0
	v_mul_f32_e32 v42, s12, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v42
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.243:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v42, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v42, v43, 0x7fff
	v_lshrrev_b32_e32 v43, 16, v42
                                        ; implicit-def: $vgpr42
; %bb.244:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.245:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v42
; %bb.246:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v105
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v105, v42
	ds_bpermute_b32 v44, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, s13, v42
	v_and_b32_e32 v42, 0x7fffffff, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.247:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v44, v42, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.248:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.249:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.250:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43
	v_fma_f32 v45, 0xbfb8aa3b, v43, -v44
	v_rndne_f32_e32 v46, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v44, v44, v46
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43
	v_fmac_f32_e32 v45, 0xb2a5705f, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v44, v44, v45
	v_cvt_i32_f32_e32 v45, v46
	v_exp_f32_e32 v44, v44
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v44, v44, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo
	v_add_f32_e32 v44, 1.0, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v45, null, v44, v44, v43
	v_rcp_f32_e32 v46, v45
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v47, -v45, v46, 1.0
	v_fmac_f32_e32 v46, v47, v46
	v_div_scale_f32 v47, vcc_lo, v43, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v48, v47, v46
	v_fma_f32 v49, -v45, v48, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v48, v49, v46
	v_fma_f32 v45, -v45, v48, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v45, v45, v46, v48
	v_div_fixup_f32 v44, v45, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v44
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_253
; %bb.251:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_254
.LBB90_252:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_255
	s_branch .LBB90_260
.LBB90_253:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v43, v44, v43, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v43, 16, v43
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_252
.LBB90_254:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v43, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v43
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_260
.LBB90_255:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v43
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s31, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s31, exec_lo, s31
; %bb.256:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.257:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s31, s31
; %bb.258:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.259:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s31
	s_ashr_i32 s31, s30, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[34:35], s[30:31], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[34:35], s[34:35], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v43, vcc_lo, v73, s34
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v44, null, s35, v74, vcc_lo
	global_store_b16 v[43:44], v42, off
.LBB90_260:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v103
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v103, v42
	ds_bpermute_b32 v43, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, s12, v42
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.261:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.262:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.263:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.264:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v5, v102
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v102, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v40, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v41, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.265:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.266:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.267:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.268:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v6, 16, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_272
; %bb.269:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_273
.LBB90_270:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execnz .LBB90_274
.LBB90_271:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_147
	s_branch .LBB90_279
.LBB90_272:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_270
.LBB90_273:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_271
.LBB90_274:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s31, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s31, exec_lo, s31
; %bb.275:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.276:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s31, s31
; %bb.277:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.278:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s31
	s_ashr_i32 s31, s30, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[30:31], s[30:31], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[30:31], s[30:31], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s30
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s31, v74, vcc_lo
	global_store_b16 v[6:7], v5, off offset:2
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s29
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_147
.LBB90_279:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v7, v5, v104
	s_wait_loadcnt_dscnt 0x200
	v_add_f32_e32 v40, v104, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v84, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	ds_bpermute_b32 v41, v6, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v41, v40, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v40, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v42, v7, v41
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v41, v42
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v42, v42, v43 :: v_dual_cndmask_b32 v41, v84, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v41, 2, v41
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_wait_kmcnt 0x0
	v_mul_f32_e32 v42, s12, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v42
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.280:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v42, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v42, v43, 0x7fff
	v_lshrrev_b32_e32 v43, 16, v42
                                        ; implicit-def: $vgpr42
; %bb.281:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.282:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v42
; %bb.283:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v101
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v101, v42
	ds_bpermute_b32 v44, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, s13, v42
	v_and_b32_e32 v42, 0x7fffffff, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.284:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v44, v42, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.285:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.286:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.287:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43
	v_fma_f32 v45, 0xbfb8aa3b, v43, -v44
	v_rndne_f32_e32 v46, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v44, v44, v46
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43
	v_fmac_f32_e32 v45, 0xb2a5705f, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v44, v44, v45
	v_cvt_i32_f32_e32 v45, v46
	v_exp_f32_e32 v44, v44
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v44, v44, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo
	v_add_f32_e32 v44, 1.0, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v45, null, v44, v44, v43
	v_rcp_f32_e32 v46, v45
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v47, -v45, v46, 1.0
	v_fmac_f32_e32 v46, v47, v46
	v_div_scale_f32 v47, vcc_lo, v43, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v48, v47, v46
	v_fma_f32 v49, -v45, v48, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v48, v49, v46
	v_fma_f32 v45, -v45, v48, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v45, v45, v46, v48
	v_div_fixup_f32 v44, v45, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v44
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_290
; %bb.288:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_291
.LBB90_289:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_292
	s_branch .LBB90_297
.LBB90_290:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v43, v44, v43, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v43, 16, v43
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_289
.LBB90_291:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v43, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v43
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_297
.LBB90_292:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v43
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s29, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s29, exec_lo, s29
; %bb.293:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.294:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s29, s29
; %bb.295:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.296:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s29
	s_ashr_i32 s29, s28, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[30:31], s[28:29], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[30:31], s[30:31], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v43, vcc_lo, v73, s30
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v44, null, s31, v74, vcc_lo
	global_store_b16 v[43:44], v42, off
.LBB90_297:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v97
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v97, v42
	ds_bpermute_b32 v43, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, s12, v42
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.298:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.299:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.300:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.301:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v5, v91
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v91, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v40, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v41, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.302:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.303:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.304:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.305:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v6, 16, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_309
; %bb.306:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_310
.LBB90_307:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execnz .LBB90_311
.LBB90_308:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_148
	s_branch .LBB90_316
.LBB90_309:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_307
.LBB90_310:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_308
.LBB90_311:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s29, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s29, exec_lo, s29
; %bb.312:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.313:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s29, s29
; %bb.314:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.315:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s29
	s_ashr_i32 s29, s28, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[28:29], s[28:29], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[28:29], s[28:29], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s28
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s29, v74, vcc_lo
	global_store_b16 v[6:7], v5, off offset:2
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s27
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_148
.LBB90_316:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v7, v5, v98
	s_wait_loadcnt_dscnt 0x200
	s_wait_alu 0xfffd
	v_dual_add_f32 v40, v98, v7 :: v_dual_cndmask_b32 v7, v84, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	ds_bpermute_b32 v41, v6, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v41, v40, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v40, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v42, v7, v41
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v41, v42
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v42, v42, v43 :: v_dual_cndmask_b32 v41, v84, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v41, 2, v41
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_wait_kmcnt 0x0
	v_mul_f32_e32 v42, s12, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v42
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.317:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v42, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v42, v43, 0x7fff
	v_lshrrev_b32_e32 v43, 16, v42
                                        ; implicit-def: $vgpr42
; %bb.318:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.319:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v42
; %bb.320:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v96
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v96, v42
	ds_bpermute_b32 v44, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, s13, v42
	v_and_b32_e32 v42, 0x7fffffff, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.321:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v44, v42, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.322:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.323:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.324:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43
	v_fma_f32 v45, 0xbfb8aa3b, v43, -v44
	v_rndne_f32_e32 v46, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v44, v44, v46
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43
	v_fmac_f32_e32 v45, 0xb2a5705f, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v44, v44, v45
	v_cvt_i32_f32_e32 v45, v46
	v_exp_f32_e32 v44, v44
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v44, v44, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo
	v_add_f32_e32 v44, 1.0, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v45, null, v44, v44, v43
	v_rcp_f32_e32 v46, v45
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v47, -v45, v46, 1.0
	v_fmac_f32_e32 v46, v47, v46
	v_div_scale_f32 v47, vcc_lo, v43, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v48, v47, v46
	v_fma_f32 v49, -v45, v48, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v48, v49, v46
	v_fma_f32 v45, -v45, v48, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v45, v45, v46, v48
	v_div_fixup_f32 v44, v45, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v44
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_327
; %bb.325:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_328
.LBB90_326:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_329
	s_branch .LBB90_334
.LBB90_327:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v43, v44, v43, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v43, 16, v43
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_326
.LBB90_328:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v43, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v43
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_334
.LBB90_329:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v43
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s27, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s27, exec_lo, s27
; %bb.330:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.331:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s27, s27
; %bb.332:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.333:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s27
	s_ashr_i32 s27, s26, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[28:29], s[26:27], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[28:29], s[28:29], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v43, vcc_lo, v73, s28
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v44, null, s29, v74, vcc_lo
	global_store_b16 v[43:44], v42, off
.LBB90_334:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v94
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v94, v42
	ds_bpermute_b32 v43, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, s12, v42
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.335:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.336:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.337:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.338:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v5, v93
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v93, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v40, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v41, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.339:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.340:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.341:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.342:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v6, 16, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_346
; %bb.343:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_347
.LBB90_344:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execnz .LBB90_348
.LBB90_345:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_149
	s_branch .LBB90_353
.LBB90_346:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_344
.LBB90_347:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_345
.LBB90_348:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s27, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s27, exec_lo, s27
; %bb.349:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.350:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s27, s27
; %bb.351:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.352:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s27
	s_ashr_i32 s27, s26, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[26:27], s[26:27], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[26:27], s[26:27], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s26
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s27, v74, vcc_lo
	global_store_b16 v[6:7], v5, off offset:2
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_149
.LBB90_353:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v6, 2, v6
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v7, v5, v95
	s_wait_loadcnt_dscnt 0x200
	s_wait_alu 0xfffd
	v_dual_add_f32 v40, v95, v7 :: v_dual_cndmask_b32 v7, v84, v2
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	ds_bpermute_b32 v41, v6, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v41, v40, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v40, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v42, v7, v41
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v41, v42
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v42, v42, v43 :: v_dual_cndmask_b32 v41, v84, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_lshlrev_b32_e32 v41, 2, v41
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_wait_kmcnt 0x0
	v_mul_f32_e32 v42, s12, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v42
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.354:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v42, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v42, v43, 0x7fff
	v_lshrrev_b32_e32 v43, 16, v42
                                        ; implicit-def: $vgpr42
; %bb.355:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.356:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v42
; %bb.357:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v92
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v92, v42
	ds_bpermute_b32 v44, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	ds_bpermute_b32 v44, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, s13, v42
	v_and_b32_e32 v42, 0x7fffffff, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.358:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v44, v42, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.359:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.360:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.361:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43
	v_fma_f32 v45, 0xbfb8aa3b, v43, -v44
	v_rndne_f32_e32 v46, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v44, v44, v46
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43
	v_fmac_f32_e32 v45, 0xb2a5705f, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v44, v44, v45
	v_cvt_i32_f32_e32 v45, v46
	v_exp_f32_e32 v44, v44
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v44, v44, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo
	v_add_f32_e32 v44, 1.0, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v45, null, v44, v44, v43
	v_rcp_f32_e32 v46, v45
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v47, -v45, v46, 1.0
	v_fmac_f32_e32 v46, v47, v46
	v_div_scale_f32 v47, vcc_lo, v43, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v48, v47, v46
	v_fma_f32 v49, -v45, v48, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v48, v49, v46
	v_fma_f32 v45, -v45, v48, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v45, v45, v46, v48
	v_div_fixup_f32 v44, v45, v44, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v43, 0x7fffffff, v44
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v43
                                        ; implicit-def: $vgpr43
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_364
; %bb.362:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_365
.LBB90_363:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_366
	s_branch .LBB90_371
.LBB90_364:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v43, v44, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v43, v44, v43, 0x7fff
                                        ; implicit-def: $vgpr44
	v_lshrrev_b32_e32 v43, 16, v43
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_363
.LBB90_365:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v43, 16, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v43, 64, v43
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_371
.LBB90_366:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshlrev_b32_e32 v43, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v43
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s25, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s25, exec_lo, s25
; %bb.367:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.368:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s25, s25
; %bb.369:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.370:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s25
	s_ashr_i32 s25, s24, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[26:27], s[24:25], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[26:27], s[26:27], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v43, vcc_lo, v73, s26
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v44, null, s27, v74, vcc_lo
	global_store_b16 v[43:44], v42, off
.LBB90_371:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v42, v5, v89
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v89, v42
	ds_bpermute_b32 v43, v6, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v7, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v40, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	ds_bpermute_b32 v43, v41, v42
	s_wait_dscnt 0x0
	v_add_f32_e32 v42, v42, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, s12, v42
	v_and_b32_e32 v42, 0x7fffffff, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v42
                                        ; implicit-def: $vgpr42
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.372:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v42, v43, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v42, v43, v42, 0x7fff
                                        ; implicit-def: $vgpr43
	v_lshrrev_b32_e32 v42, 16, v42
; %bb.373:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.374:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v42, 16, v43
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v42, 64, v42
; %bb.375:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v5, v85
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v85, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v40, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v41, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
; %bb.376:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.377:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
; %bb.378:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.379:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_lshlrev_b32_e32 v6, 16, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s14, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s14, exec_lo, s14
	s_cbranch_execnz .LBB90_383
; %bb.380:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execnz .LBB90_384
.LBB90_381:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execnz .LBB90_385
.LBB90_382:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_8
	s_branch .LBB90_390
.LBB90_383:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s14, s14
	s_cbranch_execz .LBB90_381
.LBB90_384:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_382
.LBB90_385:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s25, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s25, exec_lo, s25
; %bb.386:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.387:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s25, s25
; %bb.388:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.389:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s25
	s_ashr_i32 s25, s24, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[24:25], s[24:25], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s24
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s25, v74, vcc_lo
	global_store_b16 v[6:7], v5, off offset:2
	s_or_b32 exec_lo, exec_lo, s14
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB90_8
.LBB90_390:                             ;   in Loop: Header=BB90_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v84, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v84, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v84, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v84, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v1, 2, v1
	v_lshlrev_b32_e32 v2, 2, v2
	v_lshlrev_b32_e32 v3, 2, v3
	v_lshlrev_b32_e32 v4, 2, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, v84, v0, vcc_lo
	ds_bpermute_b32 v5, v4, v90
	s_wait_dscnt 0x0
	v_dual_add_f32 v5, v90, v5 :: v_dual_lshlrev_b32 v0, 2, v0
	ds_bpermute_b32 v6, v3, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v2, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v1, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v0, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v5, s12, v5
	v_and_b32_e32 v6, 0x7fffffff, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
; %bb.391:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v5, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v5, v6, 0x7fff
	v_lshrrev_b32_e32 v6, 16, v5
                                        ; implicit-def: $vgpr5
; %bb.392:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
; %bb.393:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v5
; %bb.394:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	ds_bpermute_b32 v5, v4, v88
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v88, v5
	ds_bpermute_b32 v7, v3, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v7
	ds_bpermute_b32 v7, v2, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v7
	ds_bpermute_b32 v7, v1, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v7
	ds_bpermute_b32 v7, v0, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, s13, v5
	v_and_b32_e32 v5, 0x7fffffff, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
; %bb.395:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v7, v5, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.396:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
; %bb.397:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.398:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v6
	s_wait_loadcnt 0x2
	v_fma_f32 v40, 0xbfb8aa3b, v6, -v7
	v_rndne_f32_e32 v41, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v7, v7, v41
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v6
	v_fmac_f32_e32 v40, 0xb2a5705f, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v7, v7, v40
	v_cvt_i32_f32_e32 v40, v41
	v_exp_f32_e32 v7, v7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v7, v7, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v7, 0x7f800000, v7, vcc_lo
	v_add_f32_e32 v7, 1.0, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v40, null, v7, v7, v6
	v_rcp_f32_e32 v41, v40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v42, -v40, v41, 1.0
	v_fmac_f32_e32 v41, v42, v41
	v_div_scale_f32 v42, vcc_lo, v6, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v43, v42, v41
	v_fma_f32 v44, -v40, v43, v42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v44, v41
	v_fma_f32 v40, -v40, v43, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v40, v40, v41, v43
	v_div_fixup_f32 v7, v40, v7, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v6, 0x7fffffff, v7
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
	s_cbranch_execnz .LBB90_401
; %bb.399:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
	s_cbranch_execnz .LBB90_402
.LBB90_400:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	s_and_saveexec_b32 s14, s1
	s_cbranch_execnz .LBB90_403
	s_branch .LBB90_408
.LBB90_401:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v6, v7, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v7, v6, 0x7fff
                                        ; implicit-def: $vgpr7
	v_lshrrev_b32_e32 v6, 16, v6
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
	s_cbranch_execz .LBB90_400
.LBB90_402:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v7
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	s_and_saveexec_b32 s14, s1
	s_cbranch_execz .LBB90_408
.LBB90_403:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v5, 16, v5
	v_lshlrev_b32_e32 v6, 16, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v6
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
; %bb.404:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.405:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
; %bb.406:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.407:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	s_ashr_i32 s11, s10, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[24:25], s[10:11], s[20:21]
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v6, vcc_lo, v73, s24
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v7, null, s25, v74, vcc_lo
	global_store_b16 v[6:7], v5, off
.LBB90_408:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	ds_bpermute_b32 v5, v4, v87
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v87, v5
	ds_bpermute_b32 v6, v3, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v2, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v1, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v0, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s12, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
; %bb.409:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.410:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
; %bb.411:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.412:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	ds_bpermute_b32 v4, v4, v86
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v86, v4
	ds_bpermute_b32 v3, v3, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v4, v3
	ds_bpermute_b32 v2, v2, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v3, v2
	ds_bpermute_b32 v1, v1, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v2, v1
	ds_bpermute_b32 v0, v0, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v1, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v1, s13, v0
	v_and_b32_e32 v0, 0x7fffffff, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
; %bb.413:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v0, v1, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v1, v0, 0x7fff
                                        ; implicit-def: $vgpr1
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.414:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
; %bb.415:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v0, 16, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.416:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	v_lshlrev_b32_e32 v1, 16, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1
	v_fma_f32 v3, 0xbfb8aa3b, v1, -v2
	v_rndne_f32_e32 v4, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v2, v2, v4
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v1
	v_fmac_f32_e32 v3, 0xb2a5705f, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v2, v2, v3
	v_cvt_i32_f32_e32 v3, v4
	v_exp_f32_e32 v2, v2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v2, v2, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v2, 0x7f800000, v2, vcc_lo
	v_add_f32_e32 v2, 1.0, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v3, null, v2, v2, v1
	v_rcp_f32_e32 v4, v3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, -v3, v4, 1.0
	v_fmac_f32_e32 v4, v5, v4
	v_div_scale_f32 v5, vcc_lo, v1, v2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, v5, v4
	v_fma_f32 v7, -v3, v6, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v6, v7, v4
	v_fma_f32 v3, -v3, v6, v5
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v3, v3, v4, v6
	v_div_fixup_f32 v2, v3, v2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
	s_cbranch_execnz .LBB90_419
; %bb.417:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
	s_cbranch_execnz .LBB90_420
.LBB90_418:                             ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_7
	s_branch .LBB90_421
.LBB90_419:                             ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
	s_cbranch_execz .LBB90_418
.LBB90_420:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	s_and_saveexec_b32 s14, s59
	s_cbranch_execz .LBB90_7
.LBB90_421:                             ;   in Loop: Header=BB90_9 Depth=1
	v_lshlrev_b32_e32 v0, 16, v0
	v_lshlrev_b32_e32 v1, 16, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v1, v0, v1
	v_and_b32_e32 v0, 0x7fffffff, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
; %bb.422:                              ;   in Loop: Header=BB90_9 Depth=1
	v_bfe_u32 v0, v1, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v1, v0, 0x7fff
                                        ; implicit-def: $vgpr1
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.423:                              ;   in Loop: Header=BB90_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
	s_cbranch_execz .LBB90_6
; %bb.424:                              ;   in Loop: Header=BB90_9 Depth=1
	v_lshrrev_b32_e32 v0, 16, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
	s_branch .LBB90_6
.LBB90_425:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_121moe_gate_up_g2_kernelILi2EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iiii
		.amdhsa_group_segment_fixed_size 64
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 80
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 213
		.amdhsa_next_free_sgpr 64
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 255
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_121moe_gate_up_g2_kernelILi2EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iiii,"axG",@progbits,_ZN12_GLOBAL__N_121moe_gate_up_g2_kernelILi2EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iiii,comdat
.Lfunc_end90:
