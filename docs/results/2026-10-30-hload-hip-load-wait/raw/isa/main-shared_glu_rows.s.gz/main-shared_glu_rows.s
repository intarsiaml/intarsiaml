_ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili: ; @_ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili
; %bb.0:
	s_load_b96 s[20:22], s[0:1], 0x48
	v_lshrrev_b32_e32 v1, 5, v0
	s_mov_b32 s2, ttmp9
	s_mov_b32 s3, 0
	v_and_b32_e32 v23, 31, v0
	s_lshl_b64 s[2:3], s[2:3], 3
	s_clause 0x1
	s_load_b128 s[12:15], s[0:1], 0x8
	s_load_b128 s[16:19], s[0:1], 0x20
	v_mov_b32_e32 v2, s3
	v_or_b32_e32 v1, s2, v1
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v22, 0
	v_mov_b32_e32 v21, 0
	v_lshlrev_b32_e32 v31, 3, v23
	v_mov_b32_e32 v41, 0
	s_wait_kmcnt 0x0
	v_cmp_gt_i64_e64 s5, s[20:21], v[1:2]
	s_lshr_b32 s2, s22, 31
	s_ashr_i32 s35, s22, 31
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s22, s2
	s_lshr_b32 s4, s35, 28
	s_wait_alu 0xfffe
	s_ashr_i32 s2, s2, 1
	v_cndmask_b32_e64 v7, 0, v1, s5
	v_cndmask_b32_e64 v8, 0, s3, s5
	s_add_co_i32 s4, s22, s4
	s_wait_alu 0xfffe
	s_ashr_i32 s3, s2, 31
	s_ashr_i32 s43, s4, 4
	v_mad_co_u64_u32 v[5:6], null, v7, s2, 0
	s_wait_alu 0xfffe
	v_mul_lo_u32 v9, v7, s3
	s_ashr_i32 s3, s43, 31
	v_mul_lo_u32 v10, v8, s2
	v_mad_co_u64_u32 v[3:4], null, v7, s43, 0
	s_wait_alu 0xfffe
	v_mul_lo_u32 v7, v7, s3
	v_mul_lo_u32 v8, v8, s43
	v_add_co_u32 v27, s2, s12, v5
	v_cmp_gt_i32_e32 vcc_lo, s43, v23
	v_add3_u32 v6, v6, v9, v10
	s_mov_b32 s34, s22
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add3_u32 v4, v4, v7, v8
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v28, null, s13, v6, s2
	v_add_co_u32 v8, s2, s14, v3
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v24, null, s15, v4, s2
	s_and_saveexec_b32 s3, vcc_lo
	s_cbranch_execz .LBB0_2
; %bb.1:
	v_add_co_u32 v9, s2, v27, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v28, s2
	v_add_co_u32 v11, s2, v8, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v24, s2
	global_load_b64 v[21:22], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v41, v[11:12], off
.LBB0_2:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_add_co_u32 v29, s2, s16, v5
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v30, null, s17, v6, s2
	v_add_co_u32 v25, s2, s18, v3
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v26, null, s19, v4, s2
	v_mov_b32_e32 v20, 0
	v_mov_b32_e32 v54, 0
	s_and_saveexec_b32 s3, vcc_lo
	s_cbranch_execz .LBB0_4
; %bb.3:
	v_add_co_u32 v9, s2, v29, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v30, s2
	v_add_co_u32 v11, s2, v25, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v26, s2
	global_load_b64 v[19:20], v[9:10], off th:TH_LOAD_NT
	global_load_u8 v54, v[11:12], off
.LBB0_4:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_or_b32_e32 v38, 32, v23
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0
	v_mov_b32_e32 v17, 0
	v_mov_b32_e32 v39, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e64 s4, s43, v38
	s_and_saveexec_b32 s3, s4
	s_cbranch_execz .LBB0_6
; %bb.5:
	v_add_co_u32 v9, s2, v27, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v28, s2
	v_add_co_u32 v11, s2, v8, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v24, s2
	global_load_b64 v[17:18], v[9:10], off offset:256 th:TH_LOAD_NT
	global_load_u8 v39, v[11:12], off offset:32
.LBB0_6:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_mov_b32_e32 v16, 0
	v_mov_b32_e32 v40, 0
	s_and_saveexec_b32 s3, s4
	s_cbranch_execz .LBB0_8
; %bb.7:
	v_add_co_u32 v9, s2, v29, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v30, s2
	v_add_co_u32 v11, s2, v25, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v12, null, 0, v26, s2
	global_load_b64 v[15:16], v[9:10], off offset:256 th:TH_LOAD_NT
	global_load_u8 v40, v[11:12], off offset:32
.LBB0_8:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_or_b32_e32 v35, 64, v23
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v14, 0
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v36, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s3, s43, v35
	s_and_saveexec_b32 s6, s3
	s_cbranch_execz .LBB0_10
; %bb.9:
	v_add_co_u32 v9, s2, v27, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v28, s2
	v_add_co_u32 v32, s2, v8, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v33, null, 0, v24, s2
	global_load_b64 v[13:14], v[9:10], off offset:512 th:TH_LOAD_NT
	global_load_u8 v36, v[32:33], off offset:64
.LBB0_10:
	s_or_b32 exec_lo, exec_lo, s6
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v37, 0
	s_and_saveexec_b32 s6, s3
	s_cbranch_execz .LBB0_12
; %bb.11:
	v_add_co_u32 v9, s2, v29, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v30, s2
	v_add_co_u32 v32, s2, v25, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v33, null, 0, v26, s2
	global_load_b64 v[11:12], v[9:10], off offset:512 th:TH_LOAD_NT
	global_load_u8 v37, v[32:33], off offset:64
.LBB0_12:
	s_or_b32 exec_lo, exec_lo, s6
	v_or_b32_e32 v32, 0x60, v23
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v10, 0
	v_mov_b32_e32 v9, 0
	v_mov_b32_e32 v33, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e64 s2, s43, v32
	s_and_saveexec_b32 s7, s2
	s_cbranch_execz .LBB0_14
; %bb.13:
	v_add_co_u32 v9, s6, v27, v31
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v10, null, 0, v28, s6
	v_add_co_u32 v27, s6, v8, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v28, null, 0, v24, s6
	global_load_b64 v[9:10], v[9:10], off offset:768 th:TH_LOAD_NT
	global_load_u8 v33, v[27:28], off offset:96
.LBB0_14:
	s_or_b32 exec_lo, exec_lo, s7
	v_mov_b32_e32 v8, 0
	v_mov_b32_e32 v34, 0
	s_and_saveexec_b32 s7, s2
	s_cbranch_execz .LBB0_16
; %bb.15:
	v_add_co_u32 v7, s6, v29, v31
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v8, null, 0, v30, s6
	v_add_co_u32 v24, s6, v25, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v25, null, 0, v26, s6
	global_load_b64 v[7:8], v[7:8], off offset:768 th:TH_LOAD_NT
	global_load_u8 v34, v[24:25], off offset:96
.LBB0_16:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s7, exec_lo
	v_cmpx_gt_u32_e32 16, v0
	s_cbranch_execz .LBB0_18
; %bb.17:
	v_and_b32_e32 v24, 7, v0
	v_lshlrev_b32_e32 v26, 28, v0
	v_lshlrev_b32_e32 v0, 2, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_lshl_add_u32 v25, v24, 22, 0.5
	v_cmp_ne_u32_e64 s6, 1, v24
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v25, 0.5, v25, s6
	v_cmp_ne_u32_e64 s6, 0, v24
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v24, 0, v25, s6
	v_and_or_b32 v24, 0x80000000, v26, v24
	ds_store_b32 v0, v24
.LBB0_18:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s6, s5
	s_cbranch_execz .LBB0_62
; %bb.19:
	s_clause 0x1
	s_load_b32 s5, s[0:1], 0x40
	s_load_b128 s[8:11], s[0:1], 0x30
	s_lshl_b32 s26, ttmp7, 2
	s_clause 0x1
	s_load_b64 s[36:37], s[0:1], 0x0
	s_load_b64 s[28:29], s[0:1], 0x18
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v0, 0
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v27, 0
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v24, 0
	s_wait_kmcnt 0x0
	s_cmp_lt_i32 s26, s5
	s_cselect_b32 s45, -1, 0
	s_ashr_i32 s27, s26, 31
	s_or_b32 s24, s26, 1
	s_mul_u64 s[6:7], s[34:35], s[26:27]
	s_wait_alu 0xfffe
	s_lshl_b64 s[30:31], s[6:7], 1
	s_cmp_lt_i32 s24, s5
	s_add_nc_u64 s[30:31], s[36:37], s[30:31]
	s_cselect_b32 s44, -1, 0
	s_ashr_i32 s25, s24, 31
	s_or_b32 s22, s26, 2
	s_mul_u64 s[6:7], s[34:35], s[24:25]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[6:7], 1
	s_cmp_lt_i32 s22, s5
	s_add_nc_u64 s[40:41], s[36:37], s[38:39]
	s_cselect_b32 s42, -1, 0
	s_ashr_i32 s23, s22, 31
	s_or_b32 s6, s26, 3
	s_mul_u64 s[0:1], s[34:35], s[22:23]
	s_delay_alu instid0(SALU_CYCLE_1)
	s_lshl_b64 s[0:1], s[0:1], 1
	s_wait_alu 0xfffe
	s_cmp_lt_i32 s6, s5
	s_cselect_b32 s33, -1, 0
	s_ashr_i32 s7, s6, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[38:39], s[34:35], s[6:7]
	s_delay_alu instid0(SALU_CYCLE_1)
	s_lshl_b64 s[46:47], s[38:39], 1
	s_add_nc_u64 s[38:39], s[36:37], s[0:1]
	s_add_nc_u64 s[0:1], s[36:37], s[46:47]
	s_and_saveexec_b32 s5, vcc_lo
	s_cbranch_execz .LBB0_28
; %bb.20:
	v_and_b32_e32 v0, 7, v41
	v_and_b32_e32 v24, 7, v54
	v_and_b32_e32 v26, 0x7f, v54
	v_lshrrev_b32_e32 v42, 6, v21
	v_lshrrev_b32_e32 v43, 18, v21
	v_cvt_f32_ubyte0_e32 v0, v0
	v_and_b32_e32 v27, 15, v21
	v_cvt_f32_ubyte0_e32 v24, v24
	v_lshl_add_u32 v30, v26, 20, 0x3c000000
	v_lshrrev_b32_e32 v28, 2, v21
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_mul_f32 v0, 0x3b000000, v0 :: v_dual_lshlrev_b32 v27, 2, v27
	v_mul_f32_e32 v24, 0x3b000000, v24
	v_and_b32_e32 v25, 0x7f, v41
	v_lshrrev_b32_e32 v44, 22, v21
	v_and_b32_e32 v28, 60, v28
	v_and_b32_e32 v46, 15, v22
	v_lshrrev_b32_e32 v48, 2, v22
	v_lshl_add_u32 v29, v25, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v25
	v_lshrrev_b32_e32 v50, 6, v22
	v_and_b32_e32 v44, 60, v44
	v_and_b32_e32 v59, 15, v19
	v_lshrrev_b32_e32 v60, 2, v19
	v_dual_cndmask_b32 v0, v0, v29 :: v_dual_and_b32 v29, 60, v42
	v_cmp_lt_u32_e32 vcc_lo, 7, v26
	v_lshrrev_b32_e32 v42, 14, v21
	v_lshrrev_b32_e32 v61, 6, v19
	v_lshrrev_b32_e32 v63, 2, v20
	v_lshrrev_b32_e32 v65, 6, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v24, v24, v30, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v25
	v_lshrrev_b32_e32 v30, 10, v21
	v_lshrrev_b32_e32 v21, 26, v21
	v_and_b32_e32 v43, 60, v43
	v_and_b32_e32 v42, 60, v42
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, 0x7fc00000, v0, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v26
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v21, 60, v21
	v_lshlrev_b32_e32 v26, 24, v54
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v24, 0x7fc00000, v24 :: v_dual_lshlrev_b32 v25, 24, v41
	ds_load_b32 v56, v27
	ds_load_b32 v53, v28
	ds_load_b32 v51, v29
	ds_load_b32 v49, v30
	ds_load_b32 v47, v42
	ds_load_b32 v45, v43
	ds_load_b32 v43, v44
	ds_load_b32 v42, v21
	v_lshrrev_b32_e32 v29, 10, v22
	v_lshrrev_b32_e32 v30, 14, v22
	v_lshrrev_b32_e32 v44, 18, v22
	v_lshlrev_b32_e32 v21, 2, v46
	v_lshrrev_b32_e32 v46, 22, v22
	v_lshrrev_b32_e32 v22, 26, v22
	v_and_b32_e32 v27, 60, v48
	v_and_b32_e32 v28, 60, v50
	v_and_b32_e32 v29, 60, v29
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v44, 60, v44
	v_and_b32_e32 v57, 60, v46
	v_and_b32_e32 v58, 60, v22
	v_and_or_b32 v54, 0x80000000, v26, v24
	v_mov_b32_e32 v26, 0
	ds_load_b32 v55, v21
	ds_load_b32 v52, v27
	ds_load_b32 v50, v28
	ds_load_b32 v48, v29
	ds_load_b32 v46, v30
	ds_load_b32 v44, v44
	ds_load_b32 v22, v57
	ds_load_b32 v21, v58
	v_lshrrev_b32_e32 v30, 10, v19
	v_lshrrev_b32_e32 v57, 14, v19
	v_lshrrev_b32_e32 v58, 18, v19
	v_lshlrev_b32_e32 v27, 2, v59
	v_lshrrev_b32_e32 v59, 22, v19
	v_lshrrev_b32_e32 v19, 26, v19
	v_and_b32_e32 v28, 60, v60
	v_and_b32_e32 v29, 60, v61
	v_and_b32_e32 v61, 15, v20
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v57, 60, v57
	v_and_b32_e32 v58, 60, v58
	v_and_b32_e32 v59, 60, v59
	v_and_b32_e32 v19, 60, v19
	ds_load_b32 v70, v27
	ds_load_b32 v69, v28
	ds_load_b32 v68, v29
	ds_load_b32 v66, v30
	ds_load_b32 v64, v57
	ds_load_b32 v62, v58
	ds_load_b32 v60, v59
	ds_load_b32 v58, v19
	v_lshrrev_b32_e32 v29, 10, v20
	v_lshrrev_b32_e32 v30, 14, v20
	v_lshrrev_b32_e32 v57, 18, v20
	v_lshlrev_b32_e32 v19, 2, v61
	v_lshrrev_b32_e32 v59, 22, v20
	v_lshrrev_b32_e32 v20, 26, v20
	v_and_b32_e32 v27, 60, v63
	v_and_b32_e32 v28, 60, v65
	v_and_b32_e32 v29, 60, v29
	v_and_b32_e32 v30, 60, v30
	v_and_b32_e32 v57, 60, v57
	v_and_b32_e32 v71, 60, v59
	v_and_b32_e32 v72, 60, v20
	ds_load_b32 v67, v19
	ds_load_b32 v65, v27
	ds_load_b32 v63, v28
	ds_load_b32 v61, v29
	ds_load_b32 v59, v30
	ds_load_b32 v57, v57
	ds_load_b32 v20, v71
	ds_load_b32 v19, v72
	v_and_or_b32 v41, 0x80000000, v25, v0
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v71, 5, v23
	v_mov_b32_e32 v29, 0
	s_and_not1_b32 vcc_lo, exec_lo, s45
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_22
; %bb.21:
	v_add_co_u32 v24, s46, s30, v71
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v25, null, s31, 0, s46
	s_clause 0x1
	global_load_b128 v[27:30], v[24:25], off
	global_load_b128 v[72:75], v[24:25], off offset:16
	s_wait_loadcnt 0x1
	v_and_b32_e32 v24, 0xffff0000, v27
	v_lshlrev_b32_e32 v0, 16, v27
	v_lshlrev_b32_e32 v27, 16, v28
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v25, v56, v0, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v25, v53, v24
	s_wait_dscnt 0xf
	v_fma_f32 v0, v70, v0, 0
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v25, v51, v27 :: v_dual_fmac_f32 v0, v69, v24
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v0, v68, v27 :: v_dual_lshlrev_b32 v27, 16, v29
	v_and_b32_e32 v24, 0xffff0000, v28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v25, v49, v24
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v25, v47, v27 :: v_dual_fmac_f32 v0, v66, v24
	v_and_b32_e32 v24, 0xffff0000, v29
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v0, v64, v27 :: v_dual_fmac_f32 v25, v45, v24
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v0, v62, v24 :: v_dual_lshlrev_b32 v27, 16, v30
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v25, v43, v27
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v0, v60, v27 :: v_dual_lshlrev_b32 v27, 16, v72
	v_and_b32_e32 v24, 0xffff0000, v30
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v25, v42, v24
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v25, v55, v27 :: v_dual_fmac_f32 v0, v58, v24
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v0, v67, v27 :: v_dual_lshlrev_b32 v27, 16, v73
	v_and_b32_e32 v24, 0xffff0000, v72
	v_fmac_f32_e32 v25, v52, v24
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v25, v50, v27 :: v_dual_fmac_f32 v0, v65, v24
	v_and_b32_e32 v24, 0xffff0000, v73
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v0, v63, v27 :: v_dual_fmac_f32 v25, v48, v24
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v0, v61, v24 :: v_dual_lshlrev_b32 v27, 16, v74
	v_fmac_f32_e32 v25, v46, v27
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v0, v59, v27
	v_lshlrev_b32_e32 v27, 16, v75
	v_and_b32_e32 v24, 0xffff0000, v74
	v_fmac_f32_e32 v25, v44, v24
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v25, v22, v27 :: v_dual_fmac_f32 v0, v57, v24
	v_and_b32_e32 v24, 0xffff0000, v75
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v0, v20, v27 :: v_dual_fmac_f32 v25, v21, v24
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v19, v24
	v_fma_f32 v30, v25, v41, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v29, v0, v54, 0
.LBB0_22:
	v_mov_b32_e32 v28, 0
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_24
; %bb.23:
	v_add_co_u32 v72, s46, s40, v71
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v73, null, s41, 0, s46
	s_clause 0x1
	global_load_b128 v[24:27], v[72:73], off
	global_load_b128 v[72:75], v[72:73], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v0, 16, v24
	v_and_b32_e32 v24, 0xffff0000, v24
	v_lshlrev_b32_e32 v76, 16, v25
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v28, v56, v0, 0
	s_wait_dscnt 0xf
	v_fma_f32 v0, v70, v0, 0
	v_fmac_f32_e32 v28, v53, v24
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v69, v24
	v_and_b32_e32 v24, 0xffff0000, v25
	v_dual_fmac_f32 v28, v51, v76 :: v_dual_lshlrev_b32 v25, 16, v26
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v68, v76
	v_fmac_f32_e32 v28, v49, v24
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v66, v24
	v_and_b32_e32 v24, 0xffff0000, v26
	v_fmac_f32_e32 v28, v47, v25
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v64, v25 :: v_dual_lshlrev_b32 v25, 16, v27
	v_fmac_f32_e32 v28, v45, v24
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v62, v24
	v_and_b32_e32 v24, 0xffff0000, v27
	v_fmac_f32_e32 v28, v43, v25
	s_wait_loadcnt_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v60, v25 :: v_dual_lshlrev_b32 v25, 16, v72
	v_fmac_f32_e32 v28, v42, v24
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v58, v24
	v_and_b32_e32 v24, 0xffff0000, v72
	v_fmac_f32_e32 v28, v55, v25
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v67, v25
	v_dual_fmac_f32 v28, v52, v24 :: v_dual_lshlrev_b32 v25, 16, v73
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v65, v24
	v_and_b32_e32 v24, 0xffff0000, v73
	v_fmac_f32_e32 v28, v50, v25
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v63, v25 :: v_dual_lshlrev_b32 v25, 16, v74
	v_fmac_f32_e32 v28, v48, v24
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v61, v24
	v_and_b32_e32 v24, 0xffff0000, v74
	v_fmac_f32_e32 v28, v46, v25
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v0, v59, v25 :: v_dual_lshlrev_b32 v25, 16, v75
	v_fmac_f32_e32 v28, v44, v24
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v57, v24
	v_and_b32_e32 v24, 0xffff0000, v75
	v_fmac_f32_e32 v28, v22, v25
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v20, v25
	v_fmac_f32_e32 v28, v21, v24
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v19, v24
	v_fma_f32 v26, v28, v41, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v28, v0, v54, 0
.LBB0_24:
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v27, 0
	v_mov_b32_e32 v25, 0
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_26
; %bb.25:
	v_add_co_u32 v24, s46, s38, v71
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v25, null, s39, 0, s46
	s_clause 0x1
	global_load_b128 v[72:75], v[24:25], off
	global_load_b128 v[76:79], v[24:25], off offset:16
	s_wait_loadcnt 0x1
	v_and_b32_e32 v25, 0xffff0000, v72
	v_lshlrev_b32_e32 v24, 16, v72
	v_lshlrev_b32_e32 v72, 16, v73
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v27, v56, v24, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v27, v53, v25
	s_wait_dscnt 0xf
	v_fma_f32 v24, v70, v24, 0
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v27, v51, v72 :: v_dual_fmac_f32 v24, v69, v25
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v24, v68, v72 :: v_dual_and_b32 v25, 0xffff0000, v73
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v27, v49, v25 :: v_dual_lshlrev_b32 v72, 16, v74
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v24, v66, v25 :: v_dual_and_b32 v25, 0xffff0000, v74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v27, v47, v72
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v24, v64, v72
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v27, v45, v25 :: v_dual_lshlrev_b32 v72, 16, v75
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v24, v62, v25 :: v_dual_and_b32 v25, 0xffff0000, v75
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v24, v60, v72
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v27, v43, v72 :: v_dual_fmac_f32 v24, v58, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v27, v42, v25
	s_wait_loadcnt 0x0
	v_and_b32_e32 v25, 0xffff0000, v76
	v_lshlrev_b32_e32 v72, 16, v76
	v_fmac_f32_e32 v27, v55, v72
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v27, v52, v25 :: v_dual_fmac_f32 v24, v67, v72
	v_lshlrev_b32_e32 v72, 16, v77
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v24, v65, v25 :: v_dual_fmac_f32 v27, v50, v72
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v24, v63, v72 :: v_dual_and_b32 v25, 0xffff0000, v77
	v_fmac_f32_e32 v27, v48, v25
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v24, v61, v25 :: v_dual_and_b32 v25, 0xffff0000, v78
	v_lshlrev_b32_e32 v72, 16, v78
	v_fmac_f32_e32 v27, v46, v72
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v27, v44, v25 :: v_dual_fmac_f32 v24, v59, v72
	v_lshlrev_b32_e32 v72, 16, v79
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v24, v57, v25 :: v_dual_fmac_f32 v27, v22, v72
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v24, v20, v72 :: v_dual_and_b32 v25, 0xffff0000, v79
	v_fmac_f32_e32 v27, v21, v25
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v24, v19, v25
	v_fma_f32 v27, v27, v41, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v25, v24, v54, 0
.LBB0_26:
	v_mov_b32_e32 v24, 0
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_28
; %bb.27:
	v_add_co_u32 v75, s46, s0, v71
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v76, null, s1, 0, s46
	s_clause 0x1
	global_load_b128 v[71:74], v[75:76], off
	global_load_b128 v[75:78], v[75:76], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v0, 16, v71
	v_and_b32_e32 v24, 0xffff0000, v71
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fma_f32 v56, v56, v0, 0
	s_wait_dscnt 0xf
	v_fma_f32 v0, v70, v0, 0
	v_lshlrev_b32_e32 v70, 16, v72
	v_fmac_f32_e32 v56, v53, v24
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v69, v24
	v_and_b32_e32 v24, 0xffff0000, v72
	v_dual_fmac_f32 v56, v51, v70 :: v_dual_lshlrev_b32 v51, 16, v73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v56, v49, v24
	v_dual_fmac_f32 v56, v47, v51 :: v_dual_lshlrev_b32 v47, 16, v74
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v0, v68, v70
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v0, v66, v24
	v_and_b32_e32 v24, 0xffff0000, v73
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v0, v64, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v45, v24
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v0, v62, v24
	v_and_b32_e32 v24, 0xffff0000, v74
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v56, v43, v47
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v43, 16, v75
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v0, v60, v47
	v_fmac_f32_e32 v56, v42, v24
	v_lshlrev_b32_e32 v42, 16, v76
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v0, v58, v24
	v_and_b32_e32 v24, 0xffff0000, v75
	v_fmac_f32_e32 v56, v55, v43
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v0, v67, v43
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v52, v24
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v0, v65, v24
	v_and_b32_e32 v24, 0xffff0000, v76
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v50, v42
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v0, v63, v42
	v_lshlrev_b32_e32 v42, 16, v77
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v48, v24
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v0, v61, v24
	v_and_b32_e32 v24, 0xffff0000, v77
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v46, v42
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v0, v59, v42
	v_lshlrev_b32_e32 v42, 16, v78
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v44, v24
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v0, v57, v24
	v_and_b32_e32 v24, 0xffff0000, v78
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v22, v42
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v0, v20, v42
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v21, v24
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v0, v19, v24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fma_f32 v24, v56, v41, 0
	v_fma_f32 v0, v0, v54, 0
.LBB0_28:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB0_34
; %bb.29:
	s_wait_dscnt 0x1
	v_and_b32_e32 v20, 7, v40
	v_and_b32_e32 v65, 0x7f, v39
	v_lshrrev_b32_e32 v22, 2, v17
	v_lshrrev_b32_e32 v41, 6, v17
	v_lshrrev_b32_e32 v43, 22, v17
	v_cvt_f32_ubyte0_e32 v20, v20
	s_wait_dscnt 0x0
	v_and_b32_e32 v19, 7, v39
	v_lshl_add_u32 v42, v65, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	v_dual_mul_f32 v68, 0x3b000000, v20 :: v_dual_and_b32 v47, 15, v18
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v19, v19
	v_lshrrev_b32_e32 v49, 2, v18
	v_and_b32_e32 v43, 60, v43
	v_lshrrev_b32_e32 v51, 6, v18
	v_and_b32_e32 v55, 15, v15
	v_mul_f32_e32 v19, 0x3b000000, v19
	v_and_b32_e32 v66, 0x7f, v40
	v_lshrrev_b32_e32 v56, 2, v15
	v_lshrrev_b32_e32 v57, 6, v15
	v_and_b32_e32 v59, 15, v16
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v19, v42, vcc_lo
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_and_b32_e32 v19, 60, v22
	v_and_b32_e32 v20, 60, v41
	v_lshrrev_b32_e32 v22, 10, v17
	v_lshrrev_b32_e32 v41, 14, v17
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshrrev_b32_e32 v42, 18, v17
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v41, 60, v41
	v_lshrrev_b32_e32 v61, 2, v16
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_and_b32_e32 v21, 15, v17
	v_lshrrev_b32_e32 v17, 26, v17
	v_and_b32_e32 v45, 60, v42
	v_lshrrev_b32_e32 v70, 6, v16
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v21, 2, v21
	v_and_b32_e32 v17, 60, v17
	ds_load_b32 v50, v21
	ds_load_b32 v48, v19
	ds_load_b32 v46, v20
	ds_load_b32 v44, v22
	ds_load_b32 v42, v41
	ds_load_b32 v22, v45
	ds_load_b32 v20, v43
	ds_load_b32 v19, v17
	v_lshrrev_b32_e32 v43, 10, v18
	v_lshlrev_b32_e32 v17, 2, v47
	v_and_b32_e32 v21, 60, v49
	v_lshrrev_b32_e32 v45, 14, v18
	v_lshrrev_b32_e32 v47, 18, v18
	v_lshrrev_b32_e32 v49, 22, v18
	v_lshrrev_b32_e32 v18, 26, v18
	v_and_b32_e32 v41, 60, v51
	v_and_b32_e32 v43, 60, v43
	v_and_b32_e32 v51, 60, v45
	v_and_b32_e32 v52, 60, v47
	v_and_b32_e32 v54, 60, v18
	v_and_b32_e32 v53, 60, v49
	ds_load_b32 v49, v17
	ds_load_b32 v47, v21
	ds_load_b32 v45, v41
	ds_load_b32 v43, v43
	ds_load_b32 v41, v51
	ds_load_b32 v21, v52
	ds_load_b32 v18, v53
	ds_load_b32 v17, v54
	v_lshrrev_b32_e32 v54, 10, v15
	v_lshlrev_b32_e32 v51, 2, v55
	v_and_b32_e32 v52, 60, v56
	v_lshrrev_b32_e32 v55, 14, v15
	v_lshrrev_b32_e32 v56, 18, v15
	v_and_b32_e32 v53, 60, v57
	v_lshrrev_b32_e32 v57, 22, v15
	v_lshrrev_b32_e32 v15, 26, v15
	v_and_b32_e32 v54, 60, v54
	v_and_b32_e32 v55, 60, v55
	v_and_b32_e32 v56, 60, v56
	v_and_b32_e32 v57, 60, v57
	v_and_b32_e32 v15, 60, v15
	ds_load_b32 v64, v51
	ds_load_b32 v63, v52
	ds_load_b32 v62, v53
	ds_load_b32 v60, v54
	ds_load_b32 v58, v55
	ds_load_b32 v56, v56
	ds_load_b32 v54, v57
	ds_load_b32 v52, v15
	v_lshrrev_b32_e32 v55, 10, v16
	v_lshrrev_b32_e32 v57, 14, v16
	v_lshlrev_b32_e32 v15, 2, v59
	v_and_b32_e32 v51, 60, v61
	v_lshrrev_b32_e32 v59, 18, v16
	v_lshrrev_b32_e32 v61, 22, v16
	v_lshrrev_b32_e32 v16, 26, v16
	v_and_b32_e32 v53, 60, v70
	v_and_b32_e32 v55, 60, v55
	v_and_b32_e32 v70, 60, v57
	v_and_b32_e32 v71, 60, v59
	v_and_b32_e32 v72, 60, v61
	v_and_b32_e32 v73, 60, v16
	ds_load_b32 v61, v15
	ds_load_b32 v59, v51
	ds_load_b32 v57, v53
	ds_load_b32 v55, v55
	ds_load_b32 v53, v70
	ds_load_b32 v51, v71
	ds_load_b32 v16, v72
	ds_load_b32 v15, v73
	v_lshlrev_b32_e32 v39, 24, v39
	v_lshlrev_b32_e32 v67, 24, v40
	v_lshlrev_b32_e32 v38, 5, v38
	s_and_not1_b32 vcc_lo, exec_lo, s45
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v40, 0x80000000, v39, v65
	v_and_or_b32 v39, 0x80000000, v67, v66
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_71
; %bb.30:
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_72
.LBB0_31:
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_73
.LBB0_32:
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_34
.LBB0_33:
	v_add_co_u32 v69, s4, s0, v38
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v70, null, s1, 0, s4
	s_clause 0x1
	global_load_b128 v[65:68], v[69:70], off
	global_load_b128 v[69:72], v[69:70], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v38, 16, v65
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_fma_f32 v50, v50, v38, 0
	s_wait_dscnt 0xf
	v_fma_f32 v38, v64, v38, 0
	v_lshlrev_b32_e32 v64, 16, v66
	v_and_b32_e32 v65, 0xffff0000, v65
	v_fmac_f32_e32 v50, v48, v65
	v_and_b32_e32 v48, 0xffff0000, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v50, v46, v64
	v_lshlrev_b32_e32 v46, 16, v67
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v38, v63, v65
	v_fmac_f32_e32 v50, v44, v48
	v_and_b32_e32 v44, 0xffff0000, v67
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v38, v62, v64
	v_fmac_f32_e32 v50, v42, v46
	v_lshlrev_b32_e32 v42, 16, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v50, v22, v44
	v_and_b32_e32 v22, 0xffff0000, v68
	v_fmac_f32_e32 v50, v20, v42
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v20, 16, v69
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v50, v19, v22 :: v_dual_and_b32 v19, 0xffff0000, v69
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v38, v60, v48
	v_fmac_f32_e32 v50, v49, v20
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v38, v58, v46
	v_fmac_f32_e32 v50, v47, v19
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v38, v56, v44
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v38, v54, v42
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v38, v52, v22
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v38, v61, v20
	v_lshlrev_b32_e32 v20, 16, v70
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v38, v59, v19 :: v_dual_and_b32 v19, 0xffff0000, v70
	v_fmac_f32_e32 v50, v45, v20
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v38, v57, v20
	v_lshlrev_b32_e32 v20, 16, v71
	v_fmac_f32_e32 v50, v43, v19
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v38, v55, v19
	v_dual_fmac_f32 v50, v41, v20 :: v_dual_and_b32 v19, 0xffff0000, v71
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v38, v53, v20
	v_lshlrev_b32_e32 v20, 16, v72
	v_fmac_f32_e32 v50, v21, v19
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v38, v51, v19 :: v_dual_and_b32 v19, 0xffff0000, v72
	v_fmac_f32_e32 v50, v18, v20
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v38, v16, v20
	v_fmac_f32_e32 v50, v17, v19
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v38, v15, v19
	v_fmac_f32_e32 v24, v50, v40
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v0, v38, v39
.LBB0_34:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB0_40
; %bb.35:
	s_wait_dscnt 0x0
	v_and_b32_e32 v15, 7, v36
	v_and_b32_e32 v58, 0x7f, v36
	v_lshrrev_b32_e32 v19, 6, v13
	v_lshrrev_b32_e32 v18, 2, v13
	v_lshrrev_b32_e32 v21, 22, v13
	v_cvt_f32_ubyte0_e32 v15, v15
	v_and_b32_e32 v16, 7, v37
	v_lshl_add_u32 v20, v58, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v15, 0x3b000000, v15 :: v_dual_and_b32 v40, 15, v14
	v_and_b32_e32 v59, 0x7f, v37
	v_cvt_f32_ubyte0_e32 v16, v16
	v_lshrrev_b32_e32 v42, 2, v14
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v62, v15, v20 :: v_dual_and_b32 v21, 60, v21
	v_lshl_add_u32 v60, v59, 20, 0x3c000000
	v_dual_mul_f32 v61, 0x3b000000, v16 :: v_dual_and_b32 v16, 60, v19
	v_cmp_lt_u32_e32 vcc_lo, 7, v59
	v_and_b32_e32 v17, 15, v13
	v_and_b32_e32 v15, 60, v18
	v_lshrrev_b32_e32 v18, 10, v13
	v_lshrrev_b32_e32 v19, 14, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v61, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	v_lshlrev_b32_e32 v17, 2, v17
	v_lshrrev_b32_e32 v20, 18, v13
	v_lshrrev_b32_e32 v13, 26, v13
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v58, 0x7fc00000, v62 :: v_dual_and_b32 v19, 60, v19
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v59
	v_and_b32_e32 v18, 60, v18
	v_lshrrev_b32_e32 v44, 6, v14
	v_and_b32_e32 v38, 60, v20
	v_and_b32_e32 v13, 60, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v60, vcc_lo
	ds_load_b32 v43, v17
	ds_load_b32 v41, v15
	ds_load_b32 v39, v16
	ds_load_b32 v22, v18
	ds_load_b32 v20, v19
	ds_load_b32 v18, v38
	ds_load_b32 v16, v21
	ds_load_b32 v15, v13
	v_lshrrev_b32_e32 v21, 10, v14
	v_lshlrev_b32_e32 v13, 2, v40
	v_and_b32_e32 v17, 60, v42
	v_lshrrev_b32_e32 v38, 14, v14
	v_lshrrev_b32_e32 v40, 18, v14
	v_lshrrev_b32_e32 v42, 22, v14
	v_lshrrev_b32_e32 v14, 26, v14
	v_and_b32_e32 v48, 15, v11
	v_lshrrev_b32_e32 v49, 2, v11
	v_and_b32_e32 v19, 60, v44
	v_lshrrev_b32_e32 v50, 6, v11
	v_and_b32_e32 v21, 60, v21
	v_and_b32_e32 v44, 60, v38
	v_and_b32_e32 v47, 60, v14
	v_and_b32_e32 v45, 60, v40
	v_and_b32_e32 v46, 60, v42
	ds_load_b32 v42, v13
	ds_load_b32 v40, v17
	ds_load_b32 v38, v19
	ds_load_b32 v21, v21
	ds_load_b32 v19, v44
	ds_load_b32 v17, v45
	ds_load_b32 v14, v46
	ds_load_b32 v13, v47
	v_lshrrev_b32_e32 v47, 10, v11
	v_lshlrev_b32_e32 v44, 2, v48
	v_and_b32_e32 v45, 60, v49
	v_lshrrev_b32_e32 v48, 14, v11
	v_lshrrev_b32_e32 v49, 18, v11
	v_and_b32_e32 v46, 60, v50
	v_lshrrev_b32_e32 v50, 22, v11
	v_lshrrev_b32_e32 v11, 26, v11
	v_and_b32_e32 v52, 15, v12
	v_lshrrev_b32_e32 v54, 2, v12
	v_and_b32_e32 v47, 60, v47
	v_and_b32_e32 v48, 60, v48
	v_and_b32_e32 v49, 60, v49
	v_lshrrev_b32_e32 v63, 6, v12
	v_and_b32_e32 v50, 60, v50
	v_and_b32_e32 v11, 60, v11
	ds_load_b32 v57, v44
	ds_load_b32 v56, v45
	ds_load_b32 v55, v46
	ds_load_b32 v53, v47
	ds_load_b32 v51, v48
	ds_load_b32 v49, v49
	ds_load_b32 v47, v50
	ds_load_b32 v45, v11
	v_lshrrev_b32_e32 v48, 10, v12
	v_lshrrev_b32_e32 v50, 14, v12
	v_lshlrev_b32_e32 v11, 2, v52
	v_and_b32_e32 v44, 60, v54
	v_lshrrev_b32_e32 v52, 18, v12
	v_lshrrev_b32_e32 v54, 22, v12
	v_lshrrev_b32_e32 v12, 26, v12
	v_and_b32_e32 v46, 60, v63
	v_and_b32_e32 v48, 60, v48
	v_and_b32_e32 v63, 60, v50
	v_and_b32_e32 v64, 60, v52
	v_and_b32_e32 v65, 60, v54
	v_and_b32_e32 v66, 60, v12
	ds_load_b32 v54, v11
	ds_load_b32 v52, v44
	ds_load_b32 v50, v46
	ds_load_b32 v48, v48
	ds_load_b32 v46, v63
	ds_load_b32 v44, v64
	ds_load_b32 v12, v65
	ds_load_b32 v11, v66
	v_lshlrev_b32_e32 v36, 24, v36
	v_lshlrev_b32_e32 v60, 24, v37
	v_lshlrev_b32_e32 v35, 5, v35
	s_and_not1_b32 vcc_lo, exec_lo, s45
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v37, 0x80000000, v36, v58
	v_and_or_b32 v36, 0x80000000, v60, v59
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_74
; %bb.36:
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_75
.LBB0_37:
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_76
.LBB0_38:
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_40
.LBB0_39:
	v_add_co_u32 v62, s3, s0, v35
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v63, null, s1, 0, s3
	s_clause 0x1
	global_load_b128 v[58:61], v[62:63], off
	global_load_b128 v[62:65], v[62:63], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v35, 16, v58
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_fma_f32 v43, v43, v35, 0
	s_wait_dscnt 0xf
	v_fma_f32 v35, v57, v35, 0
	v_lshlrev_b32_e32 v57, 16, v59
	v_and_b32_e32 v58, 0xffff0000, v58
	v_fmac_f32_e32 v43, v41, v58
	v_and_b32_e32 v41, 0xffff0000, v59
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v43, v39, v57
	v_lshlrev_b32_e32 v39, 16, v60
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v35, v56, v58
	v_dual_fmac_f32 v43, v22, v41 :: v_dual_and_b32 v22, 0xffff0000, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v43, v20, v39 :: v_dual_lshlrev_b32 v20, 16, v61
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v35, v55, v57
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v43, v18, v22 :: v_dual_and_b32 v18, 0xffff0000, v61
	s_wait_loadcnt 0x0
	v_dual_fmac_f32 v43, v16, v20 :: v_dual_lshlrev_b32 v16, 16, v62
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v35, v53, v41
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v43, v15, v18
	v_and_b32_e32 v15, 0xffff0000, v62
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v35, v51, v39
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v43, v42, v16
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v35, v49, v22
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v43, v40, v15
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v35, v47, v20
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v35, v45, v18
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v35, v54, v16 :: v_dual_lshlrev_b32 v16, 16, v63
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v35, v52, v15
	v_and_b32_e32 v15, 0xffff0000, v63
	v_fmac_f32_e32 v43, v38, v16
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v35, v50, v16
	v_dual_fmac_f32 v43, v21, v15 :: v_dual_lshlrev_b32 v16, 16, v64
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v35, v48, v15
	v_and_b32_e32 v15, 0xffff0000, v64
	v_fmac_f32_e32 v43, v19, v16
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v35, v46, v16 :: v_dual_lshlrev_b32 v16, 16, v65
	v_fmac_f32_e32 v43, v17, v15
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v35, v44, v15
	v_and_b32_e32 v15, 0xffff0000, v65
	v_fmac_f32_e32 v43, v14, v16
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v35, v12, v16
	v_fmac_f32_e32 v43, v13, v15
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v35, v11, v15
	v_fmac_f32_e32 v24, v43, v37
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v0, v35, v36
.LBB0_40:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_and_saveexec_b32 s3, s2
	s_cbranch_execz .LBB0_46
; %bb.41:
	s_wait_dscnt 0x1
	v_and_b32_e32 v12, 7, v34
	v_and_b32_e32 v51, 0x7f, v33
	s_wait_dscnt 0x0
	v_lshrrev_b32_e32 v15, 6, v9
	v_lshrrev_b32_e32 v14, 2, v9
	v_and_b32_e32 v13, 15, v9
	v_cvt_f32_ubyte0_e32 v12, v12
	v_and_b32_e32 v11, 7, v33
	v_lshl_add_u32 v16, v51, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v51
	v_lshrrev_b32_e32 v17, 22, v9
	v_mul_f32_e32 v54, 0x3b000000, v12
	v_cvt_f32_ubyte0_e32 v11, v11
	v_lshlrev_b32_e32 v13, 2, v13
	v_and_b32_e32 v21, 15, v10
	v_lshrrev_b32_e32 v35, 2, v10
	v_and_b32_e32 v17, 60, v17
	v_mul_f32_e32 v11, 0x3b000000, v11
	v_and_b32_e32 v52, 0x7f, v34
	v_lshrrev_b32_e32 v37, 6, v10
	v_and_b32_e32 v41, 15, v7
	v_lshrrev_b32_e32 v42, 2, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v11, v16, vcc_lo
	v_lshl_add_u32 v53, v52, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	v_and_b32_e32 v12, 60, v15
	v_lshrrev_b32_e32 v15, 14, v9
	v_lshrrev_b32_e32 v16, 18, v9
	v_lshrrev_b32_e32 v43, 6, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, v54, v53, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v51
	v_and_b32_e32 v15, 60, v15
	v_and_b32_e32 v19, 60, v16
	v_and_b32_e32 v45, 15, v8
	v_lshrrev_b32_e32 v47, 2, v8
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, 0x7fc00000, v55 :: v_dual_lshlrev_b32 v32, 5, v32
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_and_b32_e32 v11, 60, v14
	v_lshrrev_b32_e32 v14, 10, v9
	v_lshrrev_b32_e32 v9, 26, v9
	v_lshrrev_b32_e32 v56, 6, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v53, vcc_lo
	v_lshlrev_b32_e32 v33, 24, v33
	v_and_b32_e32 v14, 60, v14
	v_and_b32_e32 v9, 60, v9
	ds_load_b32 v36, v13
	ds_load_b32 v22, v11
	ds_load_b32 v20, v12
	ds_load_b32 v18, v14
	ds_load_b32 v16, v15
	ds_load_b32 v14, v19
	ds_load_b32 v12, v17
	ds_load_b32 v11, v9
	v_lshrrev_b32_e32 v17, 10, v10
	v_lshlrev_b32_e32 v9, 2, v21
	v_and_b32_e32 v13, 60, v35
	v_lshrrev_b32_e32 v19, 14, v10
	v_lshrrev_b32_e32 v21, 18, v10
	v_lshrrev_b32_e32 v35, 22, v10
	v_lshrrev_b32_e32 v10, 26, v10
	v_and_b32_e32 v15, 60, v37
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v37, 60, v19
	v_and_b32_e32 v38, 60, v21
	v_and_b32_e32 v40, 60, v10
	v_and_b32_e32 v39, 60, v35
	ds_load_b32 v35, v9
	ds_load_b32 v21, v13
	ds_load_b32 v19, v15
	ds_load_b32 v17, v17
	ds_load_b32 v15, v37
	ds_load_b32 v13, v38
	ds_load_b32 v10, v39
	ds_load_b32 v9, v40
	v_lshrrev_b32_e32 v40, 10, v7
	v_lshlrev_b32_e32 v37, 2, v41
	v_and_b32_e32 v38, 60, v42
	v_lshrrev_b32_e32 v41, 14, v7
	v_lshrrev_b32_e32 v42, 18, v7
	v_and_b32_e32 v39, 60, v43
	v_lshrrev_b32_e32 v43, 22, v7
	v_lshrrev_b32_e32 v7, 26, v7
	v_and_b32_e32 v40, 60, v40
	v_and_b32_e32 v41, 60, v41
	v_and_b32_e32 v42, 60, v42
	v_and_b32_e32 v43, 60, v43
	v_and_b32_e32 v7, 60, v7
	ds_load_b32 v50, v37
	ds_load_b32 v49, v38
	ds_load_b32 v48, v39
	ds_load_b32 v46, v40
	ds_load_b32 v44, v41
	ds_load_b32 v42, v42
	ds_load_b32 v40, v43
	ds_load_b32 v38, v7
	v_lshrrev_b32_e32 v41, 10, v8
	v_lshrrev_b32_e32 v43, 14, v8
	v_lshlrev_b32_e32 v7, 2, v45
	v_and_b32_e32 v37, 60, v47
	v_lshrrev_b32_e32 v45, 18, v8
	v_lshrrev_b32_e32 v47, 22, v8
	v_lshrrev_b32_e32 v8, 26, v8
	v_and_b32_e32 v39, 60, v56
	v_and_b32_e32 v41, 60, v41
	v_and_b32_e32 v56, 60, v43
	v_and_b32_e32 v57, 60, v45
	v_and_b32_e32 v58, 60, v47
	v_and_b32_e32 v59, 60, v8
	ds_load_b32 v47, v7
	ds_load_b32 v45, v37
	ds_load_b32 v43, v39
	ds_load_b32 v41, v41
	ds_load_b32 v39, v56
	ds_load_b32 v37, v57
	ds_load_b32 v8, v58
	ds_load_b32 v7, v59
	v_lshlrev_b32_e32 v53, 24, v34
	v_and_or_b32 v34, 0x80000000, v33, v51
	s_and_not1_b32 vcc_lo, exec_lo, s45
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v33, 0x80000000, v53, v52
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_77
; %bb.42:
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_78
.LBB0_43:
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_79
.LBB0_44:
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_46
.LBB0_45:
	v_add_co_u32 v55, s0, s0, v32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v56, null, s1, 0, s0
	s_clause 0x1
	global_load_b128 v[51:54], v[55:56], off
	global_load_b128 v[55:58], v[55:56], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v32, 16, v51
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_fma_f32 v36, v36, v32, 0
	s_wait_dscnt 0xf
	v_fma_f32 v32, v50, v32, 0
	v_lshlrev_b32_e32 v50, 16, v52
	v_and_b32_e32 v51, 0xffff0000, v51
	v_fmac_f32_e32 v36, v22, v51
	v_and_b32_e32 v22, 0xffff0000, v52
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v36, v20, v50
	v_lshlrev_b32_e32 v20, 16, v53
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v32, v49, v51
	v_fmac_f32_e32 v36, v18, v22
	v_and_b32_e32 v18, 0xffff0000, v53
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v32, v48, v50
	v_fmac_f32_e32 v36, v16, v20
	v_lshlrev_b32_e32 v16, 16, v54
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v36, v14, v18
	v_and_b32_e32 v14, 0xffff0000, v54
	v_fmac_f32_e32 v36, v12, v16
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v12, 16, v55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v36, v11, v14 :: v_dual_and_b32 v11, 0xffff0000, v55
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v32, v46, v22
	v_fmac_f32_e32 v36, v35, v12
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v32, v44, v20
	v_fmac_f32_e32 v36, v21, v11
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v32, v42, v18
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v32, v40, v16
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v32, v38, v14
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v32, v47, v12
	v_lshlrev_b32_e32 v12, 16, v56
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v32, v45, v11 :: v_dual_and_b32 v11, 0xffff0000, v56
	v_fmac_f32_e32 v36, v19, v12
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v32, v43, v12
	v_lshlrev_b32_e32 v12, 16, v57
	v_fmac_f32_e32 v36, v17, v11
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v32, v41, v11 :: v_dual_and_b32 v11, 0xffff0000, v57
	v_fmac_f32_e32 v36, v15, v12
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v32, v39, v12
	v_lshlrev_b32_e32 v12, 16, v58
	v_fmac_f32_e32 v36, v13, v11
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v32, v37, v11 :: v_dual_and_b32 v11, 0xffff0000, v58
	v_fmac_f32_e32 v36, v10, v12
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v32, v8, v12
	v_fmac_f32_e32 v36, v9, v11
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v32, v7, v11
	v_fmac_f32_e32 v24, v36, v34
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v0, v32, v33
.LBB0_46:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_wait_dscnt 0x0
	v_or_b32_e32 v7, 0x80, v23
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s43, v7
	s_cbranch_execz .LBB0_58
; %bb.47:
	v_add_co_u32 v5, vcc_lo, v5, v31
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo
	s_add_nc_u64 s[4:5], s[26:27], 2
	v_add_co_u32 v10, vcc_lo, 0x400, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo
	s_wait_alu 0xfffe
	s_mul_u64 s[4:5], s[4:5], s[34:35]
	v_add_co_u32 v5, vcc_lo, s12, v10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, s13, v11, vcc_lo
	v_add_co_u32 v12, vcc_lo, 0x80, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo
	s_add_nc_u64 s[2:3], s[26:27], 1
	v_add_co_u32 v8, vcc_lo, s14, v12
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v9, null, s15, v13, vcc_lo
	v_add_co_u32 v3, vcc_lo, s16, v10
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[4:5], 1
	s_add_nc_u64 s[4:5], s[26:27], 3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, s17, v11, vcc_lo
	v_add_co_u32 v10, vcc_lo, s18, v12
	s_mul_u64 s[2:3], s[2:3], s[34:35]
	s_wait_alu 0xfffe
	s_mul_u64 s[4:5], s[4:5], s[34:35]
	v_lshlrev_b32_e32 v7, 5, v23
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v11, null, s19, v13, vcc_lo
	s_lshl_b64 s[2:3], s[2:3], 1
	s_wait_alu 0xfffe
	s_lshl_b64 s[34:35], s[4:5], 1
	s_add_nc_u64 s[2:3], s[36:37], s[2:3]
	s_mov_b64 s[4:5], 0x80
	s_add_nc_u64 s[12:13], s[36:37], s[38:39]
	s_add_nc_u64 s[14:15], s[36:37], s[34:35]
	s_mov_b32 s16, 0
	s_branch .LBB0_49
.LBB0_48:                               ;   in Loop: Header=BB0_49 Depth=1
	s_add_nc_u64 s[4:5], s[4:5], 32
	v_add_co_u32 v5, vcc_lo, 0x100, v5
	s_wait_dscnt 0x10
	s_wait_alu 0xfffe
	v_add_nc_u32_e32 v12, s4, v23
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo
	v_add_co_u32 v8, vcc_lo, v8, 32
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo
	v_add_co_u32 v3, vcc_lo, 0x100, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo
	v_cmp_le_i32_e32 vcc_lo, s43, v12
	v_add_co_u32 v10, s0, v10, 32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v11, null, 0, v11, s0
	s_add_nc_u64 s[30:31], s[30:31], 0x400
	s_add_nc_u64 s[2:3], s[2:3], 0x400
	s_add_nc_u64 s[12:13], s[12:13], 0x400
	s_or_b32 s16, vcc_lo, s16
	s_add_nc_u64 s[14:15], s[14:15], 0x400
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s16
	s_cbranch_execz .LBB0_57
.LBB0_49:                               ; =>This Inner Loop Header: Depth=1
	v_add_co_u32 v16, vcc_lo, v8, v23
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v17, null, 0, v9, vcc_lo
	v_add_co_u32 v18, vcc_lo, v10, v23
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v19, null, 0, v11, vcc_lo
	global_load_b64 v[12:13], v[5:6], off th:TH_LOAD_NT
	global_load_b64 v[14:15], v[3:4], off th:TH_LOAD_NT
	global_load_i8 v21, v[16:17], off
	global_load_i8 v54, v[18:19], off
	s_wait_loadcnt 0x3
	v_lshrrev_b32_e32 v17, 2, v12
	v_lshrrev_b32_e32 v18, 6, v12
	s_wait_loadcnt 0x1
	v_and_b32_e32 v55, 0x7f, v21
	s_wait_loadcnt 0x0
	v_and_b32_e32 v57, 7, v54
	v_and_b32_e32 v53, 7, v21
	v_lshrrev_b32_e32 v19, 10, v12
	v_lshrrev_b32_e32 v20, 14, v12
	v_lshl_add_u32 v75, v55, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v57, v57
	v_and_b32_e32 v16, 15, v12
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	v_and_b32_e32 v56, 0x7f, v54
	v_lshrrev_b32_e32 v22, 18, v12
	v_lshrrev_b32_e32 v31, 22, v12
	v_lshrrev_b32_e32 v12, 26, v12
	v_lshrrev_b32_e32 v42, 10, v14
	v_lshrrev_b32_e32 v44, 18, v14
	v_lshrrev_b32_e32 v33, 2, v13
	v_lshrrev_b32_e32 v34, 6, v13
	v_lshrrev_b32_e32 v35, 10, v13
	v_lshrrev_b32_e32 v36, 14, v13
	v_lshrrev_b32_e32 v37, 18, v13
	v_lshrrev_b32_e32 v38, 22, v13
	v_and_b32_e32 v39, 15, v14
	v_lshrrev_b32_e32 v40, 2, v14
	v_lshrrev_b32_e32 v41, 6, v14
	v_lshrrev_b32_e32 v43, 14, v14
	v_lshrrev_b32_e32 v45, 22, v14
	v_lshrrev_b32_e32 v14, 26, v14
	v_lshrrev_b32_e32 v47, 2, v15
	v_lshrrev_b32_e32 v48, 6, v15
	v_lshrrev_b32_e32 v49, 10, v15
	v_lshrrev_b32_e32 v50, 14, v15
	v_lshrrev_b32_e32 v51, 18, v15
	v_lshrrev_b32_e32 v52, 22, v15
	v_cvt_f32_ubyte0_e32 v76, v53
	v_and_b32_e32 v32, 15, v13
	v_lshrrev_b32_e32 v13, 26, v13
	v_lshl_add_u32 v77, v56, 20, 0x3c000000
	v_dual_mul_f32 v57, 0x3b000000, v57 :: v_dual_and_b32 v46, 15, v15
	v_lshrrev_b32_e32 v15, 26, v15
	v_lshlrev_b32_e32 v16, 2, v16
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v18, 60, v18
	v_and_b32_e32 v19, 60, v19
	v_and_b32_e32 v20, 60, v20
	v_and_b32_e32 v22, 60, v22
	v_and_b32_e32 v12, 60, v12
	v_and_b32_e32 v42, 60, v42
	v_and_b32_e32 v44, 60, v44
	v_and_b32_e32 v31, 60, v31
	v_lshlrev_b32_e32 v32, 2, v32
	v_and_b32_e32 v58, 60, v33
	v_and_b32_e32 v34, 60, v34
	v_and_b32_e32 v59, 60, v35
	v_and_b32_e32 v36, 60, v36
	v_and_b32_e32 v60, 60, v37
	v_and_b32_e32 v38, 60, v38
	v_and_b32_e32 v61, 60, v13
	v_lshlrev_b32_e32 v62, 2, v39
	v_and_b32_e32 v40, 60, v40
	v_and_b32_e32 v63, 60, v41
	v_and_b32_e32 v64, 60, v43
	v_and_b32_e32 v65, 60, v45
	v_and_b32_e32 v66, 60, v14
	v_lshlrev_b32_e32 v67, 2, v46
	v_and_b32_e32 v68, 60, v47
	v_and_b32_e32 v69, 60, v48
	v_and_b32_e32 v70, 60, v49
	v_and_b32_e32 v71, 60, v50
	v_and_b32_e32 v72, 60, v51
	v_and_b32_e32 v73, 60, v52
	v_and_b32_e32 v74, 60, v15
	ds_load_b32 v49, v16
	ds_load_b32 v47, v17
	ds_load_b32 v45, v18
	ds_load_b32 v43, v19
	ds_load_b32 v41, v20
	ds_load_b32 v39, v22
	ds_load_b32 v37, v31
	ds_load_b32 v35, v12
	ds_load_b32 v33, v32
	ds_load_b32 v22, v58
	ds_load_b32 v19, v34
	ds_load_b32 v16, v59
	ds_load_b32 v15, v36
	ds_load_b32 v14, v60
	ds_load_b32 v13, v38
	ds_load_b32 v12, v61
	ds_load_b32 v53, v62
	ds_load_b32 v52, v40
	ds_load_b32 v51, v63
	ds_load_b32 v50, v42
	ds_load_b32 v48, v64
	ds_load_b32 v46, v44
	ds_load_b32 v44, v65
	ds_load_b32 v42, v66
	v_mul_f32_e32 v31, 0x3b000000, v76
	ds_load_b32 v40, v67
	ds_load_b32 v38, v68
	ds_load_b32 v36, v69
	ds_load_b32 v34, v70
	ds_load_b32 v32, v71
	ds_load_b32 v20, v72
	ds_load_b32 v18, v73
	ds_load_b32 v17, v74
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v31, v31, v75, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, v57, v77, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v31, 0x7fc00000, v31, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_and_or_b32 v31, 0x80000000, v21, v31
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, 0x7fc00000, v57, vcc_lo
	s_and_not1_b32 vcc_lo, exec_lo, s45
	v_and_or_b32 v21, 0x80000000, v54, v55
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_53
; %bb.50:                               ;   in Loop: Header=BB0_49 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_54
.LBB0_51:                               ;   in Loop: Header=BB0_49 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_55
.LBB0_52:                               ;   in Loop: Header=BB0_49 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_48
	s_branch .LBB0_56
.LBB0_53:                               ;   in Loop: Header=BB0_49 Depth=1
	v_add_co_u32 v58, s0, s30, v7
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v59, null, s31, 0, s0
	s_clause 0x1
	global_load_b128 v[54:57], v[58:59], off offset:4096
	global_load_b128 v[58:61], v[58:59], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v64, 16, v55
	v_lshlrev_b32_e32 v62, 16, v54
	v_and_b32_e32 v54, 0xffff0000, v54
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v63, v49, v62, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v63, v47, v54
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v63, v45, v64
	s_wait_dscnt 0xf
	v_fma_f32 v62, v53, v62, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v62, v52, v54
	v_and_b32_e32 v54, 0xffff0000, v55
	v_lshlrev_b32_e32 v55, 16, v56
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v62, v51, v64
	v_fmac_f32_e32 v63, v43, v54
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v50, v54
	v_dual_fmac_f32 v63, v41, v55 :: v_dual_and_b32 v54, 0xffff0000, v56
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v48, v55 :: v_dual_lshlrev_b32 v55, 16, v57
	v_fmac_f32_e32 v63, v39, v54
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v46, v54
	v_dual_fmac_f32 v63, v37, v55 :: v_dual_and_b32 v54, 0xffff0000, v57
	s_wait_loadcnt_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v62, v44, v55 :: v_dual_lshlrev_b32 v55, 16, v58
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v62, v42, v54
	v_fmac_f32_e32 v63, v35, v54
	v_and_b32_e32 v54, 0xffff0000, v58
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v62, v40, v55
	v_fmac_f32_e32 v63, v33, v55
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v38, v54 :: v_dual_lshlrev_b32 v55, 16, v59
	v_dual_fmac_f32 v63, v22, v54 :: v_dual_and_b32 v54, 0xffff0000, v59
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v36, v55
	v_fmac_f32_e32 v63, v19, v55
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v34, v54 :: v_dual_lshlrev_b32 v55, 16, v60
	v_dual_fmac_f32 v63, v16, v54 :: v_dual_and_b32 v54, 0xffff0000, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v63, v15, v55
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v62, v32, v55 :: v_dual_lshlrev_b32 v55, 16, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v63, v14, v54
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v62, v20, v54
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v63, v13, v55 :: v_dual_and_b32 v54, 0xffff0000, v61
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v62, v18, v55 :: v_dual_fmac_f32 v63, v12, v54
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v62, v17, v54
	v_dual_fmac_f32 v30, v63, v31 :: v_dual_fmac_f32 v29, v62, v21
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_51
.LBB0_54:                               ;   in Loop: Header=BB0_49 Depth=1
	v_add_co_u32 v58, s0, s2, v7
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v59, null, s3, 0, s0
	s_clause 0x1
	global_load_b128 v[54:57], v[58:59], off offset:4096
	global_load_b128 v[58:61], v[58:59], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v64, 16, v55
	v_lshlrev_b32_e32 v62, 16, v54
	v_and_b32_e32 v54, 0xffff0000, v54
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v63, v49, v62, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v63, v47, v54
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v63, v45, v64
	s_wait_dscnt 0xf
	v_fma_f32 v62, v53, v62, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v62, v52, v54
	v_and_b32_e32 v54, 0xffff0000, v55
	v_lshlrev_b32_e32 v55, 16, v56
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v62, v51, v64
	v_fmac_f32_e32 v63, v43, v54
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v50, v54
	v_dual_fmac_f32 v63, v41, v55 :: v_dual_and_b32 v54, 0xffff0000, v56
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v48, v55 :: v_dual_lshlrev_b32 v55, 16, v57
	v_fmac_f32_e32 v63, v39, v54
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v46, v54
	v_dual_fmac_f32 v63, v37, v55 :: v_dual_and_b32 v54, 0xffff0000, v57
	s_wait_loadcnt_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v62, v44, v55 :: v_dual_lshlrev_b32 v55, 16, v58
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v62, v42, v54
	v_fmac_f32_e32 v63, v35, v54
	v_and_b32_e32 v54, 0xffff0000, v58
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v62, v40, v55
	v_fmac_f32_e32 v63, v33, v55
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v38, v54 :: v_dual_lshlrev_b32 v55, 16, v59
	v_dual_fmac_f32 v63, v22, v54 :: v_dual_and_b32 v54, 0xffff0000, v59
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v36, v55
	v_fmac_f32_e32 v63, v19, v55
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v34, v54 :: v_dual_lshlrev_b32 v55, 16, v60
	v_dual_fmac_f32 v63, v16, v54 :: v_dual_and_b32 v54, 0xffff0000, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v63, v15, v55
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v62, v32, v55 :: v_dual_lshlrev_b32 v55, 16, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v63, v14, v54
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v62, v20, v54
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v63, v13, v55 :: v_dual_and_b32 v54, 0xffff0000, v61
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v62, v18, v55 :: v_dual_fmac_f32 v63, v12, v54
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v17, v54
	v_fmac_f32_e32 v26, v63, v31
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v28, v62, v21
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_52
.LBB0_55:                               ;   in Loop: Header=BB0_49 Depth=1
	v_add_co_u32 v58, s0, s12, v7
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v59, null, s13, 0, s0
	s_clause 0x1
	global_load_b128 v[54:57], v[58:59], off offset:4096
	global_load_b128 v[58:61], v[58:59], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v64, 16, v55
	v_lshlrev_b32_e32 v62, 16, v54
	v_and_b32_e32 v54, 0xffff0000, v54
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v63, v49, v62, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v63, v47, v54
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v63, v45, v64
	s_wait_dscnt 0xf
	v_fma_f32 v62, v53, v62, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v62, v52, v54
	v_and_b32_e32 v54, 0xffff0000, v55
	v_lshlrev_b32_e32 v55, 16, v56
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v62, v51, v64
	v_fmac_f32_e32 v63, v43, v54
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v50, v54
	v_dual_fmac_f32 v63, v41, v55 :: v_dual_and_b32 v54, 0xffff0000, v56
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v48, v55 :: v_dual_lshlrev_b32 v55, 16, v57
	v_fmac_f32_e32 v63, v39, v54
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v46, v54
	v_dual_fmac_f32 v63, v37, v55 :: v_dual_and_b32 v54, 0xffff0000, v57
	s_wait_loadcnt_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v62, v44, v55 :: v_dual_lshlrev_b32 v55, 16, v58
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v62, v42, v54
	v_fmac_f32_e32 v63, v35, v54
	v_and_b32_e32 v54, 0xffff0000, v58
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v62, v40, v55
	v_fmac_f32_e32 v63, v33, v55
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v38, v54 :: v_dual_lshlrev_b32 v55, 16, v59
	v_dual_fmac_f32 v63, v22, v54 :: v_dual_and_b32 v54, 0xffff0000, v59
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v62, v36, v55
	v_fmac_f32_e32 v63, v19, v55
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v62, v34, v54 :: v_dual_lshlrev_b32 v55, 16, v60
	v_dual_fmac_f32 v63, v16, v54 :: v_dual_and_b32 v54, 0xffff0000, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v63, v15, v55
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v62, v32, v55 :: v_dual_lshlrev_b32 v55, 16, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v63, v14, v54
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v62, v20, v54
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v63, v13, v55 :: v_dual_and_b32 v54, 0xffff0000, v61
	v_fmac_f32_e32 v63, v12, v54
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v27, v63, v31
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v62, v18, v55
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v62, v17, v54
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v25, v62, v21
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_48
.LBB0_56:                               ;   in Loop: Header=BB0_49 Depth=1
	v_add_co_u32 v58, s0, s14, v7
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v59, null, s15, 0, s0
	s_clause 0x1
	global_load_b128 v[54:57], v[58:59], off offset:4096
	global_load_b128 v[58:61], v[58:59], off offset:4112
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v62, 16, v54
	v_and_b32_e32 v54, 0xffff0000, v54
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v49, v49, v62, 0
	s_wait_dscnt 0xf
	v_fma_f32 v53, v53, v62, 0
	v_dual_fmac_f32 v49, v47, v54 :: v_dual_lshlrev_b32 v62, 16, v55
	v_and_b32_e32 v47, 0xffff0000, v55
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v53, v52, v54
	v_fmac_f32_e32 v49, v45, v62
	v_lshlrev_b32_e32 v45, 16, v56
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v49, v43, v47
	v_and_b32_e32 v43, 0xffff0000, v56
	v_fmac_f32_e32 v49, v41, v45
	v_lshlrev_b32_e32 v41, 16, v57
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v49, v39, v43
	v_and_b32_e32 v39, 0xffff0000, v57
	v_fmac_f32_e32 v49, v37, v41
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v37, 16, v58
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v49, v35, v39
	v_and_b32_e32 v35, 0xffff0000, v58
	v_fmac_f32_e32 v49, v33, v37
	v_lshlrev_b32_e32 v33, 16, v59
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v49, v22, v35
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v53, v51, v62 :: v_dual_and_b32 v22, 0xffff0000, v59
	v_fmac_f32_e32 v49, v19, v33
	v_lshlrev_b32_e32 v19, 16, v60
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v49, v16, v22 :: v_dual_and_b32 v16, 0xffff0000, v60
	v_fmac_f32_e32 v49, v15, v19
	v_lshlrev_b32_e32 v15, 16, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v49, v14, v16 :: v_dual_and_b32 v14, 0xffff0000, v61
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v53, v50, v47
	v_fmac_f32_e32 v49, v13, v15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v49, v12, v14
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v24, v49, v31 :: v_dual_fmac_f32 v53, v48, v45
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v46, v43
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v53, v44, v41
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v42, v39
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v53, v40, v37
	s_wait_dscnt 0x6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v38, v35
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v53, v36, v33
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v34, v22
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v53, v32, v19
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v20, v16
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v53, v18, v15
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v53, v17, v14
	v_fmac_f32_e32 v0, v53, v21
	s_branch .LBB0_48
.LBB0_57:
	s_or_b32 exec_lo, exec_lo, s16
.LBB0_58:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_load_b32 s2, s[28:29], 0x0
	s_load_b32 s1, s[8:9], 0x0
	v_lshlrev_b64_e32 v[1:2], 1, v[1:2]
	v_cmp_eq_u32_e64 s0, 0, v23
	v_mbcnt_lo_u32_b32 v3, -1, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_add_co_u32 v1, vcc_lo, s10, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo
	s_and_b32 vcc_lo, exec_lo, s45
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_63
; %bb.59:
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_87
.LBB0_60:
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_102
.LBB0_61:
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_117
.LBB0_62:
	s_endpgm
.LBB0_63:
	v_xor_b32_e32 v4, 16, v3
	v_xor_b32_e32 v6, 8, v3
	v_xor_b32_e32 v7, 4, v3
	v_xor_b32_e32 v10, 1, v3
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v3, v6, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v7, v3, v7 :: v_dual_lshlrev_b32 v6, 2, v6
	v_lshlrev_b32_e32 v7, 2, v7
	v_lshlrev_b32_e32 v5, 2, v4
	ds_bpermute_b32 v4, v5, v30
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v30, v4
	ds_bpermute_b32 v8, v6, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v8
	v_xor_b32_e32 v8, 2, v3
	ds_bpermute_b32 v9, v7, v4
	v_cmp_gt_i32_e32 vcc_lo, 32, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v8, v3, v8, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v10
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v8, 2, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v3, v10, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v9
	ds_bpermute_b32 v9, v8, v4
	s_wait_dscnt 0x0
	v_dual_add_f32 v4, v4, v9 :: v_dual_lshlrev_b32 v9, 2, v10
	ds_bpermute_b32 v10, v9, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v10
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v10, s2, v4
	v_and_b32_e32 v4, 0x7fffffff, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.64:
	v_bfe_u32 v4, v10, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v10, v4, 0x7fff
                                        ; implicit-def: $vgpr10
	v_lshrrev_b32_e32 v4, 16, v4
; %bb.65:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.66:
	v_lshrrev_b32_e32 v4, 16, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
; %bb.67:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v5, v5, v29
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v29, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v8, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v9, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s1, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execnz .LBB0_80
; %bb.68:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execnz .LBB0_81
.LBB0_69:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execnz .LBB0_82
.LBB0_70:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_60
	s_branch .LBB0_87
.LBB0_71:
	v_add_co_u32 v69, s4, s30, v38
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v70, null, s31, 0, s4
	s_clause 0x1
	global_load_b128 v[65:68], v[69:70], off
	global_load_b128 v[69:72], v[69:70], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v75, 16, v66
	v_lshlrev_b32_e32 v73, 16, v65
	v_and_b32_e32 v65, 0xffff0000, v65
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v74, v50, v73, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v74, v48, v65
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v46, v75
	s_wait_dscnt 0xf
	v_fma_f32 v73, v64, v73, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v73, v63, v65
	v_and_b32_e32 v65, 0xffff0000, v66
	v_lshlrev_b32_e32 v66, 16, v67
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v62, v75 :: v_dual_fmac_f32 v74, v44, v65
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v73, v60, v65 :: v_dual_fmac_f32 v74, v42, v66
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v58, v66 :: v_dual_lshlrev_b32 v66, 16, v68
	v_and_b32_e32 v65, 0xffff0000, v67
	v_fmac_f32_e32 v74, v22, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v20, v66
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v73, v56, v65
	v_and_b32_e32 v65, 0xffff0000, v68
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v73, v54, v66 :: v_dual_fmac_f32 v74, v19, v65
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v66, 16, v69
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v52, v65 :: v_dual_fmac_f32 v74, v49, v66
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v73, v61, v66
	v_lshlrev_b32_e32 v66, 16, v70
	v_and_b32_e32 v65, 0xffff0000, v69
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v47, v65
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v74, v45, v66 :: v_dual_fmac_f32 v73, v59, v65
	v_and_b32_e32 v65, 0xffff0000, v70
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v57, v66 :: v_dual_fmac_f32 v74, v43, v65
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v73, v55, v65 :: v_dual_lshlrev_b32 v66, 16, v71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v41, v66
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v73, v53, v66 :: v_dual_lshlrev_b32 v66, 16, v72
	v_and_b32_e32 v65, 0xffff0000, v71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v21, v65
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v74, v18, v66 :: v_dual_fmac_f32 v73, v51, v65
	v_and_b32_e32 v65, 0xffff0000, v72
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v16, v66 :: v_dual_fmac_f32 v74, v17, v65
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v73, v15, v65 :: v_dual_fmac_f32 v30, v74, v40
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v29, v73, v39
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_31
.LBB0_72:
	v_add_co_u32 v69, s4, s40, v38
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v70, null, s41, 0, s4
	s_clause 0x1
	global_load_b128 v[65:68], v[69:70], off
	global_load_b128 v[69:72], v[69:70], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v75, 16, v66
	v_lshlrev_b32_e32 v73, 16, v65
	v_and_b32_e32 v65, 0xffff0000, v65
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v74, v50, v73, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v74, v48, v65
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v46, v75
	s_wait_dscnt 0xf
	v_fma_f32 v73, v64, v73, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v73, v63, v65
	v_and_b32_e32 v65, 0xffff0000, v66
	v_lshlrev_b32_e32 v66, 16, v67
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v62, v75 :: v_dual_fmac_f32 v74, v44, v65
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v73, v60, v65 :: v_dual_fmac_f32 v74, v42, v66
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v58, v66 :: v_dual_lshlrev_b32 v66, 16, v68
	v_and_b32_e32 v65, 0xffff0000, v67
	v_fmac_f32_e32 v74, v22, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v20, v66
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v73, v56, v65
	v_and_b32_e32 v65, 0xffff0000, v68
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v73, v54, v66 :: v_dual_fmac_f32 v74, v19, v65
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v66, 16, v69
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v52, v65 :: v_dual_fmac_f32 v74, v49, v66
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v73, v61, v66
	v_lshlrev_b32_e32 v66, 16, v70
	v_and_b32_e32 v65, 0xffff0000, v69
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v47, v65
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v74, v45, v66 :: v_dual_fmac_f32 v73, v59, v65
	v_and_b32_e32 v65, 0xffff0000, v70
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v57, v66 :: v_dual_fmac_f32 v74, v43, v65
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v73, v55, v65 :: v_dual_lshlrev_b32 v66, 16, v71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v41, v66
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v73, v53, v66 :: v_dual_lshlrev_b32 v66, 16, v72
	v_and_b32_e32 v65, 0xffff0000, v71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v21, v65
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v74, v18, v66 :: v_dual_fmac_f32 v73, v51, v65
	v_and_b32_e32 v65, 0xffff0000, v72
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v16, v66 :: v_dual_fmac_f32 v74, v17, v65
	s_wait_dscnt 0x0
	v_dual_fmac_f32 v73, v15, v65 :: v_dual_fmac_f32 v26, v74, v40
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v28, v73, v39
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_32
.LBB0_73:
	v_add_co_u32 v69, s4, s38, v38
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v70, null, s39, 0, s4
	s_clause 0x1
	global_load_b128 v[65:68], v[69:70], off
	global_load_b128 v[69:72], v[69:70], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v75, 16, v66
	v_lshlrev_b32_e32 v73, 16, v65
	v_and_b32_e32 v65, 0xffff0000, v65
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v74, v50, v73, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v74, v48, v65
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v46, v75
	s_wait_dscnt 0xf
	v_fma_f32 v73, v64, v73, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v73, v63, v65
	v_and_b32_e32 v65, 0xffff0000, v66
	v_lshlrev_b32_e32 v66, 16, v67
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v62, v75 :: v_dual_fmac_f32 v74, v44, v65
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v73, v60, v65 :: v_dual_fmac_f32 v74, v42, v66
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v58, v66 :: v_dual_lshlrev_b32 v66, 16, v68
	v_and_b32_e32 v65, 0xffff0000, v67
	v_fmac_f32_e32 v74, v22, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v20, v66
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v73, v56, v65
	v_and_b32_e32 v65, 0xffff0000, v68
	s_wait_dscnt 0x9
	v_dual_fmac_f32 v73, v54, v66 :: v_dual_fmac_f32 v74, v19, v65
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v66, 16, v69
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v52, v65 :: v_dual_fmac_f32 v74, v49, v66
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v73, v61, v66
	v_lshlrev_b32_e32 v66, 16, v70
	v_and_b32_e32 v65, 0xffff0000, v69
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v47, v65
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v74, v45, v66 :: v_dual_fmac_f32 v73, v59, v65
	v_and_b32_e32 v65, 0xffff0000, v70
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v57, v66 :: v_dual_fmac_f32 v74, v43, v65
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v73, v55, v65 :: v_dual_lshlrev_b32 v66, 16, v71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v74, v41, v66
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v73, v53, v66 :: v_dual_lshlrev_b32 v66, 16, v72
	v_and_b32_e32 v65, 0xffff0000, v71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v74, v21, v65
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v74, v18, v66 :: v_dual_fmac_f32 v73, v51, v65
	v_and_b32_e32 v65, 0xffff0000, v72
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v73, v16, v66 :: v_dual_fmac_f32 v74, v17, v65
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v73, v15, v65
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v27, v74, v40
	v_fmac_f32_e32 v25, v73, v39
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_33
	s_branch .LBB0_34
.LBB0_74:
	v_add_co_u32 v62, s3, s30, v35
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v63, null, s31, 0, s3
	s_clause 0x1
	global_load_b128 v[58:61], v[62:63], off
	global_load_b128 v[62:65], v[62:63], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v68, 16, v59
	v_lshlrev_b32_e32 v66, 16, v58
	v_and_b32_e32 v58, 0xffff0000, v58
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v67, v43, v66, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v67, v41, v58
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v39, v68
	s_wait_dscnt 0xf
	v_fma_f32 v66, v57, v66, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v66, v56, v58
	v_and_b32_e32 v58, 0xffff0000, v59
	v_lshlrev_b32_e32 v59, 16, v60
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v55, v68 :: v_dual_fmac_f32 v67, v22, v58
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v66, v53, v58 :: v_dual_fmac_f32 v67, v20, v59
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v51, v59 :: v_dual_lshlrev_b32 v59, 16, v61
	v_and_b32_e32 v58, 0xffff0000, v60
	v_fmac_f32_e32 v67, v18, v58
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v67, v16, v59 :: v_dual_fmac_f32 v66, v49, v58
	v_and_b32_e32 v58, 0xffff0000, v61
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v66, v47, v59 :: v_dual_lshlrev_b32 v59, 16, v62
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v66, v45, v58
	v_fmac_f32_e32 v67, v15, v58
	v_and_b32_e32 v58, 0xffff0000, v62
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v66, v54, v59
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v67, v42, v59
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v66, v52, v58 :: v_dual_lshlrev_b32 v59, 16, v63
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v40, v58 :: v_dual_and_b32 v58, 0xffff0000, v63
	v_fmac_f32_e32 v67, v38, v59
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v66, v50, v59 :: v_dual_lshlrev_b32 v59, 16, v64
	v_fmac_f32_e32 v67, v21, v58
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v48, v58 :: v_dual_fmac_f32 v67, v19, v59
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v66, v46, v59 :: v_dual_lshlrev_b32 v59, 16, v65
	v_and_b32_e32 v58, 0xffff0000, v64
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v17, v58
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v67, v14, v59 :: v_dual_fmac_f32 v66, v44, v58
	v_and_b32_e32 v58, 0xffff0000, v65
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v12, v59 :: v_dual_fmac_f32 v67, v13, v58
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v66, v11, v58
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v30, v67, v37 :: v_dual_fmac_f32 v29, v66, v36
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_37
.LBB0_75:
	v_add_co_u32 v62, s3, s40, v35
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v63, null, s41, 0, s3
	s_clause 0x1
	global_load_b128 v[58:61], v[62:63], off
	global_load_b128 v[62:65], v[62:63], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v68, 16, v59
	v_lshlrev_b32_e32 v66, 16, v58
	v_and_b32_e32 v58, 0xffff0000, v58
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v67, v43, v66, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v67, v41, v58
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v39, v68
	s_wait_dscnt 0xf
	v_fma_f32 v66, v57, v66, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v66, v56, v58
	v_and_b32_e32 v58, 0xffff0000, v59
	v_lshlrev_b32_e32 v59, 16, v60
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v55, v68 :: v_dual_fmac_f32 v67, v22, v58
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v66, v53, v58 :: v_dual_fmac_f32 v67, v20, v59
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v51, v59 :: v_dual_lshlrev_b32 v59, 16, v61
	v_and_b32_e32 v58, 0xffff0000, v60
	v_fmac_f32_e32 v67, v18, v58
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v67, v16, v59 :: v_dual_fmac_f32 v66, v49, v58
	v_and_b32_e32 v58, 0xffff0000, v61
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v66, v47, v59 :: v_dual_lshlrev_b32 v59, 16, v62
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v66, v45, v58
	v_fmac_f32_e32 v67, v15, v58
	v_and_b32_e32 v58, 0xffff0000, v62
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v66, v54, v59
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v67, v42, v59
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v66, v52, v58 :: v_dual_lshlrev_b32 v59, 16, v63
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v40, v58 :: v_dual_and_b32 v58, 0xffff0000, v63
	v_fmac_f32_e32 v67, v38, v59
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v66, v50, v59 :: v_dual_lshlrev_b32 v59, 16, v64
	v_fmac_f32_e32 v67, v21, v58
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v48, v58 :: v_dual_fmac_f32 v67, v19, v59
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v66, v46, v59 :: v_dual_lshlrev_b32 v59, 16, v65
	v_and_b32_e32 v58, 0xffff0000, v64
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v17, v58
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v67, v14, v59 :: v_dual_fmac_f32 v66, v44, v58
	v_and_b32_e32 v58, 0xffff0000, v65
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v12, v59 :: v_dual_fmac_f32 v67, v13, v58
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v66, v11, v58
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v26, v67, v37
	v_fmac_f32_e32 v28, v66, v36
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_38
.LBB0_76:
	v_add_co_u32 v62, s3, s38, v35
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v63, null, s39, 0, s3
	s_clause 0x1
	global_load_b128 v[58:61], v[62:63], off
	global_load_b128 v[62:65], v[62:63], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v68, 16, v59
	v_lshlrev_b32_e32 v66, 16, v58
	v_and_b32_e32 v58, 0xffff0000, v58
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v67, v43, v66, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v67, v41, v58
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v39, v68
	s_wait_dscnt 0xf
	v_fma_f32 v66, v57, v66, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v66, v56, v58
	v_and_b32_e32 v58, 0xffff0000, v59
	v_lshlrev_b32_e32 v59, 16, v60
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v55, v68 :: v_dual_fmac_f32 v67, v22, v58
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v66, v53, v58 :: v_dual_fmac_f32 v67, v20, v59
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v51, v59 :: v_dual_lshlrev_b32 v59, 16, v61
	v_and_b32_e32 v58, 0xffff0000, v60
	v_fmac_f32_e32 v67, v18, v58
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v67, v16, v59 :: v_dual_fmac_f32 v66, v49, v58
	v_and_b32_e32 v58, 0xffff0000, v61
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v66, v47, v59 :: v_dual_lshlrev_b32 v59, 16, v62
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v66, v45, v58
	v_fmac_f32_e32 v67, v15, v58
	v_and_b32_e32 v58, 0xffff0000, v62
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v66, v54, v59
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v67, v42, v59
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v66, v52, v58 :: v_dual_lshlrev_b32 v59, 16, v63
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v40, v58 :: v_dual_and_b32 v58, 0xffff0000, v63
	v_fmac_f32_e32 v67, v38, v59
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v66, v50, v59 :: v_dual_lshlrev_b32 v59, 16, v64
	v_fmac_f32_e32 v67, v21, v58
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v48, v58 :: v_dual_fmac_f32 v67, v19, v59
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v66, v46, v59 :: v_dual_lshlrev_b32 v59, 16, v65
	v_and_b32_e32 v58, 0xffff0000, v64
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v17, v58
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v67, v14, v59 :: v_dual_fmac_f32 v66, v44, v58
	v_and_b32_e32 v58, 0xffff0000, v65
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v66, v12, v59
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v66, v11, v58
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v25, v66, v36
	v_fmac_f32_e32 v67, v13, v58
	v_fmac_f32_e32 v27, v67, v37
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_39
	s_branch .LBB0_40
.LBB0_77:
	v_add_co_u32 v55, s2, s30, v32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v56, null, s31, 0, s2
	s_clause 0x1
	global_load_b128 v[51:54], v[55:56], off
	global_load_b128 v[55:58], v[55:56], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v61, 16, v52
	v_lshlrev_b32_e32 v59, 16, v51
	v_and_b32_e32 v51, 0xffff0000, v51
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v60, v36, v59, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v60, v22, v51
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v60, v20, v61
	s_wait_dscnt 0xf
	v_fma_f32 v59, v50, v59, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v59, v49, v51
	v_and_b32_e32 v51, 0xffff0000, v52
	v_lshlrev_b32_e32 v52, 16, v53
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v48, v61 :: v_dual_fmac_f32 v60, v18, v51
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v59, v46, v51 :: v_dual_fmac_f32 v60, v16, v52
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v44, v52 :: v_dual_lshlrev_b32 v52, 16, v54
	v_and_b32_e32 v51, 0xffff0000, v53
	v_fmac_f32_e32 v60, v14, v51
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v12, v52 :: v_dual_fmac_f32 v59, v42, v51
	v_and_b32_e32 v51, 0xffff0000, v54
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v59, v40, v52 :: v_dual_lshlrev_b32 v52, 16, v55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v60, v11, v51
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v59, v38, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v35, v52 :: v_dual_and_b32 v51, 0xffff0000, v55
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v59, v47, v52
	v_lshlrev_b32_e32 v52, 16, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v60, v21, v51
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v59, v45, v51
	v_and_b32_e32 v51, 0xffff0000, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v60, v19, v52
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v59, v43, v52 :: v_dual_lshlrev_b32 v52, 16, v57
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v60, v17, v51
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v59, v41, v51 :: v_dual_fmac_f32 v60, v15, v52
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v39, v52 :: v_dual_lshlrev_b32 v52, 16, v58
	v_and_b32_e32 v51, 0xffff0000, v57
	v_fmac_f32_e32 v60, v13, v51
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v60, v10, v52 :: v_dual_fmac_f32 v59, v37, v51
	v_and_b32_e32 v51, 0xffff0000, v58
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v59, v8, v52 :: v_dual_fmac_f32 v60, v9, v51
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v7, v51 :: v_dual_fmac_f32 v30, v60, v34
	v_fmac_f32_e32 v29, v59, v33
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_43
.LBB0_78:
	v_add_co_u32 v55, s2, s40, v32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v56, null, s41, 0, s2
	s_clause 0x1
	global_load_b128 v[51:54], v[55:56], off
	global_load_b128 v[55:58], v[55:56], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v61, 16, v52
	v_lshlrev_b32_e32 v59, 16, v51
	v_and_b32_e32 v51, 0xffff0000, v51
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v60, v36, v59, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v60, v22, v51
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v60, v20, v61
	s_wait_dscnt 0xf
	v_fma_f32 v59, v50, v59, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v59, v49, v51
	v_and_b32_e32 v51, 0xffff0000, v52
	v_lshlrev_b32_e32 v52, 16, v53
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v48, v61 :: v_dual_fmac_f32 v60, v18, v51
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v59, v46, v51 :: v_dual_fmac_f32 v60, v16, v52
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v44, v52 :: v_dual_lshlrev_b32 v52, 16, v54
	v_and_b32_e32 v51, 0xffff0000, v53
	v_fmac_f32_e32 v60, v14, v51
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v12, v52 :: v_dual_fmac_f32 v59, v42, v51
	v_and_b32_e32 v51, 0xffff0000, v54
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v59, v40, v52 :: v_dual_lshlrev_b32 v52, 16, v55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v60, v11, v51
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v59, v38, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v35, v52 :: v_dual_and_b32 v51, 0xffff0000, v55
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v59, v47, v52
	v_lshlrev_b32_e32 v52, 16, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v60, v21, v51
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v59, v45, v51
	v_and_b32_e32 v51, 0xffff0000, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v60, v19, v52
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v59, v43, v52 :: v_dual_lshlrev_b32 v52, 16, v57
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v60, v17, v51
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v59, v41, v51 :: v_dual_fmac_f32 v60, v15, v52
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v39, v52 :: v_dual_lshlrev_b32 v52, 16, v58
	v_and_b32_e32 v51, 0xffff0000, v57
	v_fmac_f32_e32 v60, v13, v51
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v10, v52 :: v_dual_fmac_f32 v59, v37, v51
	v_and_b32_e32 v51, 0xffff0000, v58
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v59, v8, v52
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v59, v7, v51
	v_fmac_f32_e32 v28, v59, v33
	v_fmac_f32_e32 v60, v9, v51
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v26, v60, v34
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_44
.LBB0_79:
	v_add_co_u32 v55, s2, s38, v32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v56, null, s39, 0, s2
	s_clause 0x1
	global_load_b128 v[51:54], v[55:56], off
	global_load_b128 v[55:58], v[55:56], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v61, 16, v52
	v_lshlrev_b32_e32 v59, 16, v51
	v_and_b32_e32 v51, 0xffff0000, v51
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v60, v36, v59, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v60, v22, v51
	s_wait_dscnt 0x1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v60, v20, v61
	s_wait_dscnt 0xf
	v_fma_f32 v59, v50, v59, 0
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v59, v49, v51
	v_and_b32_e32 v51, 0xffff0000, v52
	v_lshlrev_b32_e32 v52, 16, v53
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v48, v61 :: v_dual_fmac_f32 v60, v18, v51
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v59, v46, v51 :: v_dual_fmac_f32 v60, v16, v52
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v44, v52 :: v_dual_lshlrev_b32 v52, 16, v54
	v_and_b32_e32 v51, 0xffff0000, v53
	v_fmac_f32_e32 v60, v14, v51
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v12, v52 :: v_dual_fmac_f32 v59, v42, v51
	v_and_b32_e32 v51, 0xffff0000, v54
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v59, v40, v52 :: v_dual_lshlrev_b32 v52, 16, v55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v60, v11, v51
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v59, v38, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v60, v35, v52 :: v_dual_and_b32 v51, 0xffff0000, v55
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v59, v47, v52
	v_lshlrev_b32_e32 v52, 16, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v60, v21, v51
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v59, v45, v51
	v_and_b32_e32 v51, 0xffff0000, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v60, v19, v52
	s_wait_dscnt 0x5
	v_dual_fmac_f32 v59, v43, v52 :: v_dual_lshlrev_b32 v52, 16, v57
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v60, v17, v51
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v59, v41, v51 :: v_dual_fmac_f32 v60, v15, v52
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v59, v39, v52 :: v_dual_lshlrev_b32 v52, 16, v58
	v_and_b32_e32 v51, 0xffff0000, v57
	v_fmac_f32_e32 v60, v13, v51
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v60, v10, v52 :: v_dual_fmac_f32 v59, v37, v51
	v_and_b32_e32 v51, 0xffff0000, v58
	s_wait_dscnt 0x1
	v_dual_fmac_f32 v59, v8, v52 :: v_dual_fmac_f32 v60, v9, v51
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v59, v7, v51
	v_fmac_f32_e32 v27, v60, v34
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v25, v59, v33
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB0_45
	s_branch .LBB0_46
.LBB0_80:
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execz .LBB0_69
.LBB0_81:
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execz .LBB0_70
.LBB0_82:
	v_lshlrev_b32_e32 v4, 16, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v6, 0xbfb8aa3b, v4 :: v_dual_lshlrev_b32 v5, 16, v5
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v4
	v_fma_f32 v7, 0xbfb8aa3b, v4, -v6
	v_rndne_f32_e32 v8, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v7, v4, 0xb2a5705f, v7 :: v_dual_sub_f32 v6, v6, v8
	v_add_f32_e32 v6, v6, v7
	v_cvt_i32_f32_e32 v7, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v6, v6
	v_ldexp_f32 v6, v6, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, 0x7f800000, v6, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v6, 1.0, v6
	v_div_scale_f32 v7, null, v6, v6, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v8, v7
	v_fma_f32 v9, -v7, v8, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v8, v9, v8
	v_div_scale_f32 v9, vcc_lo, v4, v6, v4
	v_mul_f32_e32 v10, v9, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v11, -v7, v10, v9
	v_fmac_f32_e32 v10, v11, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v7, -v7, v10, v9
	s_wait_alu 0xfffd
	v_div_fmas_f32 v7, v7, v8, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v4, v7, v6, v4
	v_mul_f32_e32 v5, v4, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v4, 0x7fffffff, v5
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s4, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s4, exec_lo, s4
; %bb.83:
	v_bfe_u32 v4, v5, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v5, v4, 0x7fff
                                        ; implicit-def: $vgpr5
	v_lshrrev_b32_e32 v4, 16, v4
; %bb.84:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s4, s4
; %bb.85:
	v_lshrrev_b32_e32 v4, 16, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
; %bb.86:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_mul_u64 s[4:5], s[20:21], s[26:27]
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v5, vcc_lo, v1, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, s5, v2, vcc_lo
	global_store_b16 v[5:6], v4, off
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_60
.LBB0_87:
	v_xor_b32_e32 v4, 16, v3
	v_xor_b32_e32 v6, 8, v3
	v_xor_b32_e32 v7, 4, v3
	v_xor_b32_e32 v10, 1, v3
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v3, v6, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v7, v3, v7 :: v_dual_lshlrev_b32 v6, 2, v6
	v_lshlrev_b32_e32 v7, 2, v7
	v_lshlrev_b32_e32 v5, 2, v4
	ds_bpermute_b32 v4, v5, v26
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v26, v4
	ds_bpermute_b32 v8, v6, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v8
	v_xor_b32_e32 v8, 2, v3
	ds_bpermute_b32 v9, v7, v4
	v_cmp_gt_i32_e32 vcc_lo, 32, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v8, v3, v8, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v10
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v8, 2, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v3, v10, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v9
	ds_bpermute_b32 v9, v8, v4
	s_wait_dscnt 0x0
	v_dual_add_f32 v4, v4, v9 :: v_dual_lshlrev_b32 v9, 2, v10
	ds_bpermute_b32 v10, v9, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v10
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v10, s2, v4
	v_and_b32_e32 v4, 0x7fffffff, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.88:
	v_bfe_u32 v4, v10, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v10, v4, 0x7fff
                                        ; implicit-def: $vgpr10
	v_lshrrev_b32_e32 v4, 16, v4
; %bb.89:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.90:
	v_lshrrev_b32_e32 v4, 16, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
; %bb.91:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v5, v5, v28
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v28, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v8, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v9, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s1, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execnz .LBB0_95
; %bb.92:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execnz .LBB0_96
.LBB0_93:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execnz .LBB0_97
.LBB0_94:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_61
	s_branch .LBB0_102
.LBB0_95:
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execz .LBB0_93
.LBB0_96:
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execz .LBB0_94
.LBB0_97:
	v_lshlrev_b32_e32 v4, 16, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v6, 0xbfb8aa3b, v4 :: v_dual_lshlrev_b32 v5, 16, v5
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v4
	v_fma_f32 v7, 0xbfb8aa3b, v4, -v6
	v_rndne_f32_e32 v8, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v7, v4, 0xb2a5705f, v7 :: v_dual_sub_f32 v6, v6, v8
	v_add_f32_e32 v6, v6, v7
	v_cvt_i32_f32_e32 v7, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v6, v6
	v_ldexp_f32 v6, v6, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, 0x7f800000, v6, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v6, 1.0, v6
	v_div_scale_f32 v7, null, v6, v6, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v8, v7
	v_fma_f32 v9, -v7, v8, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v8, v9, v8
	v_div_scale_f32 v9, vcc_lo, v4, v6, v4
	v_mul_f32_e32 v10, v9, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v11, -v7, v10, v9
	v_fmac_f32_e32 v10, v11, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v7, -v7, v10, v9
	s_wait_alu 0xfffd
	v_div_fmas_f32 v7, v7, v8, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v4, v7, v6, v4
	v_mul_f32_e32 v5, v4, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v4, 0x7fffffff, v5
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s4, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s4, exec_lo, s4
; %bb.98:
	v_bfe_u32 v4, v5, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v5, v4, 0x7fff
                                        ; implicit-def: $vgpr5
	v_lshrrev_b32_e32 v4, 16, v4
; %bb.99:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s4, s4
; %bb.100:
	v_lshrrev_b32_e32 v4, 16, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
; %bb.101:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_mul_u64 s[4:5], s[20:21], s[24:25]
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v5, vcc_lo, v1, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, s5, v2, vcc_lo
	global_store_b16 v[5:6], v4, off
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s42
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_61
.LBB0_102:
	v_xor_b32_e32 v4, 16, v3
	v_xor_b32_e32 v6, 8, v3
	v_xor_b32_e32 v7, 4, v3
	v_xor_b32_e32 v10, 1, v3
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v3, v6, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v7, v3, v7 :: v_dual_lshlrev_b32 v6, 2, v6
	v_lshlrev_b32_e32 v7, 2, v7
	v_lshlrev_b32_e32 v5, 2, v4
	ds_bpermute_b32 v4, v5, v27
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v27, v4
	ds_bpermute_b32 v8, v6, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v8
	v_xor_b32_e32 v8, 2, v3
	ds_bpermute_b32 v9, v7, v4
	v_cmp_gt_i32_e32 vcc_lo, 32, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v8, v3, v8, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v10
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v8, 2, v8
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v10, v3, v10, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v9
	ds_bpermute_b32 v9, v8, v4
	s_wait_dscnt 0x0
	v_dual_add_f32 v4, v4, v9 :: v_dual_lshlrev_b32 v9, 2, v10
	ds_bpermute_b32 v10, v9, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v10
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v10, s2, v4
	v_and_b32_e32 v4, 0x7fffffff, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.103:
	v_bfe_u32 v4, v10, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v10, v4, 0x7fff
                                        ; implicit-def: $vgpr10
	v_lshrrev_b32_e32 v4, 16, v4
; %bb.104:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.105:
	v_lshrrev_b32_e32 v4, 16, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
; %bb.106:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v5, v5, v25
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v25, v5
	ds_bpermute_b32 v6, v6, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v8, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	ds_bpermute_b32 v6, v9, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s1, v5
	v_and_b32_e32 v5, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execnz .LBB0_110
; %bb.107:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execnz .LBB0_111
.LBB0_108:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execnz .LBB0_112
.LBB0_109:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_62
	s_branch .LBB0_117
.LBB0_110:
	v_bfe_u32 v5, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v6, v5, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v5, 16, v5
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
	s_cbranch_execz .LBB0_108
.LBB0_111:
	v_lshrrev_b32_e32 v5, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_and_saveexec_b32 s3, s0
	s_cbranch_execz .LBB0_109
.LBB0_112:
	v_lshlrev_b32_e32 v4, 16, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v6, 0xbfb8aa3b, v4 :: v_dual_lshlrev_b32 v5, 16, v5
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v4
	v_fma_f32 v7, 0xbfb8aa3b, v4, -v6
	v_rndne_f32_e32 v8, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmamk_f32 v7, v4, 0xb2a5705f, v7 :: v_dual_sub_f32 v6, v6, v8
	v_add_f32_e32 v6, v6, v7
	v_cvt_i32_f32_e32 v7, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_exp_f32_e32 v6, v6
	v_ldexp_f32 v6, v6, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, 0x7f800000, v6, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v6, 1.0, v6
	v_div_scale_f32 v7, null, v6, v6, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v8, v7
	v_fma_f32 v9, -v7, v8, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v8, v9, v8
	v_div_scale_f32 v9, vcc_lo, v4, v6, v4
	v_mul_f32_e32 v10, v9, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v11, -v7, v10, v9
	v_fmac_f32_e32 v10, v11, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v7, -v7, v10, v9
	s_wait_alu 0xfffd
	v_div_fmas_f32 v7, v7, v8, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fixup_f32 v4, v7, v6, v4
	v_mul_f32_e32 v5, v4, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v4, 0x7fffffff, v5
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v4
                                        ; implicit-def: $vgpr4
	s_and_saveexec_b32 s4, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s4, exec_lo, s4
; %bb.113:
	v_bfe_u32 v4, v5, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v4, v5, v4, 0x7fff
                                        ; implicit-def: $vgpr5
	v_lshrrev_b32_e32 v4, 16, v4
; %bb.114:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s4, s4
; %bb.115:
	v_lshrrev_b32_e32 v4, 16, v5
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v4, 64, v4
; %bb.116:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_mul_u64 s[4:5], s[20:21], s[22:23]
	s_wait_alu 0xfffe
	s_lshl_b64 s[4:5], s[4:5], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v5, vcc_lo, v1, s4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, s5, v2, vcc_lo
	global_store_b16 v[5:6], v4, off
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB0_62
.LBB0_117:
	v_xor_b32_e32 v4, 16, v3
	v_xor_b32_e32 v5, 8, v3
	v_xor_b32_e32 v10, 1, v3
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v3, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v5, 2, v5
	v_lshlrev_b32_e32 v4, 2, v4
	ds_bpermute_b32 v6, v4, v24
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v24, v6
	v_xor_b32_e32 v6, 4, v3
	ds_bpermute_b32 v8, v5, v7
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v6, v3, v6, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v8, v7, v8
	v_xor_b32_e32 v7, 2, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v3, v7, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v10
	v_lshlrev_b32_e32 v7, 2, v7
	v_lshlrev_b32_e32 v6, 2, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v3, v10, vcc_lo
	ds_bpermute_b32 v9, v6, v8
	s_wait_dscnt 0x0
	v_add_f32_e32 v8, v8, v9
	ds_bpermute_b32 v9, v7, v8
	s_wait_dscnt 0x0
	v_dual_add_f32 v9, v8, v9 :: v_dual_lshlrev_b32 v8, 2, v3
	ds_bpermute_b32 v3, v8, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v9, v3
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v9, s2, v3
	v_and_b32_e32 v3, 0x7fffffff, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s2, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s2, exec_lo, s2
; %bb.118:
	v_bfe_u32 v3, v9, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v9, v3, 0x7fff
                                        ; implicit-def: $vgpr9
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.119:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s2, s2
; %bb.120:
	v_lshrrev_b32_e32 v3, 16, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.121:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	ds_bpermute_b32 v4, v4, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v4
	ds_bpermute_b32 v4, v5, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v4
	ds_bpermute_b32 v4, v6, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v4
	ds_bpermute_b32 v4, v7, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v4
	ds_bpermute_b32 v4, v8, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v4, s1, v0
	v_and_b32_e32 v0, 0x7fffffff, v4
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s1, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s1, exec_lo, s1
	s_cbranch_execnz .LBB0_124
; %bb.122:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
	s_cbranch_execnz .LBB0_125
.LBB0_123:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 exec_lo, exec_lo, s0
	s_cbranch_execz .LBB0_62
	s_branch .LBB0_126
.LBB0_124:
	v_bfe_u32 v0, v4, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v4, v0, 0x7fff
                                        ; implicit-def: $vgpr4
	v_lshrrev_b32_e32 v0, 16, v0
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
	s_cbranch_execz .LBB0_123
.LBB0_125:
	v_lshrrev_b32_e32 v0, 16, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	v_or_b32_e32 v0, 64, v0
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_and_b32 exec_lo, exec_lo, s0
	s_cbranch_execz .LBB0_62
.LBB0_126:
	v_lshlrev_b32_e32 v3, 16, v3
	v_lshlrev_b32_e32 v0, 16, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v4, 0xbfb8aa3b, v3
	v_fma_f32 v5, 0xbfb8aa3b, v3, -v4
	v_rndne_f32_e32 v6, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_sub_f32_e32 v4, v4, v6
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v3
	v_fmamk_f32 v5, v3, 0xb2a5705f, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_f32_e32 v4, v4, v5
	v_cvt_i32_f32_e32 v5, v6
	v_exp_f32_e32 v4, v4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_ldexp_f32 v4, v4, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v4, 0x7f800000, v4, vcc_lo
	v_add_f32_e32 v4, 1.0, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v5, null, v4, v4, v3
	v_rcp_f32_e32 v6, v5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v7, -v5, v6, 1.0
	v_fmac_f32_e32 v6, v7, v6
	v_div_scale_f32 v7, vcc_lo, v3, v4, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v8, v7, v6
	v_fma_f32 v9, -v5, v8, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v8, v9, v6
	v_fma_f32 v5, -v5, v8, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_fmas_f32 v5, v5, v6, v8
	v_div_fixup_f32 v3, v5, v4, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v3, v3, v0
	v_and_b32_e32 v0, 0x7fffffff, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.127:
	v_bfe_u32 v0, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v3, v0, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.128:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.129:
	v_lshrrev_b32_e32 v0, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.130:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_mul_u64 s[0:1], s[20:21], s[6:7]
	s_wait_alu 0xfffe
	s_lshl_b64 s[0:1], s[0:1], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v1, vcc_lo, v1, s0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo
	global_store_b16 v[1:2], v0, off
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili
		.amdhsa_group_segment_fixed_size 64
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 84
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 80
		.amdhsa_next_free_sgpr 48
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 143
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili,"axG",@progbits,_ZN12_GLOBAL__N_122shared_glu_rows_kernelEPK7ik_bf16PKhS4_PKfS4_S4_S6_PS0_ili,comdat
.Lfunc_end0:
