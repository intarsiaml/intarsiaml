_ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii: ; @_ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii
; %bb.0:
	s_clause 0x2
	s_load_b32 s14, s[0:1], 0x20
	s_load_b64 s[10:11], s[0:1], 0x0
	s_load_b64 s[12:13], s[0:1], 0x40
	v_lshrrev_b32_e32 v40, 5, v0
	v_and_b32_e32 v39, 31, v0
	s_mov_b32 s16, ttmp9
	s_mov_b32 s17, 0
	s_wait_kmcnt 0x0
	s_add_co_i32 s2, s14, 7
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_ashr_i32 s3, s2, 31
	s_lshr_b32 s3, s3, 29
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	s_add_co_i32 s2, s2, s3
	s_mov_b32 s3, -1
	s_ashr_i32 s2, s2, 3
	s_cmp_ge_i32 ttmp9, s2
	s_cbranch_scc0 .LBB317_83
; %bb.1:
	s_ashr_i32 s3, s2, 31
	s_load_b64 s[20:21], s[0:1], 0x28
	s_sub_nc_u64 s[2:3], s[16:17], s[2:3]
	s_ashr_i32 s8, s13, 31
	s_lshl_b64 s[2:3], s[2:3], 3
	s_delay_alu instid0(SALU_CYCLE_1)
	v_dual_mov_b32 v34, s3 :: v_dual_and_b32 v41, 31, v0
	v_or_b32_e32 v33, s2, v40
	s_lshr_b32 s2, s8, 28
	s_ashr_i32 s5, s12, 31
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s13, s2
	s_mov_b32 s4, s12
	v_mul_lo_u32 v1, v33, s8
	v_mad_co_u64_u32 v[35:36], null, v33, s13, 0
	s_wait_alu 0xfffe
	s_ashr_i32 s12, s2, 4
	s_mul_i32 s2, s3, s13
	v_cmp_gt_i64_e32 vcc_lo, s[4:5], v[33:34]
	s_wait_alu 0xfffe
	v_cmp_gt_i32_e64 s5, s12, v41
	v_dual_mov_b32 v9, 0 :: v_dual_lshlrev_b32 v42, 4, v41
	v_add3_u32 v36, v36, v1, s2
	s_wait_kmcnt 0x0
	s_cmp_lg_u64 s[20:21], 0
	v_add_co_u32 v17, s2, s20, v35
	s_cselect_b32 s3, -1, 0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v18, null, s21, v36, s2
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0
	s_wait_alu 0xfffe
	s_and_b32 s15, s3, vcc_lo
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s3, s5, s15
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB317_3
; %bb.2:
	v_add_co_u32 v1, vcc_lo, v17, v42
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v2, null, 0, v18, vcc_lo
	global_load_b128 v[13:16], v[1:2], off th:TH_LOAD_NT
.LBB317_3:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_or_b32_e32 v46, 32, v41
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0
	v_mov_b32_e32 v12, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s4, s12, v46
	s_and_b32 s3, s15, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB317_5
; %bb.4:
	v_add_co_u32 v1, vcc_lo, v17, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v18, vcc_lo
	global_load_b128 v[9:12], v[1:2], off offset:512 th:TH_LOAD_NT
.LBB317_5:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_load_b64 s[6:7], s[0:1], 0x30
	v_or_b32_e32 v45, 64, v41
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v6, 0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v8, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s3, s12, v45
	v_mov_b32_e32 v7, 0
	s_and_b32 s9, s15, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s9
	s_cbranch_execz .LBB317_7
; %bb.6:
	v_add_co_u32 v2, vcc_lo, v17, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v18, vcc_lo
	global_load_b128 v[5:8], v[2:3], off offset:1024 th:TH_LOAD_NT
.LBB317_7:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_or_b32_e32 v44, 0x60, v41
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0
	v_mov_b32_e32 v4, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)
	v_cmp_gt_i32_e64 s2, s12, v44
	s_and_b32 s18, s15, s2
	s_and_saveexec_b32 s9, s18
	s_cbranch_execz .LBB317_9
; %bb.8:
	v_add_co_u32 v1, vcc_lo, v17, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v18, vcc_lo
	global_load_b128 v[1:4], v[1:2], off offset:1536 th:TH_LOAD_NT
.LBB317_9:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_wait_kmcnt 0x0
	s_load_b64 s[22:23], s[6:7], 0x0
	s_load_b64 s[18:19], s[0:1], 0x38
	s_mov_b32 s28, 0
	s_mov_b32 s27, exec_lo
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s23, 0
	s_cselect_b32 s25, -1, 0
	s_cmp_ngt_f32 s23, 0
	s_cselect_b32 s24, -1, 0
	s_lshr_b32 s6, s8, 29
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_add_co_i32 s6, s13, s6
	s_ashr_i32 s26, s6, 3
	s_delay_alu instid0(SALU_CYCLE_1)
	v_cmpx_gt_i32_e64 s26, v0
	s_cbranch_execz .LBB317_14
; %bb.10:
	s_load_b32 s6, s[0:1], 0x54
	v_lshlrev_b32_e32 v17, 4, v0
	v_mov_b32_e32 v23, v0
	s_mov_b32 s31, 0xc3e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_co_u32 v18, s7, s10, v17
	v_add_co_ci_u32_e64 v19, null, s11, 0, s7
	v_add_nc_u32_e32 v24, 0, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_u32 v21, vcc_lo, v18, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v22, null, 0, v19, vcc_lo
	s_wait_kmcnt 0x0
	s_and_b32 s29, s6, 0xffff
	s_delay_alu instid0(SALU_CYCLE_1)
	s_lshl_b32 s30, s29, 4
	s_branch .LBB317_12
.LBB317_11:                             ;   in Loop: Header=BB317_12 Depth=1
	v_add_nc_u32_e32 v23, s29, v23
	v_add_co_u32 v21, s6, v21, s30
	s_wait_loadcnt 0x0
	ds_store_b128 v24, v[17:20]
	v_add_nc_u32_e32 v24, s30, v24
	v_cmp_le_i32_e32 vcc_lo, s26, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v22, null, 0, v22, s6
	s_or_b32 s28, vcc_lo, s28
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s28
	s_cbranch_execz .LBB317_14
.LBB317_12:                             ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[17:20], v[21:22], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s25
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_11
; %bb.13:                               ;   in Loop: Header=BB317_12 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v25, 16, v17
	v_and_b32_e32 v17, 0xffff0000, v17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_scale_f32 v26, null, s23, s23, v25
	v_div_scale_f32 v27, null, s23, s23, v17
	v_div_scale_f32 v49, s6, v17, s23, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v30, v26
	v_rcp_f32_e32 v31, v27
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_fma_f32 v47, -v26, v30, 1.0
	v_fma_f32 v48, -v27, v31, 1.0
	v_lshlrev_b32_e32 v28, 16, v18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v30, v47, v30 :: v_dual_fmac_f32 v31, v48, v31
	v_div_scale_f32 v32, null, s23, s23, v28
	v_div_scale_f32 v38, vcc_lo, v25, s23, v25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v52, v49, v31
	v_rcp_f32_e32 v43, v32
	v_div_scale_f32 v50, s7, v28, s23, v28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v51, v38, v30
	v_fma_f32 v55, -v26, v51, v38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v48, -v32, v43, 1.0
	v_and_b32_e32 v18, 0xffff0000, v18
	v_fmac_f32_e32 v51, v55, v30
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v43, v48, v43
	v_div_scale_f32 v47, null, s23, s23, v18
	v_fma_f32 v48, -v27, v52, v49
	v_lshlrev_b32_e32 v37, 16, v20
	v_and_b32_e32 v20, 0xffff0000, v20
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_rcp_f32_e32 v54, v47
	v_mul_f32_e32 v55, v50, v43
	v_fmac_f32_e32 v52, v48, v31
	v_div_scale_f32 v56, s8, v18, s23, v18
	v_fma_f32 v26, -v26, v51, v38
	v_fma_f32 v38, -v32, v55, v50
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_fma_f32 v27, -v27, v52, v49
	v_fma_f32 v57, -v47, v54, 1.0
	v_lshlrev_b32_e32 v29, 16, v19
	s_wait_alu 0xfffd
	v_div_fmas_f32 v26, v26, v30, v51
	v_fmac_f32_e32 v55, v38, v43
	s_mov_b32 vcc_lo, s6
	v_fmac_f32_e32 v54, v57, v54
	v_div_scale_f32 v53, null, s23, s23, v29
	v_div_fixup_f32 v25, v26, s23, v25
	s_wait_alu 0xfffe
	v_div_fmas_f32 v27, v27, v31, v52
	v_fma_f32 v31, -v32, v55, v50
	v_rcp_f32_e32 v48, v53
	s_mov_b32 vcc_lo, s7
	v_div_scale_f32 v51, null, s23, s23, v20
	s_wait_alu 0xfffe
	v_div_fmas_f32 v31, v31, v43, v55
	v_div_scale_f32 v43, null, s23, s23, v37
	v_div_fixup_f32 v17, v27, s23, v17
	s_mov_b32 vcc_lo, s8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_div_fixup_f32 v28, v31, s23, v28
	v_fma_f32 v26, -v53, v48, 1.0
	v_and_b32_e32 v19, 0xffff0000, v19
	v_rcp_f32_e32 v50, v43
	v_med3_num_f32 v25, v25, s31, 0x43e00000
	v_med3_num_f32 v17, v17, s31, 0x43e00000
	v_fmac_f32_e32 v48, v26, v48
	v_div_scale_f32 v30, null, s23, s23, v19
	v_div_scale_f32 v26, s6, v29, s23, v29
	v_med3_num_f32 v28, v28, s31, 0x43e00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)
	v_rcp_f32_e32 v32, v30
	v_fma_f32 v52, -v43, v50, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v50, v52, v50
	v_div_scale_f32 v52, s9, v37, s23, v37
	v_mul_f32_e32 v31, v26, v48
	v_fma_f32 v49, -v30, v32, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v32, v49, v32 :: v_dual_mul_f32 v27, v56, v54
	v_div_scale_f32 v49, s7, v19, s23, v19
	v_fma_f32 v38, -v47, v27, v56
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v27, v38, v54
	v_rcp_f32_e32 v38, v51
	v_fma_f32 v47, -v47, v27, v56
	v_mul_f32_e32 v56, v49, v32
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_div_fmas_f32 v27, v47, v54, v27
	v_fma_f32 v57, -v51, v38, 1.0
	v_mul_f32_e32 v54, v52, v50
	v_fma_f32 v55, -v53, v31, v26
	v_fma_f32 v47, -v30, v56, v49
	v_div_fixup_f32 v18, v27, s23, v18
	v_fmac_f32_e32 v38, v57, v38
	v_fma_f32 v27, -v43, v54, v52
	v_fmac_f32_e32 v31, v55, v48
	v_div_scale_f32 v55, s8, v20, s23, v20
	v_fmac_f32_e32 v56, v47, v32
	s_mov_b32 vcc_lo, s6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v26, -v53, v31, v26
	v_mul_f32_e32 v47, v55, v38
	v_fmac_f32_e32 v54, v27, v50
	v_fma_f32 v30, -v30, v56, v49
	v_med3_num_f32 v18, v18, s31, 0x43e00000
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v26, v48, v31
	v_fma_f32 v31, -v51, v47, v55
	s_mov_b32 vcc_lo, s7
	s_wait_alu 0xfffe
	v_div_fmas_f32 v27, v30, v32, v56
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_mov_b32 v30, 0 :: v_dual_fmac_f32 v47, v31, v38
	v_div_fixup_f32 v26, v26, s23, v29
	s_mov_b32 vcc_lo, s9
	v_div_fixup_f32 v19, v27, s23, v19
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v30, v25, v17
	v_mov_b32_e32 v17, 0
	v_fma_f32 v29, -v43, v54, v52
	v_fma_f32 v27, -v51, v47, v55
	v_med3_num_f32 v26, v26, s31, 0x43e00000
	v_med3_num_f32 v19, v19, s31, 0x43e00000
	v_cvt_pk_fp8_f32 v30, v28, v18 op_sel:[0,0,1]
	s_wait_alu 0xfffe
	v_div_fmas_f32 v29, v29, v50, v54
	s_mov_b32 vcc_lo, s8
	s_wait_alu 0xfffe
	v_div_fmas_f32 v27, v27, v38, v47
	v_cvt_pk_fp8_f32 v17, v26, v19
	v_div_fixup_f32 v29, v29, s23, v37
	v_perm_b32 v18, 0, v30, 0x10c000c
	v_perm_b32 v19, 0, v30, 0x30c020c
	v_div_fixup_f32 v20, v27, s23, v20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_med3_num_f32 v25, v29, s31, 0x43e00000
	v_lshrrev_b32_e32 v26, 1, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_med3_num_f32 v20, v20, s31, 0x43e00000
	v_and_b32_e32 v19, 0x80008000, v19
	v_cvt_pk_fp8_f32 v17, v25, v20 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v20, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_perm_b32 v25, 0, v17, 0x10c000c
	v_perm_b32 v17, 0, v17, 0x30c020c
	v_lshrrev_b32_e32 v27, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_lshrrev_b32_e32 v28, 1, v17
	v_and_b32_e32 v29, 0x80008000, v17
	v_and_or_b32 v17, 0x3f803f80, v20, v18
	v_and_or_b32 v18, 0x3f803f80, v26, v19
	v_and_or_b32 v19, 0x3f803f80, v27, v25
	v_and_or_b32 v20, 0x3f803f80, v28, v29
	s_branch .LBB317_11
.LBB317_14:
	s_or_b32 exec_lo, exec_lo, s27
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s8, s15
	s_cbranch_execz .LBB317_82
; %bb.15:
	v_xad_u32 v47, v41, 31, s12
	s_and_b32 s6, s25, exec_lo
	s_cselect_b32 s6, s23, 1.0
	s_and_b32 vcc_lo, exec_lo, s24
	s_wait_alu 0xfffe
	s_mul_f32 s9, s22, s6
	v_ashrrev_i32_e32 v17, 31, v47
	v_cmp_lt_i32_e64 s6, 31, v47
	s_mov_b32 s7, -1
	v_lshrrev_b32_e32 v17, 27, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v17, v47, v17
	v_ashrrev_i32_e32 v43, 5, v17
	s_cbranch_vccz .LBB317_45
; %bb.16:
	v_mov_b32_e32 v48, 0
	s_and_saveexec_b32 s15, s6
	s_cbranch_execz .LBB317_38
; %bb.17:
	v_dual_mov_b32 v48, 0 :: v_dual_lshlrev_b32 v17, 5, v41
	v_add_co_u32 v18, vcc_lo, v35, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v19, null, 0, v36, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add3_u32 v49, v17, 0, 0x400
	v_add_co_u32 v17, vcc_lo, s20, v18
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_ci_u32_e64 v18, null, s21, v19, vcc_lo
	v_mov_b32_e32 v50, v41
	v_add_co_u32 v37, vcc_lo, 0x400, v17
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_ci_u32_e64 v38, null, 0, v18, vcc_lo
	v_dual_mov_b32 v17, v13 :: v_dual_mov_b32 v18, v14
	v_dual_mov_b32 v19, v15 :: v_dual_mov_b32 v20, v16
	v_dual_mov_b32 v21, v9 :: v_dual_mov_b32 v22, v10
	v_dual_mov_b32 v23, v11 :: v_dual_mov_b32 v24, v12
	v_dual_mov_b32 v25, v5 :: v_dual_mov_b32 v26, v6
	v_dual_mov_b32 v27, v7 :: v_dual_mov_b32 v28, v8
	v_dual_mov_b32 v29, v1 :: v_dual_mov_b32 v30, v2
	v_dual_mov_b32 v31, v3 :: v_dual_mov_b32 v32, v4
	s_mov_b32 s22, 0
	s_mov_b32 s23, 0
	s_branch .LBB317_22
.LBB317_18:                             ;   in Loop: Header=BB317_22 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s26
.LBB317_19:                             ;   in Loop: Header=BB317_22 Depth=1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s25
.LBB317_20:                             ;   in Loop: Header=BB317_22 Depth=1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s24
.LBB317_21:                             ;   in Loop: Header=BB317_22 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_add_co_i32 s23, s23, 4
	v_add_co_u32 v37, s7, 0x800, v37
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s23, v43
	v_add_nc_u32_e32 v49, 0x1000, v49
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v38, s7
	v_add_nc_u32_e32 v50, 0x80, v50
	s_or_b32 s22, vcc_lo, s22
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execz .LBB317_37
.LBB317_22:                             ; =>This Inner Loop Header: Depth=1
	v_mov_b32_e32 v51, v41
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s23, 0
	s_cbranch_scc1 .LBB317_32
; %bb.23:                               ;   in Loop: Header=BB317_22 Depth=1
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v18, 0
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0
	v_mov_b32_e32 v19, 0
	s_mov_b32 s7, exec_lo
	v_cmpx_gt_i32_e64 s12, v50
	s_cbranch_execz .LBB317_25
; %bb.24:                               ;   in Loop: Header=BB317_22 Depth=1
	global_load_b128 v[17:20], v[37:38], off offset:-1024 th:TH_LOAD_NT
.LBB317_25:                             ;   in Loop: Header=BB317_22 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v24, 32, v50
	v_mov_b32_e32 v22, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s12, v24
	v_mov_b32_e32 v24, 0
	s_and_saveexec_b32 s7, vcc_lo
	s_cbranch_execz .LBB317_27
; %bb.26:                               ;   in Loop: Header=BB317_22 Depth=1
	global_load_b128 v[21:24], v[37:38], off offset:-512 th:TH_LOAD_NT
.LBB317_27:                             ;   in Loop: Header=BB317_22 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v28, 64, v50
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0
	v_mov_b32_e32 v27, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s12, v28
	v_mov_b32_e32 v28, 0
	s_and_saveexec_b32 s7, vcc_lo
	s_cbranch_execz .LBB317_29
; %bb.28:                               ;   in Loop: Header=BB317_22 Depth=1
	global_load_b128 v[25:28], v[37:38], off th:TH_LOAD_NT
.LBB317_29:                             ;   in Loop: Header=BB317_22 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v32, 0x60, v50
	v_mov_b32_e32 v30, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s12, v32
	v_mov_b32_e32 v32, 0
	s_and_saveexec_b32 s7, vcc_lo
	s_cbranch_execz .LBB317_31
; %bb.30:                               ;   in Loop: Header=BB317_22 Depth=1
	global_load_b128 v[29:32], v[37:38], off offset:512 th:TH_LOAD_NT
.LBB317_31:                             ;   in Loop: Header=BB317_22 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	v_mov_b32_e32 v51, v50
.LBB317_32:                             ;   in Loop: Header=BB317_22 Depth=1
	s_mov_b32 s7, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s12, v51
	s_cbranch_execz .LBB317_21
; %bb.33:                               ;   in Loop: Header=BB317_22 Depth=1
	v_lshl_add_u32 v55, v51, 5, 0
	s_wait_loadcnt 0x0
	v_bfe_u32 v61, v17, 8, 3
	v_bfe_u32 v62, v17, 8, 7
	v_bfe_u32 v71, v17, 16, 3
	v_bfe_u32 v75, v18, 8, 7
	ds_load_b128 v[51:54], v55
	ds_load_b128 v[55:58], v55 offset:16
	v_cvt_f32_ubyte0_e32 v61, v61
	v_bfe_u32 v80, v19, 8, 3
	s_mov_b32 s24, exec_lo
	v_lshlrev_b32_e32 v72, 16, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v61, 0x3b000000, v61
	v_and_b32_e32 v59, 7, v17
	v_cvt_f32_ubyte0_e32 v80, v80
	v_cvt_f32_ubyte0_e32 v59, v59
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_lshlrev_b32 v66, 16, v53
	v_lshlrev_b32_e32 v64, 16, v51
	v_and_b32_e32 v60, 0x7f, v17
	v_lshl_add_u32 v63, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v59, v59, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v70, 16, v57
	v_lshl_add_u32 v63, v62, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v61, v63, vcc_lo
	v_bfe_u32 v61, v17, 16, 7
	v_cvt_f32_ubyte0_e32 v63, v71
	v_lshlrev_b32_e32 v71, 24, v17
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v62
	v_lshlrev_b32_e32 v67, 16, v54
	v_lshl_add_u32 v62, v61, 20, 0x3c000000
	v_mul_f32_e32 v63, 0x3b000000, v63
	v_and_or_b32 v59, 0x80000000, v71, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, 0x7fc00000, v60, vcc_lo
	v_bfe_u32 v71, v17, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	v_and_b32_e32 v51, 0xffff0000, v51
	v_fma_f32 v59, v59, v64, 0
	v_and_or_b32 v60, 0x80000000, v72, v60
	v_cvt_f32_ubyte0_e32 v71, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v63, v62, vcc_lo
	v_bfe_u32 v63, v17, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_lshlrev_b32_e32 v68, 16, v55
	v_dual_mul_f32 v71, 0x3b000000, v71 :: v_dual_and_b32 v72, 7, v18
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v73, v63, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v61, 0x7fc00000, v62 :: v_dual_lshlrev_b32 v62, 8, v17
	v_cmp_lt_u32_e32 vcc_lo, 7, v63
	v_fmac_f32_e32 v59, v60, v51
	v_and_or_b32 v61, 0x80000000, v62, v61
	v_cvt_f32_ubyte0_e32 v62, v72
	v_lshlrev_b32_e32 v65, 16, v52
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v71, v71, v73 :: v_dual_and_b32 v52, 0xffff0000, v52
	v_bfe_u32 v73, v18, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v63
	v_dual_mul_f32 v62, 0x3b000000, v62 :: v_dual_fmac_f32 v59, v61, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, 0x7fc00000, v71, vcc_lo
	v_cvt_f32_ubyte0_e32 v71, v73
	v_bfe_u32 v73, v18, 16, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v63, 0x80000000, v17, v63
	v_mul_f32_e32 v71, 0x3b000000, v71
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_fmac_f32_e32 v59, v63, v52
	v_bfe_u32 v52, v20, 8, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_and_b32_e32 v74, 0x7f, v18
	v_cvt_f32_ubyte0_e32 v52, v52
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v72, v74, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	v_and_b32_e32 v53, 0xffff0000, v53
	v_mul_f32_e32 v52, 0x3b000000, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_lshlrev_b32_e32 v69, 16, v56
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	v_bfe_u32 v74, v18, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, 0x7fc00000, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v54, 0xffff0000, v54
	v_lshl_add_u32 v76, v74, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v71, v71, v72 :: v_dual_lshlrev_b32 v72, 24, v18
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v75, 16, v18
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v62, 0x80000000, v72, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, 0x7fc00000, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	v_bfe_u32 v72, v18, 24, 3
	v_fmac_f32_e32 v59, v62, v66
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v71, 0x80000000, v75, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_and_b32_e32 v74, 7, v19
	v_bfe_u32 v75, v18, 24, 7
	v_cvt_f32_ubyte0_e32 v72, v72
	v_and_b32_e32 v76, 0x7f, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, 0x7fc00000, v73, vcc_lo
	v_cvt_f32_ubyte0_e32 v74, v74
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_mul_f32_e32 v72, 0x3b000000, v72
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v55, 0xffff0000, v55
	v_lshl_add_u32 v79, v76, 20, 0x3c000000
	v_mul_f32_e32 v74, 0x3b000000, v74
	v_bfe_u32 v62, v20, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, v72, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v76
	v_and_b32_e32 v57, 0xffff0000, v57
	v_bfe_u32 v78, v19, 8, 7
	v_fmac_f32_e32 v59, v71, v53
	v_lshl_add_u32 v53, v62, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, v74, v79, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshl_add_u32 v75, v78, 20, 0x3c000000
	v_mul_f32_e32 v79, 0x3b000000, v80
	v_bfe_u32 v80, v19, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v76
	v_lshlrev_b32_e32 v76, 24, v19
	v_lshl_add_u32 v64, v80, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v72, 0x80000000, v18, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, 0x7fc00000, v74, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v75, v79, v75 :: v_dual_and_b32 v56, 0xffff0000, v56
	v_lshlrev_b32_e32 v79, 16, v19
	v_and_or_b32 v74, 0x80000000, v76, v74
	v_bfe_u32 v76, v19, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	v_bfe_u32 v78, v19, 16, 7
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v76, v76
	v_lshlrev_b32_e32 v77, 8, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, 0x7fc00000, v75, vcc_lo
	v_lshl_add_u32 v81, v78, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	v_mul_f32_e32 v76, 0x3b000000, v76
	v_and_or_b32 v73, 0x80000000, v77, v73
	v_bfe_u32 v77, v19, 24, 3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v76, v76, v81, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v80
	v_cvt_f32_ubyte0_e32 v77, v77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v77, 0x3b000000, v77
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v77, v64, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	v_lshlrev_b32_e32 v64, 8, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, 0x7fc00000, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_and_or_b32 v60, 0x80000000, v64, v60
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, 0x7fc00000, v51 :: v_dual_and_b32 v64, 7, v20
	v_cvt_f32_ubyte0_e32 v64, v64
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v51, 0x80000000, v19, v51
	v_mul_f32_e32 v64, 0x3b000000, v64
	v_and_b32_e32 v63, 0x7f, v20
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v65, v63, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v65, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v52, v53, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v63
	v_lshlrev_b32_e32 v63, 24, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v64, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v62
	v_lshlrev_b32_e32 v62, 16, v20
	v_and_or_b32 v61, 0x80000000, v79, v75
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v53, 0x80000000, v63, v53
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v52, 0x7fc00000, v52 :: v_dual_fmac_f32 v59, v73, v67
	v_bfe_u32 v63, v20, 16, 7
	v_and_or_b32 v52, 0x80000000, v62, v52
	v_bfe_u32 v62, v20, 24, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_cmp_lt_u32_e32 vcc_lo, 7, v63
	v_fmac_f32_e32 v59, v72, v54
	v_bfe_u32 v54, v20, 16, 3
	v_cvt_f32_ubyte0_e32 v62, v62
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v59, v74, v68
	v_cvt_f32_ubyte0_e32 v54, v54
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v59, v61, v55
	v_lshl_add_u32 v55, v63, 20, 0x3c000000
	v_mul_f32_e32 v54, 0x3b000000, v54
	v_bfe_u32 v61, v20, 24, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v59, v60, v69 :: v_dual_mul_f32 v60, 0x3b000000, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v54, v54, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v63
	v_lshl_add_u32 v55, v61, 20, 0x3c000000
	v_fmac_f32_e32 v59, v51, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v54, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v59, v53, v70 :: v_dual_lshlrev_b32 v54, 8, v20
	v_lshlrev_b32_e32 v53, 16, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v60, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_and_or_b32 v51, 0x80000000, v54, v51
	v_dual_fmac_f32 v59, v52, v57 :: v_dual_and_b32 v52, 0xffff0000, v58
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v54, 0x7fc00000, v55 :: v_dual_fmac_f32 v59, v51, v53
	v_add_nc_u32_e32 v51, 32, v50
	v_and_or_b32 v54, 0x80000000, v20, v54
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v59, v54, v52
	v_add_f32_e32 v48, v48, v59
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s12, v51
	s_cbranch_execz .LBB317_20
; %bb.34:                               ;   in Loop: Header=BB317_22 Depth=1
	ds_load_b128 v[51:54], v49
	ds_load_b128 v[55:58], v49 offset:16
	v_bfe_u32 v61, v21, 8, 3
	v_bfe_u32 v70, v21, 8, 7
	v_bfe_u32 v71, v21, 16, 3
	v_bfe_u32 v75, v22, 8, 7
	v_bfe_u32 v80, v23, 8, 3
	v_cvt_f32_ubyte0_e32 v61, v61
	s_mov_b32 s25, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v80, v80
	v_mul_f32_e32 v61, 0x3b000000, v61
	v_and_b32_e32 v59, 7, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v59, v59
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v66, 16, v54
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_lshlrev_b32 v64, 16, v52
	v_and_b32_e32 v60, 0x7f, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v62, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v62, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v68, 16, v56
	v_lshl_add_u32 v62, v70, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v61, v62, vcc_lo
	v_bfe_u32 v61, v21, 16, 7
	v_cvt_f32_ubyte0_e32 v62, v71
	v_lshlrev_b32_e32 v71, 24, v21
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_lshlrev_b32_e32 v63, 16, v51
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v62, 0x3b000000, v62 :: v_dual_lshlrev_b32 v65, 16, v53
	v_lshl_add_u32 v70, v61, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, 0x7fc00000, v60, vcc_lo
	v_and_or_b32 v59, 0x80000000, v71, v59
	v_bfe_u32 v71, v21, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	v_and_b32_e32 v51, 0xffff0000, v51
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v59, v59, v63, 0
	v_cvt_f32_ubyte0_e32 v71, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v70, vcc_lo
	v_bfe_u32 v70, v21, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_dual_mul_f32 v71, 0x3b000000, v71 :: v_dual_lshlrev_b32 v72, 16, v21
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v73, v70, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v61, 0x7fc00000, v62 :: v_dual_lshlrev_b32 v62, 8, v21
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	v_and_b32_e32 v52, 0xffff0000, v52
	v_and_or_b32 v60, 0x80000000, v72, v60
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v61, 0x80000000, v62, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v73, vcc_lo
	v_bfe_u32 v73, v22, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_lshlrev_b32_e32 v69, 16, v57
	v_fmac_f32_e32 v59, v60, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, 0x7fc00000, v71, vcc_lo
	v_cvt_f32_ubyte0_e32 v71, v73
	v_bfe_u32 v73, v22, 16, 3
	v_dual_fmac_f32 v59, v61, v64 :: v_dual_and_b32 v72, 7, v22
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v70, 0x80000000, v21, v70
	v_mul_f32_e32 v71, 0x3b000000, v71
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_cvt_f32_ubyte0_e32 v62, v72
	v_lshlrev_b32_e32 v67, 16, v55
	v_fmac_f32_e32 v59, v70, v52
	v_bfe_u32 v52, v24, 8, 3
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_and_b32_e32 v74, 0x7f, v22
	v_mul_f32_e32 v62, 0x3b000000, v62
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v52, v52
	v_lshl_add_u32 v72, v74, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	v_and_b32_e32 v53, 0xffff0000, v53
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v52, 0x3b000000, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	v_bfe_u32 v74, v22, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, 0x7fc00000, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v54, 0xffff0000, v54
	v_lshl_add_u32 v76, v74, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v71, 0x7fc00000, v71 :: v_dual_lshlrev_b32 v72, 24, v22
	v_and_or_b32 v62, 0x80000000, v72, v62
	v_bfe_u32 v72, v22, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v59, v62, v65 :: v_dual_and_b32 v64, 0x7f, v24
	v_cvt_f32_ubyte0_e32 v72, v72
	v_lshlrev_b32_e32 v75, 16, v22
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_and_b32_e32 v74, 7, v23
	v_mul_f32_e32 v72, 0x3b000000, v72
	v_and_or_b32 v71, 0x80000000, v75, v71
	v_bfe_u32 v75, v22, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, 0x7fc00000, v73, vcc_lo
	v_and_b32_e32 v76, 0x7f, v23
	v_cvt_f32_ubyte0_e32 v74, v74
	v_bfe_u32 v62, v24, 8, 7
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v55, 0xffff0000, v55
	v_lshl_add_u32 v79, v76, 20, 0x3c000000
	v_dual_mul_f32 v74, 0x3b000000, v74 :: v_dual_fmac_f32 v59, v71, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, v72, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v76
	v_and_b32_e32 v57, 0xffff0000, v57
	v_bfe_u32 v78, v23, 8, 7
	v_lshl_add_u32 v53, v62, 20, 0x3c000000
	v_lshl_add_u32 v65, v64, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, v74, v79, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v77, 8, v22
	v_lshl_add_u32 v75, v78, 20, 0x3c000000
	v_mul_f32_e32 v79, 0x3b000000, v80
	v_bfe_u32 v80, v23, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v76
	v_lshlrev_b32_e32 v76, 24, v23
	v_and_or_b32 v73, 0x80000000, v77, v73
	v_bfe_u32 v77, v23, 24, 3
	v_lshl_add_u32 v63, v80, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, 0x7fc00000, v74, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	v_and_b32_e32 v56, 0xffff0000, v56
	v_cvt_f32_ubyte0_e32 v77, v77
	v_and_or_b32 v72, 0x80000000, v22, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, v79, v75, vcc_lo
	v_lshlrev_b32_e32 v79, 16, v23
	v_and_or_b32 v74, 0x80000000, v76, v74
	v_bfe_u32 v76, v23, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	v_bfe_u32 v78, v23, 16, 7
	v_mul_f32_e32 v77, 0x3b000000, v77
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v76, v76
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, 0x7fc00000, v75, vcc_lo
	v_lshl_add_u32 v81, v78, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	v_mul_f32_e32 v76, 0x3b000000, v76
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v76, v76, v81, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v80
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v77, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v60, 0x7fc00000, v76 :: v_dual_lshlrev_b32 v63, 8, v23
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v60, 0x80000000, v63, v60
	v_and_b32_e32 v63, 7, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v64
	v_cvt_f32_ubyte0_e32 v63, v63
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v51, 0x80000000, v23, v51
	v_mul_f32_e32 v63, 0x3b000000, v63
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v63, v63, v65, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v52, v53, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v62
	v_lshlrev_b32_e32 v63, 24, v24
	v_lshlrev_b32_e32 v62, 16, v24
	v_and_or_b32 v61, 0x80000000, v79, v75
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v52, 0x7fc00000, v52 :: v_dual_fmac_f32 v59, v73, v66
	v_and_or_b32 v53, 0x80000000, v63, v53
	v_bfe_u32 v63, v24, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v52, 0x80000000, v62, v52
	v_fmac_f32_e32 v59, v72, v54
	v_bfe_u32 v54, v24, 16, 3
	v_bfe_u32 v62, v24, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v63
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v59, v74, v67
	v_cvt_f32_ubyte0_e32 v54, v54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v62, v62
	v_fmac_f32_e32 v59, v61, v55
	v_lshl_add_u32 v55, v63, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v54, 0x3b000000, v54
	v_bfe_u32 v61, v24, 24, 7
	v_dual_fmac_f32 v59, v60, v68 :: v_dual_mul_f32 v60, 0x3b000000, v62
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v54, v54, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v63
	v_lshl_add_u32 v55, v61, 20, 0x3c000000
	v_fmac_f32_e32 v59, v51, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v54, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v59, v53, v69 :: v_dual_lshlrev_b32 v54, 8, v24
	v_lshlrev_b32_e32 v53, 16, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v60, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_and_or_b32 v51, 0x80000000, v54, v51
	v_dual_fmac_f32 v59, v52, v57 :: v_dual_and_b32 v52, 0xffff0000, v58
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v54, 0x7fc00000, v55 :: v_dual_fmac_f32 v59, v51, v53
	v_add_nc_u32_e32 v51, 64, v50
	v_and_or_b32 v54, 0x80000000, v24, v54
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v59, v54, v52
	v_add_f32_e32 v48, v48, v59
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s12, v51
	s_cbranch_execz .LBB317_19
; %bb.35:                               ;   in Loop: Header=BB317_22 Depth=1
	ds_load_b128 v[51:54], v49 offset:1024
	ds_load_b128 v[55:58], v49 offset:1040
	v_bfe_u32 v61, v25, 8, 3
	v_bfe_u32 v70, v25, 8, 7
	v_bfe_u32 v71, v25, 16, 3
	v_bfe_u32 v75, v26, 8, 7
	v_bfe_u32 v80, v27, 8, 3
	v_cvt_f32_ubyte0_e32 v61, v61
	s_mov_b32 s26, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v80, v80
	v_mul_f32_e32 v61, 0x3b000000, v61
	v_and_b32_e32 v59, 7, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v59, v59
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v66, 16, v54
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_lshlrev_b32 v64, 16, v52
	v_and_b32_e32 v60, 0x7f, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v62, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v62, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v68, 16, v56
	v_lshl_add_u32 v62, v70, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v61, v62, vcc_lo
	v_bfe_u32 v61, v25, 16, 7
	v_cvt_f32_ubyte0_e32 v62, v71
	v_lshlrev_b32_e32 v71, 24, v25
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_lshlrev_b32_e32 v63, 16, v51
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v62, 0x3b000000, v62 :: v_dual_lshlrev_b32 v65, 16, v53
	v_lshl_add_u32 v70, v61, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, 0x7fc00000, v60, vcc_lo
	v_and_or_b32 v59, 0x80000000, v71, v59
	v_bfe_u32 v71, v25, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	v_and_b32_e32 v51, 0xffff0000, v51
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v59, v59, v63, 0
	v_cvt_f32_ubyte0_e32 v71, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v70, vcc_lo
	v_bfe_u32 v70, v25, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_dual_mul_f32 v71, 0x3b000000, v71 :: v_dual_lshlrev_b32 v72, 16, v25
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v73, v70, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v61, 0x7fc00000, v62 :: v_dual_lshlrev_b32 v62, 8, v25
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	v_and_b32_e32 v52, 0xffff0000, v52
	v_and_or_b32 v60, 0x80000000, v72, v60
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v61, 0x80000000, v62, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v73, vcc_lo
	v_bfe_u32 v73, v26, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_lshlrev_b32_e32 v69, 16, v57
	v_fmac_f32_e32 v59, v60, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, 0x7fc00000, v71, vcc_lo
	v_cvt_f32_ubyte0_e32 v71, v73
	v_bfe_u32 v73, v26, 16, 3
	v_dual_fmac_f32 v59, v61, v64 :: v_dual_and_b32 v72, 7, v26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v70, 0x80000000, v25, v70
	v_mul_f32_e32 v71, 0x3b000000, v71
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_cvt_f32_ubyte0_e32 v62, v72
	v_lshlrev_b32_e32 v67, 16, v55
	v_fmac_f32_e32 v59, v70, v52
	v_bfe_u32 v52, v28, 8, 3
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_and_b32_e32 v74, 0x7f, v26
	v_mul_f32_e32 v62, 0x3b000000, v62
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v52, v52
	v_lshl_add_u32 v72, v74, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	v_and_b32_e32 v53, 0xffff0000, v53
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v52, 0x3b000000, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	v_bfe_u32 v74, v26, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, 0x7fc00000, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v54, 0xffff0000, v54
	v_lshl_add_u32 v76, v74, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v71, 0x7fc00000, v71 :: v_dual_lshlrev_b32 v72, 24, v26
	v_and_or_b32 v62, 0x80000000, v72, v62
	v_bfe_u32 v72, v26, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v59, v62, v65 :: v_dual_and_b32 v64, 0x7f, v28
	v_cvt_f32_ubyte0_e32 v72, v72
	v_lshlrev_b32_e32 v75, 16, v26
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_and_b32_e32 v74, 7, v27
	v_mul_f32_e32 v72, 0x3b000000, v72
	v_and_or_b32 v71, 0x80000000, v75, v71
	v_bfe_u32 v75, v26, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, 0x7fc00000, v73, vcc_lo
	v_and_b32_e32 v76, 0x7f, v27
	v_cvt_f32_ubyte0_e32 v74, v74
	v_bfe_u32 v62, v28, 8, 7
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v55, 0xffff0000, v55
	v_lshl_add_u32 v79, v76, 20, 0x3c000000
	v_dual_mul_f32 v74, 0x3b000000, v74 :: v_dual_fmac_f32 v59, v71, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, v72, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v76
	v_and_b32_e32 v57, 0xffff0000, v57
	v_bfe_u32 v78, v27, 8, 7
	v_lshl_add_u32 v53, v62, 20, 0x3c000000
	v_lshl_add_u32 v65, v64, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, v74, v79, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v77, 8, v26
	v_lshl_add_u32 v75, v78, 20, 0x3c000000
	v_mul_f32_e32 v79, 0x3b000000, v80
	v_bfe_u32 v80, v27, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v76
	v_lshlrev_b32_e32 v76, 24, v27
	v_and_or_b32 v73, 0x80000000, v77, v73
	v_bfe_u32 v77, v27, 24, 3
	v_lshl_add_u32 v63, v80, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, 0x7fc00000, v74, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	v_and_b32_e32 v56, 0xffff0000, v56
	v_cvt_f32_ubyte0_e32 v77, v77
	v_and_or_b32 v72, 0x80000000, v26, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, v79, v75, vcc_lo
	v_lshlrev_b32_e32 v79, 16, v27
	v_and_or_b32 v74, 0x80000000, v76, v74
	v_bfe_u32 v76, v27, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	v_bfe_u32 v78, v27, 16, 7
	v_mul_f32_e32 v77, 0x3b000000, v77
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v76, v76
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, 0x7fc00000, v75, vcc_lo
	v_lshl_add_u32 v81, v78, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	v_mul_f32_e32 v76, 0x3b000000, v76
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v76, v76, v81, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v80
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v77, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v60, 0x7fc00000, v76 :: v_dual_lshlrev_b32 v63, 8, v27
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v60, 0x80000000, v63, v60
	v_and_b32_e32 v63, 7, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v64
	v_cvt_f32_ubyte0_e32 v63, v63
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v51, 0x80000000, v27, v51
	v_mul_f32_e32 v63, 0x3b000000, v63
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v63, v63, v65, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v52, v53, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v62
	v_lshlrev_b32_e32 v63, 24, v28
	v_lshlrev_b32_e32 v62, 16, v28
	v_and_or_b32 v61, 0x80000000, v79, v75
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v52, 0x7fc00000, v52 :: v_dual_fmac_f32 v59, v73, v66
	v_and_or_b32 v53, 0x80000000, v63, v53
	v_bfe_u32 v63, v28, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v52, 0x80000000, v62, v52
	v_fmac_f32_e32 v59, v72, v54
	v_bfe_u32 v54, v28, 16, 3
	v_bfe_u32 v62, v28, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v63
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v59, v74, v67
	v_cvt_f32_ubyte0_e32 v54, v54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v62, v62
	v_fmac_f32_e32 v59, v61, v55
	v_lshl_add_u32 v55, v63, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v54, 0x3b000000, v54
	v_bfe_u32 v61, v28, 24, 7
	v_dual_fmac_f32 v59, v60, v68 :: v_dual_mul_f32 v60, 0x3b000000, v62
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v54, v54, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v63
	v_lshl_add_u32 v55, v61, 20, 0x3c000000
	v_fmac_f32_e32 v59, v51, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v54, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v59, v53, v69 :: v_dual_lshlrev_b32 v54, 8, v28
	v_lshlrev_b32_e32 v53, 16, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v60, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_and_or_b32 v51, 0x80000000, v54, v51
	v_dual_fmac_f32 v59, v52, v57 :: v_dual_and_b32 v52, 0xffff0000, v58
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v54, 0x7fc00000, v55 :: v_dual_fmac_f32 v59, v51, v53
	v_add_nc_u32_e32 v51, 0x60, v50
	v_and_or_b32 v54, 0x80000000, v28, v54
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v59, v54, v52
	v_add_f32_e32 v48, v48, v59
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s12, v51
	s_cbranch_execz .LBB317_18
; %bb.36:                               ;   in Loop: Header=BB317_22 Depth=1
	ds_load_b128 v[51:54], v49 offset:2048
	ds_load_b128 v[55:58], v49 offset:2064
	v_bfe_u32 v61, v29, 8, 3
	v_bfe_u32 v70, v29, 8, 7
	v_bfe_u32 v71, v29, 16, 3
	v_bfe_u32 v75, v30, 8, 7
	v_bfe_u32 v80, v31, 8, 3
	v_cvt_f32_ubyte0_e32 v61, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v80, v80
	v_mul_f32_e32 v61, 0x3b000000, v61
	v_and_b32_e32 v59, 7, v29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v59, v59
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v66, 16, v54
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_lshlrev_b32 v64, 16, v52
	v_and_b32_e32 v60, 0x7f, v29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v62, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v62, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v68, 16, v56
	v_lshl_add_u32 v62, v70, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v61, v62, vcc_lo
	v_bfe_u32 v61, v29, 16, 7
	v_cvt_f32_ubyte0_e32 v62, v71
	v_lshlrev_b32_e32 v71, 24, v29
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_lshlrev_b32_e32 v63, 16, v51
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v62, 0x3b000000, v62 :: v_dual_lshlrev_b32 v65, 16, v53
	v_lshl_add_u32 v70, v61, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, 0x7fc00000, v60, vcc_lo
	v_and_or_b32 v59, 0x80000000, v71, v59
	v_bfe_u32 v71, v29, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	v_and_b32_e32 v51, 0xffff0000, v51
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v59, v59, v63, 0
	v_cvt_f32_ubyte0_e32 v71, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v70, vcc_lo
	v_bfe_u32 v70, v29, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_dual_mul_f32 v71, 0x3b000000, v71 :: v_dual_lshlrev_b32 v72, 16, v29
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v73, v70, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v61, 0x7fc00000, v62 :: v_dual_lshlrev_b32 v62, 8, v29
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	v_and_b32_e32 v52, 0xffff0000, v52
	v_and_or_b32 v60, 0x80000000, v72, v60
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v61, 0x80000000, v62, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v73, vcc_lo
	v_bfe_u32 v73, v30, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_lshlrev_b32_e32 v69, 16, v57
	v_fmac_f32_e32 v59, v60, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, 0x7fc00000, v71, vcc_lo
	v_cvt_f32_ubyte0_e32 v71, v73
	v_bfe_u32 v73, v30, 16, 3
	v_dual_fmac_f32 v59, v61, v64 :: v_dual_and_b32 v72, 7, v30
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v70, 0x80000000, v29, v70
	v_mul_f32_e32 v71, 0x3b000000, v71
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_cvt_f32_ubyte0_e32 v62, v72
	v_lshlrev_b32_e32 v67, 16, v55
	v_fmac_f32_e32 v59, v70, v52
	v_bfe_u32 v52, v32, 8, 3
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_and_b32_e32 v74, 0x7f, v30
	v_mul_f32_e32 v62, 0x3b000000, v62
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v52, v52
	v_lshl_add_u32 v72, v74, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	v_and_b32_e32 v53, 0xffff0000, v53
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v52, 0x3b000000, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	v_bfe_u32 v74, v30, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, 0x7fc00000, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v54, 0xffff0000, v54
	v_lshl_add_u32 v76, v74, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v71, 0x7fc00000, v71 :: v_dual_lshlrev_b32 v72, 24, v30
	v_and_or_b32 v62, 0x80000000, v72, v62
	v_bfe_u32 v72, v30, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v74
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v59, v62, v65 :: v_dual_and_b32 v64, 0x7f, v32
	v_cvt_f32_ubyte0_e32 v72, v72
	v_lshlrev_b32_e32 v75, 16, v30
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v74
	v_and_b32_e32 v74, 7, v31
	v_mul_f32_e32 v72, 0x3b000000, v72
	v_and_or_b32 v71, 0x80000000, v75, v71
	v_bfe_u32 v75, v30, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, 0x7fc00000, v73, vcc_lo
	v_and_b32_e32 v76, 0x7f, v31
	v_cvt_f32_ubyte0_e32 v74, v74
	v_bfe_u32 v62, v32, 8, 7
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_and_b32_e32 v55, 0xffff0000, v55
	v_lshl_add_u32 v79, v76, 20, 0x3c000000
	v_dual_mul_f32 v74, 0x3b000000, v74 :: v_dual_fmac_f32 v59, v71, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, v72, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v76
	v_and_b32_e32 v57, 0xffff0000, v57
	v_bfe_u32 v78, v31, 8, 7
	v_lshl_add_u32 v53, v62, 20, 0x3c000000
	v_lshl_add_u32 v65, v64, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, v74, v79, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v77, 8, v30
	v_lshl_add_u32 v75, v78, 20, 0x3c000000
	v_mul_f32_e32 v79, 0x3b000000, v80
	v_bfe_u32 v80, v31, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v76
	v_lshlrev_b32_e32 v76, 24, v31
	v_and_or_b32 v73, 0x80000000, v77, v73
	v_bfe_u32 v77, v31, 24, 3
	v_lshl_add_u32 v63, v80, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v74, 0x7fc00000, v74, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	v_and_b32_e32 v56, 0xffff0000, v56
	v_cvt_f32_ubyte0_e32 v77, v77
	v_and_or_b32 v72, 0x80000000, v30, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, v79, v75, vcc_lo
	v_lshlrev_b32_e32 v79, 16, v31
	v_and_or_b32 v74, 0x80000000, v76, v74
	v_bfe_u32 v76, v31, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	v_bfe_u32 v78, v31, 16, 7
	v_mul_f32_e32 v77, 0x3b000000, v77
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v76, v76
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, 0x7fc00000, v75, vcc_lo
	v_lshl_add_u32 v81, v78, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v78
	v_mul_f32_e32 v76, 0x3b000000, v76
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v76, v76, v81, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v80
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v77, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v78
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v60, 0x7fc00000, v76 :: v_dual_lshlrev_b32 v63, 8, v31
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v60, 0x80000000, v63, v60
	v_and_b32_e32 v63, 7, v32
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v64
	v_cvt_f32_ubyte0_e32 v63, v63
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v51, 0x80000000, v31, v51
	v_mul_f32_e32 v63, 0x3b000000, v63
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v63, v63, v65, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v52, v53, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v62
	v_lshlrev_b32_e32 v63, 24, v32
	v_lshlrev_b32_e32 v62, 16, v32
	v_and_or_b32 v61, 0x80000000, v79, v75
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v52, 0x7fc00000, v52 :: v_dual_fmac_f32 v59, v73, v66
	v_and_or_b32 v53, 0x80000000, v63, v53
	v_bfe_u32 v63, v32, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v52, 0x80000000, v62, v52
	v_fmac_f32_e32 v59, v72, v54
	v_bfe_u32 v54, v32, 16, 3
	v_bfe_u32 v62, v32, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v63
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v59, v74, v67
	v_cvt_f32_ubyte0_e32 v54, v54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v62, v62
	v_fmac_f32_e32 v59, v61, v55
	v_lshl_add_u32 v55, v63, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v54, 0x3b000000, v54
	v_bfe_u32 v61, v32, 24, 7
	v_dual_fmac_f32 v59, v60, v68 :: v_dual_mul_f32 v60, 0x3b000000, v62
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v54, v54, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v63
	v_lshl_add_u32 v55, v61, 20, 0x3c000000
	v_fmac_f32_e32 v59, v51, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v54, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v59, v53, v69 :: v_dual_lshlrev_b32 v54, 8, v32
	v_lshlrev_b32_e32 v53, 16, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v60, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	v_and_or_b32 v51, 0x80000000, v54, v51
	v_dual_fmac_f32 v59, v52, v57 :: v_dual_and_b32 v52, 0xffff0000, v58
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v54, 0x7fc00000, v55 :: v_dual_fmac_f32 v59, v51, v53
	v_and_or_b32 v54, 0x80000000, v32, v54
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v59, v54, v52
	v_add_f32_e32 v48, v48, v59
	s_branch .LBB317_18
.LBB317_37:
	s_or_b32 exec_lo, exec_lo, s22
.LBB317_38:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	s_or_b32 exec_lo, exec_lo, s15
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v17, -1, 0
	s_mov_b32 s7, 0
	s_mov_b32 s15, exec_lo
	v_xor_b32_e32 v18, 16, v17
	v_xor_b32_e32 v19, 8, v17
	v_xor_b32_e32 v20, 4, v17
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, 32, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v18, v17, v18, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v19, v17, v19, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v19, 2, v19
	v_lshlrev_b32_e32 v18, 2, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v20, v17, v20, vcc_lo
	ds_bpermute_b32 v18, v18, v48
	v_lshlrev_b32_e32 v20, 2, v20
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v48, v18
	ds_bpermute_b32 v19, v19, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v19
	ds_bpermute_b32 v19, v20, v18
	v_xor_b32_e32 v20, 2, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v20, v17, v20, vcc_lo
	v_lshlrev_b32_e32 v20, 2, v20
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v19
	ds_bpermute_b32 v19, v20, v18
	v_xor_b32_e32 v20, 1, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, v17, v20, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v17, v18, v19 :: v_dual_lshlrev_b32 v20, 2, v17
	ds_bpermute_b32 v18, v20, v17
	v_cmpx_eq_u32_e32 0, v41
	s_cbranch_execz .LBB317_44
; %bb.39:
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v18, s9, v17
	v_and_b32_e32 v17, 0x7fffffff, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v17
                                        ; implicit-def: $vgpr17
	s_and_saveexec_b32 s22, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s22, exec_lo, s22
; %bb.40:
	v_bfe_u32 v17, v18, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v17, v18, v17, 0x7fff
                                        ; implicit-def: $vgpr18
	v_lshrrev_b32_e32 v17, 16, v17
; %bb.41:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s22, s22
; %bb.42:
	v_lshrrev_b32_e32 v17, 16, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v17, 64, v17
; %bb.43:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s22
	v_lshlrev_b64_e32 v[18:19], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v18, vcc_lo, s18, v18
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v19, null, s19, v19, vcc_lo
	global_store_b16 v[18:19], v17, off
.LBB317_44:
	s_or_b32 exec_lo, exec_lo, s15
.LBB317_45:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s7
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB317_82
; %bb.46:
	v_mov_b32_e32 v19, 0
	s_and_saveexec_b32 s7, s6
	s_cbranch_execz .LBB317_76
; %bb.47:
	v_mov_b32_e32 v19, 0
	s_and_saveexec_b32 s6, s5
	s_cbranch_execz .LBB317_55
; %bb.48:
	v_lshl_add_u32 v21, v41, 5, 0
	v_perm_b32 v22, 0, v13, 0x10c000c
	v_perm_b32 v13, 0, v13, 0x30c020c
	v_perm_b32 v27, 0, v14, 0x10c000c
	v_perm_b32 v14, 0, v14, 0x30c020c
	s_wait_dscnt 0x0
	ds_load_b128 v[17:20], v21
	v_lshrrev_b32_e32 v25, 1, v22
	v_and_b32_e32 v26, 0x80008000, v22
	v_lshrrev_b32_e32 v28, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	ds_load_b128 v[21:24], v21 offset:16
	v_and_or_b32 v25, 0x3f803f80, v25, v26
	v_lshrrev_b32_e32 v26, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_and_or_b32 v13, 0x3f803f80, v28, v13
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v26, 0x3f803f80, v26, v27
	v_lshrrev_b32_e32 v27, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v17, v25, v17, 0
	v_perm_b32 v25, 0, v15, 0x10c000c
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v27, v14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v13, v13, v18, v17
	v_lshrrev_b32_e32 v17, 1, v25
	v_and_b32_e32 v18, 0x80008000, v25
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v13, v26, v19, v13
	v_perm_b32 v19, 0, v16, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v17, v18
	v_lshrrev_b32_e32 v18, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v13, v14, v20, v13
	v_lshrrev_b32_e32 v14, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_and_or_b32 v15, 0x3f803f80, v18, v15
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v13, v17, v21, v13
	v_and_or_b32 v14, 0x3f803f80, v14, v19
	v_lshrrev_b32_e32 v17, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v13, v15, v22, v13
	v_and_or_b32 v15, 0x3f803f80, v17, v16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v13, v14, v23, v13
	v_dot2_f32_f16 v19, v15, v24, v13
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB317_54
; %bb.49:
	v_lshl_add_u32 v17, v46, 5, 0
	v_perm_b32 v18, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_perm_b32 v25, 0, v10, 0x10c000c
	v_perm_b32 v10, 0, v10, 0x30c020c
	ds_load_b128 v[13:16], v17
	ds_load_b128 v[20:23], v17 offset:16
	v_lshrrev_b32_e32 v24, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_lshrrev_b32_e32 v17, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v18, 0x3f803f80, v24, v18
	v_lshrrev_b32_e32 v24, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_and_or_b32 v9, 0x3f803f80, v17, v9
	v_perm_b32 v17, 0, v11, 0x10c000c
	v_perm_b32 v11, 0, v11, 0x30c020c
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v13, v18, v13, v19
	v_and_or_b32 v18, 0x3f803f80, v24, v25
	v_lshrrev_b32_e32 v19, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v9, v9, v14, v13
	v_lshrrev_b32_e32 v13, 1, v17
	v_and_b32_e32 v14, 0x80008000, v17
	v_and_or_b32 v10, 0x3f803f80, v19, v10
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v9, v18, v15, v9
	v_perm_b32 v15, 0, v12, 0x10c000c
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_dot2_f32_f16 v9, v10, v16, v9
	v_lshrrev_b32_e32 v10, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_perm_b32 v12, 0, v12, 0x30c020c
	v_and_or_b32 v11, 0x3f803f80, v14, v11
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v9, v13, v20, v9
	v_and_or_b32 v10, 0x3f803f80, v10, v15
	v_lshrrev_b32_e32 v13, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v9, v11, v21, v9
	v_and_or_b32 v11, 0x3f803f80, v13, v12
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v9, v10, v22, v9
	v_dot2_f32_f16 v19, v11, v23, v9
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB317_53
; %bb.50:
	v_lshl_add_u32 v13, v45, 5, 0
	v_perm_b32 v14, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v20, 0, v6, 0x10c000c
	v_perm_b32 v6, 0, v6, 0x30c020c
	ds_load_b128 v[9:12], v13
	v_lshrrev_b32_e32 v17, 1, v14
	v_and_b32_e32 v18, 0x80008000, v14
	v_lshrrev_b32_e32 v21, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	ds_load_b128 v[13:16], v13 offset:16
	v_and_or_b32 v17, 0x3f803f80, v17, v18
	v_lshrrev_b32_e32 v18, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_and_or_b32 v5, 0x3f803f80, v21, v5
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v18, 0x3f803f80, v18, v20
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v9, v17, v9, v19
	v_perm_b32 v17, 0, v7, 0x10c000c
	v_lshrrev_b32_e32 v19, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_dot2_f32_f16 v5, v5, v10, v9
	v_lshrrev_b32_e32 v9, 1, v17
	v_and_b32_e32 v10, 0x80008000, v17
	v_and_or_b32 v6, 0x3f803f80, v19, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v5, v18, v11, v5
	v_perm_b32 v11, 0, v8, 0x10c000c
	v_and_or_b32 v9, 0x3f803f80, v9, v10
	v_lshrrev_b32_e32 v10, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v5, v6, v12, v5
	v_lshrrev_b32_e32 v6, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_and_or_b32 v7, 0x3f803f80, v10, v7
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v5, v9, v13, v5
	v_and_or_b32 v6, 0x3f803f80, v6, v11
	v_lshrrev_b32_e32 v9, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v5, v7, v14, v5
	v_and_or_b32 v7, 0x3f803f80, v9, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v5, v6, v15, v5
	v_dot2_f32_f16 v19, v7, v16, v5
	s_and_saveexec_b32 s3, s2
	s_cbranch_execz .LBB317_52
; %bb.51:
	v_lshl_add_u32 v9, v44, 5, 0
	v_perm_b32 v10, 0, v1, 0x10c000c
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_perm_b32 v15, 0, v2, 0x10c000c
	v_perm_b32 v2, 0, v2, 0x30c020c
	ds_load_b128 v[5:8], v9
	v_lshrrev_b32_e32 v13, 1, v10
	v_and_b32_e32 v14, 0x80008000, v10
	v_lshrrev_b32_e32 v16, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	ds_load_b128 v[9:12], v9 offset:16
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_and_or_b32 v1, 0x3f803f80, v16, v1
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v14, 0x3f803f80, v14, v15
	v_lshrrev_b32_e32 v15, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v5, v13, v5, v19
	v_perm_b32 v13, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v2, 0x3f803f80, v15, v2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v1, v1, v6, v5
	v_lshrrev_b32_e32 v5, 1, v13
	v_and_b32_e32 v6, 0x80008000, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v1, v14, v7, v1
	v_perm_b32 v7, 0, v4, 0x10c000c
	v_and_or_b32 v5, 0x3f803f80, v5, v6
	v_lshrrev_b32_e32 v6, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v1, v2, v8, v1
	v_lshrrev_b32_e32 v2, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v6, v3
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v5, v9, v1
	v_and_or_b32 v2, 0x3f803f80, v2, v7
	v_lshrrev_b32_e32 v5, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v1, v3, v10, v1
	v_and_or_b32 v3, 0x3f803f80, v5, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v1, v2, v11, v1
	v_dot2_f32_f16 v19, v3, v12, v1
.LBB317_52:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB317_53:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_54:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB317_55:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s5, exec_lo
	v_cmpx_lt_u32_e32 0x9f, v47
	s_cbranch_execz .LBB317_75
; %bb.56:
	v_lshlrev_b32_e32 v1, 5, v41
	v_add_co_u32 v2, vcc_lo, v35, v42
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v36, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add3_u32 v20, v1, 0, 0x1000
	v_add_co_u32 v1, vcc_lo, s20, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_ci_u32_e64 v2, null, s21, v3, vcc_lo
	v_or_b32_e32 v21, 0xe0, v41
	v_add_co_u32 v17, vcc_lo, 0xe00, v1
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, 0, v2, vcc_lo
	s_mov_b32 s6, 0
	s_mov_b32 s15, 4
	s_branch .LBB317_61
.LBB317_57:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
.LBB317_58:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB317_59:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_60:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s20
	s_add_co_i32 s15, s15, 4
	v_add_co_u32 v17, s2, 0x800, v17
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s15, v43
	v_add_nc_u32_e32 v20, 0x1000, v20
	v_add_nc_u32_e32 v21, 0x80, v21
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v18, null, 0, v18, s2
	s_or_b32 s6, vcc_lo, s6
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s6
	s_cbranch_execz .LBB317_74
.LBB317_61:                             ; =>This Inner Loop Header: Depth=1
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xffffffa0, v21
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v16, 0
	v_mov_b32_e32 v13, 0
	v_mov_b32_e32 v15, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e64 s4, s12, v1
	s_and_saveexec_b32 s2, s4
	s_cbranch_execz .LBB317_63
; %bb.62:                               ;   in Loop: Header=BB317_61 Depth=1
	global_load_b128 v[13:16], v[17:18], off offset:-1536 th:TH_LOAD_NT
.LBB317_63:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_subrev_nc_u32_e32 v1, 64, v21
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s3, s12, v1
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB317_65
; %bb.64:                               ;   in Loop: Header=BB317_61 Depth=1
	global_load_b128 v[9:12], v[17:18], off offset:-1024 th:TH_LOAD_NT
.LBB317_65:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_subrev_nc_u32_e32 v2, 32, v21
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v6, 0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s2, s12, v2
	s_and_saveexec_b32 s20, s2
	s_cbranch_execz .LBB317_67
; %bb.66:                               ;   in Loop: Header=BB317_61 Depth=1
	global_load_b128 v[5:8], v[17:18], off offset:-512 th:TH_LOAD_NT
.LBB317_67:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s20
	v_cmp_gt_i32_e32 vcc_lo, s12, v21
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0
	v_mov_b32_e32 v4, 0
	s_and_saveexec_b32 s20, vcc_lo
	s_cbranch_execz .LBB317_69
; %bb.68:                               ;   in Loop: Header=BB317_61 Depth=1
	global_load_b128 v[1:4], v[17:18], off th:TH_LOAD_NT
.LBB317_69:                             ;   in Loop: Header=BB317_61 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s20
	s_and_saveexec_b32 s20, s4
	s_cbranch_execz .LBB317_60
; %bb.70:                               ;   in Loop: Header=BB317_61 Depth=1
	ds_load_b128 v[22:25], v20
	s_wait_loadcnt 0x0
	v_perm_b32 v26, 0, v13, 0x10c000c
	v_perm_b32 v13, 0, v13, 0x30c020c
	v_perm_b32 v32, 0, v14, 0x10c000c
	v_perm_b32 v14, 0, v14, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v30, 1, v26
	v_and_b32_e32 v31, 0x80008000, v26
	v_lshrrev_b32_e32 v35, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	ds_load_b128 v[26:29], v20 offset:16
	v_and_or_b32 v30, 0x3f803f80, v30, v31
	v_lshrrev_b32_e32 v31, 1, v32
	v_and_b32_e32 v32, 0x80008000, v32
	v_and_or_b32 v13, 0x3f803f80, v35, v13
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v19, v30, v22, v19
	v_perm_b32 v22, 0, v15, 0x10c000c
	v_and_or_b32 v30, 0x3f803f80, v31, v32
	v_lshrrev_b32_e32 v31, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_dot2_f32_f16 v13, v13, v23, v19
	v_lshrrev_b32_e32 v19, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v31, v14
	v_dot2_f32_f16 v13, v30, v24, v13
	v_perm_b32 v23, 0, v16, 0x10c000c
	v_and_or_b32 v19, 0x3f803f80, v19, v22
	v_lshrrev_b32_e32 v22, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v13, v14, v25, v13
	v_lshrrev_b32_e32 v14, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_and_or_b32 v15, 0x3f803f80, v22, v15
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v13, v19, v26, v13
	v_and_or_b32 v14, 0x3f803f80, v14, v23
	v_lshrrev_b32_e32 v19, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v13, v15, v27, v13
	v_and_or_b32 v15, 0x3f803f80, v19, v16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v13, v14, v28, v13
	v_dot2_f32_f16 v19, v15, v29, v13
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB317_59
; %bb.71:                               ;   in Loop: Header=BB317_61 Depth=1
	ds_load_b128 v[13:16], v20 offset:1024
	v_perm_b32 v22, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_perm_b32 v28, 0, v10, 0x10c000c
	v_perm_b32 v10, 0, v10, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v26, 1, v22
	v_and_b32_e32 v27, 0x80008000, v22
	v_lshrrev_b32_e32 v29, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	ds_load_b128 v[22:25], v20 offset:1040
	v_and_or_b32 v26, 0x3f803f80, v26, v27
	v_lshrrev_b32_e32 v27, 1, v28
	v_and_b32_e32 v28, 0x80008000, v28
	v_and_or_b32 v9, 0x3f803f80, v29, v9
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v13, v26, v13, v19
	v_perm_b32 v19, 0, v11, 0x10c000c
	v_and_or_b32 v26, 0x3f803f80, v27, v28
	v_lshrrev_b32_e32 v27, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_dot2_f32_f16 v9, v9, v14, v13
	v_lshrrev_b32_e32 v13, 1, v19
	v_and_b32_e32 v14, 0x80008000, v19
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_and_or_b32 v10, 0x3f803f80, v27, v10
	v_dot2_f32_f16 v9, v26, v15, v9
	v_perm_b32 v15, 0, v12, 0x10c000c
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_dot2_f32_f16 v9, v10, v16, v9
	v_lshrrev_b32_e32 v10, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_perm_b32 v12, 0, v12, 0x30c020c
	v_and_or_b32 v11, 0x3f803f80, v14, v11
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v9, v13, v22, v9
	v_and_or_b32 v10, 0x3f803f80, v10, v15
	v_lshrrev_b32_e32 v13, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v9, v11, v23, v9
	v_and_or_b32 v11, 0x3f803f80, v13, v12
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v9, v10, v24, v9
	v_dot2_f32_f16 v19, v11, v25, v9
	s_and_saveexec_b32 s3, s2
	s_cbranch_execz .LBB317_58
; %bb.72:                               ;   in Loop: Header=BB317_61 Depth=1
	ds_load_b128 v[9:12], v20 offset:2048
	v_perm_b32 v13, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v24, 0, v6, 0x10c000c
	v_perm_b32 v6, 0, v6, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v22, 1, v13
	v_and_b32_e32 v23, 0x80008000, v13
	v_lshrrev_b32_e32 v25, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	ds_load_b128 v[13:16], v20 offset:2064
	v_and_or_b32 v22, 0x3f803f80, v22, v23
	v_lshrrev_b32_e32 v23, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v5, 0x3f803f80, v25, v5
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v9, v22, v9, v19
	v_perm_b32 v19, 0, v7, 0x10c000c
	v_and_or_b32 v22, 0x3f803f80, v23, v24
	v_lshrrev_b32_e32 v23, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v5, v5, v10, v9
	v_lshrrev_b32_e32 v9, 1, v19
	v_and_b32_e32 v10, 0x80008000, v19
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v23, v6
	v_dot2_f32_f16 v5, v22, v11, v5
	v_perm_b32 v11, 0, v8, 0x10c000c
	v_and_or_b32 v9, 0x3f803f80, v9, v10
	v_lshrrev_b32_e32 v10, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v5, v6, v12, v5
	v_lshrrev_b32_e32 v6, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_and_or_b32 v7, 0x3f803f80, v10, v7
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v5, v9, v13, v5
	v_and_or_b32 v6, 0x3f803f80, v6, v11
	v_lshrrev_b32_e32 v9, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v5, v7, v14, v5
	v_and_or_b32 v7, 0x3f803f80, v9, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v5, v6, v15, v5
	v_dot2_f32_f16 v19, v7, v16, v5
	s_and_saveexec_b32 s2, vcc_lo
	s_cbranch_execz .LBB317_57
; %bb.73:                               ;   in Loop: Header=BB317_61 Depth=1
	ds_load_b128 v[5:8], v20 offset:3072
	v_perm_b32 v9, 0, v1, 0x10c000c
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_perm_b32 v15, 0, v2, 0x10c000c
	v_perm_b32 v2, 0, v2, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v13, 1, v9
	v_and_b32_e32 v14, 0x80008000, v9
	v_lshrrev_b32_e32 v16, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	ds_load_b128 v[9:12], v20 offset:3088
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_and_or_b32 v1, 0x3f803f80, v16, v1
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v14, 0x3f803f80, v14, v15
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v5, v13, v5, v19
	v_perm_b32 v13, 0, v3, 0x10c000c
	v_lshrrev_b32_e32 v15, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_dot2_f32_f16 v1, v1, v6, v5
	v_lshrrev_b32_e32 v5, 1, v13
	v_and_b32_e32 v6, 0x80008000, v13
	v_and_or_b32 v2, 0x3f803f80, v15, v2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v1, v14, v7, v1
	v_perm_b32 v7, 0, v4, 0x10c000c
	v_and_or_b32 v5, 0x3f803f80, v5, v6
	v_lshrrev_b32_e32 v6, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v1, v2, v8, v1
	v_lshrrev_b32_e32 v2, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v6, v3
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v5, v9, v1
	v_and_or_b32 v2, 0x3f803f80, v2, v7
	v_lshrrev_b32_e32 v5, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v1, v3, v10, v1
	v_and_or_b32 v3, 0x3f803f80, v5, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v1, v2, v11, v1
	v_dot2_f32_f16 v19, v3, v12, v1
	s_branch .LBB317_57
.LBB317_74:
	s_or_b32 exec_lo, exec_lo, s6
.LBB317_75:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB317_76:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v1, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v2, 16, v1
	v_xor_b32_e32 v3, 8, v1
	v_xor_b32_e32 v4, 4, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v3, 2, v3
	v_lshlrev_b32_e32 v2, 2, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	ds_bpermute_b32 v2, v2, v19
	v_lshlrev_b32_e32 v4, 2, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v19, v2
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	v_xor_b32_e32 v4, 2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	v_lshlrev_b32_e32 v4, 2, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	v_xor_b32_e32 v4, 1, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo
	v_cmp_eq_u32_e32 vcc_lo, 0, v41
	s_wait_dscnt 0x0
	v_dual_add_f32 v1, v2, v3 :: v_dual_lshlrev_b32 v4, 2, v1
	ds_bpermute_b32 v2, v4, v1
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB317_82
; %bb.77:
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v1, 0x47800000, v1
	v_mul_f32_e32 v2, s9, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s2, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s2, exec_lo, s2
; %bb.78:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.79:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s2, s2
; %bb.80:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.81:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_lshlrev_b64_e32 v[2:3], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, s18, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s19, v3, vcc_lo
	global_store_b16 v[2:3], v1, off
.LBB317_82:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_mov_b32 s3, 0
.LBB317_83:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s3
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB317_165
; %bb.84:
	s_load_b64 s[18:19], s[0:1], 0x8
	s_lshl_b64 s[2:3], s[16:17], 3
	s_ashr_i32 s21, s13, 31
	s_wait_alu 0xfffe
	v_or_b32_e32 v33, s2, v40
	v_dual_mov_b32 v34, s3 :: v_dual_mov_b32 v5, 0
	s_lshr_b32 s2, s21, 28
	s_mul_i32 s3, s3, s13
	s_delay_alu instid0(VALU_DEP_2)
	v_mul_lo_u32 v1, v33, s21
	v_mad_co_u64_u32 v[35:36], null, v33, s13, 0
	s_ashr_i32 s15, s14, 31
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s13, s2
	v_cmp_gt_i64_e32 vcc_lo, s[14:15], v[33:34]
	s_wait_alu 0xfffe
	s_ashr_i32 s12, s2, 4
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v40, 4, v39
	v_add3_u32 v36, v36, v1, s3
	s_wait_alu 0xfffe
	v_cmp_gt_i32_e64 s5, s12, v39
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0
	s_wait_kmcnt 0x0
	s_cmp_lg_u64 s[18:19], 0
	v_add_co_u32 v17, s2, s18, v35
	s_wait_dscnt 0x0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v18, null, s19, v36, s2
	s_cselect_b32 s2, -1, 0
	v_mov_b32_e32 v16, 0
	s_wait_alu 0xfffe
	s_and_b32 s16, s2, vcc_lo
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s3, s16, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB317_86
; %bb.85:
	v_add_co_u32 v1, vcc_lo, v17, v40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v18, vcc_lo
	global_load_b128 v[13:16], v[1:2], off th:TH_LOAD_NT
.LBB317_86:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_or_b32_e32 v44, 32, v39
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0
	v_mov_b32_e32 v8, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s4, s12, v44
	s_and_b32 s3, s16, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s3
	s_cbranch_execz .LBB317_88
; %bb.87:
	v_add_co_u32 v1, vcc_lo, v17, v40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v18, vcc_lo
	global_load_b128 v[5:8], v[1:2], off offset:512 th:TH_LOAD_NT
.LBB317_88:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	s_load_b64 s[6:7], s[0:1], 0x10
	v_or_b32_e32 v43, 64, v39
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v10, 0
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v12, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s3, s12, v43
	v_mov_b32_e32 v11, 0
	s_and_b32 s8, s16, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s8
	s_cbranch_execz .LBB317_90
; %bb.89:
	v_add_co_u32 v2, vcc_lo, v17, v40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v18, vcc_lo
	global_load_b128 v[9:12], v[2:3], off offset:1024 th:TH_LOAD_NT
.LBB317_90:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_or_b32_e32 v42, 0x60, v39
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0
	v_mov_b32_e32 v4, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s2, s12, v42
	s_and_b32 s9, s16, s2
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s9
	s_cbranch_execz .LBB317_92
; %bb.91:
	v_add_co_u32 v1, vcc_lo, v17, v40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v18, vcc_lo
	global_load_b128 v[1:4], v[1:2], off offset:1536 th:TH_LOAD_NT
.LBB317_92:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_wait_kmcnt 0x0
	s_load_b64 s[14:15], s[6:7], 0x0
	s_load_b64 s[8:9], s[0:1], 0x18
	s_mov_b32 s22, 0
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s15, 0
	s_cselect_b32 s20, -1, 0
	s_cmp_ngt_f32 s15, 0
	s_cselect_b32 s17, -1, 0
	s_lshr_b32 s6, s21, 29
	s_mov_b32 s21, exec_lo
	s_wait_alu 0xfffe
	s_add_co_i32 s6, s13, s6
	s_wait_alu 0xfffe
	s_ashr_i32 s13, s6, 3
	s_wait_alu 0xfffe
	v_cmpx_gt_i32_e64 s13, v0
	s_cbranch_execz .LBB317_97
; %bb.93:
	s_load_b32 s0, s[0:1], 0x54
	v_lshlrev_b32_e32 v17, 4, v0
	s_mov_b32 s23, 0xc3e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_co_u32 v18, s1, s10, v17
	v_add_co_ci_u32_e64 v19, null, s11, 0, s1
	v_add_nc_u32_e32 v23, 0, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_u32 v21, vcc_lo, v18, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v22, null, 0, v19, vcc_lo
	s_wait_kmcnt 0x0
	s_and_b32 s10, s0, 0xffff
	s_wait_alu 0xfffe
	s_lshl_b32 s11, s10, 4
	s_branch .LBB317_95
.LBB317_94:                             ;   in Loop: Header=BB317_95 Depth=1
	v_add_nc_u32_e32 v0, s10, v0
	v_add_co_u32 v21, s0, v21, s11
	s_wait_loadcnt 0x0
	ds_store_b128 v23, v[17:20]
	v_add_nc_u32_e32 v23, s11, v23
	v_cmp_le_i32_e32 vcc_lo, s13, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v22, null, 0, v22, s0
	s_or_b32 s22, vcc_lo, s22
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s22
	s_cbranch_execz .LBB317_97
.LBB317_95:                             ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[17:20], v[21:22], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s20
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_94
; %bb.96:                               ;   in Loop: Header=BB317_95 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v24, 16, v17
	v_and_b32_e32 v17, 0xffff0000, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v26, null, s15, s15, v17
	v_rcp_f32_e32 v30, v26
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v45, -v26, v30, 1.0
	v_fmac_f32_e32 v30, v45, v30
	v_div_scale_f32 v46, s0, v17, s15, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v49, v46, v30
	v_div_scale_f32 v25, null, s15, s15, v24
	v_div_scale_f32 v37, vcc_lo, v24, s15, v24
	v_rcp_f32_e32 v29, v25
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v41, -v25, v29, 1.0
	v_dual_fmac_f32 v29, v41, v29 :: v_dual_lshlrev_b32 v28, 16, v19
	v_lshlrev_b32_e32 v27, 16, v18
	v_and_b32_e32 v18, 0xffff0000, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_div_scale_f32 v50, null, s15, s15, v28
	v_mul_f32_e32 v48, v37, v29
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_div_scale_f32 v31, null, s15, s15, v27
	v_div_scale_f32 v41, null, s15, s15, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v52, -v25, v48, v37
	v_rcp_f32_e32 v38, v31
	v_div_scale_f32 v47, s1, v27, s15, v27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v51, v41
	v_fmac_f32_e32 v48, v52, v29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)
	v_fma_f32 v25, -v25, v48, v37
	v_fma_f32 v45, -v31, v38, 1.0
	v_and_b32_e32 v19, 0xffff0000, v19
	s_delay_alu instid0(TRANS32_DEP_1)
	v_fma_f32 v54, -v41, v51, 1.0
	s_wait_alu 0xfffd
	v_div_fmas_f32 v25, v25, v29, v48
	v_fmac_f32_e32 v38, v45, v38
	v_fma_f32 v45, -v26, v49, v46
	v_lshlrev_b32_e32 v32, 16, v20
	s_mov_b32 vcc_lo, s0
	v_fmac_f32_e32 v51, v54, v51
	v_div_scale_f32 v53, s6, v18, s15, v18
	v_fmac_f32_e32 v49, v45, v30
	v_rcp_f32_e32 v45, v50
	v_mul_f32_e32 v52, v47, v38
	v_div_fixup_f32 v24, v25, s15, v24
	v_div_scale_f32 v29, null, s15, s15, v19
	v_fma_f32 v26, -v26, v49, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v37, -v31, v52, v47
	v_med3_num_f32 v24, v24, s23, 0x43e00000
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_div_fmas_f32 v26, v26, v30, v49
	v_fma_f32 v25, -v50, v45, 1.0
	v_and_b32_e32 v20, 0xffff0000, v20
	v_fmac_f32_e32 v52, v37, v38
	s_mov_b32 vcc_lo, s1
	v_div_fixup_f32 v17, v26, s15, v17
	v_mul_f32_e32 v26, v53, v51
	v_fmac_f32_e32 v45, v25, v45
	v_div_scale_f32 v48, null, s15, s15, v20
	v_div_scale_f32 v25, s0, v28, s15, v28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fma_f32 v37, -v41, v26, v53
	v_med3_num_f32 v17, v17, s23, 0x43e00000
	v_fmac_f32_e32 v26, v37, v51
	v_rcp_f32_e32 v37, v48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_fma_f32 v41, -v41, v26, v53
	v_fma_f32 v54, -v48, v37, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v37, v54, v37
	v_fma_f32 v30, -v31, v52, v47
	v_rcp_f32_e32 v31, v29
	s_wait_alu 0xfffe
	v_div_fmas_f32 v30, v30, v38, v52
	v_div_scale_f32 v38, null, s15, s15, v32
	s_mov_b32 vcc_lo, s6
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v41, v51, v26
	v_rcp_f32_e32 v47, v38
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fma_f32 v46, -v29, v31, 1.0
	v_div_fixup_f32 v27, v30, s15, v27
	s_mov_b32 vcc_lo, s0
	v_div_fixup_f32 v18, v26, s15, v18
	v_fmac_f32_e32 v31, v46, v31
	v_div_scale_f32 v46, s1, v19, s15, v19
	v_med3_num_f32 v27, v27, s23, 0x43e00000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_fma_f32 v49, -v38, v47, 1.0
	v_med3_num_f32 v18, v18, s23, 0x43e00000
	v_mul_f32_e32 v53, v46, v31
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v47, v49, v47
	v_div_scale_f32 v49, s7, v32, s15, v32
	v_fma_f32 v41, -v29, v53, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v51, v49, v47
	v_fmac_f32_e32 v53, v41, v31
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v26, -v38, v51, v49
	v_mul_f32_e32 v30, v25, v45
	v_fma_f32 v29, -v29, v53, v46
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v51, v26, v47
	v_fma_f32 v52, -v50, v30, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v30, v52, v45
	v_div_scale_f32 v52, s6, v20, s15, v20
	v_fma_f32 v25, -v50, v30, v25
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v41, v52, v37
	s_wait_alu 0xfffe
	v_div_fmas_f32 v25, v25, v45, v30
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v30, -v48, v41, v52
	s_mov_b32 vcc_lo, s1
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v29, v31, v53
	v_div_fixup_f32 v25, v25, s15, v28
	v_fmac_f32_e32 v41, v30, v37
	v_fma_f32 v28, -v38, v51, v49
	s_mov_b32 vcc_lo, s7
	v_div_fixup_f32 v19, v26, s15, v19
	v_mov_b32_e32 v29, 0
	v_fma_f32 v26, -v48, v41, v52
	s_wait_alu 0xfffe
	v_div_fmas_f32 v28, v28, v47, v51
	s_mov_b32 vcc_lo, s6
	v_med3_num_f32 v25, v25, s23, 0x43e00000
	v_med3_num_f32 v19, v19, s23, 0x43e00000
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v26, v37, v41
	v_div_fixup_f32 v28, v28, s15, v32
	v_cvt_pk_fp8_f32 v29, v24, v17
	v_mov_b32_e32 v17, 0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v20, v26, s15, v20
	v_med3_num_f32 v24, v28, s23, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_pk_fp8_f32 v29, v27, v18 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v17, v25, v19
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_med3_num_f32 v20, v20, s23, 0x43e00000
	v_perm_b32 v18, 0, v29, 0x10c000c
	v_perm_b32 v19, 0, v29, 0x30c020c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v17, v24, v20 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v20, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_lshrrev_b32_e32 v25, 1, v19
	v_perm_b32 v24, 0, v17, 0x10c000c
	v_perm_b32 v17, 0, v17, 0x30c020c
	v_and_b32_e32 v19, 0x80008000, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshrrev_b32_e32 v26, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_lshrrev_b32_e32 v27, 1, v17
	v_and_b32_e32 v28, 0x80008000, v17
	v_and_or_b32 v17, 0x3f803f80, v20, v18
	v_and_or_b32 v18, 0x3f803f80, v25, v19
	v_and_or_b32 v19, 0x3f803f80, v26, v24
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v20, 0x3f803f80, v27, v28
	s_branch .LBB317_94
.LBB317_97:
	s_or_b32 exec_lo, exec_lo, s21
	s_wait_storecnt 0x0
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s0, s16
	s_cbranch_execz .LBB317_165
; %bb.98:
	v_xad_u32 v0, v39, 31, s12
	s_and_b32 s0, s20, exec_lo
	s_cselect_b32 s0, s15, 1.0
	s_and_b32 vcc_lo, exec_lo, s17
	s_wait_alu 0xfffe
	s_mul_f32 s6, s14, s0
	v_ashrrev_i32_e32 v17, 31, v0
	v_cmp_lt_i32_e64 s0, 31, v0
	s_mov_b32 s1, -1
	v_lshrrev_b32_e32 v17, 27, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v17, v0, v17
	v_ashrrev_i32_e32 v41, 5, v17
	s_cbranch_vccz .LBB317_128
; %bb.99:
	v_mov_b32_e32 v45, 0
	s_and_saveexec_b32 s7, s0
	s_cbranch_execz .LBB317_121
; %bb.100:
	v_lshlrev_b32_e32 v17, 5, v39
	v_add_co_u32 v18, vcc_lo, v35, v40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v19, null, 0, v36, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add3_u32 v46, v17, 0, 0x400
	v_add_co_u32 v17, vcc_lo, s18, v18
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_ci_u32_e64 v18, null, s19, v19, vcc_lo
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v20, v16
	v_add_co_u32 v37, vcc_lo, 0x400, v17
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_ci_u32_e64 v38, null, 0, v18, vcc_lo
	v_dual_mov_b32 v47, v39 :: v_dual_mov_b32 v22, v6
	v_dual_mov_b32 v17, v13 :: v_dual_mov_b32 v24, v8
	v_dual_mov_b32 v18, v14 :: v_dual_mov_b32 v19, v15
	v_dual_mov_b32 v26, v10 :: v_dual_mov_b32 v21, v5
	v_dual_mov_b32 v28, v12 :: v_dual_mov_b32 v23, v7
	v_dual_mov_b32 v30, v2 :: v_dual_mov_b32 v25, v9
	v_dual_mov_b32 v32, v4 :: v_dual_mov_b32 v27, v11
	v_mov_b32_e32 v29, v1
	v_mov_b32_e32 v31, v3
	s_mov_b32 s10, 0
	s_mov_b32 s11, 0
	s_branch .LBB317_105
.LBB317_101:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s15
.LBB317_102:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
.LBB317_103:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
.LBB317_104:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_add_co_i32 s11, s11, 4
	v_add_co_u32 v37, s1, 0x800, v37
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s11, v41
	v_add_nc_u32_e32 v46, 0x1000, v46
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v38, s1
	v_add_nc_u32_e32 v47, 0x80, v47
	s_or_b32 s10, vcc_lo, s10
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s10
	s_cbranch_execz .LBB317_120
.LBB317_105:                            ; =>This Inner Loop Header: Depth=1
	v_mov_b32_e32 v48, v39
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s11, 0
	s_cbranch_scc1 .LBB317_115
; %bb.106:                              ;   in Loop: Header=BB317_105 Depth=1
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v18, 0
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0
	v_mov_b32_e32 v19, 0
	s_mov_b32 s1, exec_lo
	v_cmpx_gt_i32_e64 s12, v47
	s_cbranch_execz .LBB317_108
; %bb.107:                              ;   in Loop: Header=BB317_105 Depth=1
	global_load_b128 v[17:20], v[37:38], off offset:-1024 th:TH_LOAD_NT
.LBB317_108:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v24, 32, v47
	v_mov_b32_e32 v22, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s12, v24
	v_mov_b32_e32 v24, 0
	s_and_saveexec_b32 s1, vcc_lo
	s_cbranch_execz .LBB317_110
; %bb.109:                              ;   in Loop: Header=BB317_105 Depth=1
	global_load_b128 v[21:24], v[37:38], off offset:-512 th:TH_LOAD_NT
.LBB317_110:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v28, 64, v47
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0
	v_mov_b32_e32 v27, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s12, v28
	v_mov_b32_e32 v28, 0
	s_and_saveexec_b32 s1, vcc_lo
	s_cbranch_execz .LBB317_112
; %bb.111:                              ;   in Loop: Header=BB317_105 Depth=1
	global_load_b128 v[25:28], v[37:38], off th:TH_LOAD_NT
.LBB317_112:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v32, 0x60, v47
	v_mov_b32_e32 v30, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s12, v32
	v_mov_b32_e32 v32, 0
	s_and_saveexec_b32 s1, vcc_lo
	s_cbranch_execz .LBB317_114
; %bb.113:                              ;   in Loop: Header=BB317_105 Depth=1
	global_load_b128 v[29:32], v[37:38], off offset:512 th:TH_LOAD_NT
.LBB317_114:                            ;   in Loop: Header=BB317_105 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_mov_b32_e32 v48, v47
.LBB317_115:                            ;   in Loop: Header=BB317_105 Depth=1
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s12, v48
	s_cbranch_execz .LBB317_104
; %bb.116:                              ;   in Loop: Header=BB317_105 Depth=1
	v_lshl_add_u32 v52, v48, 5, 0
	s_wait_loadcnt 0x0
	v_bfe_u32 v58, v17, 8, 3
	v_bfe_u32 v59, v17, 8, 7
	v_bfe_u32 v68, v17, 16, 3
	v_bfe_u32 v72, v18, 8, 7
	ds_load_b128 v[48:51], v52
	ds_load_b128 v[52:55], v52 offset:16
	v_cvt_f32_ubyte0_e32 v58, v58
	v_bfe_u32 v77, v19, 8, 3
	s_mov_b32 s13, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v58, 0x3b000000, v58 :: v_dual_lshlrev_b32 v69, 16, v17
	v_and_b32_e32 v56, 7, v17
	v_cvt_f32_ubyte0_e32 v77, v77
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v56, v56
	s_wait_dscnt 0x1
	v_dual_mul_f32 v56, 0x3b000000, v56 :: v_dual_lshlrev_b32 v63, 16, v50
	v_lshlrev_b32_e32 v61, 16, v48
	v_and_b32_e32 v57, 0x7f, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v60, v57, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, v56, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v57
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v67, 16, v54
	v_lshl_add_u32 v60, v59, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, 0x7fc00000, v56, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, v58, v60, vcc_lo
	v_bfe_u32 v58, v17, 16, 7
	v_cvt_f32_ubyte0_e32 v60, v68
	v_lshlrev_b32_e32 v68, 24, v17
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v59
	v_lshlrev_b32_e32 v64, 16, v51
	v_lshl_add_u32 v59, v58, 20, 0x3c000000
	v_mul_f32_e32 v60, 0x3b000000, v60
	v_and_or_b32 v56, 0x80000000, v68, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v57, vcc_lo
	v_bfe_u32 v68, v17, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_and_b32_e32 v48, 0xffff0000, v48
	v_fma_f32 v56, v56, v61, 0
	v_and_or_b32 v57, 0x80000000, v69, v57
	v_cvt_f32_ubyte0_e32 v68, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v60, v59, vcc_lo
	v_bfe_u32 v60, v17, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	v_lshlrev_b32_e32 v65, 16, v52
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_and_b32 v69, 7, v18
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v70, v60, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v58, 0x7fc00000, v59 :: v_dual_lshlrev_b32 v59, 8, v17
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	v_fmac_f32_e32 v56, v57, v48
	v_and_or_b32 v58, 0x80000000, v59, v58
	v_cvt_f32_ubyte0_e32 v59, v69
	v_lshlrev_b32_e32 v62, 16, v49
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v68, v68, v70 :: v_dual_and_b32 v49, 0xffff0000, v49
	v_bfe_u32 v70, v18, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_fmac_f32 v56, v58, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, 0x7fc00000, v68, vcc_lo
	v_cvt_f32_ubyte0_e32 v68, v70
	v_bfe_u32 v70, v18, 16, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v60, 0x80000000, v17, v60
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v70, v70
	v_mul_f32_e32 v70, 0x3b000000, v70
	v_and_b32_e32 v71, 0x7f, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v69, v71, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v59, v59, v69 :: v_dual_and_b32 v50, 0xffff0000, v50
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_lshlrev_b32_e32 v66, 16, v53
	v_lshl_add_u32 v69, v72, 20, 0x3c000000
	v_bfe_u32 v71, v18, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v51, 0xffff0000, v51
	v_lshl_add_u32 v73, v71, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v68, v68, v69 :: v_dual_lshlrev_b32 v69, 24, v18
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v59, 0x80000000, v69, v59
	v_bfe_u32 v69, v18, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, 0x7fc00000, v68, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	v_cvt_f32_ubyte0_e32 v69, v69
	v_lshlrev_b32_e32 v72, 16, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, v70, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_and_b32_e32 v71, 7, v19
	v_mul_f32_e32 v69, 0x3b000000, v69
	v_and_or_b32 v68, 0x80000000, v72, v68
	v_bfe_u32 v72, v18, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, 0x7fc00000, v70, vcc_lo
	v_and_b32_e32 v73, 0x7f, v19
	v_cvt_f32_ubyte0_e32 v71, v71
	v_lshl_add_u32 v75, v72, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v52, 0xffff0000, v52
	v_lshl_add_u32 v76, v73, 20, 0x3c000000
	v_mul_f32_e32 v71, 0x3b000000, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v69, v75, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v73
	v_and_b32_e32 v54, 0xffff0000, v54
	v_bfe_u32 v75, v19, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	v_lshlrev_b32_e32 v74, 8, v18
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, 0x7fc00000, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v73
	v_lshlrev_b32_e32 v73, 24, v19
	v_and_or_b32 v70, 0x80000000, v74, v70
	v_bfe_u32 v74, v19, 24, 3
	v_and_or_b32 v69, 0x80000000, v18, v69
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, 0x7fc00000, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_cvt_f32_ubyte0_e32 v74, v74
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v71, 0x80000000, v73, v71
	v_bfe_u32 v73, v19, 16, 3
	v_mul_f32_e32 v74, 0x3b000000, v74
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_mul_f32_e32 v76, 0x3b000000, v77
	v_and_b32_e32 v53, 0xffff0000, v53
	v_bfe_u32 v77, v19, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v72, v76, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_bfe_u32 v75, v19, 16, 7
	v_lshl_add_u32 v61, v77, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v77
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v74, v61, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v76, 16, v19
	v_lshlrev_b32_e32 v61, 8, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v77
	v_and_or_b32 v58, 0x80000000, v76, v72
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v57, 0x80000000, v61, v57
	v_and_b32_e32 v61, 7, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, 0x7fc00000, v48, vcc_lo
	v_cvt_f32_ubyte0_e32 v61, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v48, 0x80000000, v19, v48
	v_mul_f32_e32 v61, 0x3b000000, v61
	v_fmac_f32_e32 v56, v60, v49
	v_bfe_u32 v49, v20, 8, 3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v49, v49
	v_mul_f32_e32 v49, 0x3b000000, v49
	v_and_b32_e32 v60, 0x7f, v20
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v62, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v61, v61, v62 :: v_dual_fmac_f32 v56, v59, v63
	v_bfe_u32 v59, v20, 8, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v68, v50
	v_lshl_add_u32 v50, v59, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v59
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v56, v70, v64 :: v_dual_cndmask_b32 v49, v49, v50
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	v_fmac_f32_e32 v56, v69, v51
	v_bfe_u32 v51, v20, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v61, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v59
	v_lshlrev_b32_e32 v59, 16, v20
	v_cvt_f32_ubyte0_e32 v51, v51
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v49, 0x7fc00000, v49 :: v_dual_lshlrev_b32 v60, 24, v20
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v51, 0x3b000000, v51
	v_and_or_b32 v50, 0x80000000, v60, v50
	v_bfe_u32 v60, v20, 16, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v49, 0x80000000, v59, v49
	v_bfe_u32 v59, v20, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v59, v59
	v_fmac_f32_e32 v56, v71, v65
	v_fmac_f32_e32 v56, v58, v52
	v_lshl_add_u32 v52, v60, 20, 0x3c000000
	v_bfe_u32 v58, v20, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v56, v57, v66 :: v_dual_cndmask_b32 v51, v51, v52
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	v_lshl_add_u32 v52, v58, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_mul_f32 v57, 0x3b000000, v59 :: v_dual_fmac_f32 v56, v48, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_lshlrev_b32_e32 v51, 8, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v57, v52, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v48, 0x80000000, v51, v48
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, 0x7fc00000, v52 :: v_dual_fmac_f32 v56, v50, v67
	v_lshlrev_b32_e32 v50, 16, v55
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v51, 0x80000000, v20, v51
	v_dual_fmac_f32 v56, v49, v54 :: v_dual_and_b32 v49, 0xffff0000, v55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v48, v50
	v_add_nc_u32_e32 v48, 32, v47
	v_fmac_f32_e32 v56, v51, v49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add_f32_e32 v45, v45, v56
	v_cmpx_gt_i32_e64 s12, v48
	s_cbranch_execz .LBB317_103
; %bb.117:                              ;   in Loop: Header=BB317_105 Depth=1
	ds_load_b128 v[48:51], v46
	ds_load_b128 v[52:55], v46 offset:16
	v_bfe_u32 v58, v21, 8, 3
	v_bfe_u32 v67, v21, 8, 7
	v_bfe_u32 v68, v21, 16, 3
	v_bfe_u32 v72, v22, 8, 7
	v_bfe_u32 v77, v23, 8, 3
	v_cvt_f32_ubyte0_e32 v58, v58
	s_mov_b32 s14, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v77, v77
	v_mul_f32_e32 v58, 0x3b000000, v58
	v_and_b32_e32 v56, 7, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v56, v56
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v63, 16, v51
	v_dual_mul_f32 v56, 0x3b000000, v56 :: v_dual_lshlrev_b32 v61, 16, v49
	v_and_b32_e32 v57, 0x7f, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v59, v57, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, v56, v59, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v57
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v65, 16, v53
	v_lshl_add_u32 v59, v67, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, 0x7fc00000, v56, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, v58, v59, vcc_lo
	v_bfe_u32 v58, v21, 16, 7
	v_cvt_f32_ubyte0_e32 v59, v68
	v_lshlrev_b32_e32 v68, 24, v21
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v60, 16, v48
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_lshlrev_b32 v62, 16, v50
	v_lshl_add_u32 v67, v58, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v57, vcc_lo
	v_and_or_b32 v56, 0x80000000, v68, v56
	v_bfe_u32 v68, v21, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_and_b32_e32 v48, 0xffff0000, v48
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v56, v56, v60, 0
	v_cvt_f32_ubyte0_e32 v68, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v67, vcc_lo
	v_bfe_u32 v67, v21, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_lshlrev_b32 v69, 16, v21
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v70, v67, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v58, 0x7fc00000, v59 :: v_dual_lshlrev_b32 v59, 8, v21
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v49, 0xffff0000, v49
	v_and_or_b32 v57, 0x80000000, v69, v57
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v58, 0x80000000, v59, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, v68, v70, vcc_lo
	v_bfe_u32 v70, v22, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v66, 16, v54
	v_fmac_f32_e32 v56, v57, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v68, vcc_lo
	v_cvt_f32_ubyte0_e32 v68, v70
	v_bfe_u32 v70, v22, 16, 3
	v_dual_fmac_f32 v56, v58, v61 :: v_dual_and_b32 v69, 7, v22
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v67, 0x80000000, v21, v67
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v70, v70
	v_cvt_f32_ubyte0_e32 v59, v69
	v_lshlrev_b32_e32 v64, 16, v52
	v_dual_fmac_f32 v56, v67, v49 :: v_dual_and_b32 v61, 0x7f, v24
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v70, 0x3b000000, v70
	v_and_b32_e32 v71, 0x7f, v22
	v_mul_f32_e32 v59, 0x3b000000, v59
	v_bfe_u32 v49, v24, 8, 3
	v_lshl_add_u32 v69, v71, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	v_and_b32_e32 v50, 0xffff0000, v50
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v49, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_lshl_add_u32 v69, v72, 20, 0x3c000000
	v_bfe_u32 v71, v22, 16, 7
	v_mul_f32_e32 v49, 0x3b000000, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v51, 0xffff0000, v51
	v_lshl_add_u32 v73, v71, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, v68, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v68, 0x7fc00000, v68 :: v_dual_lshlrev_b32 v69, 24, v22
	v_and_or_b32 v59, 0x80000000, v69, v59
	v_bfe_u32 v69, v22, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v59, v62
	v_cvt_f32_ubyte0_e32 v69, v69
	v_lshlrev_b32_e32 v72, 16, v22
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, v70, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_and_b32_e32 v71, 7, v23
	v_mul_f32_e32 v69, 0x3b000000, v69
	v_and_or_b32 v68, 0x80000000, v72, v68
	v_bfe_u32 v72, v22, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, 0x7fc00000, v70, vcc_lo
	v_and_b32_e32 v73, 0x7f, v23
	v_cvt_f32_ubyte0_e32 v71, v71
	v_lshlrev_b32_e32 v74, 8, v22
	v_lshl_add_u32 v75, v72, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v52, 0xffff0000, v52
	v_lshl_add_u32 v76, v73, 20, 0x3c000000
	v_mul_f32_e32 v71, 0x3b000000, v71
	v_bfe_u32 v59, v24, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v69, v75, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v73
	v_and_b32_e32 v54, 0xffff0000, v54
	v_bfe_u32 v75, v23, 8, 7
	v_fmac_f32_e32 v56, v68, v50
	v_lshl_add_u32 v50, v59, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	v_lshl_add_u32 v62, v61, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, 0x7fc00000, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v73
	v_lshlrev_b32_e32 v73, 24, v23
	v_and_or_b32 v70, 0x80000000, v74, v70
	v_bfe_u32 v74, v23, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, 0x7fc00000, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_fmac_f32_e32 v56, v70, v63
	v_cvt_f32_ubyte0_e32 v74, v74
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v71, 0x80000000, v73, v71
	v_bfe_u32 v73, v23, 16, 3
	v_mul_f32_e32 v74, 0x3b000000, v74
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_mul_f32_e32 v76, 0x3b000000, v77
	v_and_b32_e32 v53, 0xffff0000, v53
	v_bfe_u32 v77, v23, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v72, v76, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_bfe_u32 v75, v23, 16, 7
	v_lshl_add_u32 v60, v77, 20, 0x3c000000
	v_lshlrev_b32_e32 v76, 16, v23
	v_and_or_b32 v69, 0x80000000, v22, v69
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_fmac_f32_e32 v56, v69, v51
	v_bfe_u32 v51, v24, 16, 3
	v_and_or_b32 v58, 0x80000000, v76, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v77
	v_fmac_f32_e32 v56, v71, v64
	v_cvt_f32_ubyte0_e32 v51, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v74, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v60, 8, v23
	v_dual_mul_f32 v51, 0x3b000000, v51 :: v_dual_fmac_f32 v56, v58, v52
	v_bfe_u32 v58, v24, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v77
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v57, 0x80000000, v60, v57
	v_and_b32_e32 v60, 7, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, 0x7fc00000, v48, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	v_fmac_f32_e32 v56, v57, v65
	v_cvt_f32_ubyte0_e32 v60, v60
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v48, 0x80000000, v23, v48
	v_mul_f32_e32 v60, 0x3b000000, v60
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v48, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v60, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, v49, v50, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v59
	v_lshlrev_b32_e32 v59, 16, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, 0x7fc00000, v49, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v49, 0x80000000, v59, v49
	v_bfe_u32 v59, v24, 24, 3
	v_cvt_f32_ubyte0_e32 v59, v59
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v57, 0x3b000000, v59 :: v_dual_lshlrev_b32 v60, 24, v24
	v_and_or_b32 v50, 0x80000000, v60, v50
	v_bfe_u32 v60, v24, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v50, v66
	v_lshl_add_u32 v52, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	v_lshlrev_b32_e32 v50, 16, v55
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_fmac_f32 v56, v49, v54 :: v_dual_and_b32 v49, 0xffff0000, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v51, v52, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	v_lshl_add_u32 v52, v58, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v48, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_lshlrev_b32_e32 v51, 8, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v57, v52, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v48, 0x80000000, v51, v48
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, 0x7fc00000, v52 :: v_dual_fmac_f32 v56, v48, v50
	v_add_nc_u32_e32 v48, 64, v47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v51, 0x80000000, v24, v51
	v_fmac_f32_e32 v56, v51, v49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_add_f32_e32 v45, v45, v56
	v_cmpx_gt_i32_e64 s12, v48
	s_cbranch_execz .LBB317_102
; %bb.118:                              ;   in Loop: Header=BB317_105 Depth=1
	ds_load_b128 v[48:51], v46 offset:1024
	ds_load_b128 v[52:55], v46 offset:1040
	v_bfe_u32 v58, v25, 8, 3
	v_bfe_u32 v67, v25, 8, 7
	v_bfe_u32 v68, v25, 16, 3
	v_bfe_u32 v72, v26, 8, 7
	v_bfe_u32 v77, v27, 8, 3
	v_cvt_f32_ubyte0_e32 v58, v58
	s_mov_b32 s15, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v77, v77
	v_mul_f32_e32 v58, 0x3b000000, v58
	v_and_b32_e32 v56, 7, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v56, v56
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v63, 16, v51
	v_dual_mul_f32 v56, 0x3b000000, v56 :: v_dual_lshlrev_b32 v61, 16, v49
	v_and_b32_e32 v57, 0x7f, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v59, v57, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, v56, v59, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v57
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v65, 16, v53
	v_lshl_add_u32 v59, v67, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, 0x7fc00000, v56, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, v58, v59, vcc_lo
	v_bfe_u32 v58, v25, 16, 7
	v_cvt_f32_ubyte0_e32 v59, v68
	v_lshlrev_b32_e32 v68, 24, v25
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v60, 16, v48
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_lshlrev_b32 v62, 16, v50
	v_lshl_add_u32 v67, v58, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v57, vcc_lo
	v_and_or_b32 v56, 0x80000000, v68, v56
	v_bfe_u32 v68, v25, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_and_b32_e32 v48, 0xffff0000, v48
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v56, v56, v60, 0
	v_cvt_f32_ubyte0_e32 v68, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v67, vcc_lo
	v_bfe_u32 v67, v25, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_lshlrev_b32 v69, 16, v25
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v70, v67, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v58, 0x7fc00000, v59 :: v_dual_lshlrev_b32 v59, 8, v25
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v49, 0xffff0000, v49
	v_and_or_b32 v57, 0x80000000, v69, v57
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v58, 0x80000000, v59, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, v68, v70, vcc_lo
	v_bfe_u32 v70, v26, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v66, 16, v54
	v_fmac_f32_e32 v56, v57, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v68, vcc_lo
	v_cvt_f32_ubyte0_e32 v68, v70
	v_bfe_u32 v70, v26, 16, 3
	v_dual_fmac_f32 v56, v58, v61 :: v_dual_and_b32 v69, 7, v26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v67, 0x80000000, v25, v67
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v70, v70
	v_cvt_f32_ubyte0_e32 v59, v69
	v_lshlrev_b32_e32 v64, 16, v52
	v_dual_fmac_f32 v56, v67, v49 :: v_dual_and_b32 v61, 0x7f, v28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v70, 0x3b000000, v70
	v_and_b32_e32 v71, 0x7f, v26
	v_mul_f32_e32 v59, 0x3b000000, v59
	v_bfe_u32 v49, v28, 8, 3
	v_lshl_add_u32 v69, v71, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	v_and_b32_e32 v50, 0xffff0000, v50
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v49, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_lshl_add_u32 v69, v72, 20, 0x3c000000
	v_bfe_u32 v71, v26, 16, 7
	v_mul_f32_e32 v49, 0x3b000000, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v51, 0xffff0000, v51
	v_lshl_add_u32 v73, v71, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, v68, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v68, 0x7fc00000, v68 :: v_dual_lshlrev_b32 v69, 24, v26
	v_and_or_b32 v59, 0x80000000, v69, v59
	v_bfe_u32 v69, v26, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v59, v62
	v_cvt_f32_ubyte0_e32 v69, v69
	v_lshlrev_b32_e32 v72, 16, v26
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, v70, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_and_b32_e32 v71, 7, v27
	v_mul_f32_e32 v69, 0x3b000000, v69
	v_and_or_b32 v68, 0x80000000, v72, v68
	v_bfe_u32 v72, v26, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, 0x7fc00000, v70, vcc_lo
	v_and_b32_e32 v73, 0x7f, v27
	v_cvt_f32_ubyte0_e32 v71, v71
	v_lshlrev_b32_e32 v74, 8, v26
	v_lshl_add_u32 v75, v72, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v52, 0xffff0000, v52
	v_lshl_add_u32 v76, v73, 20, 0x3c000000
	v_mul_f32_e32 v71, 0x3b000000, v71
	v_bfe_u32 v59, v28, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v69, v75, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v73
	v_and_b32_e32 v54, 0xffff0000, v54
	v_bfe_u32 v75, v27, 8, 7
	v_fmac_f32_e32 v56, v68, v50
	v_lshl_add_u32 v50, v59, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	v_lshl_add_u32 v62, v61, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, 0x7fc00000, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v73
	v_lshlrev_b32_e32 v73, 24, v27
	v_and_or_b32 v70, 0x80000000, v74, v70
	v_bfe_u32 v74, v27, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, 0x7fc00000, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_fmac_f32_e32 v56, v70, v63
	v_cvt_f32_ubyte0_e32 v74, v74
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v71, 0x80000000, v73, v71
	v_bfe_u32 v73, v27, 16, 3
	v_mul_f32_e32 v74, 0x3b000000, v74
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_mul_f32_e32 v76, 0x3b000000, v77
	v_and_b32_e32 v53, 0xffff0000, v53
	v_bfe_u32 v77, v27, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v72, v76, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_bfe_u32 v75, v27, 16, 7
	v_lshl_add_u32 v60, v77, 20, 0x3c000000
	v_lshlrev_b32_e32 v76, 16, v27
	v_and_or_b32 v69, 0x80000000, v26, v69
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_fmac_f32_e32 v56, v69, v51
	v_bfe_u32 v51, v28, 16, 3
	v_and_or_b32 v58, 0x80000000, v76, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v77
	v_fmac_f32_e32 v56, v71, v64
	v_cvt_f32_ubyte0_e32 v51, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v74, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v60, 8, v27
	v_dual_mul_f32 v51, 0x3b000000, v51 :: v_dual_fmac_f32 v56, v58, v52
	v_bfe_u32 v58, v28, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v77
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v57, 0x80000000, v60, v57
	v_and_b32_e32 v60, 7, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, 0x7fc00000, v48, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	v_fmac_f32_e32 v56, v57, v65
	v_cvt_f32_ubyte0_e32 v60, v60
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v48, 0x80000000, v27, v48
	v_mul_f32_e32 v60, 0x3b000000, v60
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v48, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v60, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, v49, v50, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v59
	v_lshlrev_b32_e32 v59, 16, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, 0x7fc00000, v49, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v49, 0x80000000, v59, v49
	v_bfe_u32 v59, v28, 24, 3
	v_cvt_f32_ubyte0_e32 v59, v59
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v57, 0x3b000000, v59 :: v_dual_lshlrev_b32 v60, 24, v28
	v_and_or_b32 v50, 0x80000000, v60, v50
	v_bfe_u32 v60, v28, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v50, v66
	v_lshl_add_u32 v52, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	v_lshlrev_b32_e32 v50, 16, v55
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_fmac_f32 v56, v49, v54 :: v_dual_and_b32 v49, 0xffff0000, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v51, v52, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	v_lshl_add_u32 v52, v58, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v48, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_lshlrev_b32_e32 v51, 8, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v57, v52, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v48, 0x80000000, v51, v48
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, 0x7fc00000, v52 :: v_dual_fmac_f32 v56, v48, v50
	v_add_nc_u32_e32 v48, 0x60, v47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v51, 0x80000000, v28, v51
	v_fmac_f32_e32 v56, v51, v49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_add_f32_e32 v45, v45, v56
	v_cmpx_gt_i32_e64 s12, v48
	s_cbranch_execz .LBB317_101
; %bb.119:                              ;   in Loop: Header=BB317_105 Depth=1
	ds_load_b128 v[48:51], v46 offset:2048
	ds_load_b128 v[52:55], v46 offset:2064
	v_bfe_u32 v58, v29, 8, 3
	v_bfe_u32 v67, v29, 8, 7
	v_bfe_u32 v68, v29, 16, 3
	v_bfe_u32 v72, v30, 8, 7
	v_bfe_u32 v77, v31, 8, 3
	v_cvt_f32_ubyte0_e32 v58, v58
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v77, v77
	v_mul_f32_e32 v58, 0x3b000000, v58
	v_and_b32_e32 v56, 7, v29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v56, v56
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v63, 16, v51
	v_dual_mul_f32 v56, 0x3b000000, v56 :: v_dual_lshlrev_b32 v61, 16, v49
	v_and_b32_e32 v57, 0x7f, v29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v59, v57, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, v56, v59, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v57
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v65, 16, v53
	v_lshl_add_u32 v59, v67, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, 0x7fc00000, v56, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, v58, v59, vcc_lo
	v_bfe_u32 v58, v29, 16, 7
	v_cvt_f32_ubyte0_e32 v59, v68
	v_lshlrev_b32_e32 v68, 24, v29
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v60, 16, v48
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v59, 0x3b000000, v59 :: v_dual_lshlrev_b32 v62, 16, v50
	v_lshl_add_u32 v67, v58, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v57, vcc_lo
	v_and_or_b32 v56, 0x80000000, v68, v56
	v_bfe_u32 v68, v29, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_and_b32_e32 v48, 0xffff0000, v48
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v56, v56, v60, 0
	v_cvt_f32_ubyte0_e32 v68, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v67, vcc_lo
	v_bfe_u32 v67, v29, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_lshlrev_b32 v69, 16, v29
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v70, v67, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v58, 0x7fc00000, v59 :: v_dual_lshlrev_b32 v59, 8, v29
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v49, 0xffff0000, v49
	v_and_or_b32 v57, 0x80000000, v69, v57
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v58, 0x80000000, v59, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, v68, v70, vcc_lo
	v_bfe_u32 v70, v30, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v66, 16, v54
	v_fmac_f32_e32 v56, v57, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v68, vcc_lo
	v_cvt_f32_ubyte0_e32 v68, v70
	v_bfe_u32 v70, v30, 16, 3
	v_dual_fmac_f32 v56, v58, v61 :: v_dual_and_b32 v69, 7, v30
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v67, 0x80000000, v29, v67
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v70, v70
	v_cvt_f32_ubyte0_e32 v59, v69
	v_lshlrev_b32_e32 v64, 16, v52
	v_dual_fmac_f32 v56, v67, v49 :: v_dual_and_b32 v61, 0x7f, v32
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v70, 0x3b000000, v70
	v_and_b32_e32 v71, 0x7f, v30
	v_mul_f32_e32 v59, 0x3b000000, v59
	v_bfe_u32 v49, v32, 8, 3
	v_lshl_add_u32 v69, v71, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	v_and_b32_e32 v50, 0xffff0000, v50
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v49, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, v59, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_lshl_add_u32 v69, v72, 20, 0x3c000000
	v_bfe_u32 v71, v30, 16, 7
	v_mul_f32_e32 v49, 0x3b000000, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v59, 0x7fc00000, v59, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v51, 0xffff0000, v51
	v_lshl_add_u32 v73, v71, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, v68, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v68, 0x7fc00000, v68 :: v_dual_lshlrev_b32 v69, 24, v30
	v_and_or_b32 v59, 0x80000000, v69, v59
	v_bfe_u32 v69, v30, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v56, v59, v62
	v_cvt_f32_ubyte0_e32 v69, v69
	v_lshlrev_b32_e32 v72, 16, v30
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, v70, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_and_b32_e32 v71, 7, v31
	v_mul_f32_e32 v69, 0x3b000000, v69
	v_and_or_b32 v68, 0x80000000, v72, v68
	v_bfe_u32 v72, v30, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v70, 0x7fc00000, v70, vcc_lo
	v_and_b32_e32 v73, 0x7f, v31
	v_cvt_f32_ubyte0_e32 v71, v71
	v_lshlrev_b32_e32 v74, 8, v30
	v_lshl_add_u32 v75, v72, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	v_and_b32_e32 v52, 0xffff0000, v52
	v_lshl_add_u32 v76, v73, 20, 0x3c000000
	v_mul_f32_e32 v71, 0x3b000000, v71
	v_bfe_u32 v59, v32, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v69, v75, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v73
	v_and_b32_e32 v54, 0xffff0000, v54
	v_bfe_u32 v75, v31, 8, 7
	v_fmac_f32_e32 v56, v68, v50
	v_lshl_add_u32 v50, v59, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, v71, v76, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	v_lshl_add_u32 v72, v75, 20, 0x3c000000
	v_lshl_add_u32 v62, v61, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, 0x7fc00000, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v73
	v_lshlrev_b32_e32 v73, 24, v31
	v_and_or_b32 v70, 0x80000000, v74, v70
	v_bfe_u32 v74, v31, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v71, 0x7fc00000, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_fmac_f32_e32 v56, v70, v63
	v_cvt_f32_ubyte0_e32 v74, v74
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v71, 0x80000000, v73, v71
	v_bfe_u32 v73, v31, 16, 3
	v_mul_f32_e32 v74, 0x3b000000, v74
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v73, v73
	v_mul_f32_e32 v73, 0x3b000000, v73
	v_mul_f32_e32 v76, 0x3b000000, v77
	v_and_b32_e32 v53, 0xffff0000, v53
	v_bfe_u32 v77, v31, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v72, v76, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_bfe_u32 v75, v31, 16, 7
	v_lshl_add_u32 v60, v77, 20, 0x3c000000
	v_lshlrev_b32_e32 v76, 16, v31
	v_and_or_b32 v69, 0x80000000, v30, v69
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v72, 0x7fc00000, v72, vcc_lo
	v_lshl_add_u32 v78, v75, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v75
	v_fmac_f32_e32 v56, v69, v51
	v_bfe_u32 v51, v32, 16, 3
	v_and_or_b32 v58, 0x80000000, v76, v72
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v73, v73, v78, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v77
	v_fmac_f32_e32 v56, v71, v64
	v_cvt_f32_ubyte0_e32 v51, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v74, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v75
	v_lshlrev_b32_e32 v60, 8, v31
	v_dual_mul_f32 v51, 0x3b000000, v51 :: v_dual_fmac_f32 v56, v58, v52
	v_bfe_u32 v58, v32, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v57, 0x7fc00000, v73, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v77
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v57, 0x80000000, v60, v57
	v_and_b32_e32 v60, 7, v32
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, 0x7fc00000, v48, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v61
	v_fmac_f32_e32 v56, v57, v65
	v_cvt_f32_ubyte0_e32 v60, v60
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_and_or_b32 v48, 0x80000000, v31, v48
	v_mul_f32_e32 v60, 0x3b000000, v60
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v48, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v60, v60, v62, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, v49, v50, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v60, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v59
	v_lshlrev_b32_e32 v59, 16, v32
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, 0x7fc00000, v49, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v49, 0x80000000, v59, v49
	v_bfe_u32 v59, v32, 24, 3
	v_cvt_f32_ubyte0_e32 v59, v59
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v57, 0x3b000000, v59 :: v_dual_lshlrev_b32 v60, 24, v32
	v_and_or_b32 v50, 0x80000000, v60, v50
	v_bfe_u32 v60, v32, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v56, v50, v66
	v_lshl_add_u32 v52, v60, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v60
	v_lshlrev_b32_e32 v50, 16, v55
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_fmac_f32 v56, v49, v54 :: v_dual_and_b32 v49, 0xffff0000, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v51, v52, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v60
	v_lshl_add_u32 v52, v58, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v48, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v58
	v_lshlrev_b32_e32 v51, 8, v32
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v57, v52, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v48, 0x80000000, v51, v48
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, 0x7fc00000, v52 :: v_dual_fmac_f32 v56, v48, v50
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v51, 0x80000000, v32, v51
	v_fmac_f32_e32 v56, v51, v49
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v45, v45, v56
	s_branch .LBB317_101
.LBB317_120:
	s_or_b32 exec_lo, exec_lo, s10
.LBB317_121:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v17, -1, 0
	s_mov_b32 s1, 0
	s_mov_b32 s7, exec_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v18, 16, v17
	v_xor_b32_e32 v19, 8, v17
	v_xor_b32_e32 v20, 4, v17
	v_cmp_gt_i32_e32 vcc_lo, 32, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v18, v17, v18, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v19, v17, v19, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v20, v17, v20, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v20, 2, v20
	v_lshlrev_b32_e32 v19, 2, v19
	v_lshlrev_b32_e32 v18, 2, v18
	ds_bpermute_b32 v18, v18, v45
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v45, v18
	ds_bpermute_b32 v19, v19, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v19
	ds_bpermute_b32 v19, v20, v18
	v_xor_b32_e32 v20, 2, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v20, v17, v20, vcc_lo
	v_lshlrev_b32_e32 v20, 2, v20
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v19
	ds_bpermute_b32 v19, v20, v18
	v_xor_b32_e32 v20, 1, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, v17, v20, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v17, v18, v19 :: v_dual_lshlrev_b32 v20, 2, v17
	ds_bpermute_b32 v18, v20, v17
	v_cmpx_eq_u32_e32 0, v39
	s_cbranch_execz .LBB317_127
; %bb.122:
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v18, s6, v17
	v_and_b32_e32 v17, 0x7fffffff, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v17
                                        ; implicit-def: $vgpr17
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.123:
	v_bfe_u32 v17, v18, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v17, v18, v17, 0x7fff
                                        ; implicit-def: $vgpr18
	v_lshrrev_b32_e32 v17, 16, v17
; %bb.124:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.125:
	v_lshrrev_b32_e32 v17, 16, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v17, 64, v17
; %bb.126:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_lshlrev_b64_e32 v[18:19], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v18, vcc_lo, s8, v18
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v19, null, s9, v19, vcc_lo
	global_store_b16 v[18:19], v17, off
.LBB317_127:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
.LBB317_128:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s1
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB317_165
; %bb.129:
	s_wait_dscnt 0x0
	v_mov_b32_e32 v18, 0
	s_and_saveexec_b32 s7, s0
	s_cbranch_execz .LBB317_159
; %bb.130:
	v_mov_b32_e32 v18, 0
	s_and_saveexec_b32 s0, s5
	s_cbranch_execz .LBB317_138
; %bb.131:
	v_lshl_add_u32 v21, v39, 5, 0
	v_perm_b32 v22, 0, v13, 0x10c000c
	v_perm_b32 v13, 0, v13, 0x30c020c
	v_perm_b32 v27, 0, v14, 0x10c000c
	v_perm_b32 v14, 0, v14, 0x30c020c
	ds_load_b128 v[17:20], v21
	v_lshrrev_b32_e32 v25, 1, v22
	v_and_b32_e32 v26, 0x80008000, v22
	v_lshrrev_b32_e32 v28, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	ds_load_b128 v[21:24], v21 offset:16
	v_and_or_b32 v25, 0x3f803f80, v25, v26
	v_lshrrev_b32_e32 v26, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_and_or_b32 v13, 0x3f803f80, v28, v13
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v26, 0x3f803f80, v26, v27
	v_lshrrev_b32_e32 v27, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v17, v25, v17, 0
	v_perm_b32 v25, 0, v15, 0x10c000c
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v27, v14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v13, v13, v18, v17
	v_lshrrev_b32_e32 v17, 1, v25
	v_and_b32_e32 v18, 0x80008000, v25
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v13, v26, v19, v13
	v_perm_b32 v19, 0, v16, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v17, v18
	v_lshrrev_b32_e32 v18, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v13, v14, v20, v13
	v_lshrrev_b32_e32 v14, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_and_or_b32 v15, 0x3f803f80, v18, v15
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v13, v17, v21, v13
	v_and_or_b32 v14, 0x3f803f80, v14, v19
	v_lshrrev_b32_e32 v17, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v13, v15, v22, v13
	v_and_or_b32 v15, 0x3f803f80, v17, v16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v13, v14, v23, v13
	v_dot2_f32_f16 v18, v15, v24, v13
	s_and_saveexec_b32 s1, s4
	s_cbranch_execz .LBB317_137
; %bb.132:
	v_lshl_add_u32 v17, v44, 5, 0
	v_perm_b32 v19, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v25, 0, v6, 0x10c000c
	v_perm_b32 v6, 0, v6, 0x30c020c
	ds_load_b128 v[13:16], v17
	v_lshrrev_b32_e32 v23, 1, v19
	v_and_b32_e32 v24, 0x80008000, v19
	ds_load_b128 v[19:22], v17 offset:16
	v_lshrrev_b32_e32 v17, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_and_or_b32 v23, 0x3f803f80, v23, v24
	v_lshrrev_b32_e32 v24, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v5, 0x3f803f80, v17, v5
	v_perm_b32 v17, 0, v7, 0x10c000c
	v_perm_b32 v7, 0, v7, 0x30c020c
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v13, v23, v13, v18
	v_and_or_b32 v18, 0x3f803f80, v24, v25
	v_lshrrev_b32_e32 v23, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v5, v5, v14, v13
	v_lshrrev_b32_e32 v13, 1, v17
	v_and_b32_e32 v14, 0x80008000, v17
	v_and_or_b32 v6, 0x3f803f80, v23, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v5, v18, v15, v5
	v_perm_b32 v15, 0, v8, 0x10c000c
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v5, v6, v16, v5
	v_lshrrev_b32_e32 v6, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_and_or_b32 v7, 0x3f803f80, v14, v7
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v5, v13, v19, v5
	v_and_or_b32 v6, 0x3f803f80, v6, v15
	v_lshrrev_b32_e32 v13, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v5, v7, v20, v5
	v_and_or_b32 v7, 0x3f803f80, v13, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v5, v6, v21, v5
	v_dot2_f32_f16 v18, v7, v22, v5
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB317_136
; %bb.133:
	v_lshl_add_u32 v13, v43, 5, 0
	v_perm_b32 v14, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_perm_b32 v20, 0, v10, 0x10c000c
	v_perm_b32 v10, 0, v10, 0x30c020c
	ds_load_b128 v[5:8], v13
	v_lshrrev_b32_e32 v17, 1, v14
	v_and_b32_e32 v19, 0x80008000, v14
	v_lshrrev_b32_e32 v21, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	ds_load_b128 v[13:16], v13 offset:16
	v_and_or_b32 v17, 0x3f803f80, v17, v19
	v_lshrrev_b32_e32 v19, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_and_or_b32 v9, 0x3f803f80, v21, v9
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v5, v17, v5, v18
	v_perm_b32 v17, 0, v11, 0x10c000c
	v_and_or_b32 v18, 0x3f803f80, v19, v20
	v_lshrrev_b32_e32 v19, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_dot2_f32_f16 v5, v9, v6, v5
	v_lshrrev_b32_e32 v6, 1, v17
	v_and_b32_e32 v9, 0x80008000, v17
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_and_or_b32 v10, 0x3f803f80, v19, v10
	v_dot2_f32_f16 v5, v18, v7, v5
	v_perm_b32 v7, 0, v12, 0x10c000c
	v_and_or_b32 v6, 0x3f803f80, v6, v9
	v_lshrrev_b32_e32 v9, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_dot2_f32_f16 v5, v10, v8, v5
	v_lshrrev_b32_e32 v8, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v10, 0, v12, 0x30c020c
	v_and_or_b32 v9, 0x3f803f80, v9, v11
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v5, v6, v13, v5
	v_and_or_b32 v6, 0x3f803f80, v8, v7
	v_lshrrev_b32_e32 v7, 1, v10
	v_and_b32_e32 v8, 0x80008000, v10
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v5, v9, v14, v5
	v_and_or_b32 v7, 0x3f803f80, v7, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v5, v6, v15, v5
	v_dot2_f32_f16 v18, v7, v16, v5
	s_and_saveexec_b32 s3, s2
	s_cbranch_execz .LBB317_135
; %bb.134:
	v_lshl_add_u32 v9, v42, 5, 0
	v_perm_b32 v10, 0, v1, 0x10c000c
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_perm_b32 v15, 0, v2, 0x10c000c
	v_perm_b32 v2, 0, v2, 0x30c020c
	ds_load_b128 v[5:8], v9
	v_lshrrev_b32_e32 v13, 1, v10
	v_and_b32_e32 v14, 0x80008000, v10
	v_lshrrev_b32_e32 v16, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	ds_load_b128 v[9:12], v9 offset:16
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_and_or_b32 v1, 0x3f803f80, v16, v1
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v14, 0x3f803f80, v14, v15
	v_lshrrev_b32_e32 v15, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v5, v13, v5, v18
	v_perm_b32 v13, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v2, 0x3f803f80, v15, v2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v1, v1, v6, v5
	v_lshrrev_b32_e32 v5, 1, v13
	v_and_b32_e32 v6, 0x80008000, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v1, v14, v7, v1
	v_perm_b32 v7, 0, v4, 0x10c000c
	v_and_or_b32 v5, 0x3f803f80, v5, v6
	v_lshrrev_b32_e32 v6, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v1, v2, v8, v1
	v_lshrrev_b32_e32 v2, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v6, v3
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v5, v9, v1
	v_and_or_b32 v2, 0x3f803f80, v2, v7
	v_lshrrev_b32_e32 v5, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v1, v3, v10, v1
	v_and_or_b32 v3, 0x3f803f80, v5, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v1, v2, v11, v1
	v_dot2_f32_f16 v18, v3, v12, v1
.LBB317_135:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB317_136:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_137:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
.LBB317_138:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s3, exec_lo
	v_cmpx_lt_u32_e32 0x9f, v0
	s_cbranch_execz .LBB317_158
; %bb.139:
	v_lshlrev_b32_e32 v0, 5, v39
	v_add_co_u32 v1, vcc_lo, v35, v40
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v36, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add3_u32 v19, v0, 0, 0x1000
	v_add_co_u32 v0, vcc_lo, s18, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo
	v_or_b32_e32 v20, 0xe0, v39
	v_add_co_u32 v16, vcc_lo, 0xe00, v0
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_ci_u32_e64 v17, null, 0, v1, vcc_lo
	s_mov_b32 s4, 0
	s_mov_b32 s5, 4
	s_branch .LBB317_144
.LBB317_140:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
.LBB317_141:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
.LBB317_142:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
.LBB317_143:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_add_co_i32 s5, s5, 4
	v_add_co_u32 v16, s0, 0x800, v16
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s5, v41
	v_add_nc_u32_e32 v19, 0x1000, v19
	v_add_nc_u32_e32 v20, 0x80, v20
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v17, null, 0, v17, s0
	s_or_b32 s4, vcc_lo, s4
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s4
	s_cbranch_execz .LBB317_157
.LBB317_144:                            ; =>This Inner Loop Header: Depth=1
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v13, 0 :: v_dual_add_nc_u32 v0, 0xffffffa0, v20
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v15, 0
	v_mov_b32_e32 v12, 0
	v_mov_b32_e32 v14, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e64 s2, s12, v0
	s_and_saveexec_b32 s0, s2
	s_cbranch_execz .LBB317_146
; %bb.145:                              ;   in Loop: Header=BB317_144 Depth=1
	global_load_b128 v[12:15], v[16:17], off offset:-1536 th:TH_LOAD_NT
.LBB317_146:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_subrev_nc_u32_e32 v0, 64, v20
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s1, s12, v0
	s_and_saveexec_b32 s0, s1
	s_cbranch_execz .LBB317_148
; %bb.147:                              ;   in Loop: Header=BB317_144 Depth=1
	global_load_b128 v[8:11], v[16:17], off offset:-1024 th:TH_LOAD_NT
.LBB317_148:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_subrev_nc_u32_e32 v1, 32, v20
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v5, 0
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s0, s12, v1
	s_and_saveexec_b32 s10, s0
	s_cbranch_execz .LBB317_150
; %bb.149:                              ;   in Loop: Header=BB317_144 Depth=1
	global_load_b128 v[4:7], v[16:17], off offset:-512 th:TH_LOAD_NT
.LBB317_150:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	v_cmp_gt_i32_e32 vcc_lo, s12, v20
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0
	v_mov_b32_e32 v3, 0
	s_and_saveexec_b32 s10, vcc_lo
	s_cbranch_execz .LBB317_152
; %bb.151:                              ;   in Loop: Header=BB317_144 Depth=1
	global_load_b128 v[0:3], v[16:17], off th:TH_LOAD_NT
.LBB317_152:                            ;   in Loop: Header=BB317_144 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_and_saveexec_b32 s10, s2
	s_cbranch_execz .LBB317_143
; %bb.153:                              ;   in Loop: Header=BB317_144 Depth=1
	ds_load_b128 v[21:24], v19
	s_wait_loadcnt 0x0
	v_perm_b32 v25, 0, v12, 0x10c000c
	v_perm_b32 v12, 0, v12, 0x30c020c
	v_perm_b32 v31, 0, v13, 0x10c000c
	v_perm_b32 v13, 0, v13, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v29, 1, v25
	v_and_b32_e32 v30, 0x80008000, v25
	v_lshrrev_b32_e32 v32, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	ds_load_b128 v[25:28], v19 offset:16
	v_and_or_b32 v29, 0x3f803f80, v29, v30
	v_lshrrev_b32_e32 v30, 1, v31
	v_and_b32_e32 v31, 0x80008000, v31
	v_and_or_b32 v12, 0x3f803f80, v32, v12
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v18, v29, v21, v18
	v_perm_b32 v21, 0, v14, 0x10c000c
	v_and_or_b32 v29, 0x3f803f80, v30, v31
	v_lshrrev_b32_e32 v30, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	v_dot2_f32_f16 v12, v12, v22, v18
	v_lshrrev_b32_e32 v18, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_perm_b32 v14, 0, v14, 0x30c020c
	v_and_or_b32 v13, 0x3f803f80, v30, v13
	v_dot2_f32_f16 v12, v29, v23, v12
	v_perm_b32 v22, 0, v15, 0x10c000c
	v_and_or_b32 v18, 0x3f803f80, v18, v21
	v_lshrrev_b32_e32 v21, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_dot2_f32_f16 v12, v13, v24, v12
	v_lshrrev_b32_e32 v13, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v21, v14
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v12, v18, v25, v12
	v_and_or_b32 v13, 0x3f803f80, v13, v22
	v_lshrrev_b32_e32 v18, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v12, v14, v26, v12
	v_and_or_b32 v14, 0x3f803f80, v18, v15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v12, v13, v27, v12
	v_dot2_f32_f16 v18, v14, v28, v12
	s_and_saveexec_b32 s2, s1
	s_cbranch_execz .LBB317_142
; %bb.154:                              ;   in Loop: Header=BB317_144 Depth=1
	ds_load_b128 v[12:15], v19 offset:1024
	v_perm_b32 v21, 0, v8, 0x10c000c
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_perm_b32 v27, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v25, 1, v21
	v_and_b32_e32 v26, 0x80008000, v21
	v_lshrrev_b32_e32 v28, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	ds_load_b128 v[21:24], v19 offset:1040
	v_and_or_b32 v25, 0x3f803f80, v25, v26
	v_lshrrev_b32_e32 v26, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_and_or_b32 v8, 0x3f803f80, v28, v8
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v12, v25, v12, v18
	v_perm_b32 v18, 0, v10, 0x10c000c
	v_and_or_b32 v25, 0x3f803f80, v26, v27
	v_lshrrev_b32_e32 v26, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_dot2_f32_f16 v8, v8, v13, v12
	v_lshrrev_b32_e32 v12, 1, v18
	v_and_b32_e32 v13, 0x80008000, v18
	v_perm_b32 v10, 0, v10, 0x30c020c
	v_and_or_b32 v9, 0x3f803f80, v26, v9
	v_dot2_f32_f16 v8, v25, v14, v8
	v_perm_b32 v14, 0, v11, 0x10c000c
	v_and_or_b32 v12, 0x3f803f80, v12, v13
	v_lshrrev_b32_e32 v13, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_dot2_f32_f16 v8, v9, v15, v8
	v_lshrrev_b32_e32 v9, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_and_or_b32 v10, 0x3f803f80, v13, v10
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v8, v12, v21, v8
	v_and_or_b32 v9, 0x3f803f80, v9, v14
	v_lshrrev_b32_e32 v12, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v8, v10, v22, v8
	v_and_or_b32 v10, 0x3f803f80, v12, v11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v8, v9, v23, v8
	v_dot2_f32_f16 v18, v10, v24, v8
	s_and_saveexec_b32 s1, s0
	s_cbranch_execz .LBB317_141
; %bb.155:                              ;   in Loop: Header=BB317_144 Depth=1
	ds_load_b128 v[8:11], v19 offset:2048
	v_perm_b32 v12, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v23, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v21, 1, v12
	v_and_b32_e32 v22, 0x80008000, v12
	v_lshrrev_b32_e32 v24, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	ds_load_b128 v[12:15], v19 offset:2064
	v_and_or_b32 v21, 0x3f803f80, v21, v22
	v_lshrrev_b32_e32 v22, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_and_or_b32 v4, 0x3f803f80, v24, v4
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v8, v21, v8, v18
	v_perm_b32 v18, 0, v6, 0x10c000c
	v_and_or_b32 v21, 0x3f803f80, v22, v23
	v_lshrrev_b32_e32 v22, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v4, v4, v9, v8
	v_lshrrev_b32_e32 v8, 1, v18
	v_and_b32_e32 v9, 0x80008000, v18
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v22, v5
	v_dot2_f32_f16 v4, v21, v10, v4
	v_perm_b32 v10, 0, v7, 0x10c000c
	v_and_or_b32 v8, 0x3f803f80, v8, v9
	v_lshrrev_b32_e32 v9, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v4, v5, v11, v4
	v_lshrrev_b32_e32 v5, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v9, v6
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v4, v8, v12, v4
	v_and_or_b32 v5, 0x3f803f80, v5, v10
	v_lshrrev_b32_e32 v8, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v4, v6, v13, v4
	v_and_or_b32 v6, 0x3f803f80, v8, v7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v4, v5, v14, v4
	v_dot2_f32_f16 v18, v6, v15, v4
	s_and_saveexec_b32 s0, vcc_lo
	s_cbranch_execz .LBB317_140
; %bb.156:                              ;   in Loop: Header=BB317_144 Depth=1
	ds_load_b128 v[4:7], v19 offset:3072
	v_perm_b32 v8, 0, v0, 0x10c000c
	v_perm_b32 v0, 0, v0, 0x30c020c
	v_perm_b32 v14, 0, v1, 0x10c000c
	v_perm_b32 v1, 0, v1, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v12, 1, v8
	v_and_b32_e32 v13, 0x80008000, v8
	v_lshrrev_b32_e32 v15, 1, v0
	v_and_b32_e32 v0, 0x80008000, v0
	ds_load_b128 v[8:11], v19 offset:3088
	v_and_or_b32 v12, 0x3f803f80, v12, v13
	v_lshrrev_b32_e32 v13, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_and_or_b32 v0, 0x3f803f80, v15, v0
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v4, v12, v4, v18
	v_perm_b32 v12, 0, v2, 0x10c000c
	v_lshrrev_b32_e32 v14, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_perm_b32 v2, 0, v2, 0x30c020c
	v_dot2_f32_f16 v0, v0, v5, v4
	v_lshrrev_b32_e32 v4, 1, v12
	v_and_b32_e32 v5, 0x80008000, v12
	v_and_or_b32 v1, 0x3f803f80, v14, v1
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v0, v13, v6, v0
	v_perm_b32 v6, 0, v3, 0x10c000c
	v_and_or_b32 v4, 0x3f803f80, v4, v5
	v_lshrrev_b32_e32 v5, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_dot2_f32_f16 v0, v1, v7, v0
	v_lshrrev_b32_e32 v1, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v2, 0x3f803f80, v5, v2
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v4, v8, v0
	v_and_or_b32 v1, 0x3f803f80, v1, v6
	v_lshrrev_b32_e32 v4, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v0, v2, v9, v0
	v_and_or_b32 v2, 0x3f803f80, v4, v3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v0, v1, v10, v0
	v_dot2_f32_f16 v18, v2, v11, v0
	s_branch .LBB317_140
.LBB317_157:
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_158:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB317_159:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v0, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v1, 16, v0
	v_xor_b32_e32 v2, 8, v0
	v_xor_b32_e32 v3, 4, v0
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v2, 2, v2
	v_lshlrev_b32_e32 v1, 2, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo
	ds_bpermute_b32 v1, v1, v18
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v18, v1
	ds_bpermute_b32 v2, v2, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	ds_bpermute_b32 v2, v3, v1
	v_xor_b32_e32 v3, 2, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	ds_bpermute_b32 v2, v3, v1
	v_xor_b32_e32 v3, 1, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, v0, v3, vcc_lo
	v_cmp_eq_u32_e32 vcc_lo, 0, v39
	s_wait_dscnt 0x0
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v3, 2, v0
	ds_bpermute_b32 v1, v3, v0
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB317_165
; %bb.160:
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v0, 0x47800000, v0
	v_mul_f32_e32 v1, s6, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v0, 0x7fffffff, v1
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.161:
	v_bfe_u32 v0, v1, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v1, v0, 0x7fff
                                        ; implicit-def: $vgpr1
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.162:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.163:
	v_lshrrev_b32_e32 v0, 16, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.164:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_lshlrev_b64_e32 v[1:2], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v1, vcc_lo, s8, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo
	global_store_b16 v[1:2], v0, off
.LBB317_165:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 328
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 82
		.amdhsa_next_free_sgpr 32
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 217
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii,"axG",@progbits,_ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii,comdat
.Lfunc_end317:
