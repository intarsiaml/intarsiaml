_ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii: ; @_ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
; %bb.0:
	s_clause 0x1
	s_load_b64 s[8:9], s[0:1], 0x20
	s_load_b64 s[2:3], s[0:1], 0x8
	s_mov_b32 s4, ttmp9
	s_mov_b32 s5, 0
	v_lshrrev_b32_e32 v1, 4, v0
	s_lshl_b64 s[4:5], s[4:5], 4
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, s5
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v71, 0
	v_and_or_b32 v67, v1, 14, s4
	v_mov_b32_e32 v72, 0
	s_mov_b32 s4, exec_lo
	s_wait_kmcnt 0x0
	s_ashr_i32 s11, s8, 31
	s_mov_b32 s10, s8
	s_ashr_i32 s7, s9, 31
	v_cmpx_gt_i64_e64 s[10:11], v[67:68]
; %bb.1:
	v_mad_co_u64_u32 v[71:72], null, v67, s9, s[2:3]
	v_mul_lo_u32 v1, v67, s7
	v_mul_lo_u32 v2, v68, s9
	s_delay_alu instid0(VALU_DEP_1)
	v_add3_u32 v72, v2, v72, v1
; %bb.2:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v65, 1, v67
	v_mov_b32_e32 v66, v68
	s_mov_b32 s4, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i64_e64 s[10:11], v[65:66]
; %bb.3:
	v_mad_co_u64_u32 v[69:70], null, v65, s9, s[2:3]
	v_mul_lo_u32 v1, v65, s7
	v_mul_lo_u32 v2, v66, s9
	s_delay_alu instid0(VALU_DEP_1)
	v_add3_u32 v70, v2, v70, v1
; %bb.4:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_lshr_b32 s2, s7, 28
	v_dual_mov_b32 v30, 0 :: v_dual_and_b32 v77, 31, v0
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s9, s2
	v_cmp_ne_u64_e32 vcc_lo, 0, v[71:72]
	s_wait_alu 0xfffe
	s_ashr_i32 s16, s2, 4
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v78, 4, v77
	v_cmp_gt_i32_e64 s6, s16, v77
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v32, 0
	v_mov_b32_e32 v31, 0
	s_and_b32 s2, s6, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s3, s2
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execz .LBB69_6
; %bb.5:
	v_add_co_u32 v1, s2, v71, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v72, s2
	global_load_b128 v[29:32], v[1:2], off th:TH_LOAD_NT
.LBB69_6:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_cmp_ne_u64_e64 s2, 0, v[69:70]
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0
	v_mov_b32_e32 v24, 0
	s_and_b32 s3, s6, s2
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB69_8
; %bb.7:
	v_add_co_u32 v1, s3, v69, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v70, s3
	global_load_b128 v[21:24], v[1:2], off th:TH_LOAD_NT
.LBB69_8:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v82, 32, v77
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v26, 0
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v28, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s5, s16, v82
	v_mov_b32_e32 v27, 0
	s_and_b32 s3, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB69_10
; %bb.9:
	v_add_co_u32 v1, s3, v71, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v72, s3
	global_load_b128 v[25:28], v[1:2], off offset:512 th:TH_LOAD_NT
.LBB69_10:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0
	v_mov_b32_e32 v16, 0
	s_and_b32 s3, s2, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB69_12
; %bb.11:
	v_add_co_u32 v1, s3, v69, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v70, s3
	global_load_b128 v[13:16], v[1:2], off offset:512 th:TH_LOAD_NT
.LBB69_12:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v81, 64, v77
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v18, 0
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s4, s16, v81
	v_mov_b32_e32 v19, 0
	s_and_b32 s3, vcc_lo, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s3
	s_cbranch_execz .LBB69_14
; %bb.13:
	v_add_co_u32 v1, s3, v71, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v72, s3
	global_load_b128 v[17:20], v[1:2], off offset:1024 th:TH_LOAD_NT
.LBB69_14:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0
	v_mov_b32_e32 v8, 0
	s_and_b32 s3, s2, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s3
	s_cbranch_execz .LBB69_16
; %bb.15:
	v_add_co_u32 v1, s3, v69, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v70, s3
	global_load_b128 v[5:8], v[1:2], off offset:1024 th:TH_LOAD_NT
.LBB69_16:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_load_b64 s[12:13], s[0:1], 0x10
	v_or_b32_e32 v80, 0x60, v77
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v10, 0
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v12, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	v_cmp_gt_i32_e64 s3, s16, v80
	v_mov_b32_e32 v11, 0
	s_and_b32 s14, vcc_lo, s3
	s_and_saveexec_b32 s8, s14
	s_cbranch_execz .LBB69_18
; %bb.17:
	v_add_co_u32 v2, vcc_lo, v71, v78
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v3, null, 0, v72, vcc_lo
	global_load_b128 v[9:12], v[2:3], off offset:1536 th:TH_LOAD_NT
.LBB69_18:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0
	v_mov_b32_e32 v4, 0
	s_and_b32 s14, s2, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_saveexec_b32 s8, s14
	s_cbranch_execz .LBB69_20
; %bb.19:
	v_add_co_u32 v1, vcc_lo, v69, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v70, vcc_lo
	global_load_b128 v[1:4], v[1:2], off offset:1536 th:TH_LOAD_NT
.LBB69_20:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_wait_kmcnt 0x0
	s_load_b64 s[14:15], s[12:13], 0x0
	s_load_b64 s[12:13], s[0:1], 0x18
	s_mov_b32 s21, 0
	s_mov_b32 s20, exec_lo
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s15, 0
	s_cselect_b32 s18, -1, 0
	s_cmp_ngt_f32 s15, 0
	s_cselect_b32 s17, -1, 0
	s_lshr_b32 s7, s7, 30
	s_wait_alu 0xfffe
	s_add_co_i32 s7, s9, s7
	s_wait_alu 0xfffe
	s_ashr_i32 s19, s7, 2
	s_delay_alu instid0(SALU_CYCLE_1)
	v_cmpx_gt_i32_e64 s19, v0
	s_cbranch_execz .LBB69_25
; %bb.21:
	s_clause 0x1
	s_load_b64 s[22:23], s[0:1], 0x0
	s_load_b32 s0, s[0:1], 0x34
	v_lshlrev_b32_e32 v33, 4, v0
	s_mov_b32 s24, 0xc3e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v39, 0, v33
	s_wait_kmcnt 0x0
	v_add_co_u32 v33, s1, s22, v33
	v_add_co_ci_u32_e64 v34, null, s23, 0, s1
	s_and_b32 s22, s0, 0xffff
	v_add_co_u32 v37, vcc_lo, v33, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, 0, v34, vcc_lo
	s_wait_alu 0xfffe
	s_lshl_b32 s23, s22, 4
	s_branch .LBB69_23
.LBB69_22:                              ;   in Loop: Header=BB69_23 Depth=1
	v_add_nc_u32_e32 v0, s22, v0
	v_add_co_u32 v37, s0, v37, s23
	s_wait_loadcnt 0x0
	ds_store_b128 v39, v[33:36]
	v_add_nc_u32_e32 v39, s23, v39
	v_cmp_le_i32_e32 vcc_lo, s19, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v38, s0
	s_or_b32 s21, vcc_lo, s21
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 exec_lo, exec_lo, s21
	s_cbranch_execz .LBB69_25
.LBB69_23:                              ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[33:36], v[37:38], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s18
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB69_22
; %bb.24:                               ;   in Loop: Header=BB69_23 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v43, 16, v34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_div_scale_f32 v54, s1, v43, s15, v43
	v_lshlrev_b32_e32 v40, 16, v33
	v_and_b32_e32 v33, 0xffff0000, v33
	v_div_scale_f32 v47, null, s15, s15, v43
	v_div_scale_f32 v41, null, s15, s15, v40
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_scale_f32 v42, null, s15, s15, v33
	v_rcp_f32_e32 v50, v47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v45, v41
	v_div_scale_f32 v49, vcc_lo, v40, s15, v40
	v_rcp_f32_e32 v46, v42
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v51, -v41, v45, 1.0
	v_and_b32_e32 v34, 0xffff0000, v34
	v_fma_f32 v52, -v42, v46, 1.0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v45, v51, v45 :: v_dual_lshlrev_b32 v44, 16, v35
	v_div_scale_f32 v51, null, s15, s15, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v46, v52, v46
	v_div_scale_f32 v53, s0, v33, s15, v33
	v_fma_f32 v52, -v47, v50, 1.0
	v_mul_f32_e32 v55, v49, v45
	v_dual_mul_f32 v56, v53, v46 :: v_dual_and_b32 v35, 0xffff0000, v35
	v_div_scale_f32 v57, null, s15, s15, v44
	s_delay_alu instid0(VALU_DEP_3)
	v_fma_f32 v59, -v41, v55, v49
	v_fmac_f32_e32 v50, v52, v50
	v_lshlrev_b32_e32 v48, 16, v36
	v_fma_f32 v52, -v42, v56, v53
	v_rcp_f32_e32 v58, v51
	v_fmac_f32_e32 v55, v59, v45
	v_mul_f32_e32 v59, v54, v50
	v_div_scale_f32 v60, s7, v34, s15, v34
	v_fmac_f32_e32 v56, v52, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v41, -v41, v55, v49
	v_fma_f32 v49, -v47, v59, v54
	v_and_b32_e32 v36, 0xffff0000, v36
	v_rcp_f32_e32 v52, v57
	v_fma_f32 v42, -v42, v56, v53
	s_wait_alu 0xfffd
	v_div_fmas_f32 v41, v41, v45, v55
	v_div_scale_f32 v45, null, s15, s15, v35
	v_fmac_f32_e32 v59, v49, v50
	s_mov_b32 vcc_lo, s0
	s_delay_alu instid0(VALU_DEP_3)
	v_div_fixup_f32 v40, v41, s15, v40
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v46, v56
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v46, -v47, v59, v54
	v_rcp_f32_e32 v47, v45
	v_fma_f32 v41, -v57, v52, 1.0
	v_fma_f32 v61, -v51, v58, 1.0
	v_div_fixup_f32 v33, v42, s15, v33
	v_div_scale_f32 v55, null, s15, s15, v36
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v52, v41, v52
	v_div_scale_f32 v41, s0, v44, s15, v44
	v_med3_num_f32 v40, v40, s24, 0x43e00000
	v_fma_f32 v53, -v45, v47, 1.0
	v_med3_num_f32 v33, v33, s24, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v47, v53, v47
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v46, v50, v59
	s_mov_b32 vcc_lo, s7
	v_div_scale_f32 v50, null, s15, s15, v48
	v_div_scale_f32 v53, s1, v35, s15, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v43, v46, s15, v43
	v_mul_f32_e32 v46, v41, v52
	v_rcp_f32_e32 v54, v50
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v43, v43, s24, 0x43e00000
	v_fma_f32 v59, -v57, v46, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v46, v59, v52
	v_div_scale_f32 v59, s7, v36, s15, v36
	v_fmac_f32_e32 v58, v61, v58
	v_fma_f32 v56, -v50, v54, 1.0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v41, -v57, v46, v41
	v_mul_f32_e32 v42, v60, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v54, v56, v54
	v_div_scale_f32 v56, s8, v48, s15, v48
	v_fma_f32 v49, -v51, v42, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v42, v49, v58
	v_rcp_f32_e32 v49, v55
	v_fma_f32 v51, -v51, v42, v60
	v_mul_f32_e32 v60, v53, v47
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fmas_f32 v42, v51, v58, v42
	v_fma_f32 v51, -v45, v60, v53
	v_mul_f32_e32 v58, v56, v54
	s_delay_alu instid0(TRANS32_DEP_1)
	v_fma_f32 v61, -v55, v49, 1.0
	s_mov_b32 vcc_lo, s0
	v_div_fixup_f32 v34, v42, s15, v34
	v_fmac_f32_e32 v60, v51, v47
	v_fma_f32 v42, -v50, v58, v56
	v_fmac_f32_e32 v49, v61, v49
	s_wait_alu 0xfffe
	v_div_fmas_f32 v41, v41, v52, v46
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v45, -v45, v60, v53
	v_dual_fmac_f32 v58, v42, v54 :: v_dual_mul_f32 v51, v59, v49
	v_med3_num_f32 v34, v34, s24, 0x43e00000
	v_div_fixup_f32 v41, v41, s15, v44
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v45, v47, v60
	v_mov_b32_e32 v45, 0
	v_fma_f32 v46, -v55, v51, v59
	v_fma_f32 v44, -v50, v58, v56
	v_med3_num_f32 v41, v41, s24, 0x43e00000
	v_div_fixup_f32 v35, v42, s15, v35
	v_cvt_pk_fp8_f32 v45, v40, v33
	v_mov_b32_e32 v33, 0
	v_fmac_f32_e32 v51, v46, v49
	s_mov_b32 vcc_lo, s8
	v_med3_num_f32 v35, v35, s24, 0x43e00000
	v_cvt_pk_fp8_f32 v45, v43, v34 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v42, -v55, v51, v59
	v_cvt_pk_fp8_f32 v33, v41, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_perm_b32 v35, 0, v45, 0x30c020c
	v_perm_b32 v34, 0, v45, 0x10c000c
	v_lshrrev_b32_e32 v41, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	s_wait_alu 0xfffe
	v_div_fmas_f32 v44, v44, v54, v58
	s_mov_b32 vcc_lo, s7
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v49, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fixup_f32 v44, v44, s15, v48
	v_div_fixup_f32 v36, v42, s15, v36
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v40, v44, s24, 0x43e00000
	v_med3_num_f32 v36, v36, s24, 0x43e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v33, v40, v36 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v36, 1, v34
	v_and_b32_e32 v34, 0x80008000, v34
	v_perm_b32 v40, 0, v33, 0x10c000c
	v_perm_b32 v33, 0, v33, 0x30c020c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v42, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_lshrrev_b32_e32 v43, 1, v33
	v_and_b32_e32 v44, 0x80008000, v33
	v_and_or_b32 v33, 0x3f803f80, v36, v34
	v_and_or_b32 v34, 0x3f803f80, v41, v35
	v_and_or_b32 v35, 0x3f803f80, v42, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v36, 0x3f803f80, v43, v44
	s_branch .LBB69_22
.LBB69_25:
	s_or_b32 exec_lo, exec_lo, s20
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_mov_b32 s0, exec_lo
	v_cmpx_ne_u64_e32 0, v[71:72]
	s_cbranch_execz .LBB69_145
; %bb.26:
	v_xad_u32 v0, v77, 31, s16
	s_and_b32 s0, s18, exec_lo
	s_cselect_b32 s1, s15, 1.0
	s_and_not1_b32 vcc_lo, exec_lo, s17
	s_wait_alu 0xfffe
	s_mul_f32 s14, s14, s1
	v_ashrrev_i32_e32 v33, 31, v0
	v_cmp_lt_i32_e64 s0, 31, v0
	s_mov_b32 s1, -1
	v_lshrrev_b32_e32 v33, 27, v33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v33, v0, v33
	v_ashrrev_i32_e32 v79, 5, v33
	s_cbranch_vccnz .LBB69_82
; %bb.27:
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v85, 0
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v83, 0
	s_and_saveexec_b32 s7, s0
	s_cbranch_execz .LBB69_57
; %bb.28:
	v_dual_mov_b32 v74, v72 :: v_dual_lshlrev_b32 v33, 5, v77
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v76, v70
	v_dual_mov_b32 v73, v71 :: v_dual_mov_b32 v60, v12
	v_dual_mov_b32 v75, v69 :: v_dual_mov_b32 v58, v10
	s_delay_alu instid0(VALU_DEP_4)
	v_add3_u32 v87, v33, 0, 0x400
	v_dual_mov_b32 v59, v11 :: v_dual_mov_b32 v52, v20
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v50, v18
	v_dual_mov_b32 v51, v19 :: v_dual_mov_b32 v44, v28
	v_dual_mov_b32 v49, v17 :: v_dual_mov_b32 v42, v26
	v_dual_mov_b32 v43, v27 :: v_dual_mov_b32 v36, v32
	v_dual_mov_b32 v41, v25 :: v_dual_mov_b32 v34, v30
	v_dual_mov_b32 v35, v31 :: v_dual_mov_b32 v38, v22
	v_dual_mov_b32 v33, v29 :: v_dual_mov_b32 v40, v24
	v_dual_mov_b32 v37, v21 :: v_dual_mov_b32 v46, v14
	v_dual_mov_b32 v39, v23 :: v_dual_mov_b32 v48, v16
	v_dual_mov_b32 v45, v13 :: v_dual_mov_b32 v54, v6
	v_dual_mov_b32 v47, v15 :: v_dual_mov_b32 v56, v8
	v_dual_mov_b32 v53, v5 :: v_dual_mov_b32 v62, v2
	v_dual_mov_b32 v55, v7 :: v_dual_mov_b32 v64, v4
	v_dual_mov_b32 v61, v1 :: v_dual_mov_b32 v84, 0
	v_dual_mov_b32 v63, v3 :: v_dual_mov_b32 v86, 0
	v_mov_b32_e32 v85, 0
	s_lshl_b32 s8, s9, 1
	s_mov_b32 s15, 0
	s_mov_b32 s17, 0
	s_mov_b32 s18, 0
	s_branch .LBB69_33
.LBB69_29:                              ;   in Loop: Header=BB69_33 Depth=1
	s_or_b32 exec_lo, exec_lo, s21
.LBB69_30:                              ;   in Loop: Header=BB69_33 Depth=1
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s20
.LBB69_31:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s19
.LBB69_32:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_add_co_i32 s18, s18, 4
	v_add_co_u32 v75, vcc_lo, 0x800, v75
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v76, null, 0, v76, vcc_lo
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s18, v79
	v_add_co_u32 v73, s1, 0x800, v73
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v74, null, 0, v74, s1
	v_add_nc_u32_e32 v87, 0x1000, v87
	s_addk_co_i32 s17, 0x80
	s_or_b32 s15, vcc_lo, s15
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s15
	s_cbranch_execz .LBB69_56
.LBB69_33:                              ; =>This Inner Loop Header: Depth=1
	s_wait_alu 0xfffe
	v_dual_mov_b32 v89, v77 :: v_dual_add_nc_u32 v88, s17, v77
	s_cmp_eq_u32 s17, 0
	s_cbranch_scc1 .LBB69_51
; %bb.34:                               ;   in Loop: Header=BB69_33 Depth=1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, s16, v88
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v34, 0
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v36, 0
	v_mov_b32_e32 v35, 0
	s_and_saveexec_b32 s19, vcc_lo
	s_cbranch_execz .LBB69_36
; %bb.35:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v33, s1, v73, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v34, null, 0, v74, s1
	global_load_b128 v[33:36], v[33:34], off th:TH_LOAD_NT
.LBB69_36:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s19
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0
	v_mov_b32_e32 v40, 0
	s_and_b32 s19, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s19
	s_cbranch_execz .LBB69_38
; %bb.37:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v37, vcc_lo, v75, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, 0, v76, vcc_lo
	global_load_b128 v[37:40], v[37:38], off th:TH_LOAD_NT
.LBB69_38:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v45, 0 :: v_dual_add_nc_u32 v44, 32, v88
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0
	v_mov_b32_e32 v43, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s16, v44
	v_mov_b32_e32 v44, 0
	s_and_saveexec_b32 s19, vcc_lo
	s_cbranch_execz .LBB69_40
; %bb.39:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v41, s1, v73, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v42, null, 0, v74, s1
	global_load_b128 v[41:44], v[41:42], off offset:512 th:TH_LOAD_NT
.LBB69_40:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s19
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0
	v_mov_b32_e32 v48, 0
	s_and_b32 s19, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s19
	s_cbranch_execz .LBB69_42
; %bb.41:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v45, vcc_lo, v75, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v46, null, 0, v76, vcc_lo
	global_load_b128 v[45:48], v[45:46], off offset:512 th:TH_LOAD_NT
.LBB69_42:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v53, 0 :: v_dual_add_nc_u32 v52, 64, v88
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0
	v_mov_b32_e32 v51, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s16, v52
	v_mov_b32_e32 v52, 0
	s_and_saveexec_b32 s19, vcc_lo
	s_cbranch_execz .LBB69_44
; %bb.43:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v49, s1, v73, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v50, null, 0, v74, s1
	global_load_b128 v[49:52], v[49:50], off offset:1024 th:TH_LOAD_NT
.LBB69_44:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s19
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v55, 0
	v_mov_b32_e32 v56, 0
	s_and_b32 s19, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s19
	s_cbranch_execz .LBB69_46
; %bb.45:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v53, vcc_lo, v75, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v54, null, 0, v76, vcc_lo
	global_load_b128 v[53:56], v[53:54], off offset:1024 th:TH_LOAD_NT
.LBB69_46:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v61, 0 :: v_dual_add_nc_u32 v60, 0x60, v88
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v58, 0
	v_mov_b32_e32 v59, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s16, v60
	v_mov_b32_e32 v60, 0
	s_and_saveexec_b32 s19, vcc_lo
	s_cbranch_execz .LBB69_48
; %bb.47:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v57, s1, v73, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v58, null, 0, v74, s1
	global_load_b128 v[57:60], v[57:58], off offset:1536 th:TH_LOAD_NT
.LBB69_48:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s19
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v63, 0
	v_mov_b32_e32 v64, 0
	s_and_b32 s19, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s19
	s_cbranch_execz .LBB69_50
; %bb.49:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_co_u32 v61, vcc_lo, v75, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v62, null, 0, v76, vcc_lo
	global_load_b128 v[61:64], v[61:62], off offset:1536 th:TH_LOAD_NT
.LBB69_50:                              ;   in Loop: Header=BB69_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_mov_b32_e32 v89, v88
.LBB69_51:                              ;   in Loop: Header=BB69_33 Depth=1
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s16, v89
	s_cbranch_execz .LBB69_32
; %bb.52:                               ;   in Loop: Header=BB69_33 Depth=1
	v_lshl_add_u32 v93, v89, 5, 0
	s_wait_loadcnt 0x0
	v_and_b32_e32 v96, 7, v33
	v_bfe_u32 v137, v36, 8, 3
	v_bfe_u32 v130, v34, 8, 7
	v_bfe_u32 v134, v35, 8, 3
	ds_load_b128 v[89:92], v93
	ds_load_b128 v[116:119], v93 offset:16
	v_lshl_add_u32 v93, s9, 1, v93
	v_cvt_f32_ubyte0_e32 v100, v96
	v_cvt_f32_ubyte0_e32 v137, v137
	v_bfe_u32 v136, v35, 24, 7
	ds_load_b128 v[121:124], v93
	ds_load_b128 v[125:128], v93 offset:16
	v_lshlrev_b32_e32 v135, 16, v35
	v_bfe_u32 v140, v39, 24, 3
	v_lshlrev_b32_e32 v139, 24, v39
	s_mov_b32 s19, exec_lo
	v_lshlrev_b32_e32 v138, 24, v36
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v140, v140
	s_wait_dscnt 0x3
	v_dual_mul_f32 v140, 0x3b000000, v140 :: v_dual_lshlrev_b32 v113, 16, v90
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v97, 16, v116
	v_and_b32_e32 v95, 0xffff0000, v116
	v_lshlrev_b32_e32 v94, 16, v117
	v_and_b32_e32 v93, 0xffff0000, v117
	v_and_b32_e32 v111, 0xffff0000, v90
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v117, 16, v122
	v_and_b32_e32 v116, 0xffff0000, v122
	v_bfe_u32 v122, v33, 8, 3
	v_and_b32_e32 v107, 0xffff0000, v91
	v_lshlrev_b32_e32 v104, 16, v92
	v_and_b32_e32 v101, 0xffff0000, v92
	v_lshlrev_b32_e32 v92, 16, v118
	v_cvt_f32_ubyte0_e32 v122, v122
	v_lshlrev_b32_e32 v109, 16, v91
	v_lshlrev_b32_e32 v90, 16, v119
	v_lshlrev_b32_e32 v114, 16, v123
	v_lshlrev_b32_e32 v110, 16, v124
	v_and_b32_e32 v108, 0xffff0000, v124
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v98, 16, v127
	v_mul_f32_e32 v124, 0x3b000000, v100
	v_lshlrev_b32_e32 v120, 16, v89
	v_mul_f32_e32 v122, 0x3b000000, v122
	v_and_b32_e32 v115, 0xffff0000, v89
	v_and_b32_e32 v89, 0xffff0000, v119
	v_lshlrev_b32_e32 v119, 16, v121
	v_mul_f32_e32 v137, 0x3b000000, v137
	v_and_b32_e32 v91, 0xffff0000, v118
	v_and_b32_e32 v118, 0xffff0000, v121
	v_and_b32_e32 v121, 0x7f, v33
	v_and_b32_e32 v112, 0xffff0000, v123
	v_lshlrev_b32_e32 v106, 16, v125
	v_and_b32_e32 v103, 0xffff0000, v125
	v_bfe_u32 v125, v33, 8, 7
	v_lshl_add_u32 v123, v121, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v121
	v_lshlrev_b32_e32 v105, 16, v126
	v_and_b32_e32 v102, 0xffff0000, v126
	v_bfe_u32 v126, v33, 16, 3
	v_and_b32_e32 v96, 0xffff0000, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v124, v123, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v121
	v_lshl_add_u32 v124, v125, 20, 0x3c000000
	v_lshlrev_b32_e32 v127, 16, v33
	v_lshlrev_b32_e32 v99, 16, v128
	v_and_b32_e32 v129, 0x7f, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v123, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v125
	v_bfe_u32 v123, v33, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v124, vcc_lo
	v_cvt_f32_ubyte0_e32 v124, v126
	v_lshlrev_b32_e32 v126, 24, v33
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v125
	v_lshl_add_u32 v125, v123, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v124, 0x3b000000, v124
	v_and_or_b32 v126, 0x80000000, v126, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_bfe_u32 v121, v33, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v122, 0x80000000, v127, v122
	v_cvt_f32_ubyte0_e32 v121, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, v124, v125, vcc_lo
	v_bfe_u32 v125, v33, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_and_b32_e32 v100, 0xffff0000, v128
	v_and_b32_e32 v127, 7, v34
	v_mul_f32_e32 v121, 0x3b000000, v121
	v_lshl_add_u32 v128, v125, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v123, 0x7fc00000, v124 :: v_dual_lshlrev_b32 v124, 8, v33
	v_cmp_lt_u32_e32 vcc_lo, 7, v125
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v123, 0x80000000, v124, v123
	v_cvt_f32_ubyte0_e32 v124, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v121, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v125
	v_lshl_add_u32 v127, v129, 20, 0x3c000000
	v_bfe_u32 v128, v34, 8, 3
	v_mul_f32_e32 v124, 0x3b000000, v124
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	v_cvt_f32_ubyte0_e32 v125, v128
	v_bfe_u32 v128, v34, 16, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v132, 0x80000000, v33, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, v124, v127, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_lshl_add_u32 v127, v130, 20, 0x3c000000
	v_mul_f32_e32 v125, 0x3b000000, v125
	v_bfe_u32 v129, v34, 16, 7
	v_cvt_f32_ubyte0_e32 v128, v128
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, 0x7fc00000, v124, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_lshl_add_u32 v131, v129, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v128, 0x3b000000, v128 :: v_dual_cndmask_b32 v125, v125, v127
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshlrev_b32_e32 v127, 24, v34
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v125, 0x7fc00000, v125, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	v_and_or_b32 v124, 0x80000000, v127, v124
	v_bfe_u32 v127, v34, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v128, v131, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_lshlrev_b32_e32 v130, 16, v34
	v_lshlrev_b32_e32 v129, 8, v34
	v_cvt_f32_ubyte0_e32 v127, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_and_or_b32 v125, 0x80000000, v130, v125
	v_bfe_u32 v130, v34, 24, 7
	v_mul_f32_e32 v127, 0x3b000000, v127
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v129, 0x80000000, v129, v121
	v_and_b32_e32 v131, 0x7f, v35
	v_lshl_add_u32 v121, v130, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v133, v131, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v121, v127, v121 :: v_dual_and_b32 v128, 7, v35
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v128, v128
	v_mul_f32_e32 v128, 0x3b000000, v128
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v127, v128, v133, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_bfe_u32 v128, v35, 8, 7
	v_cvt_f32_ubyte0_e32 v133, v134
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_lshl_add_u32 v130, v128, 20, 0x3c000000
	v_mul_f32_e32 v131, 0x3b000000, v133
	v_lshlrev_b32_e32 v133, 24, v35
	v_and_or_b32 v134, 0x80000000, v34, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v127, 0x7fc00000, v127, vcc_lo
	v_bfe_u32 v121, v35, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v128
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v127, 0x80000000, v133, v127
	v_cvt_f32_ubyte0_e32 v121, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, v131, v130, vcc_lo
	v_bfe_u32 v131, v35, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v128
	v_mul_f32_e32 v121, 0x3b000000, v121
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v133, v131, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, 0x7fc00000, v130, vcc_lo
	v_bfe_u32 v130, v35, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_and_or_b32 v128, 0x80000000, v135, v128
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v130, v130
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v121, v133, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_lshl_add_u32 v133, v136, 20, 0x3c000000
	v_mul_f32_e32 v130, 0x3b000000, v130
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v130, v130, v133 :: v_dual_lshlrev_b32 v133, 8, v35
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v133, 0x80000000, v133, v121
	v_fma_f32 v121, v126, v120, 0
	v_fma_f32 v126, v126, v119, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v130, 0x7fc00000, v130 :: v_dual_fmac_f32 v121, v122, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v126, v122, v118
	v_and_or_b32 v130, 0x80000000, v35, v130
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v121, v123, v113
	v_dual_fmac_f32 v126, v123, v117 :: v_dual_fmac_f32 v121, v132, v111
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v126, v132, v116
	v_bfe_u32 v132, v36, 16, 3
	v_fmac_f32_e32 v121, v124, v109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v126, v124, v114 :: v_dual_fmac_f32 v121, v125, v107
	v_fmac_f32_e32 v126, v125, v112
	v_bfe_u32 v125, v36, 24, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v121, v129, v104
	v_dual_fmac_f32 v126, v129, v110 :: v_dual_fmac_f32 v121, v134, v101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v126, v134, v108
	v_bfe_u32 v134, v38, 8, 3
	v_fmac_f32_e32 v121, v127, v97
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v126, v127, v106 :: v_dual_lshlrev_b32 v127, 8, v36
	v_fmac_f32_e32 v121, v128, v95
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v126, v128, v103 :: v_dual_and_b32 v131, 7, v36
	v_bfe_u32 v128, v37, 8, 3
	v_fmac_f32_e32 v121, v133, v94
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v126, v133, v105 :: v_dual_and_b32 v135, 0x7f, v36
	v_cvt_f32_ubyte0_e32 v131, v131
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v128, v128
	v_fmac_f32_e32 v121, v130, v93
	s_delay_alu instid0(VALU_DEP_4)
	v_fmac_f32_e32 v126, v130, v102
	v_lshl_add_u32 v136, v135, 20, 0x3c000000
	v_mul_f32_e32 v131, 0x3b000000, v131
	v_cmp_lt_u32_e32 vcc_lo, 7, v135
	v_mul_f32_e32 v128, 0x3b000000, v128
	v_lshlrev_b32_e32 v123, 16, v36
	v_bfe_u32 v130, v37, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v131, v131, v136, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v135
	v_bfe_u32 v136, v36, 8, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v131, 0x7fc00000, v131, vcc_lo
	v_lshl_add_u32 v135, v136, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v131, 0x80000000, v138, v131
	v_bfe_u32 v138, v39, 16, 7
	v_fmac_f32_e32 v126, v131, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v137, v135, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_bfe_u32 v135, v36, 16, 7
	v_fmac_f32_e32 v121, v131, v92
	v_bfe_u32 v131, v37, 16, 3
	v_bfe_u32 v136, v38, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_lshl_add_u32 v124, v135, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v135
	v_cvt_f32_ubyte0_e32 v131, v131
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_and_or_b32 v122, 0x80000000, v123, v122
	v_cvt_f32_ubyte0_e32 v123, v132
	v_bfe_u32 v132, v36, 24, 3
	v_dual_mul_f32 v131, 0x3b000000, v131 :: v_dual_fmac_f32 v126, v122, v96
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v123, 0x3b000000, v123
	v_cvt_f32_ubyte0_e32 v132, v132
	v_fmac_f32_e32 v121, v122, v91
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v123, v123, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v135
	v_lshl_add_u32 v124, v125, 20, 0x3c000000
	v_mul_f32_e32 v129, 0x3b000000, v132
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v125
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v123, 0x80000000, v127, v123
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, v129, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v125
	v_and_b32_e32 v125, 7, v37
	v_and_b32_e32 v127, 0x7f, v37
	v_fmac_f32_e32 v121, v123, v90
	v_fmac_f32_e32 v126, v123, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, 0x7fc00000, v124, vcc_lo
	v_cvt_f32_ubyte0_e32 v125, v125
	v_lshl_add_u32 v129, v127, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v127
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v124, 0x80000000, v36, v124
	v_mul_f32_e32 v125, 0x3b000000, v125
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v121, v124, v89
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v125, v129, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v127
	v_lshl_add_u32 v129, v130, 20, 0x3c000000
	v_bfe_u32 v127, v37, 16, 7
	v_fmac_f32_e32 v126, v124, v100
	v_add_f32_e32 v86, v86, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, 0x7fc00000, v125, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_lshl_add_u32 v132, v127, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_add_f32 v85, v85, v126 :: v_dual_cndmask_b32 v128, v128, v129
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshlrev_b32_e32 v129, 24, v37
	v_lshlrev_b32_e32 v130, 16, v37
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, 0x7fc00000, v128, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v127
	v_and_or_b32 v125, 0x80000000, v129, v125
	v_bfe_u32 v129, v37, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v128, 0x80000000, v130, v128
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v131, v132, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v127
	v_and_b32_e32 v127, 7, v38
	v_lshlrev_b32_e32 v130, 8, v37
	v_bfe_u32 v131, v37, 24, 7
	v_cvt_f32_ubyte0_e32 v129, v129
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_and_b32_e32 v132, 0x7f, v38
	v_cvt_f32_ubyte0_e32 v127, v127
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_mul_f32_e32 v129, 0x3b000000, v129
	v_and_or_b32 v122, 0x80000000, v130, v122
	v_lshl_add_u32 v130, v131, 20, 0x3c000000
	v_lshl_add_u32 v133, v132, 20, 0x3c000000
	v_mul_f32_e32 v127, 0x3b000000, v127
	v_fma_f32 v120, v125, v120, 0
	v_fma_f32 v119, v125, v119, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, v129, v130, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	v_bfe_u32 v130, v38, 8, 7
	v_dual_fmac_f32 v120, v128, v115 :: v_dual_and_b32 v125, 0x7f, v40
	v_fmac_f32_e32 v119, v128, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v127, v127, v133, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_cvt_f32_ubyte0_e32 v133, v134
	v_lshl_add_u32 v131, v130, 20, 0x3c000000
	v_bfe_u32 v134, v38, 16, 3
	v_fmac_f32_e32 v120, v122, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, 0x7fc00000, v129, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_dual_mul_f32 v132, 0x3b000000, v133 :: v_dual_lshlrev_b32 v133, 24, v38
	v_fmac_f32_e32 v119, v122, v117
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v129, 0x80000000, v37, v129
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v127, 0x7fc00000, v127, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_lshl_add_u32 v115, v125, 20, 0x3c000000
	v_bfe_u32 v128, v40, 8, 3
	v_fmac_f32_e32 v120, v129, v111
	v_and_or_b32 v127, 0x80000000, v133, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v131, v132, v131, vcc_lo
	v_bfe_u32 v132, v38, 16, 7
	v_cvt_f32_ubyte0_e32 v133, v134
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_bfe_u32 v134, v38, 24, 3
	v_fmac_f32_e32 v119, v129, v116
	v_lshl_add_u32 v135, v132, 20, 0x3c000000
	v_mul_f32_e32 v133, 0x3b000000, v133
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v130, 0x7fc00000, v131 :: v_dual_lshlrev_b32 v131, 16, v38
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	v_cvt_f32_ubyte0_e32 v111, v128
	v_fmac_f32_e32 v120, v127, v109
	v_fmac_f32_e32 v119, v127, v114
	v_and_or_b32 v130, 0x80000000, v131, v130
	v_cvt_f32_ubyte0_e32 v131, v134
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v133, v133, v135, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_lshl_add_u32 v134, v136, 20, 0x3c000000
	v_and_b32_e32 v135, 7, v39
	v_mul_f32_e32 v131, 0x3b000000, v131
	v_mul_f32_e32 v111, 0x3b000000, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v132, 0x7fc00000, v133, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	v_and_b32_e32 v133, 0x7f, v39
	v_cvt_f32_ubyte0_e32 v135, v135
	v_fmac_f32_e32 v120, v130, v107
	v_fmac_f32_e32 v119, v130, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v131, v131, v134, vcc_lo
	v_lshlrev_b32_e32 v134, 8, v38
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_lshl_add_u32 v137, v133, 20, 0x3c000000
	v_mul_f32_e32 v135, 0x3b000000, v135
	v_bfe_u32 v136, v39, 8, 7
	v_and_or_b32 v132, 0x80000000, v134, v132
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v131, 0x7fc00000, v131, vcc_lo
	v_bfe_u32 v134, v39, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v133
	v_lshlrev_b32_e32 v114, 24, v40
	v_fmac_f32_e32 v120, v132, v104
	v_and_or_b32 v131, 0x80000000, v38, v131
	v_cvt_f32_ubyte0_e32 v134, v134
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, v135, v137, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v133
	v_lshl_add_u32 v137, v136, 20, 0x3c000000
	v_fmac_f32_e32 v119, v132, v110
	v_mul_f32_e32 v134, 0x3b000000, v134
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v120, v131, v101 :: v_dual_cndmask_b32 v133, 0x7fc00000, v135
	v_bfe_u32 v135, v39, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	v_fmac_f32_e32 v119, v131, v108
	v_bfe_u32 v101, v40, 16, 7
	v_and_or_b32 v133, 0x80000000, v139, v133
	v_cvt_f32_ubyte0_e32 v135, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v134, v134, v137, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_lshl_add_u32 v137, v138, 20, 0x3c000000
	v_bfe_u32 v136, v39, 24, 7
	v_dual_mul_f32 v135, 0x3b000000, v135 :: v_dual_fmac_f32 v120, v133, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v134, 0x7fc00000, v134, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v138
	v_lshl_add_u32 v141, v136, 20, 0x3c000000
	v_fmac_f32_e32 v119, v133, v106
	v_lshl_add_u32 v97, v101, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v135, v135, v137 :: v_dual_lshlrev_b32 v110, 16, v40
	v_lshlrev_b32_e32 v137, 16, v39
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v138
	v_lshlrev_b32_e32 v138, 8, v39
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v134, 0x80000000, v137, v134
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, 0x7fc00000, v135, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	v_dual_fmac_f32 v120, v134, v95 :: v_dual_and_b32 v137, 7, v40
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v135, 0x80000000, v138, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v139, v140, v141, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_cvt_f32_ubyte0_e32 v137, v137
	v_dual_fmac_f32 v119, v134, v103 :: v_dual_fmac_f32 v120, v135, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v136, 0x7fc00000, v139, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v118, 0x3b000000, v137
	v_cmp_lt_u32_e32 vcc_lo, 7, v125
	v_fmac_f32_e32 v119, v135, v105
	v_and_or_b32 v136, 0x80000000, v39, v136
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v118, v115, vcc_lo
	v_bfe_u32 v115, v40, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v125
	v_fmac_f32_e32 v120, v136, v93
	v_fmac_f32_e32 v119, v136, v102
	v_lshlrev_b32_e32 v93, 8, v40
	v_lshl_add_u32 v109, v115, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v111, v109, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_and_or_b32 v109, 0x80000000, v114, v113
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v104, 0x7fc00000, v107, vcc_lo
	v_bfe_u32 v107, v40, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_fmac_f32_e32 v120, v109, v92
	v_fmac_f32_e32 v119, v109, v98
	v_and_or_b32 v104, 0x80000000, v110, v104
	v_cvt_f32_ubyte0_e32 v107, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v120, v104, v91
	v_mul_f32_e32 v106, 0x3b000000, v107
	v_bfe_u32 v107, v40, 24, 3
	v_fmac_f32_e32 v119, v104, v96
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v95, v106, v97, vcc_lo
	v_bfe_u32 v97, v40, 24, 7
	v_cvt_f32_ubyte0_e32 v103, v107
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_mul_f32_e32 v101, 0x3b000000, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v95, vcc_lo
	v_lshl_add_u32 v95, v97, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v92, 0x80000000, v93, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, v101, v95, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v120, v92, v90
	v_fmac_f32_e32 v119, v92, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v95, vcc_lo
	v_and_or_b32 v91, 0x80000000, v40, v93
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v120, v91, v89
	v_fmac_f32_e32 v119, v91, v100
	v_add_nc_u32_e32 v89, 32, v88
	v_dual_add_f32 v84, v84, v120 :: v_dual_add_f32 v83, v83, v119
	s_delay_alu instid0(VALU_DEP_2)
	v_cmpx_gt_i32_e64 s16, v89
	s_cbranch_execz .LBB69_31
; %bb.53:                               ;   in Loop: Header=BB69_33 Depth=1
	v_add_nc_u32_e32 v89, s8, v87
	ds_load_b128 v[90:93], v87
	ds_load_b128 v[117:120], v87 offset:16
	v_bfe_u32 v138, v44, 8, 3
	v_and_b32_e32 v97, 7, v41
	v_bfe_u32 v131, v42, 8, 7
	ds_load_b128 v[122:125], v89
	ds_load_b128 v[126:129], v89 offset:16
	v_bfe_u32 v135, v43, 8, 3
	v_cvt_f32_ubyte0_e32 v138, v138
	v_cvt_f32_ubyte0_e32 v101, v97
	v_bfe_u32 v137, v43, 24, 7
	v_bfe_u32 v141, v47, 24, 3
	s_mov_b32 s20, exec_lo
	v_lshlrev_b32_e32 v139, 24, v44
	s_delay_alu instid0(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v141, v141
	s_wait_dscnt 0x3
	v_lshlrev_b32_e32 v121, 16, v90
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v98, 16, v117
	v_and_b32_e32 v96, 0xffff0000, v117
	v_lshlrev_b32_e32 v95, 16, v118
	v_and_b32_e32 v94, 0xffff0000, v118
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v118, 16, v123
	v_and_b32_e32 v117, 0xffff0000, v123
	v_bfe_u32 v123, v41, 8, 3
	v_lshlrev_b32_e32 v114, 16, v91
	v_and_b32_e32 v112, 0xffff0000, v91
	v_and_b32_e32 v108, 0xffff0000, v92
	v_lshlrev_b32_e32 v105, 16, v93
	v_cvt_f32_ubyte0_e32 v123, v123
	v_lshlrev_b32_e32 v110, 16, v92
	v_and_b32_e32 v102, 0xffff0000, v93
	v_lshlrev_b32_e32 v93, 16, v119
	v_lshlrev_b32_e32 v91, 16, v120
	v_lshlrev_b32_e32 v115, 16, v124
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v107, 16, v126
	v_mul_f32_e32 v123, 0x3b000000, v123
	v_and_b32_e32 v116, 0xffff0000, v90
	v_and_b32_e32 v90, 0xffff0000, v120
	v_lshlrev_b32_e32 v120, 16, v122
	v_mul_f32_e32 v138, 0x3b000000, v138
	v_and_b32_e32 v92, 0xffff0000, v119
	v_and_b32_e32 v119, 0xffff0000, v122
	v_and_b32_e32 v122, 0x7f, v41
	v_and_b32_e32 v113, 0xffff0000, v124
	v_lshlrev_b32_e32 v111, 16, v125
	v_and_b32_e32 v109, 0xffff0000, v125
	v_mul_f32_e32 v125, 0x3b000000, v101
	v_lshl_add_u32 v124, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_and_b32_e32 v104, 0xffff0000, v126
	v_bfe_u32 v126, v41, 8, 7
	v_lshlrev_b32_e32 v106, 16, v127
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v124, v125, v124 :: v_dual_and_b32 v103, 0xffff0000, v127
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_lshl_add_u32 v125, v126, 20, 0x3c000000
	v_bfe_u32 v127, v41, 16, 3
	v_lshlrev_b32_e32 v99, 16, v128
	v_and_b32_e32 v97, 0xffff0000, v128
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v124, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	v_bfe_u32 v124, v41, 16, 7
	v_lshlrev_b32_e32 v128, 16, v41
	v_lshlrev_b32_e32 v100, 16, v129
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v123, v123, v125 :: v_dual_and_b32 v130, 0x7f, v42
	v_cvt_f32_ubyte0_e32 v125, v127
	v_lshlrev_b32_e32 v127, 24, v41
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_lshl_add_u32 v126, v124, 20, 0x3c000000
	v_mul_f32_e32 v141, 0x3b000000, v141
	v_mul_f32_e32 v125, 0x3b000000, v125
	v_and_or_b32 v127, 0x80000000, v127, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_bfe_u32 v122, v41, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v123, 0x80000000, v128, v123
	v_cvt_f32_ubyte0_e32 v122, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v125, v126, vcc_lo
	v_bfe_u32 v126, v41, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v124
	v_and_b32_e32 v101, 0xffff0000, v129
	v_mul_f32_e32 v122, 0x3b000000, v122
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v129, v126, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, 0x7fc00000, v125, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	v_lshlrev_b32_e32 v125, 8, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v129, vcc_lo
	v_bfe_u32 v129, v42, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_and_or_b32 v124, 0x80000000, v125, v124
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v126, v129
	v_bfe_u32 v129, v42, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_mul_f32_e32 v126, 0x3b000000, v126
	v_cvt_f32_ubyte0_e32 v129, v129
	v_and_b32_e32 v128, 7, v42
	v_and_or_b32 v133, 0x80000000, v41, v122
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v129, 0x3b000000, v129
	v_cvt_f32_ubyte0_e32 v125, v128
	v_lshl_add_u32 v128, v130, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v125, 0x3b000000, v125
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v125, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshl_add_u32 v128, v131, 20, 0x3c000000
	v_bfe_u32 v130, v42, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, 0x7fc00000, v125, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v132, v130, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v126, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_lshlrev_b32_e32 v131, 16, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v126, 0x7fc00000, v126, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_and_or_b32 v126, 0x80000000, v131, v126
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v122, v129, v132 :: v_dual_and_b32 v129, 7, v43
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshlrev_b32_e32 v130, 8, v42
	v_bfe_u32 v131, v42, 24, 7
	v_and_b32_e32 v132, 0x7f, v43
	v_cvt_f32_ubyte0_e32 v129, v129
	v_lshlrev_b32_e32 v128, 24, v42
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_lshl_add_u32 v134, v132, 20, 0x3c000000
	v_mul_f32_e32 v129, 0x3b000000, v129
	v_and_or_b32 v125, 0x80000000, v128, v125
	v_bfe_u32 v128, v42, 24, 3
	v_and_or_b32 v130, 0x80000000, v130, v122
	v_lshl_add_u32 v122, v131, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v128, v128
	v_mul_f32_e32 v128, 0x3b000000, v128
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v122, v128, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, v129, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_bfe_u32 v129, v43, 8, 7
	v_cvt_f32_ubyte0_e32 v134, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_lshl_add_u32 v131, v129, 20, 0x3c000000
	v_mul_f32_e32 v132, 0x3b000000, v134
	v_lshlrev_b32_e32 v134, 24, v43
	v_and_or_b32 v135, 0x80000000, v42, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, 0x7fc00000, v128, vcc_lo
	v_bfe_u32 v122, v43, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v128, 0x80000000, v134, v128
	v_cvt_f32_ubyte0_e32 v122, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v131, v132, v131, vcc_lo
	v_bfe_u32 v132, v43, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_mul_f32_e32 v122, 0x3b000000, v122
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v134, v132, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, 0x7fc00000, v131, vcc_lo
	v_bfe_u32 v131, v43, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	v_cvt_f32_ubyte0_e32 v131, v131
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_lshl_add_u32 v134, v137, 20, 0x3c000000
	v_dual_mul_f32 v131, 0x3b000000, v131 :: v_dual_and_b32 v132, 7, v44
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v132, v132
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v131, v131, v134 :: v_dual_lshlrev_b32 v134, 8, v43
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_mul_f32_e32 v132, 0x3b000000, v132
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v134, 0x80000000, v134, v122
	v_fma_f32 v122, v127, v121, 0
	v_fma_f32 v127, v127, v120, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v131, 0x7fc00000, v131 :: v_dual_fmac_f32 v122, v123, v116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v127, v123, v119
	v_and_or_b32 v131, 0x80000000, v43, v131
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v124, v118
	v_fmac_f32_e32 v127, v133, v117
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v125, v115
	v_dual_fmac_f32 v127, v126, v113 :: v_dual_fmac_f32 v122, v124, v114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v130, v111
	v_fmac_f32_e32 v127, v135, v109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v128, v107
	v_lshlrev_b32_e32 v136, 16, v43
	v_and_or_b32 v129, 0x80000000, v136, v129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v129, v104
	v_dual_fmac_f32 v127, v134, v106 :: v_dual_and_b32 v136, 0x7f, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v137, v136, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v127, v131, v103 :: v_dual_cndmask_b32 v132, v132, v137
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_bfe_u32 v137, v44, 8, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v132, 0x7fc00000, v132, vcc_lo
	v_lshl_add_u32 v136, v137, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v132, 0x80000000, v139, v132
	v_fmac_f32_e32 v122, v133, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v138, v136, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_bfe_u32 v133, v44, 16, 3
	v_dual_fmac_f32 v127, v132, v99 :: v_dual_fmac_f32 v122, v125, v110
	v_bfe_u32 v136, v44, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_bfe_u32 v137, v46, 24, 7
	v_bfe_u32 v139, v47, 16, 7
	v_fmac_f32_e32 v122, v126, v108
	v_lshl_add_u32 v125, v136, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	v_bfe_u32 v126, v44, 24, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v122, v130, v105
	v_fmac_f32_e32 v122, v135, v102
	v_bfe_u32 v135, v46, 8, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v122, v128, v98
	v_lshlrev_b32_e32 v128, 8, v44
	v_fmac_f32_e32 v122, v129, v96
	v_bfe_u32 v129, v45, 8, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v122, v134, v95
	v_cvt_f32_ubyte0_e32 v129, v129
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v122, v131, v94 :: v_dual_mul_f32 v129, 0x3b000000, v129
	v_lshlrev_b32_e32 v124, 16, v44
	v_bfe_u32 v131, v45, 8, 7
	v_fmac_f32_e32 v122, v132, v93
	v_bfe_u32 v132, v45, 16, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v123, 0x80000000, v124, v123
	v_cvt_f32_ubyte0_e32 v124, v133
	v_bfe_u32 v133, v44, 24, 3
	v_cvt_f32_ubyte0_e32 v132, v132
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v127, v123, v97 :: v_dual_mul_f32 v124, 0x3b000000, v124
	v_cvt_f32_ubyte0_e32 v133, v133
	v_fmac_f32_e32 v122, v123, v92
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v132, 0x3b000000, v132
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, v124, v125, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_lshl_add_u32 v125, v126, 20, 0x3c000000
	v_mul_f32_e32 v130, 0x3b000000, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, 0x7fc00000, v124, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v124, 0x80000000, v128, v124
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v130, v125, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_and_b32_e32 v126, 7, v45
	v_and_b32_e32 v128, 0x7f, v45
	v_dual_fmac_f32 v127, v124, v100 :: v_dual_lshlrev_b32 v140, 24, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, 0x7fc00000, v125, vcc_lo
	v_cvt_f32_ubyte0_e32 v126, v126
	v_lshl_add_u32 v130, v128, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v128
	v_fmac_f32_e32 v122, v124, v91
	v_and_or_b32 v125, 0x80000000, v44, v125
	v_mul_f32_e32 v126, 0x3b000000, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v122, v125, v90
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v126, v130, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v128
	v_lshl_add_u32 v130, v131, 20, 0x3c000000
	v_bfe_u32 v128, v45, 16, 7
	v_dual_add_f32 v86, v86, v122 :: v_dual_fmac_f32 v127, v125, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, 0x7fc00000, v126, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_lshl_add_u32 v133, v128, 20, 0x3c000000
	v_add_f32_e32 v85, v85, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, v129, v130, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_lshlrev_b32_e32 v130, 24, v45
	v_lshlrev_b32_e32 v131, 16, v45
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, 0x7fc00000, v129, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v128
	v_and_or_b32 v126, 0x80000000, v130, v126
	v_bfe_u32 v130, v45, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v129, 0x80000000, v131, v129
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v132, v133, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v128
	v_and_b32_e32 v128, 7, v46
	v_lshlrev_b32_e32 v131, 8, v45
	v_bfe_u32 v132, v45, 24, 7
	v_cvt_f32_ubyte0_e32 v130, v130
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_and_b32_e32 v133, 0x7f, v46
	v_cvt_f32_ubyte0_e32 v128, v128
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	v_mul_f32_e32 v130, 0x3b000000, v130
	v_and_or_b32 v123, 0x80000000, v131, v123
	v_lshl_add_u32 v131, v132, 20, 0x3c000000
	v_fma_f32 v121, v126, v121, 0
	v_lshl_add_u32 v134, v133, 20, 0x3c000000
	v_fma_f32 v120, v126, v120, 0
	v_and_b32_e32 v126, 0x7f, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, v130, v131, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v133
	v_fmac_f32_e32 v121, v129, v116
	v_mul_f32_e32 v128, 0x3b000000, v128
	v_bfe_u32 v131, v46, 8, 7
	v_fmac_f32_e32 v120, v129, v119
	v_lshl_add_u32 v116, v126, 20, 0x3c000000
	v_fmac_f32_e32 v121, v123, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, v128, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_cvt_f32_ubyte0_e32 v134, v135
	v_lshl_add_u32 v132, v131, 20, 0x3c000000
	v_bfe_u32 v135, v46, 16, 3
	v_fmac_f32_e32 v120, v123, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, 0x7fc00000, v130, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v133
	v_mul_f32_e32 v133, 0x3b000000, v134
	v_lshlrev_b32_e32 v134, 24, v46
	v_bfe_u32 v129, v48, 8, 3
	v_and_or_b32 v130, 0x80000000, v45, v130
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, 0x7fc00000, v128, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v121, v130, v112
	v_and_or_b32 v128, 0x80000000, v134, v128
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v132, v133, v132, vcc_lo
	v_bfe_u32 v133, v46, 16, 7
	v_cvt_f32_ubyte0_e32 v134, v135
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_bfe_u32 v135, v46, 24, 3
	v_fmac_f32_e32 v120, v130, v117
	v_lshl_add_u32 v136, v133, 20, 0x3c000000
	v_mul_f32_e32 v134, 0x3b000000, v134
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v131, 0x7fc00000, v132 :: v_dual_lshlrev_b32 v132, 16, v46
	v_cmp_lt_u32_e32 vcc_lo, 7, v133
	v_cvt_f32_ubyte0_e32 v112, v129
	v_fmac_f32_e32 v121, v128, v110
	v_fmac_f32_e32 v120, v128, v115
	v_and_or_b32 v131, 0x80000000, v132, v131
	v_cvt_f32_ubyte0_e32 v132, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v134, v134, v136, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v133
	v_lshl_add_u32 v135, v137, 20, 0x3c000000
	v_and_b32_e32 v136, 7, v47
	v_mul_f32_e32 v132, 0x3b000000, v132
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v133, 0x7fc00000, v134, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_and_b32_e32 v134, 0x7f, v47
	v_cvt_f32_ubyte0_e32 v136, v136
	v_fmac_f32_e32 v121, v131, v108
	v_fmac_f32_e32 v120, v131, v113
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v132, v132, v135 :: v_dual_lshlrev_b32 v135, 8, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_lshl_add_u32 v138, v134, 20, 0x3c000000
	v_mul_f32_e32 v136, 0x3b000000, v136
	v_bfe_u32 v137, v47, 8, 7
	v_and_or_b32 v133, 0x80000000, v135, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v132, 0x7fc00000, v132, vcc_lo
	v_bfe_u32 v135, v47, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v134
	v_lshlrev_b32_e32 v115, 24, v48
	v_fmac_f32_e32 v121, v133, v105
	v_and_or_b32 v132, 0x80000000, v46, v132
	v_cvt_f32_ubyte0_e32 v135, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v136, v136, v138, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v134
	v_lshl_add_u32 v138, v137, 20, 0x3c000000
	v_fmac_f32_e32 v120, v133, v111
	v_mul_f32_e32 v135, 0x3b000000, v135
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v121, v132, v102 :: v_dual_cndmask_b32 v134, 0x7fc00000, v136
	v_bfe_u32 v136, v47, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_fmac_f32_e32 v120, v132, v109
	v_bfe_u32 v102, v48, 16, 7
	v_and_or_b32 v134, 0x80000000, v140, v134
	v_cvt_f32_ubyte0_e32 v136, v136
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, v135, v138, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_lshl_add_u32 v138, v139, 20, 0x3c000000
	v_bfe_u32 v137, v47, 24, 7
	v_dual_mul_f32 v136, 0x3b000000, v136 :: v_dual_fmac_f32 v121, v134, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, 0x7fc00000, v135, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v139
	v_lshl_add_u32 v142, v137, 20, 0x3c000000
	v_fmac_f32_e32 v120, v134, v107
	v_lshl_add_u32 v98, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v136, v136, v138 :: v_dual_lshlrev_b32 v111, 16, v48
	v_lshlrev_b32_e32 v138, 16, v47
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v139
	v_lshlrev_b32_e32 v139, 8, v47
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v135, 0x80000000, v138, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v136, 0x7fc00000, v136, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_and_b32_e32 v138, 7, v48
	v_fmac_f32_e32 v121, v135, v96
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v136, 0x80000000, v139, v136
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v140, v141, v142, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_cvt_f32_ubyte0_e32 v138, v138
	v_dual_fmac_f32 v120, v135, v104 :: v_dual_fmac_f32 v121, v136, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v137, 0x7fc00000, v140, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v119, 0x3b000000, v138
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	v_fmac_f32_e32 v120, v136, v106
	v_and_or_b32 v137, 0x80000000, v47, v137
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v119, v116, vcc_lo
	v_bfe_u32 v116, v48, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_fmac_f32_e32 v121, v137, v94
	v_fmac_f32_e32 v120, v137, v103
	v_lshlrev_b32_e32 v94, 8, v48
	v_lshl_add_u32 v110, v116, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v112, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_and_or_b32 v110, 0x80000000, v115, v114
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v105, 0x7fc00000, v108, vcc_lo
	v_bfe_u32 v108, v48, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_fmac_f32_e32 v121, v110, v93
	v_fmac_f32_e32 v120, v110, v99
	v_and_or_b32 v105, 0x80000000, v111, v105
	v_cvt_f32_ubyte0_e32 v108, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v121, v105, v92
	v_mul_f32_e32 v107, 0x3b000000, v108
	v_bfe_u32 v108, v48, 24, 3
	v_fmac_f32_e32 v120, v105, v97
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v96, v107, v98, vcc_lo
	v_bfe_u32 v98, v48, 24, 7
	v_cvt_f32_ubyte0_e32 v104, v108
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_mul_f32_e32 v102, 0x3b000000, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v96, vcc_lo
	v_lshl_add_u32 v96, v98, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v94, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v102, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v121, v93, v91
	v_fmac_f32_e32 v120, v93, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v96, vcc_lo
	v_and_or_b32 v92, 0x80000000, v48, v94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v121, v92, v90
	v_fmac_f32_e32 v120, v92, v101
	v_add_nc_u32_e32 v90, 64, v88
	v_dual_add_f32 v84, v84, v121 :: v_dual_add_f32 v83, v83, v120
	s_delay_alu instid0(VALU_DEP_2)
	v_cmpx_gt_i32_e64 s16, v90
	s_cbranch_execz .LBB69_30
; %bb.54:                               ;   in Loop: Header=BB69_33 Depth=1
	ds_load_b128 v[90:93], v87 offset:1024
	ds_load_b128 v[117:120], v87 offset:1040
	ds_load_b128 v[122:125], v89 offset:1024
	ds_load_b128 v[126:129], v89 offset:1040
	v_and_b32_e32 v97, 7, v49
	v_bfe_u32 v138, v52, 8, 3
	v_bfe_u32 v131, v50, 8, 7
	v_bfe_u32 v135, v51, 8, 3
	v_bfe_u32 v137, v51, 24, 7
	v_cvt_f32_ubyte0_e32 v101, v97
	v_cvt_f32_ubyte0_e32 v138, v138
	v_bfe_u32 v141, v55, 24, 3
	v_add_nc_u32_e32 v88, 0x60, v88
	s_mov_b32 s21, exec_lo
	v_lshlrev_b32_e32 v139, 24, v52
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v141, v141
	s_wait_dscnt 0x3
	v_lshlrev_b32_e32 v114, 16, v91
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v98, 16, v117
	v_and_b32_e32 v96, 0xffff0000, v117
	v_lshlrev_b32_e32 v95, 16, v118
	v_and_b32_e32 v94, 0xffff0000, v118
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v118, 16, v123
	v_and_b32_e32 v117, 0xffff0000, v123
	v_bfe_u32 v123, v49, 8, 3
	v_and_b32_e32 v112, 0xffff0000, v91
	v_and_b32_e32 v108, 0xffff0000, v92
	v_lshlrev_b32_e32 v105, 16, v93
	v_and_b32_e32 v102, 0xffff0000, v93
	v_cvt_f32_ubyte0_e32 v123, v123
	v_lshlrev_b32_e32 v110, 16, v92
	v_lshlrev_b32_e32 v93, 16, v119
	v_lshlrev_b32_e32 v91, 16, v120
	v_lshlrev_b32_e32 v115, 16, v124
	v_lshlrev_b32_e32 v111, 16, v125
	v_and_b32_e32 v109, 0xffff0000, v125
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v107, 16, v126
	v_mul_f32_e32 v125, 0x3b000000, v101
	v_lshlrev_b32_e32 v121, 16, v90
	v_mul_f32_e32 v123, 0x3b000000, v123
	v_and_b32_e32 v116, 0xffff0000, v90
	v_and_b32_e32 v90, 0xffff0000, v120
	v_lshlrev_b32_e32 v120, 16, v122
	v_mul_f32_e32 v138, 0x3b000000, v138
	v_and_b32_e32 v92, 0xffff0000, v119
	v_and_b32_e32 v119, 0xffff0000, v122
	v_and_b32_e32 v122, 0x7f, v49
	v_and_b32_e32 v113, 0xffff0000, v124
	v_and_b32_e32 v104, 0xffff0000, v126
	v_bfe_u32 v126, v49, 8, 7
	v_lshlrev_b32_e32 v106, 16, v127
	v_lshl_add_u32 v124, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_and_b32_e32 v103, 0xffff0000, v127
	v_bfe_u32 v127, v49, 16, 3
	v_lshlrev_b32_e32 v99, 16, v128
	v_and_b32_e32 v97, 0xffff0000, v128
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, v125, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_lshl_add_u32 v125, v126, 20, 0x3c000000
	v_lshlrev_b32_e32 v128, 16, v49
	v_lshlrev_b32_e32 v100, 16, v129
	v_and_b32_e32 v130, 0x7f, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v124, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	v_bfe_u32 v124, v49, 16, 7
	v_mul_f32_e32 v141, 0x3b000000, v141
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v123, v125, vcc_lo
	v_cvt_f32_ubyte0_e32 v125, v127
	v_lshlrev_b32_e32 v127, 24, v49
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_lshl_add_u32 v126, v124, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v125, 0x3b000000, v125
	v_and_or_b32 v127, 0x80000000, v127, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_bfe_u32 v122, v49, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v123, 0x80000000, v128, v123
	v_cvt_f32_ubyte0_e32 v122, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v125, v126, vcc_lo
	v_bfe_u32 v126, v49, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v124
	v_and_b32_e32 v101, 0xffff0000, v129
	v_mul_f32_e32 v122, 0x3b000000, v122
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v129, v126, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, 0x7fc00000, v125, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	v_lshlrev_b32_e32 v125, 8, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v129, vcc_lo
	v_bfe_u32 v129, v50, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_and_or_b32 v124, 0x80000000, v125, v124
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v126, v129
	v_bfe_u32 v129, v50, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_mul_f32_e32 v126, 0x3b000000, v126
	v_cvt_f32_ubyte0_e32 v129, v129
	v_and_b32_e32 v128, 7, v50
	v_and_or_b32 v133, 0x80000000, v49, v122
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v129, 0x3b000000, v129
	v_cvt_f32_ubyte0_e32 v125, v128
	v_lshl_add_u32 v128, v130, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v125, 0x3b000000, v125
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v125, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshl_add_u32 v128, v131, 20, 0x3c000000
	v_bfe_u32 v130, v50, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, 0x7fc00000, v125, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v132, v130, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v126, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_lshlrev_b32_e32 v131, 16, v50
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v126, 0x7fc00000, v126, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_and_or_b32 v126, 0x80000000, v131, v126
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v122, v129, v132 :: v_dual_and_b32 v129, 7, v51
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshlrev_b32_e32 v130, 8, v50
	v_bfe_u32 v131, v50, 24, 7
	v_and_b32_e32 v132, 0x7f, v51
	v_cvt_f32_ubyte0_e32 v129, v129
	v_lshlrev_b32_e32 v128, 24, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_lshl_add_u32 v134, v132, 20, 0x3c000000
	v_mul_f32_e32 v129, 0x3b000000, v129
	v_and_or_b32 v125, 0x80000000, v128, v125
	v_bfe_u32 v128, v50, 24, 3
	v_and_or_b32 v130, 0x80000000, v130, v122
	v_lshl_add_u32 v122, v131, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v128, v128
	v_mul_f32_e32 v128, 0x3b000000, v128
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v122, v128, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, v129, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_bfe_u32 v129, v51, 8, 7
	v_cvt_f32_ubyte0_e32 v134, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_lshl_add_u32 v131, v129, 20, 0x3c000000
	v_mul_f32_e32 v132, 0x3b000000, v134
	v_lshlrev_b32_e32 v134, 24, v51
	v_and_or_b32 v135, 0x80000000, v50, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, 0x7fc00000, v128, vcc_lo
	v_bfe_u32 v122, v51, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v128, 0x80000000, v134, v128
	v_cvt_f32_ubyte0_e32 v122, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v131, v132, v131, vcc_lo
	v_bfe_u32 v132, v51, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_mul_f32_e32 v122, 0x3b000000, v122
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v134, v132, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, 0x7fc00000, v131, vcc_lo
	v_bfe_u32 v131, v51, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	v_cvt_f32_ubyte0_e32 v131, v131
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_lshl_add_u32 v134, v137, 20, 0x3c000000
	v_dual_mul_f32 v131, 0x3b000000, v131 :: v_dual_and_b32 v132, 7, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v132, v132
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v131, v131, v134 :: v_dual_lshlrev_b32 v134, 8, v51
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_mul_f32_e32 v132, 0x3b000000, v132
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v134, 0x80000000, v134, v122
	v_fma_f32 v122, v127, v121, 0
	v_fma_f32 v127, v127, v120, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v131, 0x7fc00000, v131 :: v_dual_fmac_f32 v122, v123, v116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v127, v123, v119
	v_and_or_b32 v131, 0x80000000, v51, v131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v122, v124, v114
	v_fmac_f32_e32 v127, v124, v118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v133, v117
	v_fmac_f32_e32 v127, v125, v115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v126, v113
	v_fmac_f32_e32 v127, v130, v111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v127, v135, v109
	v_fmac_f32_e32 v127, v128, v107
	v_lshlrev_b32_e32 v136, 16, v51
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v129, 0x80000000, v136, v129
	v_fmac_f32_e32 v127, v129, v104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v127, v134, v106 :: v_dual_and_b32 v136, 0x7f, v52
	v_lshl_add_u32 v137, v136, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v127, v131, v103 :: v_dual_cndmask_b32 v132, v132, v137
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_bfe_u32 v137, v52, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v132, 0x7fc00000, v132, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v136, v137, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_and_or_b32 v132, 0x80000000, v139, v132
	v_fmac_f32_e32 v122, v133, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v138, v136, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_bfe_u32 v133, v52, 16, 3
	v_dual_fmac_f32 v127, v132, v99 :: v_dual_fmac_f32 v122, v125, v110
	v_bfe_u32 v136, v52, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_bfe_u32 v137, v54, 24, 7
	v_bfe_u32 v139, v55, 16, 7
	v_fmac_f32_e32 v122, v126, v108
	v_lshl_add_u32 v125, v136, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v136
	v_bfe_u32 v126, v52, 24, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v122, v130, v105
	v_fmac_f32_e32 v122, v135, v102
	v_bfe_u32 v135, v54, 8, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v122, v128, v98
	v_lshlrev_b32_e32 v128, 8, v52
	v_fmac_f32_e32 v122, v129, v96
	v_bfe_u32 v129, v53, 8, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v122, v134, v95
	v_cvt_f32_ubyte0_e32 v129, v129
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v122, v131, v94 :: v_dual_mul_f32 v129, 0x3b000000, v129
	v_lshlrev_b32_e32 v124, 16, v52
	v_bfe_u32 v131, v53, 8, 7
	v_fmac_f32_e32 v122, v132, v93
	v_bfe_u32 v132, v53, 16, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v123, 0x80000000, v124, v123
	v_cvt_f32_ubyte0_e32 v124, v133
	v_bfe_u32 v133, v52, 24, 3
	v_cvt_f32_ubyte0_e32 v132, v132
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v127, v123, v97 :: v_dual_mul_f32 v124, 0x3b000000, v124
	v_cvt_f32_ubyte0_e32 v133, v133
	v_fmac_f32_e32 v122, v123, v92
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v132, 0x3b000000, v132
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, v124, v125, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v136
	v_lshl_add_u32 v125, v126, 20, 0x3c000000
	v_mul_f32_e32 v130, 0x3b000000, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, 0x7fc00000, v124, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v124, 0x80000000, v128, v124
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v130, v125, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_and_b32_e32 v126, 7, v53
	v_and_b32_e32 v128, 0x7f, v53
	v_dual_fmac_f32 v127, v124, v100 :: v_dual_lshlrev_b32 v140, 24, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, 0x7fc00000, v125, vcc_lo
	v_cvt_f32_ubyte0_e32 v126, v126
	v_lshl_add_u32 v130, v128, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v128
	v_fmac_f32_e32 v122, v124, v91
	v_and_or_b32 v125, 0x80000000, v52, v125
	v_mul_f32_e32 v126, 0x3b000000, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v122, v125, v90
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v126, v130, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v128
	v_lshl_add_u32 v130, v131, 20, 0x3c000000
	v_bfe_u32 v128, v53, 16, 7
	v_dual_add_f32 v86, v86, v122 :: v_dual_fmac_f32 v127, v125, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, 0x7fc00000, v126, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_lshl_add_u32 v133, v128, 20, 0x3c000000
	v_add_f32_e32 v85, v85, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, v129, v130, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_lshlrev_b32_e32 v130, 24, v53
	v_lshlrev_b32_e32 v131, 16, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, 0x7fc00000, v129, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v128
	v_and_or_b32 v126, 0x80000000, v130, v126
	v_bfe_u32 v130, v53, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v129, 0x80000000, v131, v129
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v132, v133, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v128
	v_and_b32_e32 v128, 7, v54
	v_lshlrev_b32_e32 v131, 8, v53
	v_bfe_u32 v132, v53, 24, 7
	v_cvt_f32_ubyte0_e32 v130, v130
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_and_b32_e32 v133, 0x7f, v54
	v_cvt_f32_ubyte0_e32 v128, v128
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	v_mul_f32_e32 v130, 0x3b000000, v130
	v_and_or_b32 v123, 0x80000000, v131, v123
	v_lshl_add_u32 v131, v132, 20, 0x3c000000
	v_fma_f32 v121, v126, v121, 0
	v_lshl_add_u32 v134, v133, 20, 0x3c000000
	v_fma_f32 v120, v126, v120, 0
	v_and_b32_e32 v126, 0x7f, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, v130, v131, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v133
	v_fmac_f32_e32 v121, v129, v116
	v_mul_f32_e32 v128, 0x3b000000, v128
	v_bfe_u32 v131, v54, 8, 7
	v_fmac_f32_e32 v120, v129, v119
	v_lshl_add_u32 v116, v126, 20, 0x3c000000
	v_fmac_f32_e32 v121, v123, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, v128, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_cvt_f32_ubyte0_e32 v134, v135
	v_lshl_add_u32 v132, v131, 20, 0x3c000000
	v_bfe_u32 v135, v54, 16, 3
	v_fmac_f32_e32 v120, v123, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, 0x7fc00000, v130, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v133
	v_mul_f32_e32 v133, 0x3b000000, v134
	v_lshlrev_b32_e32 v134, 24, v54
	v_bfe_u32 v129, v56, 8, 3
	v_and_or_b32 v130, 0x80000000, v53, v130
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, 0x7fc00000, v128, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v121, v130, v112
	v_and_or_b32 v128, 0x80000000, v134, v128
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v132, v133, v132, vcc_lo
	v_bfe_u32 v133, v54, 16, 7
	v_cvt_f32_ubyte0_e32 v134, v135
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_bfe_u32 v135, v54, 24, 3
	v_fmac_f32_e32 v120, v130, v117
	v_lshl_add_u32 v136, v133, 20, 0x3c000000
	v_mul_f32_e32 v134, 0x3b000000, v134
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v131, 0x7fc00000, v132 :: v_dual_lshlrev_b32 v132, 16, v54
	v_cmp_lt_u32_e32 vcc_lo, 7, v133
	v_cvt_f32_ubyte0_e32 v112, v129
	v_fmac_f32_e32 v121, v128, v110
	v_fmac_f32_e32 v120, v128, v115
	v_and_or_b32 v131, 0x80000000, v132, v131
	v_cvt_f32_ubyte0_e32 v132, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v134, v134, v136, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v133
	v_lshl_add_u32 v135, v137, 20, 0x3c000000
	v_and_b32_e32 v136, 7, v55
	v_mul_f32_e32 v132, 0x3b000000, v132
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v133, 0x7fc00000, v134, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_and_b32_e32 v134, 0x7f, v55
	v_cvt_f32_ubyte0_e32 v136, v136
	v_fmac_f32_e32 v121, v131, v108
	v_fmac_f32_e32 v120, v131, v113
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v132, v132, v135 :: v_dual_lshlrev_b32 v135, 8, v54
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_lshl_add_u32 v138, v134, 20, 0x3c000000
	v_mul_f32_e32 v136, 0x3b000000, v136
	v_bfe_u32 v137, v55, 8, 7
	v_and_or_b32 v133, 0x80000000, v135, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v132, 0x7fc00000, v132, vcc_lo
	v_bfe_u32 v135, v55, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v134
	v_lshlrev_b32_e32 v115, 24, v56
	v_fmac_f32_e32 v121, v133, v105
	v_and_or_b32 v132, 0x80000000, v54, v132
	v_cvt_f32_ubyte0_e32 v135, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v136, v136, v138, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v134
	v_lshl_add_u32 v138, v137, 20, 0x3c000000
	v_fmac_f32_e32 v120, v133, v111
	v_mul_f32_e32 v135, 0x3b000000, v135
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v121, v132, v102 :: v_dual_cndmask_b32 v134, 0x7fc00000, v136
	v_bfe_u32 v136, v55, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_fmac_f32_e32 v120, v132, v109
	v_bfe_u32 v102, v56, 16, 7
	v_and_or_b32 v134, 0x80000000, v140, v134
	v_cvt_f32_ubyte0_e32 v136, v136
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, v135, v138, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_lshl_add_u32 v138, v139, 20, 0x3c000000
	v_bfe_u32 v137, v55, 24, 7
	v_dual_mul_f32 v136, 0x3b000000, v136 :: v_dual_fmac_f32 v121, v134, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, 0x7fc00000, v135, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v139
	v_lshl_add_u32 v142, v137, 20, 0x3c000000
	v_fmac_f32_e32 v120, v134, v107
	v_lshl_add_u32 v98, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v136, v136, v138 :: v_dual_lshlrev_b32 v111, 16, v56
	v_lshlrev_b32_e32 v138, 16, v55
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v139
	v_lshlrev_b32_e32 v139, 8, v55
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v135, 0x80000000, v138, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v136, 0x7fc00000, v136, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_and_b32_e32 v138, 7, v56
	v_fmac_f32_e32 v121, v135, v96
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v136, 0x80000000, v139, v136
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v140, v141, v142, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_cvt_f32_ubyte0_e32 v138, v138
	v_dual_fmac_f32 v120, v135, v104 :: v_dual_fmac_f32 v121, v136, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v137, 0x7fc00000, v140, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v119, 0x3b000000, v138
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	v_fmac_f32_e32 v120, v136, v106
	v_and_or_b32 v137, 0x80000000, v55, v137
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v119, v116, vcc_lo
	v_bfe_u32 v116, v56, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_fmac_f32_e32 v121, v137, v94
	v_fmac_f32_e32 v120, v137, v103
	v_lshlrev_b32_e32 v94, 8, v56
	v_lshl_add_u32 v110, v116, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v112, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_and_or_b32 v110, 0x80000000, v115, v114
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v105, 0x7fc00000, v108, vcc_lo
	v_bfe_u32 v108, v56, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_fmac_f32_e32 v121, v110, v93
	v_fmac_f32_e32 v120, v110, v99
	v_and_or_b32 v105, 0x80000000, v111, v105
	v_cvt_f32_ubyte0_e32 v108, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v121, v105, v92
	v_mul_f32_e32 v107, 0x3b000000, v108
	v_bfe_u32 v108, v56, 24, 3
	v_fmac_f32_e32 v120, v105, v97
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v96, v107, v98, vcc_lo
	v_bfe_u32 v98, v56, 24, 7
	v_cvt_f32_ubyte0_e32 v104, v108
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_mul_f32_e32 v102, 0x3b000000, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v96, vcc_lo
	v_lshl_add_u32 v96, v98, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v94, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v102, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v121, v93, v91
	v_fmac_f32_e32 v120, v93, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v96, vcc_lo
	v_and_or_b32 v92, 0x80000000, v56, v94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v121, v92, v90
	v_fmac_f32_e32 v120, v92, v101
	v_dual_add_f32 v84, v84, v121 :: v_dual_add_f32 v83, v83, v120
	v_cmpx_gt_i32_e64 s16, v88
	s_cbranch_execz .LBB69_29
; %bb.55:                               ;   in Loop: Header=BB69_33 Depth=1
	ds_load_b128 v[90:93], v87 offset:2048
	ds_load_b128 v[115:118], v87 offset:2064
	ds_load_b128 v[120:123], v89 offset:2048
	ds_load_b128 v[124:127], v89 offset:2064
	v_and_b32_e32 v95, 7, v57
	v_bfe_u32 v136, v60, 8, 3
	v_bfe_u32 v129, v58, 8, 7
	v_bfe_u32 v133, v59, 8, 3
	v_bfe_u32 v135, v59, 24, 7
	v_cvt_f32_ubyte0_e32 v99, v95
	v_cvt_f32_ubyte0_e32 v136, v136
	v_bfe_u32 v139, v63, 24, 3
	v_lshlrev_b32_e32 v138, 24, v63
	v_lshlrev_b32_e32 v137, 24, v60
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v139, v139
	s_wait_dscnt 0x3
	v_lshlrev_b32_e32 v108, 16, v92
	v_and_b32_e32 v106, 0xffff0000, v92
	v_and_b32_e32 v100, 0xffff0000, v93
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v96, 16, v115
	v_and_b32_e32 v94, 0xffff0000, v115
	v_and_b32_e32 v92, 0xffff0000, v116
	s_wait_dscnt 0x1
	v_and_b32_e32 v115, 0xffff0000, v121
	v_lshlrev_b32_e32 v109, 16, v123
	v_and_b32_e32 v107, 0xffff0000, v123
	v_mul_f32_e32 v123, 0x3b000000, v99
	v_lshlrev_b32_e32 v103, 16, v93
	v_lshlrev_b32_e32 v93, 16, v116
	v_lshlrev_b32_e32 v116, 16, v121
	v_bfe_u32 v121, v57, 8, 3
	v_lshlrev_b32_e32 v119, 16, v90
	v_and_b32_e32 v110, 0xffff0000, v91
	v_lshlrev_b32_e32 v89, 16, v118
	v_and_b32_e32 v88, 0xffff0000, v118
	v_cvt_f32_ubyte0_e32 v121, v121
	v_lshlrev_b32_e32 v112, 16, v91
	v_lshlrev_b32_e32 v91, 16, v117
	v_lshlrev_b32_e32 v118, 16, v120
	v_and_b32_e32 v111, 0xffff0000, v122
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v97, 16, v126
	v_mul_f32_e32 v121, 0x3b000000, v121
	v_and_b32_e32 v114, 0xffff0000, v90
	v_mul_f32_e32 v136, 0x3b000000, v136
	v_and_b32_e32 v90, 0xffff0000, v117
	v_and_b32_e32 v117, 0xffff0000, v120
	v_and_b32_e32 v120, 0x7f, v57
	v_lshlrev_b32_e32 v113, 16, v122
	v_lshlrev_b32_e32 v105, 16, v124
	v_and_b32_e32 v102, 0xffff0000, v124
	v_bfe_u32 v124, v57, 8, 7
	v_lshl_add_u32 v122, v120, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v120
	v_lshlrev_b32_e32 v104, 16, v125
	v_and_b32_e32 v101, 0xffff0000, v125
	v_bfe_u32 v125, v57, 16, 3
	v_and_b32_e32 v95, 0xffff0000, v126
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v123, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v120
	v_lshl_add_u32 v123, v124, 20, 0x3c000000
	v_lshlrev_b32_e32 v126, 16, v57
	v_lshlrev_b32_e32 v98, 16, v127
	v_mul_f32_e32 v139, 0x3b000000, v139
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v124
	v_bfe_u32 v122, v57, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v121, v123, vcc_lo
	v_cvt_f32_ubyte0_e32 v123, v125
	v_lshlrev_b32_e32 v125, 24, v57
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v124
	v_lshl_add_u32 v124, v122, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v123, 0x3b000000, v123
	v_and_or_b32 v125, 0x80000000, v125, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_bfe_u32 v120, v57, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v121, 0x80000000, v126, v121
	v_cvt_f32_ubyte0_e32 v120, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v123, v124, vcc_lo
	v_bfe_u32 v124, v57, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_and_b32_e32 v99, 0xffff0000, v127
	v_mul_f32_e32 v120, 0x3b000000, v120
	v_and_b32_e32 v126, 7, v58
	v_lshl_add_u32 v127, v124, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v123, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v124
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v120, v120, v127 :: v_dual_lshlrev_b32 v123, 8, v57
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v124
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v122, 0x80000000, v123, v122
	v_cvt_f32_ubyte0_e32 v123, v126
	v_bfe_u32 v127, v58, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, 0x7fc00000, v120, vcc_lo
	v_and_b32_e32 v128, 0x7f, v58
	v_mul_f32_e32 v123, 0x3b000000, v123
	v_cvt_f32_ubyte0_e32 v124, v127
	v_bfe_u32 v127, v58, 16, 3
	v_and_or_b32 v131, 0x80000000, v57, v120
	v_lshl_add_u32 v126, v128, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v128
	v_mul_f32_e32 v124, 0x3b000000, v124
	v_cvt_f32_ubyte0_e32 v127, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v123, v126, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v128
	v_lshl_add_u32 v126, v129, 20, 0x3c000000
	v_bfe_u32 v128, v58, 16, 7
	v_mul_f32_e32 v127, 0x3b000000, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	v_lshl_add_u32 v130, v128, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, v124, v126, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_lshlrev_b32_e32 v126, 24, v58
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_cndmask_b32 v124, 0x7fc00000, v124 :: v_dual_lshlrev_b32 v129, 16, v58
	v_cmp_lt_u32_e32 vcc_lo, 7, v128
	v_and_or_b32 v123, 0x80000000, v126, v123
	v_bfe_u32 v126, v58, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v124, 0x80000000, v129, v124
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, v127, v130, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v128
	v_and_b32_e32 v127, 7, v59
	v_lshlrev_b32_e32 v128, 8, v58
	v_bfe_u32 v129, v58, 24, 7
	v_cvt_f32_ubyte0_e32 v126, v126
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, 0x7fc00000, v120, vcc_lo
	v_cvt_f32_ubyte0_e32 v127, v127
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	v_mul_f32_e32 v126, 0x3b000000, v126
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v128, 0x80000000, v128, v120
	v_and_b32_e32 v130, 0x7f, v59
	v_lshl_add_u32 v120, v129, 20, 0x3c000000
	v_mul_f32_e32 v127, 0x3b000000, v127
	v_lshl_add_u32 v132, v130, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v120, v126, v120, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v127, v132, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_bfe_u32 v127, v59, 8, 7
	v_cvt_f32_ubyte0_e32 v132, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, 0x7fc00000, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshl_add_u32 v129, v127, 20, 0x3c000000
	v_mul_f32_e32 v130, 0x3b000000, v132
	v_lshlrev_b32_e32 v132, 24, v59
	v_and_or_b32 v133, 0x80000000, v58, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, 0x7fc00000, v126, vcc_lo
	v_bfe_u32 v120, v59, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v127
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v126, 0x80000000, v132, v126
	v_cvt_f32_ubyte0_e32 v120, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, v130, v129, vcc_lo
	v_bfe_u32 v130, v59, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v127
	v_mul_f32_e32 v120, 0x3b000000, v120
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v132, v130, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v127, 0x7fc00000, v129, vcc_lo
	v_bfe_u32 v129, v59, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_cvt_f32_ubyte0_e32 v129, v129
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, v120, v132, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_lshl_add_u32 v132, v135, 20, 0x3c000000
	v_dual_mul_f32 v129, 0x3b000000, v129 :: v_dual_and_b32 v130, 7, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, 0x7fc00000, v120, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v135
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v130, v130
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v129, v129, v132 :: v_dual_lshlrev_b32 v132, 8, v59
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v135
	v_mul_f32_e32 v130, 0x3b000000, v130
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v132, 0x80000000, v132, v120
	v_fma_f32 v120, v125, v119, 0
	v_fma_f32 v125, v125, v118, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v129, 0x7fc00000, v129 :: v_dual_fmac_f32 v120, v121, v114
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v125, v121, v117
	v_and_or_b32 v129, 0x80000000, v59, v129
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v120, v122, v112
	v_fmac_f32_e32 v125, v122, v116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v125, v131, v115 :: v_dual_lshlrev_b32 v122, 16, v60
	v_fmac_f32_e32 v125, v123, v113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v125, v124, v111
	v_fmac_f32_e32 v125, v128, v109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v125, v133, v107
	v_dual_fmac_f32 v125, v126, v105 :: v_dual_lshlrev_b32 v134, 16, v59
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v127, 0x80000000, v134, v127
	v_fmac_f32_e32 v125, v127, v102
	v_fmac_f32_e32 v120, v131, v110
	v_bfe_u32 v131, v60, 16, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v125, v132, v104
	v_and_b32_e32 v134, 0x7f, v60
	v_dual_fmac_f32 v120, v123, v108 :: v_dual_fmac_f32 v125, v129, v101
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v135, v134, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v134
	v_fmac_f32_e32 v120, v124, v106
	v_bfe_u32 v124, v60, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, v130, v135, vcc_lo
	v_bfe_u32 v135, v60, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v134
	v_fmac_f32_e32 v120, v128, v103
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v134, v135, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, 0x7fc00000, v130, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v135
	v_fmac_f32_e32 v120, v133, v100
	v_bfe_u32 v133, v62, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v136, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v135
	v_bfe_u32 v134, v60, 16, 7
	v_fmac_f32_e32 v120, v126, v96
	v_lshlrev_b32_e32 v126, 8, v60
	v_bfe_u32 v135, v62, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_lshl_add_u32 v123, v134, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v134
	v_fmac_f32_e32 v120, v127, v94
	v_bfe_u32 v127, v61, 8, 3
	v_and_or_b32 v121, 0x80000000, v122, v121
	v_cvt_f32_ubyte0_e32 v122, v131
	v_bfe_u32 v131, v60, 24, 3
	v_fmac_f32_e32 v120, v132, v93
	v_cvt_f32_ubyte0_e32 v127, v127
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v122, 0x3b000000, v122
	v_cvt_f32_ubyte0_e32 v131, v131
	s_delay_alu instid0(VALU_DEP_4)
	v_fmac_f32_e32 v120, v129, v92
	v_bfe_u32 v129, v61, 8, 7
	v_mul_f32_e32 v127, 0x3b000000, v127
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v123, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v134
	v_lshl_add_u32 v123, v124, 20, 0x3c000000
	v_mul_f32_e32 v128, 0x3b000000, v131
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v124
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v122, 0x80000000, v126, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, v128, v123, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v124
	v_and_b32_e32 v124, 7, v61
	v_and_b32_e32 v126, 0x7f, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v123, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v124, v124
	v_lshl_add_u32 v128, v126, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v123, 0x80000000, v60, v123
	v_mul_f32_e32 v124, 0x3b000000, v124
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v124, v124, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_lshl_add_u32 v128, v129, 20, 0x3c000000
	v_bfe_u32 v126, v61, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v124, 0x7fc00000, v124, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v131, v126, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v127, v127, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_lshlrev_b32_e32 v129, 16, v61
	v_and_or_b32 v130, 0x80000000, v137, v130
	v_lshlrev_b32_e32 v128, 24, v61
	v_bfe_u32 v137, v63, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v127, 0x7fc00000, v127, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v126
	v_fmac_f32_e32 v120, v130, v91
	v_fmac_f32_e32 v125, v130, v97
	v_bfe_u32 v130, v61, 16, 3
	v_and_or_b32 v124, 0x80000000, v128, v124
	v_and_or_b32 v127, 0x80000000, v129, v127
	v_fmac_f32_e32 v120, v121, v90
	v_fmac_f32_e32 v125, v121, v95
	v_cvt_f32_ubyte0_e32 v130, v130
	v_bfe_u32 v128, v61, 24, 3
	v_lshlrev_b32_e32 v129, 8, v61
	v_fma_f32 v119, v124, v119, 0
	v_fma_f32 v118, v124, v118, 0
	v_mul_f32_e32 v130, 0x3b000000, v130
	v_cvt_f32_ubyte0_e32 v128, v128
	v_dual_fmac_f32 v125, v122, v98 :: v_dual_and_b32 v124, 0x7f, v64
	v_fmac_f32_e32 v119, v127, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v130, v131, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v126
	v_bfe_u32 v130, v61, 24, 7
	v_and_b32_e32 v131, 0x7f, v62
	v_dual_mul_f32 v128, 0x3b000000, v128 :: v_dual_fmac_f32 v125, v123, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v130
	v_lshl_add_u32 v132, v131, 20, 0x3c000000
	v_fmac_f32_e32 v118, v127, v117
	v_lshl_add_u32 v114, v124, 20, 0x3c000000
	v_and_or_b32 v121, 0x80000000, v129, v121
	v_and_b32_e32 v126, 7, v62
	v_lshl_add_u32 v129, v130, 20, 0x3c000000
	v_bfe_u32 v127, v64, 8, 3
	v_add_f32_e32 v85, v85, v125
	v_fmac_f32_e32 v119, v121, v112
	v_cvt_f32_ubyte0_e32 v126, v126
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, v128, v129, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_bfe_u32 v129, v62, 8, 7
	v_fmac_f32_e32 v118, v121, v116
	v_mul_f32_e32 v126, 0x3b000000, v126
	v_fmac_f32_e32 v120, v122, v89
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v126, v126, v132, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v130
	v_cvt_f32_ubyte0_e32 v132, v133
	v_lshl_add_u32 v130, v129, 20, 0x3c000000
	v_bfe_u32 v133, v62, 16, 3
	v_fmac_f32_e32 v120, v123, v88
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v128, 0x7fc00000, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_dual_mul_f32 v131, 0x3b000000, v132 :: v_dual_lshlrev_b32 v132, 24, v62
	v_add_f32_e32 v86, v86, v120
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v128, 0x80000000, v61, v128
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, 0x7fc00000, v126, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v129
	v_fmac_f32_e32 v119, v128, v110
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v126, 0x80000000, v132, v126
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, v131, v130, vcc_lo
	v_bfe_u32 v131, v62, 16, 7
	v_cvt_f32_ubyte0_e32 v132, v133
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v129
	v_bfe_u32 v133, v62, 24, 3
	v_fmac_f32_e32 v118, v128, v115
	v_lshl_add_u32 v134, v131, 20, 0x3c000000
	v_mul_f32_e32 v132, 0x3b000000, v132
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v129, 0x7fc00000, v130, vcc_lo
	v_lshlrev_b32_e32 v130, 16, v62
	v_cmp_lt_u32_e32 vcc_lo, 7, v131
	v_cvt_f32_ubyte0_e32 v110, v127
	v_fmac_f32_e32 v119, v126, v108
	v_fmac_f32_e32 v118, v126, v113
	v_and_or_b32 v129, 0x80000000, v130, v129
	v_cvt_f32_ubyte0_e32 v130, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v132, v132, v134, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v131
	v_lshl_add_u32 v133, v135, 20, 0x3c000000
	v_and_b32_e32 v134, 7, v63
	v_mul_f32_e32 v130, 0x3b000000, v130
	v_mul_f32_e32 v110, 0x3b000000, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v131, 0x7fc00000, v132, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v135
	v_and_b32_e32 v132, 0x7f, v63
	v_cvt_f32_ubyte0_e32 v134, v134
	v_fmac_f32_e32 v119, v129, v106
	v_fmac_f32_e32 v118, v129, v111
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v130, v130, v133 :: v_dual_lshlrev_b32 v133, 8, v62
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v135
	v_lshl_add_u32 v136, v132, 20, 0x3c000000
	v_mul_f32_e32 v134, 0x3b000000, v134
	v_bfe_u32 v135, v63, 8, 7
	v_and_or_b32 v131, 0x80000000, v133, v131
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v130, 0x7fc00000, v130, vcc_lo
	v_bfe_u32 v133, v63, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v132
	v_lshlrev_b32_e32 v113, 24, v64
	v_fmac_f32_e32 v119, v131, v103
	v_and_or_b32 v130, 0x80000000, v62, v130
	v_cvt_f32_ubyte0_e32 v133, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v134, v134, v136, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v132
	v_lshl_add_u32 v136, v135, 20, 0x3c000000
	v_fmac_f32_e32 v118, v131, v109
	v_mul_f32_e32 v133, 0x3b000000, v133
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v119, v130, v100 :: v_dual_cndmask_b32 v132, 0x7fc00000, v134
	v_bfe_u32 v134, v63, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v135
	v_fmac_f32_e32 v118, v130, v107
	v_bfe_u32 v100, v64, 16, 7
	v_and_or_b32 v132, 0x80000000, v138, v132
	v_cvt_f32_ubyte0_e32 v134, v134
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v133, v133, v136, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v135
	v_lshl_add_u32 v136, v137, 20, 0x3c000000
	v_bfe_u32 v135, v63, 24, 7
	v_dual_mul_f32 v134, 0x3b000000, v134 :: v_dual_fmac_f32 v119, v132, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v133, 0x7fc00000, v133, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v137
	v_lshl_add_u32 v140, v135, 20, 0x3c000000
	v_fmac_f32_e32 v118, v132, v105
	v_lshl_add_u32 v96, v100, 20, 0x3c000000
	v_lshlrev_b32_e32 v109, 16, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v134, v134, v136, vcc_lo
	v_lshlrev_b32_e32 v136, 16, v63
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v137
	v_lshlrev_b32_e32 v137, 8, v63
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v133, 0x80000000, v136, v133
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v134, 0x7fc00000, v134, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v135
	v_dual_fmac_f32 v119, v133, v94 :: v_dual_and_b32 v136, 7, v64
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v134, 0x80000000, v137, v134
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v138, v139, v140, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v135
	v_cvt_f32_ubyte0_e32 v136, v136
	v_dual_fmac_f32 v118, v133, v102 :: v_dual_fmac_f32 v119, v134, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v135, 0x7fc00000, v138, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v117, 0x3b000000, v136
	v_cmp_lt_u32_e32 vcc_lo, 7, v124
	v_fmac_f32_e32 v118, v134, v104
	v_and_or_b32 v135, 0x80000000, v63, v135
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v117, v114, vcc_lo
	v_bfe_u32 v114, v64, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v124
	v_fmac_f32_e32 v119, v135, v92
	v_fmac_f32_e32 v118, v135, v101
	v_lshlrev_b32_e32 v92, 8, v64
	v_lshl_add_u32 v108, v114, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v110, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_and_or_b32 v108, 0x80000000, v113, v112
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v103, 0x7fc00000, v106, vcc_lo
	v_bfe_u32 v106, v64, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v100
	v_fmac_f32_e32 v119, v108, v91
	v_fmac_f32_e32 v118, v108, v97
	v_and_or_b32 v103, 0x80000000, v109, v103
	v_cvt_f32_ubyte0_e32 v106, v106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v119, v103, v90
	v_mul_f32_e32 v105, 0x3b000000, v106
	v_bfe_u32 v106, v64, 24, 3
	v_fmac_f32_e32 v118, v103, v95
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v94, v105, v96, vcc_lo
	v_bfe_u32 v96, v64, 24, 7
	v_cvt_f32_ubyte0_e32 v102, v106
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v100
	v_mul_f32_e32 v100, 0x3b000000, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v94, vcc_lo
	v_lshl_add_u32 v94, v96, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v96
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v91, 0x80000000, v92, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v100, v94, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v96
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v119, v91, v89
	v_fmac_f32_e32 v118, v91, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, 0x7fc00000, v94, vcc_lo
	v_and_or_b32 v90, 0x80000000, v64, v92
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v119, v90, v88
	v_fmac_f32_e32 v118, v90, v99
	v_dual_add_f32 v84, v84, v119 :: v_dual_add_f32 v83, v83, v118
	s_branch .LBB69_29
.LBB69_56:
	s_or_b32 exec_lo, exec_lo, s15
.LBB69_57:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v33, -1, 0
	v_cmp_gt_i64_e64 s7, s[10:11], v[67:68]
	v_cmp_eq_u32_e64 s1, 0, v77
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v34, 16, v33
	v_xor_b32_e32 v36, 8, v33
	v_xor_b32_e32 v37, 4, v33
	s_and_b32 s7, s1, s7
	v_cmp_gt_i32_e32 vcc_lo, 32, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v34, v33, v34, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v36
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v36, v33, v36, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v37
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v37, v33, v37 :: v_dual_lshlrev_b32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v37
	v_lshlrev_b32_e32 v35, 2, v34
	ds_bpermute_b32 v34, v35, v86
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v86, v34
	ds_bpermute_b32 v38, v36, v34
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v38
	v_xor_b32_e32 v38, 2, v33
	ds_bpermute_b32 v39, v37, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v38
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v38, v33, v38, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v38, 2, v38
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v39
	v_xor_b32_e32 v39, 1, v33
	ds_bpermute_b32 v40, v38, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v39
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v33, v33, v39, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v77
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_add_f32 v40, v34, v40 :: v_dual_lshlrev_b32 v39, 2, v33
	v_lshlrev_b64_e32 v[33:34], 1, v[67:68]
	ds_bpermute_b32 v41, v39, v40
	v_add_co_u32 v33, s8, s12, v33
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v34, null, s13, v34, s8
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s7
	s_cbranch_execz .LBB69_63
; %bb.58:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s14, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e64 s1, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s15, s1
	s_wait_alu 0xfffe
	s_xor_b32 s1, exec_lo, s15
; %bb.59:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.60:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
; %bb.61:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.62:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	global_store_b16 v[33:34], v40, off
.LBB69_63:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	ds_bpermute_b32 v40, v35, v85
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v85, v40
	ds_bpermute_b32 v41, v36, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v37, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v38, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v39, v40
	s_and_saveexec_b32 s8, s7
	s_cbranch_execz .LBB69_69
; %bb.64:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s14, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e64 s1, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s7, s1
	s_wait_alu 0xfffe
	s_xor_b32 s1, exec_lo, s7
; %bb.65:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.66:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
; %bb.67:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.68:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_lshl_b64 s[18:19], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v41, s1, v33, s18
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v42, null, s19, v34, s1
	global_store_b16 v[41:42], v40, off
.LBB69_69:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	ds_bpermute_b32 v40, v35, v84
	v_cmp_gt_i64_e64 s1, s[10:11], v[65:66]
	s_xor_b32 s7, vcc_lo, -1
	s_wait_alu 0xfffe
	s_and_b32 s1, s7, s1
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v84, v40
	ds_bpermute_b32 v41, v36, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v37, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v38, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v39, v40
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s7, s1
	s_cbranch_execz .LBB69_75
; %bb.70:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s14, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s8, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s8, exec_lo, s8
; %bb.71:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.72:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s8, s8
; %bb.73:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.74:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	global_store_b16 v[33:34], v40, off offset:2
.LBB69_75:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	ds_bpermute_b32 v35, v35, v83
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v83, v35
	ds_bpermute_b32 v36, v36, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	ds_bpermute_b32 v36, v37, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	ds_bpermute_b32 v36, v38, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	ds_bpermute_b32 v36, v39, v35
	s_and_saveexec_b32 s7, s1
	s_cbranch_execz .LBB69_81
; %bb.76:
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v36, s14, v35
	v_and_b32_e32 v35, 0x7fffffff, v36
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v35
                                        ; implicit-def: $vgpr35
	s_and_saveexec_b32 s1, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s1, exec_lo, s1
; %bb.77:
	v_bfe_u32 v35, v36, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v35, v36, v35, 0x7fff
                                        ; implicit-def: $vgpr36
	v_lshrrev_b32_e32 v35, 16, v35
; %bb.78:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
; %bb.79:
	v_lshrrev_b32_e32 v35, 16, v36
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v35, 64, v35
; %bb.80:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_lshl_b64 s[18:19], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v33, vcc_lo, v33, s18
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v34, null, s19, v34, vcc_lo
	global_store_b16 v[33:34], v35, off offset:2
.LBB69_81:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_mov_b32 s1, 0
.LBB69_82:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s1
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB69_145
; %bb.83:
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v34, 0
	v_mov_b32_e32 v35, 0
	v_mov_b32_e32 v33, 0
	s_and_saveexec_b32 s7, s0
	s_cbranch_execz .LBB69_121
; %bb.84:
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0
	v_mov_b32_e32 v35, 0
	v_mov_b32_e32 v37, 0
	s_and_saveexec_b32 s0, s6
	s_cbranch_execz .LBB69_92
; %bb.85:
	v_lshl_add_u32 v41, v77, 5, 0
	v_perm_b32 v42, 0, v29, 0x10c000c
	v_perm_b32 v43, 0, v29, 0x30c020c
	v_perm_b32 v44, 0, v30, 0x10c000c
	v_perm_b32 v46, 0, v30, 0x30c020c
	v_lshl_add_u32 v45, s9, 1, v41
	s_wait_dscnt 0x0
	ds_load_b128 v[33:36], v41
	v_lshrrev_b32_e32 v52, 1, v42
	v_and_b32_e32 v42, 0x80008000, v42
	v_perm_b32 v47, 0, v31, 0x10c000c
	ds_load_b128 v[37:40], v45
	v_perm_b32 v48, 0, v31, 0x30c020c
	v_perm_b32 v49, 0, v32, 0x10c000c
	v_perm_b32 v50, 0, v32, 0x30c020c
	ds_load_b128 v[29:32], v41 offset:16
	v_lshrrev_b32_e32 v41, 1, v43
	v_and_b32_e32 v43, 0x80008000, v43
	v_and_or_b32 v52, 0x3f803f80, v52, v42
	v_lshrrev_b32_e32 v53, 1, v44
	v_and_b32_e32 v54, 0x80008000, v44
	v_lshrrev_b32_e32 v55, 1, v46
	v_and_or_b32 v56, 0x3f803f80, v41, v43
	ds_load_b128 v[41:44], v45 offset:16
	v_and_b32_e32 v46, 0x80008000, v46
	v_and_or_b32 v45, 0x3f803f80, v53, v54
	v_lshrrev_b32_e32 v58, 1, v47
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v57, v52, v33, 0
	v_and_b32_e32 v47, 0x80008000, v47
	v_and_or_b32 v46, 0x3f803f80, v55, v46
	v_perm_b32 v51, 0, v21, 0x10c000c
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v52, v52, v37, 0
	v_dot2_f32_f16 v53, v56, v34, v57
	v_lshrrev_b32_e32 v54, 1, v48
	v_and_b32_e32 v48, 0x80008000, v48
	v_lshrrev_b32_e32 v55, 1, v49
	v_dot2_f32_f16 v52, v56, v38, v52
	v_dot2_f32_f16 v53, v45, v35, v53
	v_and_b32_e32 v49, 0x80008000, v49
	v_and_or_b32 v47, 0x3f803f80, v58, v47
	v_and_or_b32 v48, 0x3f803f80, v54, v48
	v_dot2_f32_f16 v45, v45, v39, v52
	v_dot2_f32_f16 v53, v46, v36, v53
	v_lshrrev_b32_e32 v52, 1, v50
	v_and_b32_e32 v50, 0x80008000, v50
	v_perm_b32 v21, 0, v21, 0x30c020c
	v_dot2_f32_f16 v45, v46, v40, v45
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v53, v47, v29, v53
	v_and_or_b32 v46, 0x3f803f80, v55, v49
	v_and_or_b32 v49, 0x3f803f80, v52, v50
	v_lshrrev_b32_e32 v52, 1, v51
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v45, v47, v41, v45
	v_and_b32_e32 v51, 0x80008000, v51
	v_dot2_f32_f16 v50, v48, v30, v53
	v_perm_b32 v47, 0, v22, 0x10c000c
	v_lshrrev_b32_e32 v53, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_dot2_f32_f16 v45, v48, v42, v45
	v_and_or_b32 v48, 0x3f803f80, v52, v51
	v_lshrrev_b32_e32 v54, 1, v47
	v_and_b32_e32 v47, 0x80008000, v47
	v_perm_b32 v22, 0, v22, 0x30c020c
	v_and_or_b32 v21, 0x3f803f80, v53, v21
	v_dot2_f32_f16 v33, v48, v33, 0
	v_dot2_f32_f16 v37, v48, v37, 0
	v_and_or_b32 v47, 0x3f803f80, v54, v47
	v_perm_b32 v51, 0, v23, 0x10c000c
	v_lshrrev_b32_e32 v52, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_dot2_f32_f16 v33, v21, v34, v33
	v_dot2_f32_f16 v21, v21, v38, v37
	v_lshrrev_b32_e32 v48, 1, v51
	v_and_b32_e32 v51, 0x80008000, v51
	v_and_or_b32 v22, 0x3f803f80, v52, v22
	v_perm_b32 v23, 0, v23, 0x30c020c
	v_dot2_f32_f16 v33, v47, v35, v33
	v_dot2_f32_f16 v21, v47, v39, v21
	v_and_or_b32 v34, 0x3f803f80, v48, v51
	v_perm_b32 v37, 0, v24, 0x10c000c
	v_lshrrev_b32_e32 v35, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_dot2_f32_f16 v33, v22, v36, v33
	v_dot2_f32_f16 v21, v22, v40, v21
	v_lshrrev_b32_e32 v38, 1, v37
	v_and_b32_e32 v22, 0x80008000, v37
	v_perm_b32 v24, 0, v24, 0x30c020c
	v_and_or_b32 v23, 0x3f803f80, v35, v23
	v_dot2_f32_f16 v29, v34, v29, v33
	v_dot2_f32_f16 v21, v34, v41, v21
	v_and_or_b32 v22, 0x3f803f80, v38, v22
	v_lshrrev_b32_e32 v33, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_dot2_f32_f16 v29, v23, v30, v29
	v_dot2_f32_f16 v21, v23, v42, v21
	v_dot2_f32_f16 v23, v46, v31, v50
	v_dot2_f32_f16 v30, v46, v43, v45
	v_and_or_b32 v24, 0x3f803f80, v33, v24
	v_dot2_f32_f16 v29, v22, v31, v29
	v_dot2_f32_f16 v21, v22, v43, v21
	v_dot2_f32_f16 v37, v49, v32, v23
	v_dot2_f32_f16 v35, v49, v44, v30
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v24, v32, v29
	v_dot2_f32_f16 v33, v24, v44, v21
	s_and_saveexec_b32 s1, s5
	s_cbranch_execz .LBB69_91
; %bb.86:
	v_lshl_add_u32 v36, v82, 5, 0
	v_perm_b32 v38, 0, v25, 0x10c000c
	v_perm_b32 v39, 0, v25, 0x30c020c
	v_perm_b32 v40, 0, v26, 0x10c000c
	v_perm_b32 v42, 0, v26, 0x30c020c
	v_lshl_add_u32 v41, s9, 1, v36
	ds_load_b128 v[21:24], v36
	v_lshrrev_b32_e32 v48, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_perm_b32 v43, 0, v27, 0x10c000c
	ds_load_b128 v[29:32], v41
	v_perm_b32 v44, 0, v27, 0x30c020c
	v_perm_b32 v45, 0, v28, 0x10c000c
	v_perm_b32 v46, 0, v28, 0x30c020c
	ds_load_b128 v[25:28], v36 offset:16
	v_lshrrev_b32_e32 v36, 1, v39
	v_and_b32_e32 v39, 0x80008000, v39
	v_and_or_b32 v48, 0x3f803f80, v48, v38
	v_lshrrev_b32_e32 v49, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_lshrrev_b32_e32 v50, 1, v42
	v_and_or_b32 v51, 0x3f803f80, v36, v39
	v_and_b32_e32 v42, 0x80008000, v42
	v_lshrrev_b32_e32 v53, 1, v43
	v_and_or_b32 v40, 0x3f803f80, v49, v40
	v_and_b32_e32 v43, 0x80008000, v43
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v52, v48, v21, v37
	ds_load_b128 v[36:39], v41 offset:16
	v_and_or_b32 v42, 0x3f803f80, v50, v42
	v_perm_b32 v47, 0, v13, 0x10c000c
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v35, v48, v29, v35
	v_dot2_f32_f16 v41, v51, v22, v52
	v_lshrrev_b32_e32 v48, 1, v44
	v_and_b32_e32 v44, 0x80008000, v44
	v_lshrrev_b32_e32 v49, 1, v45
	v_dot2_f32_f16 v35, v51, v30, v35
	v_dot2_f32_f16 v41, v40, v23, v41
	v_and_b32_e32 v45, 0x80008000, v45
	v_and_or_b32 v43, 0x3f803f80, v53, v43
	v_and_or_b32 v44, 0x3f803f80, v48, v44
	v_dot2_f32_f16 v35, v40, v31, v35
	v_dot2_f32_f16 v41, v42, v24, v41
	v_lshrrev_b32_e32 v40, 1, v46
	v_and_b32_e32 v46, 0x80008000, v46
	v_perm_b32 v13, 0, v13, 0x30c020c
	v_dot2_f32_f16 v35, v42, v32, v35
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v41, v43, v25, v41
	v_and_or_b32 v42, 0x3f803f80, v49, v45
	v_and_or_b32 v40, 0x3f803f80, v40, v46
	v_lshrrev_b32_e32 v45, 1, v47
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v35, v43, v36, v35
	v_and_b32_e32 v46, 0x80008000, v47
	v_dot2_f32_f16 v41, v44, v26, v41
	v_perm_b32 v43, 0, v14, 0x10c000c
	v_lshrrev_b32_e32 v47, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	v_dot2_f32_f16 v35, v44, v37, v35
	v_and_or_b32 v44, 0x3f803f80, v45, v46
	v_lshrrev_b32_e32 v48, 1, v43
	v_and_b32_e32 v43, 0x80008000, v43
	v_perm_b32 v14, 0, v14, 0x30c020c
	v_and_or_b32 v13, 0x3f803f80, v47, v13
	v_dot2_f32_f16 v21, v44, v21, v34
	v_dot2_f32_f16 v29, v44, v29, v33
	v_and_or_b32 v43, 0x3f803f80, v48, v43
	v_perm_b32 v45, 0, v15, 0x10c000c
	v_lshrrev_b32_e32 v46, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_dot2_f32_f16 v21, v13, v22, v21
	v_dot2_f32_f16 v13, v13, v30, v29
	v_lshrrev_b32_e32 v33, 1, v45
	v_and_b32_e32 v34, 0x80008000, v45
	v_and_or_b32 v14, 0x3f803f80, v46, v14
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_dot2_f32_f16 v21, v43, v23, v21
	v_dot2_f32_f16 v13, v43, v31, v13
	v_and_or_b32 v22, 0x3f803f80, v33, v34
	v_perm_b32 v29, 0, v16, 0x10c000c
	v_lshrrev_b32_e32 v23, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v21, v14, v24, v21
	v_dot2_f32_f16 v13, v14, v32, v13
	v_lshrrev_b32_e32 v30, 1, v29
	v_and_b32_e32 v14, 0x80008000, v29
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_and_or_b32 v15, 0x3f803f80, v23, v15
	v_dot2_f32_f16 v21, v22, v25, v21
	v_dot2_f32_f16 v13, v22, v36, v13
	v_and_or_b32 v14, 0x3f803f80, v30, v14
	v_lshrrev_b32_e32 v22, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_dot2_f32_f16 v21, v15, v26, v21
	v_dot2_f32_f16 v13, v15, v37, v13
	v_dot2_f32_f16 v15, v42, v27, v41
	v_dot2_f32_f16 v23, v42, v38, v35
	v_and_or_b32 v16, 0x3f803f80, v22, v16
	v_dot2_f32_f16 v21, v14, v27, v21
	v_dot2_f32_f16 v13, v14, v38, v13
	v_dot2_f32_f16 v37, v40, v28, v15
	v_dot2_f32_f16 v35, v40, v39, v23
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v16, v28, v21
	v_dot2_f32_f16 v33, v16, v39, v13
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB69_90
; %bb.87:
	v_lshl_add_u32 v25, v81, 5, 0
	v_perm_b32 v26, 0, v17, 0x10c000c
	v_perm_b32 v27, 0, v17, 0x30c020c
	v_perm_b32 v28, 0, v18, 0x10c000c
	v_perm_b32 v30, 0, v18, 0x30c020c
	ds_load_b128 v[13:16], v25
	v_lshl_add_u32 v29, s9, 1, v25
	v_lshrrev_b32_e32 v40, 1, v26
	v_and_b32_e32 v26, 0x80008000, v26
	v_perm_b32 v31, 0, v19, 0x10c000c
	v_perm_b32 v32, 0, v19, 0x30c020c
	ds_load_b128 v[21:24], v29
	v_perm_b32 v36, 0, v20, 0x10c000c
	v_perm_b32 v38, 0, v20, 0x30c020c
	ds_load_b128 v[17:20], v25 offset:16
	v_lshrrev_b32_e32 v25, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_and_or_b32 v40, 0x3f803f80, v40, v26
	v_lshrrev_b32_e32 v41, 1, v28
	v_and_b32_e32 v42, 0x80008000, v28
	v_lshrrev_b32_e32 v43, 1, v30
	v_and_or_b32 v44, 0x3f803f80, v25, v27
	v_and_b32_e32 v30, 0x80008000, v30
	ds_load_b128 v[25:28], v29 offset:16
	v_and_or_b32 v29, 0x3f803f80, v41, v42
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v37, v40, v13, v37
	v_lshrrev_b32_e32 v45, 1, v31
	v_and_b32_e32 v31, 0x80008000, v31
	v_and_or_b32 v30, 0x3f803f80, v43, v30
	v_perm_b32 v39, 0, v5, 0x10c000c
	v_dot2_f32_f16 v37, v44, v14, v37
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v35, v40, v21, v35
	v_lshrrev_b32_e32 v40, 1, v32
	v_and_b32_e32 v32, 0x80008000, v32
	v_and_or_b32 v31, 0x3f803f80, v45, v31
	v_dot2_f32_f16 v37, v29, v15, v37
	v_dot2_f32_f16 v35, v44, v22, v35
	v_lshrrev_b32_e32 v41, 1, v36
	v_and_b32_e32 v36, 0x80008000, v36
	v_and_or_b32 v32, 0x3f803f80, v40, v32
	v_dot2_f32_f16 v37, v30, v16, v37
	v_dot2_f32_f16 v29, v29, v23, v35
	v_lshrrev_b32_e32 v35, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_perm_b32 v5, 0, v5, 0x30c020c
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v37, v31, v17, v37
	v_dot2_f32_f16 v29, v30, v24, v29
	v_and_or_b32 v30, 0x3f803f80, v41, v36
	v_and_or_b32 v35, 0x3f803f80, v35, v38
	v_and_b32_e32 v38, 0x80008000, v39
	v_dot2_f32_f16 v36, v32, v18, v37
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v29, v31, v25, v29
	v_lshrrev_b32_e32 v37, 1, v39
	v_perm_b32 v31, 0, v6, 0x10c000c
	v_lshrrev_b32_e32 v39, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v29, v32, v26, v29
	v_and_or_b32 v32, 0x3f803f80, v37, v38
	v_lshrrev_b32_e32 v40, 1, v31
	v_and_b32_e32 v31, 0x80008000, v31
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v39, v5
	v_dot2_f32_f16 v13, v32, v13, v34
	v_dot2_f32_f16 v21, v32, v21, v33
	v_and_or_b32 v31, 0x3f803f80, v40, v31
	v_perm_b32 v37, 0, v7, 0x10c000c
	v_lshrrev_b32_e32 v38, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v13, v5, v14, v13
	v_dot2_f32_f16 v5, v5, v22, v21
	v_lshrrev_b32_e32 v32, 1, v37
	v_and_b32_e32 v33, 0x80008000, v37
	v_and_or_b32 v6, 0x3f803f80, v38, v6
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_dot2_f32_f16 v13, v31, v15, v13
	v_dot2_f32_f16 v5, v31, v23, v5
	v_and_or_b32 v14, 0x3f803f80, v32, v33
	v_perm_b32 v21, 0, v8, 0x10c000c
	v_lshrrev_b32_e32 v15, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v13, v6, v16, v13
	v_dot2_f32_f16 v5, v6, v24, v5
	v_lshrrev_b32_e32 v22, 1, v21
	v_and_b32_e32 v6, 0x80008000, v21
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_and_or_b32 v7, 0x3f803f80, v15, v7
	v_dot2_f32_f16 v13, v14, v17, v13
	v_dot2_f32_f16 v5, v14, v25, v5
	v_and_or_b32 v6, 0x3f803f80, v22, v6
	v_lshrrev_b32_e32 v14, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_dot2_f32_f16 v13, v7, v18, v13
	v_dot2_f32_f16 v5, v7, v26, v5
	v_dot2_f32_f16 v7, v30, v19, v36
	v_dot2_f32_f16 v15, v30, v27, v29
	v_and_or_b32 v8, 0x3f803f80, v14, v8
	v_dot2_f32_f16 v13, v6, v19, v13
	v_dot2_f32_f16 v5, v6, v27, v5
	v_dot2_f32_f16 v37, v35, v20, v7
	v_dot2_f32_f16 v35, v35, v28, v15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v8, v20, v13
	v_dot2_f32_f16 v33, v8, v28, v5
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB69_89
; %bb.88:
	v_lshl_add_u32 v17, v80, 5, 0
	v_perm_b32 v18, 0, v9, 0x10c000c
	v_perm_b32 v19, 0, v9, 0x30c020c
	v_perm_b32 v20, 0, v10, 0x10c000c
	v_perm_b32 v22, 0, v10, 0x30c020c
	v_lshl_add_u32 v21, s9, 1, v17
	ds_load_b128 v[5:8], v17
	v_lshrrev_b32_e32 v28, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_perm_b32 v23, 0, v11, 0x10c000c
	ds_load_b128 v[13:16], v21
	v_perm_b32 v24, 0, v11, 0x30c020c
	v_perm_b32 v25, 0, v12, 0x10c000c
	v_perm_b32 v26, 0, v12, 0x30c020c
	ds_load_b128 v[9:12], v17 offset:16
	v_lshrrev_b32_e32 v17, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_and_or_b32 v28, 0x3f803f80, v28, v18
	v_lshrrev_b32_e32 v29, 1, v20
	v_and_b32_e32 v30, 0x80008000, v20
	v_lshrrev_b32_e32 v31, 1, v22
	v_and_or_b32 v32, 0x3f803f80, v17, v19
	ds_load_b128 v[17:20], v21 offset:16
	v_and_b32_e32 v22, 0x80008000, v22
	v_and_or_b32 v21, 0x3f803f80, v29, v30
	v_perm_b32 v27, 0, v1, 0x10c000c
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v36, v28, v5, v37
	v_lshrrev_b32_e32 v37, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_and_or_b32 v22, 0x3f803f80, v31, v22
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v28, v28, v13, v35
	v_dot2_f32_f16 v29, v32, v6, v36
	v_lshrrev_b32_e32 v30, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_lshrrev_b32_e32 v31, 1, v25
	v_dot2_f32_f16 v28, v32, v14, v28
	v_dot2_f32_f16 v29, v21, v7, v29
	v_and_b32_e32 v25, 0x80008000, v25
	v_and_or_b32 v23, 0x3f803f80, v37, v23
	v_and_or_b32 v24, 0x3f803f80, v30, v24
	v_dot2_f32_f16 v21, v21, v15, v28
	v_dot2_f32_f16 v29, v22, v8, v29
	v_lshrrev_b32_e32 v28, 1, v26
	v_and_b32_e32 v26, 0x80008000, v26
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_dot2_f32_f16 v21, v22, v16, v21
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v29, v23, v9, v29
	v_and_or_b32 v22, 0x3f803f80, v31, v25
	v_and_or_b32 v25, 0x3f803f80, v28, v26
	v_lshrrev_b32_e32 v28, 1, v27
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v21, v23, v17, v21
	v_and_b32_e32 v27, 0x80008000, v27
	v_dot2_f32_f16 v26, v24, v10, v29
	v_perm_b32 v23, 0, v2, 0x10c000c
	v_lshrrev_b32_e32 v29, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_dot2_f32_f16 v21, v24, v18, v21
	v_and_or_b32 v24, 0x3f803f80, v28, v27
	v_lshrrev_b32_e32 v30, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_perm_b32 v2, 0, v2, 0x30c020c
	v_and_or_b32 v1, 0x3f803f80, v29, v1
	v_dot2_f32_f16 v5, v24, v5, v34
	v_dot2_f32_f16 v13, v24, v13, v33
	v_and_or_b32 v23, 0x3f803f80, v30, v23
	v_perm_b32 v27, 0, v3, 0x10c000c
	v_lshrrev_b32_e32 v28, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_dot2_f32_f16 v5, v1, v6, v5
	v_dot2_f32_f16 v1, v1, v14, v13
	v_lshrrev_b32_e32 v24, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_and_or_b32 v2, 0x3f803f80, v28, v2
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_dot2_f32_f16 v5, v23, v7, v5
	v_dot2_f32_f16 v1, v23, v15, v1
	v_and_or_b32 v6, 0x3f803f80, v24, v27
	v_perm_b32 v13, 0, v4, 0x10c000c
	v_lshrrev_b32_e32 v7, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v5, v2, v8, v5
	v_dot2_f32_f16 v1, v2, v16, v1
	v_lshrrev_b32_e32 v14, 1, v13
	v_and_b32_e32 v2, 0x80008000, v13
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v7, v3
	v_dot2_f32_f16 v5, v6, v9, v5
	v_dot2_f32_f16 v1, v6, v17, v1
	v_and_or_b32 v2, 0x3f803f80, v14, v2
	v_lshrrev_b32_e32 v6, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_dot2_f32_f16 v5, v3, v10, v5
	v_dot2_f32_f16 v1, v3, v18, v1
	v_dot2_f32_f16 v3, v22, v11, v26
	v_dot2_f32_f16 v7, v22, v19, v21
	v_and_or_b32 v4, 0x3f803f80, v6, v4
	v_dot2_f32_f16 v5, v2, v11, v5
	v_dot2_f32_f16 v1, v2, v19, v1
	v_dot2_f32_f16 v37, v25, v12, v3
	v_dot2_f32_f16 v35, v25, v20, v7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v4, v12, v5
	v_dot2_f32_f16 v33, v4, v20, v1
.LBB69_89:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB69_90:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB69_91:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
.LBB69_92:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s5, exec_lo
	v_cmpx_lt_u32_e32 0x9f, v0
	s_cbranch_execz .LBB69_120
; %bb.93:
	v_lshlrev_b32_e32 v0, 5, v77
	s_wait_dscnt 0x0
	v_or_b32_e32 v36, 0xe0, v77
	s_lshl_b32 s8, s9, 1
	s_mov_b32 s6, 0
	s_mov_b32 s9, 4
	v_add3_u32 v32, v0, 0, 0x1000
	s_branch .LBB69_98
.LBB69_94:                              ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
.LBB69_95:                              ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
.LBB69_96:                              ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB69_97:                              ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_add_co_i32 s9, s9, 4
	v_add_co_u32 v69, vcc_lo, 0x800, v69
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v70, null, 0, v70, vcc_lo
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s9, v79
	v_add_co_u32 v71, s0, 0x800, v71
	v_add_nc_u32_e32 v32, 0x1000, v32
	v_add_nc_u32_e32 v36, 0x80, v36
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v72, null, 0, v72, s0
	s_or_b32 s6, vcc_lo, s6
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s6
	s_cbranch_execz .LBB69_119
.LBB69_98:                              ; =>This Inner Loop Header: Depth=1
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v0, 0xffffffa0, v36
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v31, 0
	v_mov_b32_e32 v28, 0
	v_mov_b32_e32 v30, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e64 s3, s16, v0
	s_and_saveexec_b32 s0, s3
	s_cbranch_execz .LBB69_100
; %bb.99:                               ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v0, vcc_lo, v71, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v72, vcc_lo
	global_load_b128 v[28:31], v[0:1], off offset:2048 th:TH_LOAD_NT
.LBB69_100:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0
	s_and_b32 s1, s2, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s1
	s_cbranch_execz .LBB69_102
; %bb.101:                              ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v0, vcc_lo, v69, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v70, vcc_lo
	global_load_b128 v[24:27], v[0:1], off offset:2048 th:TH_LOAD_NT
.LBB69_102:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_subrev_nc_u32_e32 v0, 64, v36
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v17, 0
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s1, s16, v0
	s_and_saveexec_b32 s0, s1
	s_cbranch_execz .LBB69_104
; %bb.103:                              ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v0, vcc_lo, v71, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v72, vcc_lo
	global_load_b128 v[16:19], v[0:1], off offset:2560 th:TH_LOAD_NT
.LBB69_104:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0
	s_and_b32 s4, s2, s1
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB69_106
; %bb.105:                              ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v0, vcc_lo, v69, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v70, vcc_lo
	global_load_b128 v[20:23], v[0:1], off offset:2560 th:TH_LOAD_NT
.LBB69_106:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_subrev_nc_u32_e32 v0, 32, v36
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v9, 0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s0, s16, v0
	s_and_saveexec_b32 s4, s0
	s_cbranch_execz .LBB69_108
; %bb.107:                              ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v0, vcc_lo, v71, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v72, vcc_lo
	global_load_b128 v[8:11], v[0:1], off offset:3072 th:TH_LOAD_NT
.LBB69_108:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0
	s_and_b32 s15, s2, s0
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s15
	s_cbranch_execz .LBB69_110
; %bb.109:                              ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v0, vcc_lo, v69, v78
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v70, vcc_lo
	global_load_b128 v[12:15], v[0:1], off offset:3072 th:TH_LOAD_NT
.LBB69_110:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_cmp_gt_i32_e32 vcc_lo, s16, v36
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v5, 0
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0
	s_and_saveexec_b32 s15, vcc_lo
	s_cbranch_execz .LBB69_112
; %bb.111:                              ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v1, s4, v71, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v72, s4
	global_load_b128 v[4:7], v[1:2], off offset:3584 th:TH_LOAD_NT
.LBB69_112:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s15
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0
	v_mov_b32_e32 v3, 0
	s_and_b32 s4, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s15, s4
	s_cbranch_execz .LBB69_114
; %bb.113:                              ;   in Loop: Header=BB69_98 Depth=1
	v_add_co_u32 v0, s4, v69, v78
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v1, null, 0, v70, s4
	global_load_b128 v[0:3], v[0:1], off offset:3584 th:TH_LOAD_NT
.LBB69_114:                             ;   in Loop: Header=BB69_98 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s15
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB69_97
; %bb.115:                              ;   in Loop: Header=BB69_98 Depth=1
	s_wait_loadcnt 0x0
	v_perm_b32 v46, 0, v28, 0x10c000c
	v_perm_b32 v47, 0, v28, 0x30c020c
	v_add_nc_u32_e32 v28, s8, v32
	ds_load_b128 v[38:41], v32
	ds_load_b128 v[42:45], v32 offset:16
	v_perm_b32 v58, 0, v29, 0x10c000c
	v_lshrrev_b32_e32 v54, 1, v46
	v_and_b32_e32 v55, 0x80008000, v46
	v_lshrrev_b32_e32 v56, 1, v47
	v_and_b32_e32 v57, 0x80008000, v47
	ds_load_b128 v[46:49], v28
	ds_load_b128 v[50:53], v28 offset:16
	v_perm_b32 v29, 0, v29, 0x30c020c
	v_and_or_b32 v54, 0x3f803f80, v54, v55
	v_and_or_b32 v55, 0x3f803f80, v56, v57
	v_lshrrev_b32_e32 v57, 1, v58
	v_and_b32_e32 v58, 0x80008000, v58
	v_perm_b32 v56, 0, v30, 0x10c000c
	v_lshrrev_b32_e32 v59, 1, v29
	v_and_b32_e32 v29, 0x80008000, v29
	v_perm_b32 v30, 0, v30, 0x30c020c
	v_and_or_b32 v57, 0x3f803f80, v57, v58
	v_lshrrev_b32_e32 v60, 1, v56
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v37, v54, v38, v37
	v_and_b32_e32 v56, 0x80008000, v56
	v_and_or_b32 v29, 0x3f803f80, v59, v29
	v_lshrrev_b32_e32 v58, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_dot2_f32_f16 v37, v55, v39, v37
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v35, v54, v46, v35
	v_and_or_b32 v56, 0x3f803f80, v60, v56
	v_perm_b32 v54, 0, v31, 0x10c000c
	v_and_or_b32 v30, 0x3f803f80, v58, v30
	v_dot2_f32_f16 v37, v57, v40, v37
	v_dot2_f32_f16 v35, v55, v47, v35
	v_perm_b32 v31, 0, v31, 0x30c020c
	v_lshrrev_b32_e32 v55, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_dot2_f32_f16 v37, v29, v41, v37
	v_dot2_f32_f16 v35, v57, v48, v35
	v_lshrrev_b32_e32 v59, 1, v31
	v_and_b32_e32 v31, 0x80008000, v31
	v_and_or_b32 v54, 0x3f803f80, v55, v54
	v_dot2_f32_f16 v37, v56, v42, v37
	v_dot2_f32_f16 v29, v29, v49, v35
	v_perm_b32 v35, 0, v24, 0x10c000c
	v_perm_b32 v24, 0, v24, 0x30c020c
	v_perm_b32 v55, 0, v25, 0x10c000c
	v_dot2_f32_f16 v37, v30, v43, v37
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v29, v56, v50, v29
	v_lshrrev_b32_e32 v56, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	v_lshrrev_b32_e32 v57, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_dot2_f32_f16 v29, v30, v51, v29
	v_lshrrev_b32_e32 v58, 1, v55
	v_and_or_b32 v30, 0x3f803f80, v56, v35
	v_and_b32_e32 v55, 0x80008000, v55
	v_perm_b32 v25, 0, v25, 0x30c020c
	v_and_or_b32 v24, 0x3f803f80, v57, v24
	v_and_or_b32 v31, 0x3f803f80, v59, v31
	v_dot2_f32_f16 v34, v30, v38, v34
	v_dot2_f32_f16 v30, v30, v46, v33
	v_and_or_b32 v35, 0x3f803f80, v58, v55
	v_perm_b32 v55, 0, v26, 0x10c000c
	v_lshrrev_b32_e32 v56, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_dot2_f32_f16 v34, v24, v39, v34
	v_dot2_f32_f16 v24, v24, v47, v30
	v_lshrrev_b32_e32 v33, 1, v55
	v_and_b32_e32 v38, 0x80008000, v55
	v_and_or_b32 v25, 0x3f803f80, v56, v25
	v_perm_b32 v26, 0, v26, 0x30c020c
	v_dot2_f32_f16 v34, v35, v40, v34
	v_dot2_f32_f16 v24, v35, v48, v24
	v_and_or_b32 v30, 0x3f803f80, v33, v38
	v_perm_b32 v33, 0, v27, 0x10c000c
	v_lshrrev_b32_e32 v35, 1, v26
	v_and_b32_e32 v26, 0x80008000, v26
	v_dot2_f32_f16 v34, v25, v41, v34
	v_dot2_f32_f16 v24, v25, v49, v24
	v_lshrrev_b32_e32 v38, 1, v33
	v_and_b32_e32 v25, 0x80008000, v33
	v_perm_b32 v27, 0, v27, 0x30c020c
	v_and_or_b32 v26, 0x3f803f80, v35, v26
	v_dot2_f32_f16 v33, v30, v42, v34
	v_dot2_f32_f16 v24, v30, v50, v24
	v_and_or_b32 v25, 0x3f803f80, v38, v25
	v_lshrrev_b32_e32 v30, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_dot2_f32_f16 v33, v26, v43, v33
	v_dot2_f32_f16 v24, v26, v51, v24
	v_dot2_f32_f16 v26, v54, v44, v37
	v_dot2_f32_f16 v29, v54, v52, v29
	v_and_or_b32 v27, 0x3f803f80, v30, v27
	v_dot2_f32_f16 v30, v25, v44, v33
	v_dot2_f32_f16 v24, v25, v52, v24
	v_dot2_f32_f16 v37, v31, v45, v26
	v_dot2_f32_f16 v35, v31, v53, v29
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v27, v45, v30
	v_dot2_f32_f16 v33, v27, v53, v24
	s_and_saveexec_b32 s3, s1
	s_cbranch_execz .LBB69_96
; %bb.116:                              ;   in Loop: Header=BB69_98 Depth=1
	ds_load_b128 v[24:27], v32 offset:1024
	ds_load_b128 v[38:41], v32 offset:1040
	ds_load_b128 v[42:45], v28 offset:1024
	ds_load_b128 v[46:49], v28 offset:1040
	v_perm_b32 v29, 0, v16, 0x10c000c
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_perm_b32 v50, 0, v17, 0x10c000c
	v_perm_b32 v17, 0, v17, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v30, 1, v29
	v_and_b32_e32 v29, 0x80008000, v29
	v_lshrrev_b32_e32 v31, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_lshrrev_b32_e32 v51, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_and_or_b32 v29, 0x3f803f80, v30, v29
	v_perm_b32 v30, 0, v18, 0x10c000c
	v_and_or_b32 v16, 0x3f803f80, v31, v16
	v_lshrrev_b32_e32 v31, 1, v50
	v_and_b32_e32 v50, 0x80008000, v50
	v_and_or_b32 v17, 0x3f803f80, v51, v17
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v37, v29, v24, v37
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v29, v29, v42, v35
	v_perm_b32 v35, 0, v19, 0x10c000c
	v_and_or_b32 v31, 0x3f803f80, v31, v50
	v_perm_b32 v19, 0, v19, 0x30c020c
	v_dot2_f32_f16 v37, v16, v25, v37
	v_dot2_f32_f16 v16, v16, v43, v29
	v_lshrrev_b32_e32 v52, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_lshrrev_b32_e32 v51, 1, v19
	v_dot2_f32_f16 v37, v31, v26, v37
	v_dot2_f32_f16 v16, v31, v44, v16
	v_and_b32_e32 v19, 0x80008000, v19
	v_perm_b32 v18, 0, v18, 0x30c020c
	v_lshrrev_b32_e32 v29, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	v_dot2_f32_f16 v37, v17, v27, v37
	v_dot2_f32_f16 v16, v17, v45, v16
	v_and_or_b32 v17, 0x3f803f80, v51, v19
	v_perm_b32 v19, 0, v20, 0x10c000c
	v_and_or_b32 v30, 0x3f803f80, v52, v30
	v_lshrrev_b32_e32 v50, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_and_or_b32 v29, 0x3f803f80, v29, v35
	v_perm_b32 v20, 0, v20, 0x30c020c
	v_lshrrev_b32_e32 v35, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_and_or_b32 v18, 0x3f803f80, v50, v18
	v_dot2_f32_f16 v31, v30, v38, v37
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v16, v30, v46, v16
	v_perm_b32 v30, 0, v21, 0x10c000c
	v_lshrrev_b32_e32 v37, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_and_or_b32 v19, 0x3f803f80, v35, v19
	v_dot2_f32_f16 v31, v18, v39, v31
	v_lshrrev_b32_e32 v50, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_dot2_f32_f16 v16, v18, v47, v16
	v_perm_b32 v18, 0, v21, 0x30c020c
	v_and_or_b32 v20, 0x3f803f80, v37, v20
	v_dot2_f32_f16 v24, v19, v24, v34
	v_dot2_f32_f16 v19, v19, v42, v33
	v_and_or_b32 v21, 0x3f803f80, v50, v30
	v_perm_b32 v30, 0, v22, 0x10c000c
	v_lshrrev_b32_e32 v35, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_dot2_f32_f16 v24, v20, v25, v24
	v_dot2_f32_f16 v19, v20, v43, v19
	v_lshrrev_b32_e32 v33, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_and_or_b32 v18, 0x3f803f80, v35, v18
	v_perm_b32 v20, 0, v22, 0x30c020c
	v_dot2_f32_f16 v24, v21, v26, v24
	v_dot2_f32_f16 v19, v21, v44, v19
	v_and_or_b32 v22, 0x3f803f80, v33, v30
	v_perm_b32 v25, 0, v23, 0x10c000c
	v_lshrrev_b32_e32 v21, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_dot2_f32_f16 v24, v18, v27, v24
	v_dot2_f32_f16 v18, v18, v45, v19
	v_lshrrev_b32_e32 v26, 1, v25
	v_and_b32_e32 v19, 0x80008000, v25
	v_perm_b32 v23, 0, v23, 0x30c020c
	v_and_or_b32 v20, 0x3f803f80, v21, v20
	v_dot2_f32_f16 v21, v22, v38, v24
	v_dot2_f32_f16 v18, v22, v46, v18
	v_and_or_b32 v19, 0x3f803f80, v26, v19
	v_lshrrev_b32_e32 v22, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_dot2_f32_f16 v21, v20, v39, v21
	v_dot2_f32_f16 v18, v20, v47, v18
	v_dot2_f32_f16 v20, v29, v40, v31
	v_dot2_f32_f16 v16, v29, v48, v16
	v_and_or_b32 v22, 0x3f803f80, v22, v23
	v_dot2_f32_f16 v21, v19, v40, v21
	v_dot2_f32_f16 v18, v19, v48, v18
	v_dot2_f32_f16 v37, v17, v41, v20
	v_dot2_f32_f16 v35, v17, v49, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v22, v41, v21
	v_dot2_f32_f16 v33, v22, v49, v18
	s_and_saveexec_b32 s1, s0
	s_cbranch_execz .LBB69_95
; %bb.117:                              ;   in Loop: Header=BB69_98 Depth=1
	v_perm_b32 v24, 0, v8, 0x10c000c
	ds_load_b128 v[16:19], v32 offset:2048
	ds_load_b128 v[20:23], v32 offset:2064
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_perm_b32 v42, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_lshrrev_b32_e32 v29, 1, v24
	v_and_b32_e32 v30, 0x80008000, v24
	ds_load_b128 v[24:27], v28 offset:2048
	ds_load_b128 v[38:41], v28 offset:2064
	v_lshrrev_b32_e32 v31, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_lshrrev_b32_e32 v43, 1, v9
	v_and_or_b32 v29, 0x3f803f80, v29, v30
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v30, 0, v10, 0x10c000c
	v_and_or_b32 v8, 0x3f803f80, v31, v8
	v_lshrrev_b32_e32 v31, 1, v42
	v_and_b32_e32 v42, 0x80008000, v42
	v_and_or_b32 v9, 0x3f803f80, v43, v9
	v_lshrrev_b32_e32 v44, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v37, v29, v16, v37
	v_and_or_b32 v31, 0x3f803f80, v31, v42
	v_perm_b32 v10, 0, v10, 0x30c020c
	v_and_or_b32 v30, 0x3f803f80, v44, v30
	s_delay_alu instid0(VALU_DEP_4)
	v_dot2_f32_f16 v37, v8, v17, v37
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v29, v29, v24, v35
	v_perm_b32 v35, 0, v11, 0x10c000c
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_lshrrev_b32_e32 v42, 1, v10
	v_dot2_f32_f16 v37, v31, v18, v37
	v_dot2_f32_f16 v8, v8, v25, v29
	v_lshrrev_b32_e32 v29, 1, v35
	v_lshrrev_b32_e32 v43, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_and_b32_e32 v35, 0x80008000, v35
	v_dot2_f32_f16 v8, v31, v26, v8
	v_dot2_f32_f16 v37, v9, v19, v37
	v_and_b32_e32 v10, 0x80008000, v10
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v29, 0x3f803f80, v29, v35
	v_dot2_f32_f16 v8, v9, v27, v8
	v_and_or_b32 v9, 0x3f803f80, v43, v11
	v_perm_b32 v11, 0, v12, 0x10c000c
	v_perm_b32 v12, 0, v12, 0x30c020c
	v_and_or_b32 v10, 0x3f803f80, v42, v10
	v_dot2_f32_f16 v31, v30, v20, v37
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v8, v30, v38, v8
	v_lshrrev_b32_e32 v35, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_perm_b32 v30, 0, v13, 0x10c000c
	v_lshrrev_b32_e32 v37, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	v_dot2_f32_f16 v31, v10, v21, v31
	v_and_or_b32 v11, 0x3f803f80, v35, v11
	v_lshrrev_b32_e32 v42, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_dot2_f32_f16 v8, v10, v39, v8
	v_perm_b32 v10, 0, v13, 0x30c020c
	v_and_or_b32 v12, 0x3f803f80, v37, v12
	v_dot2_f32_f16 v16, v11, v16, v34
	v_dot2_f32_f16 v11, v11, v24, v33
	v_and_or_b32 v13, 0x3f803f80, v42, v30
	v_perm_b32 v30, 0, v14, 0x10c000c
	v_lshrrev_b32_e32 v35, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_dot2_f32_f16 v16, v12, v17, v16
	v_dot2_f32_f16 v11, v12, v25, v11
	v_lshrrev_b32_e32 v24, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_and_or_b32 v10, 0x3f803f80, v35, v10
	v_perm_b32 v12, 0, v14, 0x30c020c
	v_dot2_f32_f16 v16, v13, v18, v16
	v_dot2_f32_f16 v11, v13, v26, v11
	v_and_or_b32 v14, 0x3f803f80, v24, v30
	v_perm_b32 v17, 0, v15, 0x10c000c
	v_lshrrev_b32_e32 v13, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	v_dot2_f32_f16 v16, v10, v19, v16
	v_dot2_f32_f16 v10, v10, v27, v11
	v_lshrrev_b32_e32 v18, 1, v17
	v_and_b32_e32 v11, 0x80008000, v17
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v12, 0x3f803f80, v13, v12
	v_dot2_f32_f16 v13, v14, v20, v16
	v_dot2_f32_f16 v10, v14, v38, v10
	v_and_or_b32 v11, 0x3f803f80, v18, v11
	v_lshrrev_b32_e32 v14, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v13, v12, v21, v13
	v_dot2_f32_f16 v10, v12, v39, v10
	v_dot2_f32_f16 v12, v29, v22, v31
	v_dot2_f32_f16 v8, v29, v40, v8
	v_and_or_b32 v14, 0x3f803f80, v14, v15
	v_dot2_f32_f16 v13, v11, v22, v13
	v_dot2_f32_f16 v10, v11, v40, v10
	v_dot2_f32_f16 v37, v9, v23, v12
	v_dot2_f32_f16 v35, v9, v41, v8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v14, v23, v13
	v_dot2_f32_f16 v33, v14, v41, v10
	s_and_saveexec_b32 s0, vcc_lo
	s_cbranch_execz .LBB69_94
; %bb.118:                              ;   in Loop: Header=BB69_98 Depth=1
	v_perm_b32 v16, 0, v4, 0x10c000c
	ds_load_b128 v[8:11], v32 offset:3072
	ds_load_b128 v[12:15], v32 offset:3088
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v27, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_lshrrev_b32_e32 v24, 1, v16
	v_and_b32_e32 v25, 0x80008000, v16
	ds_load_b128 v[16:19], v28 offset:3072
	ds_load_b128 v[20:23], v28 offset:3088
	v_lshrrev_b32_e32 v26, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_lshrrev_b32_e32 v28, 1, v5
	v_and_or_b32 v24, 0x3f803f80, v24, v25
	v_perm_b32 v25, 0, v6, 0x10c000c
	v_and_b32_e32 v5, 0x80008000, v5
	v_and_or_b32 v4, 0x3f803f80, v26, v4
	v_lshrrev_b32_e32 v26, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_lshrrev_b32_e32 v29, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_perm_b32 v6, 0, v6, 0x30c020c
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v30, v24, v8, v37
	v_and_or_b32 v26, 0x3f803f80, v26, v27
	v_and_or_b32 v5, 0x3f803f80, v28, v5
	v_and_or_b32 v25, 0x3f803f80, v29, v25
	v_perm_b32 v29, 0, v7, 0x10c000c
	v_dot2_f32_f16 v27, v4, v9, v30
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v24, v24, v16, v35
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_lshrrev_b32_e32 v28, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v27, v26, v10, v27
	v_dot2_f32_f16 v4, v4, v17, v24
	v_lshrrev_b32_e32 v30, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_and_or_b32 v6, 0x3f803f80, v28, v6
	v_dot2_f32_f16 v27, v5, v11, v27
	v_dot2_f32_f16 v4, v26, v18, v4
	v_lshrrev_b32_e32 v24, 1, v29
	v_and_b32_e32 v29, 0x80008000, v29
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v26, v25, v12, v27
	v_dot2_f32_f16 v4, v5, v19, v4
	v_and_or_b32 v5, 0x3f803f80, v30, v7
	v_perm_b32 v7, 0, v0, 0x10c000c
	v_perm_b32 v0, 0, v0, 0x30c020c
	v_dot2_f32_f16 v26, v6, v13, v26
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v4, v25, v20, v4
	v_perm_b32 v25, 0, v1, 0x10c000c
	v_lshrrev_b32_e32 v27, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_lshrrev_b32_e32 v28, 1, v0
	v_and_b32_e32 v0, 0x80008000, v0
	v_dot2_f32_f16 v4, v6, v21, v4
	v_and_or_b32 v24, 0x3f803f80, v24, v29
	v_and_or_b32 v6, 0x3f803f80, v27, v7
	v_lshrrev_b32_e32 v29, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_and_or_b32 v0, 0x3f803f80, v28, v0
	v_dot2_f32_f16 v8, v6, v8, v34
	v_dot2_f32_f16 v6, v6, v16, v33
	v_and_or_b32 v7, 0x3f803f80, v29, v25
	v_perm_b32 v25, 0, v2, 0x10c000c
	v_lshrrev_b32_e32 v27, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_dot2_f32_f16 v8, v0, v9, v8
	v_dot2_f32_f16 v0, v0, v17, v6
	v_lshrrev_b32_e32 v16, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_and_or_b32 v1, 0x3f803f80, v27, v1
	v_perm_b32 v2, 0, v2, 0x30c020c
	v_dot2_f32_f16 v8, v7, v10, v8
	v_dot2_f32_f16 v0, v7, v18, v0
	v_and_or_b32 v6, 0x3f803f80, v16, v25
	v_perm_b32 v9, 0, v3, 0x10c000c
	v_lshrrev_b32_e32 v7, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_dot2_f32_f16 v8, v1, v11, v8
	v_dot2_f32_f16 v0, v1, v19, v0
	v_lshrrev_b32_e32 v10, 1, v9
	v_and_b32_e32 v1, 0x80008000, v9
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v2, 0x3f803f80, v7, v2
	v_dot2_f32_f16 v7, v6, v12, v8
	v_dot2_f32_f16 v0, v6, v20, v0
	v_and_or_b32 v1, 0x3f803f80, v10, v1
	v_lshrrev_b32_e32 v6, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v7, v2, v13, v7
	v_dot2_f32_f16 v0, v2, v21, v0
	v_dot2_f32_f16 v2, v24, v14, v26
	v_dot2_f32_f16 v4, v24, v22, v4
	v_and_or_b32 v3, 0x3f803f80, v6, v3
	v_dot2_f32_f16 v6, v1, v14, v7
	v_dot2_f32_f16 v0, v1, v22, v0
	v_dot2_f32_f16 v37, v5, v15, v2
	v_dot2_f32_f16 v35, v5, v23, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v3, v15, v6
	v_dot2_f32_f16 v33, v3, v23, v0
	s_branch .LBB69_94
.LBB69_119:
	s_or_b32 exec_lo, exec_lo, s6
.LBB69_120:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB69_121:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v0, -1, 0
	v_cmp_gt_i64_e64 s1, s[10:11], v[67:68]
	v_cmp_eq_u32_e64 s0, 0, v77
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v1, 16, v0
	v_xor_b32_e32 v3, 8, v0
	v_xor_b32_e32 v4, 4, v0
	s_and_b32 s1, s0, s1
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v4, v0, v4 :: v_dual_lshlrev_b32 v3, 2, v3
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v2, 2, v1
	ds_bpermute_b32 v1, v2, v37
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v37, v1
	ds_bpermute_b32 v5, v3, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v5
	v_xor_b32_e32 v5, 2, v0
	ds_bpermute_b32 v6, v4, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v5, 2, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v6
	v_xor_b32_e32 v6, 1, v0
	ds_bpermute_b32 v7, v5, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v77
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_add_f32 v7, v1, v7 :: v_dual_lshlrev_b32 v6, 2, v0
	v_lshlrev_b64_e32 v[0:1], 1, v[67:68]
	ds_bpermute_b32 v8, v6, v7
	v_add_co_u32 v0, s2, s12, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v1, null, s13, v1, s2
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s2, s1
	s_cbranch_execz .LBB69_127
; %bb.122:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s14, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e64 s0, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s3, s0
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s3
; %bb.123:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.124:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.125:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.126:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	global_store_b16 v[0:1], v7, off
.LBB69_127:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	ds_bpermute_b32 v7, v2, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v35, v7
	ds_bpermute_b32 v8, v3, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v4, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v5, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v6, v7
	s_and_saveexec_b32 s2, s1
	s_cbranch_execz .LBB69_133
; %bb.128:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s14, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e64 s0, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s1, s0
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s1
; %bb.129:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.130:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.131:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.132:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshl_b64 s[0:1], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v8, s0, v0, s0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v9, null, s1, v1, s0
	global_store_b16 v[8:9], v7, off
.LBB69_133:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	ds_bpermute_b32 v7, v2, v34
	v_cmp_gt_i64_e64 s0, s[10:11], v[65:66]
	s_xor_b32 s1, vcc_lo, -1
	s_wait_alu 0xfffe
	s_and_b32 s0, s1, s0
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v34, v7
	ds_bpermute_b32 v8, v3, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v4, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v5, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v6, v7
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s0
	s_cbranch_execz .LBB69_139
; %bb.134:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s14, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s2, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s2, exec_lo, s2
; %bb.135:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.136:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s2, s2
; %bb.137:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.138:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	global_store_b16 v[0:1], v7, off offset:2
.LBB69_139:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	ds_bpermute_b32 v2, v2, v33
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v33, v2
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v6, v2
	s_and_b32 exec_lo, exec_lo, s0
	s_cbranch_execz .LBB69_145
; %bb.140:
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, 0x47800000, v2
	v_mul_f32_e32 v3, s14, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.141:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.142:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.143:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.144:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshl_b64 s[0:1], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v0, vcc_lo, v0, s0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo
	global_store_b16 v[0:1], v2, off offset:2
.LBB69_145:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 296
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 143
		.amdhsa_next_free_sgpr 25
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 216
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,"axG",@progbits,_ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,comdat
.Lfunc_end69:
