_ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii: ; @_ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
; %bb.0:
	s_clause 0x2
	s_load_b64 s[16:17], s[0:1], 0x20
	s_load_b32 s3, s[0:1], 0x34
	s_load_b128 s[12:15], s[0:1], 0x0
	s_mov_b32 s2, ttmp9
	s_load_b64 s[6:7], s[0:1], 0x10
	v_and_b32_e32 v71, 31, v0
	s_wait_kmcnt 0x0
	s_ashr_i32 s20, s17, 31
	s_and_b32 s18, s3, 0xffff
	s_lshr_b32 s4, s20, 30
	s_ashr_i32 s11, s16, 31
	s_add_co_i32 s3, s17, s4
	s_mov_b32 s10, s16
	s_ashr_i32 s19, s3, 2
	s_mov_b32 s3, 0
	v_cmp_gt_i32_e64 s5, s19, v0
	s_lshl_b64 s[8:9], s[2:3], 4
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mov_b32 v66, s9 :: v_dual_add_nc_u32 v41, s18, v0
	v_cndmask_b32_e64 v1, 0, v0, s5
	v_cmp_gt_i32_e64 s4, s19, v41
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v1, 4, v1
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v2, 0, v41, s4
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v2, 4, v2
	s_clause 0x1
	global_load_b128 v[37:40], v1, s[12:13]
	global_load_b128 v[33:36], v2, s[12:13]
	v_lshrrev_b32_e32 v1, 4, v0
	v_mov_b32_e32 v2, s9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_and_or_b32 v65, v1, 14, s8
	s_lshr_b32 s8, s20, 28
	s_wait_alu 0xfffe
	s_add_co_i32 s8, s17, s8
	v_or_b32_e32 v1, 1, v65
	v_cmp_gt_i64_e64 s3, s[10:11], v[65:66]
	s_wait_alu 0xfffe
	s_ashr_i32 s16, s8, 4
	v_cmp_gt_i64_e64 s2, s[10:11], v[1:2]
	v_cndmask_b32_e64 v3, 0, v65, s3
	v_cndmask_b32_e64 v2, 0, s9, s3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cndmask_b32_e64 v1, 0, v1, s2
	v_mul_lo_u32 v4, v3, s20
	v_mad_co_u64_u32 v[67:68], null, v3, s17, s[14:15]
	v_cndmask_b32_e64 v3, 0, s9, s2
	v_mul_lo_u32 v2, v2, s17
	v_mul_lo_u32 v5, v1, s20
	v_mad_co_u64_u32 v[69:70], null, v1, s17, s[14:15]
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_lo_u32 v1, v3, s17
	v_add3_u32 v68, v2, v68, v4
	s_delay_alu instid0(VALU_DEP_2)
	v_add3_u32 v70, v1, v70, v5
	; sched_barrier mask(0x00000000)
	v_cmp_gt_i32_e32 vcc_lo, s16, v71
	v_or_b32_e32 v2, 32, v71
	v_or_b32_e32 v9, 64, v71
	v_or_b32_e32 v15, 0x60, v71
	v_dual_mov_b32 v42, 0 :: v_dual_cndmask_b32 v1, 0, v71
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s16, v2
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v4, 0, v2 :: v_dual_lshlrev_b32 v3, 4, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_u32 v1, vcc_lo, v67, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v68, vcc_lo
	v_add_co_u32 v5, vcc_lo, v69, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v70, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v9
	v_lshlrev_b32_e32 v11, 4, v4
	s_clause 0x1
	global_load_b128 v[1:4], v[1:2], off th:TH_LOAD_NT
	global_load_b128 v[5:8], v[5:6], off th:TH_LOAD_NT
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v12, 0, v9, vcc_lo
	v_add_co_u32 v9, vcc_lo, v67, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, 0, v68, vcc_lo
	v_add_co_u32 v13, vcc_lo, v69, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v14, null, 0, v70, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v15
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v11, 0, v15 :: v_dual_lshlrev_b32 v12, 4, v12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_add_co_u32 v17, vcc_lo, v67, v12
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, 0, v68, vcc_lo
	v_lshlrev_b32_e32 v11, 4, v11
	v_add_co_u32 v21, vcc_lo, v69, v12
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v22, null, 0, v70, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_u32 v25, vcc_lo, v67, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, 0, v68, vcc_lo
	v_add_co_u32 v29, vcc_lo, v69, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v30, null, 0, v70, vcc_lo
	s_clause 0x5
	global_load_b128 v[9:12], v[9:10], off th:TH_LOAD_NT
	global_load_b128 v[13:16], v[13:14], off th:TH_LOAD_NT
	global_load_b128 v[17:20], v[17:18], off th:TH_LOAD_NT
	global_load_b128 v[21:24], v[21:22], off th:TH_LOAD_NT
	global_load_b128 v[25:28], v[25:26], off th:TH_LOAD_NT
	global_load_b128 v[29:32], v[29:30], off th:TH_LOAD_NT
	s_load_b64 s[14:15], s[6:7], 0x0
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s15, 0
	s_cselect_b32 s21, -1, 0
	s_cmp_ngt_f32 s15, 0
	s_cselect_b32 s20, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s20
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB69_14
; %bb.1:
	s_and_saveexec_b32 s6, s5
	s_cbranch_execnz .LBB69_15
.LBB69_2:
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s21
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB69_16
.LBB69_3:
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB69_5
.LBB69_4:
	s_wait_loadcnt 0x9
	v_lshl_add_u32 v37, v41, 4, 0
	s_wait_loadcnt 0x8
	ds_store_b128 v37, v[33:36]
.LBB69_5:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_load_b64 s[6:7], s[0:1], 0x18
	s_wait_loadcnt 0x9
	v_add_nc_u32_e32 v39, s18, v41
	s_mov_b32 s8, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s19, v39
	s_cbranch_execz .LBB69_10
; %bb.6:
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v33, 4, v39
	v_lshlrev_b32_e32 v0, 4, v0
	s_lshl_b32 s0, s18, 5
	s_mov_b32 s9, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_co_u32 v33, s1, s12, v33
	v_add_co_ci_u32_e64 v34, null, s13, 0, s1
	v_add3_u32 v0, 0, s0, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_u32 v37, vcc_lo, v33, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, 0, v34, vcc_lo
	s_lshl_b32 s12, s18, 4
	s_mov_b32 s13, 0xc3e00000
	s_branch .LBB69_8
.LBB69_7:                               ;   in Loop: Header=BB69_8 Depth=1
	v_add_nc_u32_e32 v39, s18, v39
	v_add_co_u32 v37, s0, v37, s12
	s_wait_loadcnt 0x0
	ds_store_b128 v0, v[33:36]
	v_add_nc_u32_e32 v0, s12, v0
	v_cmp_le_i32_e32 vcc_lo, s19, v39
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v38, s0
	s_or_b32 s9, vcc_lo, s9
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s9
	s_cbranch_execz .LBB69_10
.LBB69_8:                               ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[33:36], v[37:38], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s21
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB69_7
; %bb.9:                                ;   in Loop: Header=BB69_8 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v43, 16, v34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_div_scale_f32 v54, s1, v43, s15, v43
	v_lshlrev_b32_e32 v40, 16, v33
	v_and_b32_e32 v33, 0xffff0000, v33
	v_div_scale_f32 v47, null, s15, s15, v43
	v_div_scale_f32 v41, null, s15, s15, v40
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_scale_f32 v42, null, s15, s15, v33
	v_rcp_f32_e32 v50, v47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v45, v41
	v_div_scale_f32 v49, vcc_lo, v40, s15, v40
	v_rcp_f32_e32 v46, v42
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v51, -v41, v45, 1.0
	v_and_b32_e32 v34, 0xffff0000, v34
	v_fma_f32 v52, -v42, v46, 1.0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v45, v51, v45 :: v_dual_lshlrev_b32 v44, 16, v35
	v_div_scale_f32 v51, null, s15, s15, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v46, v52, v46
	v_div_scale_f32 v53, s0, v33, s15, v33
	v_fma_f32 v52, -v47, v50, 1.0
	v_mul_f32_e32 v55, v49, v45
	v_dual_mul_f32 v56, v53, v46 :: v_dual_and_b32 v35, 0xffff0000, v35
	v_div_scale_f32 v57, null, s15, s15, v44
	s_delay_alu instid0(VALU_DEP_3)
	v_fma_f32 v59, -v41, v55, v49
	v_fmac_f32_e32 v50, v52, v50
	v_lshlrev_b32_e32 v48, 16, v36
	v_fma_f32 v52, -v42, v56, v53
	v_rcp_f32_e32 v58, v51
	v_fmac_f32_e32 v55, v59, v45
	v_mul_f32_e32 v59, v54, v50
	v_div_scale_f32 v60, s4, v34, s15, v34
	v_fmac_f32_e32 v56, v52, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v41, -v41, v55, v49
	v_fma_f32 v49, -v47, v59, v54
	v_and_b32_e32 v36, 0xffff0000, v36
	v_rcp_f32_e32 v52, v57
	v_fma_f32 v42, -v42, v56, v53
	s_wait_alu 0xfffd
	v_div_fmas_f32 v41, v41, v45, v55
	v_div_scale_f32 v45, null, s15, s15, v35
	v_fmac_f32_e32 v59, v49, v50
	s_mov_b32 vcc_lo, s0
	s_delay_alu instid0(VALU_DEP_3)
	v_div_fixup_f32 v40, v41, s15, v40
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v46, v56
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v46, -v47, v59, v54
	v_rcp_f32_e32 v47, v45
	v_fma_f32 v41, -v57, v52, 1.0
	v_fma_f32 v61, -v51, v58, 1.0
	v_div_fixup_f32 v33, v42, s15, v33
	v_div_scale_f32 v55, null, s15, s15, v36
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v52, v41, v52
	v_div_scale_f32 v41, s0, v44, s15, v44
	v_med3_num_f32 v40, v40, s13, 0x43e00000
	v_fma_f32 v53, -v45, v47, 1.0
	v_med3_num_f32 v33, v33, s13, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v47, v53, v47
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v46, v50, v59
	s_mov_b32 vcc_lo, s4
	v_div_scale_f32 v50, null, s15, s15, v48
	v_div_scale_f32 v53, s1, v35, s15, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v43, v46, s15, v43
	v_mul_f32_e32 v46, v41, v52
	v_rcp_f32_e32 v54, v50
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v43, v43, s13, 0x43e00000
	v_fma_f32 v59, -v57, v46, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v46, v59, v52
	v_div_scale_f32 v59, s4, v36, s15, v36
	v_fmac_f32_e32 v58, v61, v58
	v_fma_f32 v56, -v50, v54, 1.0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v41, -v57, v46, v41
	v_mul_f32_e32 v42, v60, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v54, v56, v54
	v_div_scale_f32 v56, s5, v48, s15, v48
	v_fma_f32 v49, -v51, v42, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v42, v49, v58
	v_rcp_f32_e32 v49, v55
	v_fma_f32 v51, -v51, v42, v60
	v_mul_f32_e32 v60, v53, v47
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fmas_f32 v42, v51, v58, v42
	v_fma_f32 v51, -v45, v60, v53
	v_mul_f32_e32 v58, v56, v54
	s_delay_alu instid0(TRANS32_DEP_1)
	v_fma_f32 v61, -v55, v49, 1.0
	s_mov_b32 vcc_lo, s0
	v_div_fixup_f32 v34, v42, s15, v34
	v_fmac_f32_e32 v60, v51, v47
	v_fma_f32 v42, -v50, v58, v56
	v_fmac_f32_e32 v49, v61, v49
	s_wait_alu 0xfffe
	v_div_fmas_f32 v41, v41, v52, v46
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v45, -v45, v60, v53
	v_dual_fmac_f32 v58, v42, v54 :: v_dual_mul_f32 v51, v59, v49
	v_med3_num_f32 v34, v34, s13, 0x43e00000
	v_div_fixup_f32 v41, v41, s15, v44
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v45, v47, v60
	v_mov_b32_e32 v45, 0
	v_fma_f32 v46, -v55, v51, v59
	v_fma_f32 v44, -v50, v58, v56
	v_med3_num_f32 v41, v41, s13, 0x43e00000
	v_div_fixup_f32 v35, v42, s15, v35
	v_cvt_pk_fp8_f32 v45, v40, v33
	v_mov_b32_e32 v33, 0
	v_fmac_f32_e32 v51, v46, v49
	s_mov_b32 vcc_lo, s5
	v_med3_num_f32 v35, v35, s13, 0x43e00000
	v_cvt_pk_fp8_f32 v45, v43, v34 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v42, -v55, v51, v59
	v_cvt_pk_fp8_f32 v33, v41, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_perm_b32 v35, 0, v45, 0x30c020c
	v_perm_b32 v34, 0, v45, 0x10c000c
	v_lshrrev_b32_e32 v41, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	s_wait_alu 0xfffe
	v_div_fmas_f32 v44, v44, v54, v58
	s_mov_b32 vcc_lo, s4
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v49, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fixup_f32 v44, v44, s15, v48
	v_div_fixup_f32 v36, v42, s15, v36
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v40, v44, s13, 0x43e00000
	v_med3_num_f32 v36, v36, s13, 0x43e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v33, v40, v36 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v36, 1, v34
	v_and_b32_e32 v34, 0x80008000, v34
	v_perm_b32 v40, 0, v33, 0x10c000c
	v_perm_b32 v33, 0, v33, 0x30c020c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v42, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_lshrrev_b32_e32 v43, 1, v33
	v_and_b32_e32 v44, 0x80008000, v33
	v_and_or_b32 v33, 0x3f803f80, v36, v34
	v_and_or_b32 v34, 0x3f803f80, v41, v35
	v_and_or_b32 v35, 0x3f803f80, v42, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v36, 0x3f803f80, v43, v44
	s_branch .LBB69_7
.LBB69_10:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s0, s3
	s_cbranch_execz .LBB69_91
; %bb.11:
	s_and_b32 s0, s21, exec_lo
	s_cselect_b32 s0, s15, 1.0
	s_add_co_i32 s1, s16, 31
	s_mov_b32 s5, -1
	s_wait_alu 0xfffe
	s_ashr_i32 s3, s1, 31
	s_wait_alu 0xfffe
	s_lshr_b32 s3, s3, 27
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, s3
	s_wait_alu 0xfffe
	s_ashr_i32 s1, s1, 5
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, 3
	s_wait_alu 0xfffe
	s_lshr_b32 s3, s1, 30
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, s3
	s_wait_alu 0xfffe
	s_ashr_i32 s3, s1, 2
	s_cmp_gt_i32 s17, 15
	s_mul_f32 s1, s14, s0
	s_cselect_b32 s4, -1, 0
	s_and_b32 vcc_lo, exec_lo, s20
	s_wait_alu 0xfffe
	v_cndmask_b32_e64 v0, 0, 1, s4
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_ne_u32_e64 s0, 1, v0
	s_cbranch_vccz .LBB69_53
; %bb.12:
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v73, 0
	v_mov_b32_e32 v72, 0
	v_mov_b32_e32 v0, 0
	s_and_b32 vcc_lo, exec_lo, s0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB69_28
; %bb.13:
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v73, 0
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v41, v9
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v35, v3
	v_dual_mov_b32 v36, v4 :: v_dual_mov_b32 v33, v1
	v_dual_mov_b32 v34, v2 :: v_dual_mov_b32 v43, v11
	v_dual_mov_b32 v42, v10 :: v_dual_mov_b32 v45, v17
	v_dual_mov_b32 v44, v12 :: v_dual_mov_b32 v47, v19
	v_dual_mov_b32 v46, v18 :: v_dual_mov_b32 v49, v25
	v_dual_mov_b32 v48, v20 :: v_dual_mov_b32 v51, v27
	v_dual_mov_b32 v50, v26 :: v_dual_mov_b32 v37, v5
	v_dual_mov_b32 v52, v28 :: v_dual_mov_b32 v39, v7
	v_dual_mov_b32 v38, v6 :: v_dual_mov_b32 v53, v13
	v_dual_mov_b32 v40, v8 :: v_dual_mov_b32 v55, v15
	v_dual_mov_b32 v54, v14 :: v_dual_mov_b32 v57, v21
	v_dual_mov_b32 v56, v16 :: v_dual_mov_b32 v59, v23
	v_dual_mov_b32 v58, v22 :: v_dual_mov_b32 v61, v29
	v_dual_mov_b32 v60, v24 :: v_dual_mov_b32 v63, v31
	v_mov_b32_e32 v62, v30
	v_mov_b32_e32 v64, v32
	s_max_i32 s0, s3, 1
	s_mov_b32 s5, 0
	s_wait_alu 0xfffe
	s_lshl_b32 s0, s0, 7
	s_branch .LBB69_21
.LBB69_14:
	s_wait_loadcnt 0x9
	v_lshlrev_b32_e32 v44, 16, v38
	v_lshlrev_b32_e32 v43, 16, v37
	s_mov_b32 s22, 0xc3e00000
	v_lshlrev_b32_e32 v62, 16, v40
	v_and_b32_e32 v40, 0xffff0000, v40
	v_div_scale_f32 v47, null, s15, s15, v44
	v_div_scale_f32 v45, null, s15, s15, v43
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_rcp_f32_e32 v50, v47
	v_rcp_f32_e32 v48, v45
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v57, -v47, v50, 1.0
	v_and_b32_e32 v37, 0xffff0000, v37
	v_fma_f32 v54, -v45, v48, 1.0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v50, v57, v50
	v_div_scale_f32 v46, null, s15, s15, v37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v48, v54, v48
	v_div_scale_f32 v52, vcc_lo, v43, s15, v43
	v_rcp_f32_e32 v49, v46
	v_and_b32_e32 v38, 0xffff0000, v38
	v_div_scale_f32 v53, s6, v37, s15, v37
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v55, -v46, v49, 1.0
	v_fmac_f32_e32 v49, v55, v49
	v_div_scale_f32 v56, s7, v44, s15, v44
	v_mul_f32_e32 v55, v52, v48
	v_div_scale_f32 v54, null, s15, s15, v38
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v59, v56, v50
	v_mul_f32_e32 v57, v53, v49
	v_fma_f32 v60, -v45, v55, v52
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_rcp_f32_e32 v58, v54
	v_fma_f32 v63, -v47, v59, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v61, -v46, v57, v53
	v_fmac_f32_e32 v55, v60, v48
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v59, v63, v50
	v_fma_f32 v45, -v45, v55, v52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_fma_f32 v60, -v54, v58, 1.0
	v_lshlrev_b32_e32 v51, 16, v39
	v_fma_f32 v47, -v47, v59, v56
	v_div_scale_f32 v52, s8, v38, s15, v38
	s_wait_alu 0xfffd
	v_div_fmas_f32 v45, v45, v48, v55
	s_mov_b32 vcc_lo, s6
	v_fmac_f32_e32 v58, v60, v58
	v_div_scale_f32 v56, s6, v51, s15, v51
	v_fmac_f32_e32 v57, v61, v49
	v_div_fixup_f32 v43, v45, s15, v43
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v46, -v46, v57, v53
	v_div_scale_f32 v53, null, s15, s15, v51
	v_med3_num_f32 v43, v43, s22, 0x43e00000
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fmas_f32 v46, v46, v49, v57
	v_rcp_f32_e32 v48, v53
	s_mov_b32 vcc_lo, s7
	v_div_scale_f32 v57, null, s15, s15, v40
	s_delay_alu instid0(VALU_DEP_2)
	v_div_fixup_f32 v37, v46, s15, v37
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v47, v50, v59
	v_div_scale_f32 v50, null, s15, s15, v62
	v_rcp_f32_e32 v60, v57
	s_mov_b32 vcc_lo, s8
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_fma_f32 v47, -v53, v48, 1.0
	v_and_b32_e32 v39, 0xffff0000, v39
	v_div_fixup_f32 v44, v46, s15, v44
	v_med3_num_f32 v37, v37, s22, 0x43e00000
	v_fmac_f32_e32 v48, v47, v48
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)
	v_div_scale_f32 v49, null, s15, s15, v39
	v_rcp_f32_e32 v47, v50
	v_fma_f32 v63, -v57, v60, 1.0
	v_med3_num_f32 v44, v44, s22, 0x43e00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v55, v49
	v_fmac_f32_e32 v60, v63, v60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v59, -v49, v55, 1.0
	v_fmac_f32_e32 v55, v59, v55
	v_div_scale_f32 v59, s7, v39, s15, v39
	v_mul_f32_e32 v45, v52, v58
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v46, -v54, v45, v52
	v_dual_fmac_f32 v45, v46, v58 :: v_dual_mul_f32 v46, v56, v48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v52, -v54, v45, v52
	v_fma_f32 v54, -v50, v47, 1.0
	v_fma_f32 v61, -v53, v46, v56
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fmas_f32 v45, v52, v58, v45
	v_fmac_f32_e32 v47, v54, v47
	v_div_scale_f32 v54, s9, v62, s15, v62
	v_fmac_f32_e32 v46, v61, v48
	v_mul_f32_e32 v52, v59, v55
	v_div_scale_f32 v61, s8, v40, s15, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v58, v54, v47
	v_div_fixup_f32 v38, v45, s15, v38
	v_fma_f32 v45, -v53, v46, v56
	v_fma_f32 v53, -v49, v52, v59
	s_mov_b32 vcc_lo, s6
	v_fma_f32 v56, -v50, v58, v54
	v_mul_f32_e32 v63, v61, v60
	s_wait_alu 0xfffe
	v_div_fmas_f32 v45, v45, v48, v46
	s_mov_b32 vcc_lo, s7
	v_med3_num_f32 v38, v38, s22, 0x43e00000
	v_fmac_f32_e32 v58, v56, v47
	v_fma_f32 v46, -v57, v63, v61
	v_fmac_f32_e32 v52, v53, v55
	v_div_fixup_f32 v45, v45, s15, v51
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v63, v46, v60
	v_fma_f32 v48, -v49, v52, v59
	v_fma_f32 v46, -v50, v58, v54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_med3_num_f32 v45, v45, s22, 0x43e00000
	v_fma_f32 v49, -v57, v63, v61
	s_wait_alu 0xfffe
	v_div_fmas_f32 v48, v48, v55, v52
	s_mov_b32 vcc_lo, s9
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v46, v47, v58
	s_mov_b32 vcc_lo, s8
	v_div_fixup_f32 v39, v48, s15, v39
	s_wait_alu 0xfffe
	v_div_fmas_f32 v47, v49, v60, v63
	v_mov_b32_e32 v49, 0
	v_div_fixup_f32 v46, v46, s15, v62
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fixup_f32 v40, v47, s15, v40
	v_cvt_pk_fp8_f32 v49, v43, v37
	v_med3_num_f32 v37, v39, s22, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_med3_num_f32 v39, v46, s22, 0x43e00000
	v_med3_num_f32 v40, v40, s22, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_pk_fp8_f32 v49, v44, v38 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v42, v45, v37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_perm_b32 v37, 0, v49, 0x10c000c
	v_cvt_pk_fp8_f32 v42, v39, v40 op_sel:[0,0,1]
	v_perm_b32 v38, 0, v49, 0x30c020c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v39, 1, v37
	v_perm_b32 v40, 0, v42, 0x10c000c
	v_perm_b32 v42, 0, v42, 0x30c020c
	v_and_b32_e32 v37, 0x80008000, v37
	v_lshrrev_b32_e32 v43, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_lshrrev_b32_e32 v44, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_lshrrev_b32_e32 v45, 1, v42
	v_and_b32_e32 v42, 0x80008000, v42
	v_and_or_b32 v37, 0x3f803f80, v39, v37
	v_and_or_b32 v38, 0x3f803f80, v43, v38
	v_and_or_b32 v39, 0x3f803f80, v44, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v40, 0x3f803f80, v45, v42
	s_and_saveexec_b32 s6, s5
	s_cbranch_execz .LBB69_2
.LBB69_15:
	v_lshl_add_u32 v42, v0, 4, 0
	s_wait_loadcnt 0x9
	ds_store_b128 v42, v[37:40]
	s_or_b32 exec_lo, exec_lo, s6
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s21
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB69_3
.LBB69_16:
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v37, 16, v33
	v_lshlrev_b32_e32 v44, 16, v35
	s_mov_b32 s9, 0xc3e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v38, null, s15, s15, v37
	v_rcp_f32_e32 v42, v38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v48, -v38, v42, 1.0
	v_fmac_f32_e32 v42, v48, v42
	v_div_scale_f32 v50, vcc_lo, v37, s15, v37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v52, v50, v42 :: v_dual_and_b32 v33, 0xffff0000, v33
	v_div_scale_f32 v39, null, s15, s15, v33
	v_div_scale_f32 v51, s5, v33, s15, v33
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v43, v39
	v_fma_f32 v49, -v39, v43, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v43, v49, v43 :: v_dual_lshlrev_b32 v40, 16, v34
	v_div_scale_f32 v45, null, s15, s15, v40
	v_and_b32_e32 v34, 0xffff0000, v34
	v_div_scale_f32 v54, s6, v40, s15, v40
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_rcp_f32_e32 v47, v45
	v_mul_f32_e32 v53, v51, v43
	v_div_scale_f32 v48, null, s15, s15, v34
	v_div_scale_f32 v57, s7, v34, s15, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v56, -v39, v53, v51
	v_rcp_f32_e32 v55, v48
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v49, -v45, v47, 1.0
	v_lshlrev_b32_e32 v46, 16, v36
	v_dual_fmac_f32 v53, v56, v43 :: v_dual_and_b32 v36, 0xffff0000, v36
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v47, v49, v47
	v_fma_f32 v49, -v38, v52, v50
	v_and_b32_e32 v35, 0xffff0000, v35
	v_fma_f32 v39, -v39, v53, v51
	v_div_scale_f32 v51, null, s15, s15, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v49, v42
	v_div_scale_f32 v49, null, s15, s15, v44
	v_fma_f32 v56, -v48, v55, 1.0
	v_fma_f32 v38, -v38, v52, v50
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_div_fmas_f32 v38, v38, v42, v52
	s_mov_b32 vcc_lo, s5
	v_rcp_f32_e32 v42, v49
	s_wait_alu 0xfffe
	v_div_fmas_f32 v39, v39, v43, v53
	v_rcp_f32_e32 v53, v51
	v_fmac_f32_e32 v55, v56, v55
	v_div_fixup_f32 v37, v38, s15, v37
	v_div_scale_f32 v38, null, s15, s15, v35
	v_div_fixup_f32 v33, v39, s15, v33
	s_mov_b32 vcc_lo, s6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_med3_num_f32 v37, v37, s9, 0x43e00000
	v_fma_f32 v56, -v51, v53, 1.0
	v_mul_f32_e32 v58, v54, v47
	v_med3_num_f32 v33, v33, s9, 0x43e00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v53, v56, v53
	v_fma_f32 v50, -v45, v58, v54
	v_div_scale_f32 v56, s8, v46, s15, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v58, v50, v47
	v_rcp_f32_e32 v50, v38
	v_fma_f32 v43, -v45, v58, v54
	v_fma_f32 v45, -v49, v42, 1.0
	v_div_scale_f32 v54, null, s15, s15, v36
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fmas_f32 v43, v43, v47, v58
	v_fmac_f32_e32 v42, v45, v42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_fma_f32 v52, -v38, v50, 1.0
	v_mul_f32_e32 v39, v57, v55
	v_div_scale_f32 v45, s5, v44, s15, v44
	v_div_fixup_f32 v40, v43, s15, v40
	v_fmac_f32_e32 v50, v52, v50
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fma_f32 v47, -v48, v39, v57
	v_div_scale_f32 v52, s6, v35, s15, v35
	v_mul_f32_e32 v43, v45, v42
	s_mov_b32 vcc_lo, s7
	v_dual_fmac_f32 v39, v47, v55 :: v_dual_mul_f32 v58, v52, v50
	v_rcp_f32_e32 v47, v54
	v_med3_num_f32 v40, v40, s9, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v48, -v48, v39, v57
	v_fma_f32 v57, -v49, v43, v45
	s_wait_alu 0xfffe
	v_div_fmas_f32 v39, v48, v55, v39
	v_fma_f32 v48, -v38, v58, v52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fma_f32 v59, -v54, v47, 1.0
	v_fmac_f32_e32 v43, v57, v42
	v_div_scale_f32 v57, s7, v36, s15, v36
	v_dual_fmac_f32 v58, v48, v50 :: v_dual_fmac_f32 v47, v59, v47
	v_mul_f32_e32 v55, v56, v53
	v_div_fixup_f32 v34, v39, s15, v34
	v_fma_f32 v39, -v49, v43, v45
	s_mov_b32 vcc_lo, s5
	v_mul_f32_e32 v48, v57, v47
	v_fma_f32 v45, -v51, v55, v56
	v_fma_f32 v38, -v38, v58, v52
	s_wait_alu 0xfffe
	v_div_fmas_f32 v39, v39, v42, v43
	s_mov_b32 vcc_lo, s6
	v_fma_f32 v42, -v54, v48, v57
	v_fmac_f32_e32 v55, v45, v53
	s_wait_alu 0xfffe
	v_div_fmas_f32 v38, v38, v50, v58
	s_mov_b32 vcc_lo, s8
	v_div_fixup_f32 v39, v39, s15, v44
	v_fmac_f32_e32 v48, v42, v47
	v_fma_f32 v42, -v51, v55, v56
	v_div_fixup_f32 v35, v38, s15, v35
	v_mov_b32_e32 v43, 0
	v_med3_num_f32 v39, v39, s9, 0x43e00000
	v_fma_f32 v38, -v54, v48, v57
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v53, v55
	s_mov_b32 vcc_lo, s7
	v_med3_num_f32 v35, v35, s9, 0x43e00000
	v_cvt_pk_fp8_f32 v43, v37, v33
	s_wait_alu 0xfffe
	v_div_fmas_f32 v38, v38, v47, v48
	v_div_fixup_f32 v42, v42, s15, v46
	v_mov_b32_e32 v33, 0
	v_med3_num_f32 v34, v34, s9, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v36, v38, s15, v36
	v_med3_num_f32 v37, v42, s9, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_pk_fp8_f32 v33, v39, v35
	v_cvt_pk_fp8_f32 v43, v40, v34 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v36, v36, s9, 0x43e00000
	v_perm_b32 v34, 0, v43, 0x10c000c
	v_perm_b32 v35, 0, v43, 0x30c020c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v33, v37, v36 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v36, 1, v34
	v_and_b32_e32 v34, 0x80008000, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_perm_b32 v37, 0, v33, 0x10c000c
	v_perm_b32 v33, 0, v33, 0x30c020c
	v_lshrrev_b32_e32 v38, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	v_lshrrev_b32_e32 v39, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	v_lshrrev_b32_e32 v40, 1, v33
	v_and_b32_e32 v42, 0x80008000, v33
	v_and_or_b32 v33, 0x3f803f80, v36, v34
	v_and_or_b32 v34, 0x3f803f80, v38, v35
	v_and_or_b32 v35, 0x3f803f80, v39, v37
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v36, 0x3f803f80, v40, v42
	s_and_saveexec_b32 s5, s4
	s_cbranch_execnz .LBB69_4
	s_branch .LBB69_5
.LBB69_17:                              ;   in Loop: Header=BB69_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
.LBB69_18:                              ;   in Loop: Header=BB69_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
.LBB69_19:                              ;   in Loop: Header=BB69_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
.LBB69_20:                              ;   in Loop: Header=BB69_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	s_addk_co_i32 s5, 0x80
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s0, s5
	s_cbranch_scc0 .LBB69_28
.LBB69_21:                              ; =>This Inner Loop Header: Depth=1
	s_cmp_eq_u32 s5, 0
	s_mov_b32 s8, 0
	s_cbranch_scc1 .LBB69_23
; %bb.22:                               ;   in Loop: Header=BB69_21 Depth=1
	s_wait_loadcnt 0x5
	v_add_nc_u32_e32 v42, s5, v71
	s_mov_b32 s8, s5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s16, v42
	v_add_nc_u32_e32 v35, 32, v42
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v33, 0, v42, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v35
	v_add_nc_u32_e32 v36, 64, v42
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_ashrrev_i32_e32 v34, 31, v33
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v35, 0, v35, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v36
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[33:34], 4, v[33:34]
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v41, 0, v36, vcc_lo
	v_ashrrev_i32_e32 v36, 31, v35
	s_wait_loadcnt 0x3
	v_add_nc_u32_e32 v47, 0x60, v42
	v_add_co_u32 v37, vcc_lo, v67, v33
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[43:44], 4, v[35:36]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, v68, v34, vcc_lo
	v_add_co_u32 v39, vcc_lo, v69, v33
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v40, null, v70, v34, vcc_lo
	v_add_co_u32 v45, vcc_lo, v67, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v46, null, v68, v44, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v47
	v_ashrrev_i32_e32 v42, 31, v41
	s_clause 0x1
	global_load_b128 v[33:36], v[37:38], off th:TH_LOAD_NT
	global_load_b128 v[37:40], v[39:40], off th:TH_LOAD_NT
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v47, 0, v47, vcc_lo
	v_lshlrev_b64_e32 v[41:42], 4, v[41:42]
	s_wait_loadcnt 0x3
	v_add_co_u32 v49, vcc_lo, v69, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v50, null, v70, v44, vcc_lo
	v_ashrrev_i32_e32 v48, 31, v47
	v_add_co_u32 v51, vcc_lo, v67, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v52, null, v68, v42, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshlrev_b64_e32 v[43:44], 4, v[47:48]
	v_add_co_u32 v57, vcc_lo, v69, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v58, null, v70, v42, vcc_lo
	s_wait_loadcnt 0x2
	v_add_co_u32 v61, vcc_lo, v67, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v62, null, v68, v44, vcc_lo
	v_add_co_u32 v63, vcc_lo, v69, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v64, null, v70, v44, vcc_lo
	s_clause 0x5
	global_load_b128 v[41:44], v[45:46], off th:TH_LOAD_NT
	global_load_b128 v[53:56], v[49:50], off th:TH_LOAD_NT
	global_load_b128 v[45:48], v[51:52], off th:TH_LOAD_NT
	global_load_b128 v[57:60], v[57:58], off th:TH_LOAD_NT
	global_load_b128 v[49:52], v[61:62], off th:TH_LOAD_NT
	global_load_b128 v[61:64], v[63:64], off th:TH_LOAD_NT
.LBB69_23:                              ;   in Loop: Header=BB69_21 Depth=1
	s_wait_alu 0xfffe
	v_or_b32_e32 v75, s8, v71
	s_mov_b32 s8, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s16, v75
	s_cbranch_execz .LBB69_20
; %bb.24:                               ;   in Loop: Header=BB69_21 Depth=1
	v_lshl_add_u32 v80, v75, 5, 0
	s_wait_loadcnt 0x7
	v_and_b32_e32 v83, 7, v33
	v_bfe_u32 v124, v36, 8, 3
	v_bfe_u32 v117, v34, 8, 7
	v_bfe_u32 v121, v35, 8, 3
	ds_load_b128 v[76:79], v80
	ds_load_b128 v[103:106], v80 offset:16
	v_lshl_add_u32 v80, s17, 1, v80
	v_cvt_f32_ubyte0_e32 v87, v83
	v_cvt_f32_ubyte0_e32 v124, v124
	v_bfe_u32 v123, v35, 24, 7
	ds_load_b128 v[108:111], v80
	ds_load_b128 v[112:115], v80 offset:16
	s_wait_loadcnt 0x6
	v_bfe_u32 v127, v39, 24, 3
	v_lshlrev_b32_e32 v126, 24, v39
	s_mov_b32 s9, exec_lo
	v_lshlrev_b32_e32 v125, 24, v36
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v127, v127
	s_wait_dscnt 0x3
	v_dual_mul_f32 v127, 0x3b000000, v127 :: v_dual_lshlrev_b32 v100, 16, v77
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v84, 16, v103
	v_and_b32_e32 v82, 0xffff0000, v103
	v_lshlrev_b32_e32 v81, 16, v104
	v_and_b32_e32 v80, 0xffff0000, v104
	v_and_b32_e32 v98, 0xffff0000, v77
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v104, 16, v109
	v_and_b32_e32 v103, 0xffff0000, v109
	v_bfe_u32 v109, v33, 8, 3
	v_and_b32_e32 v94, 0xffff0000, v78
	v_lshlrev_b32_e32 v91, 16, v79
	v_and_b32_e32 v88, 0xffff0000, v79
	v_lshlrev_b32_e32 v79, 16, v105
	v_cvt_f32_ubyte0_e32 v109, v109
	v_lshlrev_b32_e32 v96, 16, v78
	v_lshlrev_b32_e32 v77, 16, v106
	v_and_b32_e32 v99, 0xffff0000, v110
	v_lshlrev_b32_e32 v97, 16, v111
	v_and_b32_e32 v95, 0xffff0000, v111
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v85, 16, v114
	v_mul_f32_e32 v111, 0x3b000000, v87
	v_lshlrev_b32_e32 v107, 16, v76
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_and_b32_e32 v102, 0xffff0000, v76
	v_and_b32_e32 v76, 0xffff0000, v106
	v_lshlrev_b32_e32 v106, 16, v108
	v_mul_f32_e32 v124, 0x3b000000, v124
	v_and_b32_e32 v78, 0xffff0000, v105
	v_and_b32_e32 v105, 0xffff0000, v108
	v_and_b32_e32 v108, 0x7f, v33
	v_lshlrev_b32_e32 v101, 16, v110
	v_lshlrev_b32_e32 v93, 16, v112
	v_and_b32_e32 v90, 0xffff0000, v112
	v_bfe_u32 v112, v33, 8, 7
	v_lshl_add_u32 v110, v108, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_lshlrev_b32_e32 v92, 16, v113
	v_and_b32_e32 v89, 0xffff0000, v113
	v_bfe_u32 v113, v33, 16, 3
	v_and_b32_e32 v83, 0xffff0000, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v111, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshl_add_u32 v111, v112, 20, 0x3c000000
	v_lshlrev_b32_e32 v114, 16, v33
	v_lshlrev_b32_e32 v86, 16, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_bfe_u32 v110, v33, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v111, vcc_lo
	v_cvt_f32_ubyte0_e32 v111, v113
	v_lshlrev_b32_e32 v113, 24, v33
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_lshl_add_u32 v112, v110, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_and_or_b32 v113, 0x80000000, v113, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_bfe_u32 v108, v33, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v109, 0x80000000, v114, v109
	v_cvt_f32_ubyte0_e32 v108, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v112, vcc_lo
	v_bfe_u32 v112, v33, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v110
	v_and_b32_e32 v87, 0xffff0000, v115
	v_mul_f32_e32 v108, 0x3b000000, v108
	v_and_b32_e32 v114, 7, v34
	v_lshl_add_u32 v115, v112, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v108, v108, v115 :: v_dual_lshlrev_b32 v111, 8, v33
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v110, 0x80000000, v111, v110
	v_cvt_f32_ubyte0_e32 v111, v114
	v_bfe_u32 v115, v34, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_and_b32_e32 v116, 0x7f, v34
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_cvt_f32_ubyte0_e32 v112, v115
	v_bfe_u32 v115, v34, 16, 3
	v_and_or_b32 v119, 0x80000000, v33, v108
	v_lshl_add_u32 v114, v116, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_cvt_f32_ubyte0_e32 v115, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v114, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshl_add_u32 v114, v117, 20, 0x3c000000
	v_bfe_u32 v116, v34, 16, 7
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_lshl_add_u32 v118, v116, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v114, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v114, 24, v34
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_cndmask_b32 v112, 0x7fc00000, v112 :: v_dual_lshlrev_b32 v117, 16, v34
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_and_or_b32 v111, 0x80000000, v114, v111
	v_bfe_u32 v114, v34, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v117, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v115, v118, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_and_b32_e32 v115, 7, v35
	v_lshlrev_b32_e32 v116, 8, v34
	v_bfe_u32 v117, v34, 24, 7
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cvt_f32_ubyte0_e32 v115, v115
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v116, 0x80000000, v116, v108
	v_and_b32_e32 v118, 0x7f, v35
	v_lshl_add_u32 v108, v117, 20, 0x3c000000
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_lshl_add_u32 v120, v118, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v108, v114, v108, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v115, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_bfe_u32 v115, v35, 8, 7
	v_cvt_f32_ubyte0_e32 v120, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	v_mul_f32_e32 v118, 0x3b000000, v120
	v_lshlrev_b32_e32 v120, 24, v35
	v_and_or_b32 v121, 0x80000000, v34, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_bfe_u32 v108, v35, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v114, 0x80000000, v120, v114
	v_cvt_f32_ubyte0_e32 v108, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, v118, v117, vcc_lo
	v_bfe_u32 v118, v35, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_mul_f32_e32 v108, 0x3b000000, v108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v120, v118, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v117, vcc_lo
	v_bfe_u32 v117, v35, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_cvt_f32_ubyte0_e32 v117, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v108, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_lshl_add_u32 v120, v123, 20, 0x3c000000
	v_dual_mul_f32 v117, 0x3b000000, v117 :: v_dual_and_b32 v118, 7, v36
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v118, v118
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v117, v117, v120 :: v_dual_lshlrev_b32 v120, 8, v35
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_mul_f32_e32 v118, 0x3b000000, v118
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v120, 0x80000000, v120, v108
	v_fma_f32 v108, v113, v107, 0
	v_fma_f32 v113, v113, v106, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v117, 0x7fc00000, v117 :: v_dual_fmac_f32 v108, v109, v102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v113, v109, v105
	v_and_or_b32 v117, 0x80000000, v35, v117
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v108, v110, v100
	v_fmac_f32_e32 v113, v110, v104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v113, v119, v103 :: v_dual_lshlrev_b32 v110, 16, v36
	v_fmac_f32_e32 v113, v111, v101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v113, v112, v99
	v_fmac_f32_e32 v113, v116, v97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v113, v121, v95
	v_dual_fmac_f32 v113, v114, v93 :: v_dual_lshlrev_b32 v122, 16, v35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v115, 0x80000000, v122, v115
	v_fmac_f32_e32 v113, v115, v90
	v_fmac_f32_e32 v108, v119, v98
	v_bfe_u32 v119, v36, 16, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v113, v120, v92
	v_and_b32_e32 v122, 0x7f, v36
	v_dual_fmac_f32 v108, v111, v96 :: v_dual_fmac_f32 v113, v117, v89
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v123, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_fmac_f32_e32 v108, v112, v94
	v_bfe_u32 v112, v36, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, v118, v123, vcc_lo
	v_bfe_u32 v123, v36, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_fmac_f32_e32 v108, v116, v91
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v122, v123, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, 0x7fc00000, v118, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_fmac_f32_e32 v108, v121, v88
	v_bfe_u32 v121, v38, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v124, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_bfe_u32 v122, v36, 16, 7
	v_fmac_f32_e32 v108, v114, v84
	v_lshlrev_b32_e32 v114, 8, v36
	v_bfe_u32 v123, v38, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_lshl_add_u32 v111, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_fmac_f32_e32 v108, v115, v82
	v_bfe_u32 v115, v37, 8, 3
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_cvt_f32_ubyte0_e32 v110, v119
	v_bfe_u32 v119, v36, 24, 3
	v_fmac_f32_e32 v108, v120, v81
	v_cvt_f32_ubyte0_e32 v115, v115
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_cvt_f32_ubyte0_e32 v119, v119
	s_delay_alu instid0(VALU_DEP_4)
	v_fmac_f32_e32 v108, v117, v80
	v_bfe_u32 v117, v37, 8, 7
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_lshl_add_u32 v111, v112, 20, 0x3c000000
	v_mul_f32_e32 v116, 0x3b000000, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v110, 0x80000000, v114, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v116, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_and_b32_e32 v112, 7, v37
	v_and_b32_e32 v114, 0x7f, v37
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v112, v112
	v_lshl_add_u32 v116, v114, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v111, 0x80000000, v36, v111
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v112, v112, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_lshl_add_u32 v116, v117, 20, 0x3c000000
	v_bfe_u32 v114, v37, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v119, v114, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v117, 16, v37
	v_and_or_b32 v118, 0x80000000, v125, v118
	v_lshlrev_b32_e32 v116, 24, v37
	v_bfe_u32 v125, v39, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	v_fmac_f32_e32 v108, v118, v79
	v_fmac_f32_e32 v113, v118, v85
	v_bfe_u32 v118, v37, 16, 3
	v_and_or_b32 v112, 0x80000000, v116, v112
	v_and_or_b32 v115, 0x80000000, v117, v115
	v_fmac_f32_e32 v108, v109, v78
	v_fmac_f32_e32 v113, v109, v83
	v_cvt_f32_ubyte0_e32 v118, v118
	v_bfe_u32 v116, v37, 24, 3
	v_lshlrev_b32_e32 v117, 8, v37
	v_fma_f32 v107, v112, v107, 0
	v_fma_f32 v106, v112, v106, 0
	v_mul_f32_e32 v118, 0x3b000000, v118
	v_cvt_f32_ubyte0_e32 v116, v116
	v_dual_fmac_f32 v113, v110, v86 :: v_dual_and_b32 v112, 0x7f, v40
	v_fmac_f32_e32 v107, v115, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v118, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_bfe_u32 v118, v37, 24, 7
	v_and_b32_e32 v119, 0x7f, v38
	v_dual_mul_f32 v116, 0x3b000000, v116 :: v_dual_fmac_f32 v113, v111, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_lshl_add_u32 v120, v119, 20, 0x3c000000
	v_fmac_f32_e32 v106, v115, v105
	v_lshl_add_u32 v102, v112, 20, 0x3c000000
	v_and_or_b32 v109, 0x80000000, v117, v109
	v_and_b32_e32 v114, 7, v38
	v_lshl_add_u32 v117, v118, 20, 0x3c000000
	v_bfe_u32 v115, v40, 8, 3
	v_add_f32_e32 v73, v73, v113
	v_fmac_f32_e32 v107, v109, v100
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v116, v117, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_bfe_u32 v117, v38, 8, 7
	v_fmac_f32_e32 v106, v109, v104
	v_mul_f32_e32 v114, 0x3b000000, v114
	v_fmac_f32_e32 v108, v110, v77
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v114, v114, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_cvt_f32_ubyte0_e32 v120, v121
	v_lshl_add_u32 v118, v117, 20, 0x3c000000
	v_bfe_u32 v121, v38, 16, 3
	v_fmac_f32_e32 v108, v111, v76
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, 0x7fc00000, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_dual_mul_f32 v119, 0x3b000000, v120 :: v_dual_lshlrev_b32 v120, 24, v38
	v_add_f32_e32 v74, v74, v108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v116, 0x80000000, v37, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_fmac_f32_e32 v107, v116, v98
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v114, 0x80000000, v120, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, v119, v118, vcc_lo
	v_bfe_u32 v119, v38, 16, 7
	v_cvt_f32_ubyte0_e32 v120, v121
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_bfe_u32 v121, v38, 24, 3
	v_fmac_f32_e32 v106, v116, v103
	v_lshl_add_u32 v122, v119, 20, 0x3c000000
	v_mul_f32_e32 v120, 0x3b000000, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, 0x7fc00000, v118, vcc_lo
	v_lshlrev_b32_e32 v118, 16, v38
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_cvt_f32_ubyte0_e32 v98, v115
	v_fmac_f32_e32 v107, v114, v96
	v_fmac_f32_e32 v106, v114, v101
	v_and_or_b32 v117, 0x80000000, v118, v117
	v_cvt_f32_ubyte0_e32 v118, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, v120, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_lshl_add_u32 v121, v123, 20, 0x3c000000
	v_and_b32_e32 v122, 7, v39
	v_mul_f32_e32 v118, 0x3b000000, v118
	v_mul_f32_e32 v98, 0x3b000000, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v119, 0x7fc00000, v120, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_and_b32_e32 v120, 0x7f, v39
	v_cvt_f32_ubyte0_e32 v122, v122
	v_fmac_f32_e32 v107, v117, v94
	v_fmac_f32_e32 v106, v117, v99
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v118, v118, v121 :: v_dual_lshlrev_b32 v121, 8, v38
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_lshl_add_u32 v124, v120, 20, 0x3c000000
	v_mul_f32_e32 v122, 0x3b000000, v122
	v_bfe_u32 v123, v39, 8, 7
	v_and_or_b32 v119, 0x80000000, v121, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, 0x7fc00000, v118, vcc_lo
	v_bfe_u32 v121, v39, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v120
	v_lshlrev_b32_e32 v101, 24, v40
	v_fmac_f32_e32 v107, v119, v91
	v_and_or_b32 v118, 0x80000000, v38, v118
	v_cvt_f32_ubyte0_e32 v121, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v120
	v_lshl_add_u32 v124, v123, 20, 0x3c000000
	v_fmac_f32_e32 v106, v119, v97
	v_mul_f32_e32 v121, 0x3b000000, v121
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v107, v118, v88 :: v_dual_cndmask_b32 v120, 0x7fc00000, v122
	v_bfe_u32 v122, v39, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_fmac_f32_e32 v106, v118, v95
	v_bfe_u32 v88, v40, 16, 7
	v_and_or_b32 v120, 0x80000000, v126, v120
	v_cvt_f32_ubyte0_e32 v122, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v121, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_lshl_add_u32 v124, v125, 20, 0x3c000000
	v_bfe_u32 v123, v39, 24, 7
	v_dual_mul_f32 v122, 0x3b000000, v122 :: v_dual_fmac_f32 v107, v120, v84
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v125
	v_lshl_add_u32 v128, v123, 20, 0x3c000000
	v_fmac_f32_e32 v106, v120, v93
	v_lshl_add_u32 v84, v88, 20, 0x3c000000
	v_lshlrev_b32_e32 v97, 16, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v124, vcc_lo
	v_lshlrev_b32_e32 v124, 16, v39
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v125
	v_lshlrev_b32_e32 v125, 8, v39
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v121, 0x80000000, v124, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_dual_fmac_f32 v107, v121, v82 :: v_dual_and_b32 v124, 7, v40
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v122, 0x80000000, v125, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v127, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_cvt_f32_ubyte0_e32 v124, v124
	v_dual_fmac_f32 v106, v121, v90 :: v_dual_fmac_f32 v107, v122, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v126, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v105, 0x3b000000, v124
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_fmac_f32_e32 v106, v122, v92
	v_and_or_b32 v123, 0x80000000, v39, v123
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v105, v102, vcc_lo
	v_bfe_u32 v102, v40, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_fmac_f32_e32 v107, v123, v80
	v_fmac_f32_e32 v106, v123, v89
	v_lshlrev_b32_e32 v80, 8, v40
	v_lshl_add_u32 v96, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v98, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_and_or_b32 v96, 0x80000000, v101, v100
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v91, 0x7fc00000, v94, vcc_lo
	v_bfe_u32 v94, v40, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v88
	v_fmac_f32_e32 v107, v96, v79
	v_fmac_f32_e32 v106, v96, v85
	v_and_or_b32 v91, 0x80000000, v97, v91
	v_cvt_f32_ubyte0_e32 v94, v94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v107, v91, v78
	v_mul_f32_e32 v93, 0x3b000000, v94
	v_bfe_u32 v94, v40, 24, 3
	v_fmac_f32_e32 v106, v91, v83
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v82, v93, v84, vcc_lo
	v_bfe_u32 v84, v40, 24, 7
	v_cvt_f32_ubyte0_e32 v90, v94
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v88
	v_mul_f32_e32 v88, 0x3b000000, v90
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v81, 0x7fc00000, v82, vcc_lo
	v_lshl_add_u32 v82, v84, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v79, 0x80000000, v80, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v82, v88, v82, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v107, v79, v77
	v_fmac_f32_e32 v106, v79, v86
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v80, 0x7fc00000, v82, vcc_lo
	v_and_or_b32 v78, 0x80000000, v40, v80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v107, v78, v76
	v_fmac_f32_e32 v106, v78, v87
	v_or_b32_e32 v76, 32, v75
	v_add_f32_e32 v72, v72, v107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add_f32_e32 v0, v0, v106
	v_cmpx_gt_i32_e64 s16, v76
	s_cbranch_execz .LBB69_19
; %bb.25:                               ;   in Loop: Header=BB69_21 Depth=1
	v_lshl_add_u32 v80, v76, 5, 0
	s_wait_loadcnt 0x5
	v_and_b32_e32 v83, 7, v41
	v_bfe_u32 v124, v44, 8, 3
	v_bfe_u32 v117, v42, 8, 7
	v_bfe_u32 v121, v43, 8, 3
	ds_load_b128 v[76:79], v80
	ds_load_b128 v[103:106], v80 offset:16
	v_lshl_add_u32 v80, s17, 1, v80
	v_cvt_f32_ubyte0_e32 v87, v83
	v_cvt_f32_ubyte0_e32 v124, v124
	v_bfe_u32 v123, v43, 24, 7
	ds_load_b128 v[108:111], v80
	ds_load_b128 v[112:115], v80 offset:16
	s_wait_loadcnt 0x4
	v_bfe_u32 v127, v55, 24, 3
	v_lshlrev_b32_e32 v126, 24, v55
	s_mov_b32 s12, exec_lo
	v_lshlrev_b32_e32 v125, 24, v44
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v127, v127
	s_wait_dscnt 0x3
	v_dual_mul_f32 v127, 0x3b000000, v127 :: v_dual_lshlrev_b32 v100, 16, v77
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v84, 16, v103
	v_and_b32_e32 v82, 0xffff0000, v103
	v_lshlrev_b32_e32 v81, 16, v104
	v_and_b32_e32 v80, 0xffff0000, v104
	v_and_b32_e32 v98, 0xffff0000, v77
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v104, 16, v109
	v_and_b32_e32 v103, 0xffff0000, v109
	v_bfe_u32 v109, v41, 8, 3
	v_and_b32_e32 v94, 0xffff0000, v78
	v_lshlrev_b32_e32 v91, 16, v79
	v_and_b32_e32 v88, 0xffff0000, v79
	v_lshlrev_b32_e32 v79, 16, v105
	v_cvt_f32_ubyte0_e32 v109, v109
	v_lshlrev_b32_e32 v96, 16, v78
	v_lshlrev_b32_e32 v77, 16, v106
	v_and_b32_e32 v99, 0xffff0000, v110
	v_lshlrev_b32_e32 v97, 16, v111
	v_and_b32_e32 v95, 0xffff0000, v111
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v85, 16, v114
	v_mul_f32_e32 v111, 0x3b000000, v87
	v_lshlrev_b32_e32 v107, 16, v76
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_and_b32_e32 v102, 0xffff0000, v76
	v_and_b32_e32 v76, 0xffff0000, v106
	v_lshlrev_b32_e32 v106, 16, v108
	v_mul_f32_e32 v124, 0x3b000000, v124
	v_and_b32_e32 v78, 0xffff0000, v105
	v_and_b32_e32 v105, 0xffff0000, v108
	v_and_b32_e32 v108, 0x7f, v41
	v_lshlrev_b32_e32 v101, 16, v110
	v_lshlrev_b32_e32 v93, 16, v112
	v_and_b32_e32 v90, 0xffff0000, v112
	v_bfe_u32 v112, v41, 8, 7
	v_lshl_add_u32 v110, v108, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_lshlrev_b32_e32 v92, 16, v113
	v_and_b32_e32 v89, 0xffff0000, v113
	v_bfe_u32 v113, v41, 16, 3
	v_and_b32_e32 v83, 0xffff0000, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v111, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshl_add_u32 v111, v112, 20, 0x3c000000
	v_lshlrev_b32_e32 v114, 16, v41
	v_lshlrev_b32_e32 v86, 16, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_bfe_u32 v110, v41, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v111, vcc_lo
	v_cvt_f32_ubyte0_e32 v111, v113
	v_lshlrev_b32_e32 v113, 24, v41
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_lshl_add_u32 v112, v110, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_and_or_b32 v113, 0x80000000, v113, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_bfe_u32 v108, v41, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v109, 0x80000000, v114, v109
	v_cvt_f32_ubyte0_e32 v108, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v112, vcc_lo
	v_bfe_u32 v112, v41, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v110
	v_and_b32_e32 v87, 0xffff0000, v115
	v_mul_f32_e32 v108, 0x3b000000, v108
	v_and_b32_e32 v114, 7, v42
	v_lshl_add_u32 v115, v112, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v108, v108, v115 :: v_dual_lshlrev_b32 v111, 8, v41
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v110, 0x80000000, v111, v110
	v_cvt_f32_ubyte0_e32 v111, v114
	v_bfe_u32 v115, v42, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_and_b32_e32 v116, 0x7f, v42
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_cvt_f32_ubyte0_e32 v112, v115
	v_bfe_u32 v115, v42, 16, 3
	v_and_or_b32 v119, 0x80000000, v41, v108
	v_lshl_add_u32 v114, v116, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_cvt_f32_ubyte0_e32 v115, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v114, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshl_add_u32 v114, v117, 20, 0x3c000000
	v_bfe_u32 v116, v42, 16, 7
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_lshl_add_u32 v118, v116, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v114, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v114, 24, v42
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_cndmask_b32 v112, 0x7fc00000, v112 :: v_dual_lshlrev_b32 v117, 16, v42
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_and_or_b32 v111, 0x80000000, v114, v111
	v_bfe_u32 v114, v42, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v117, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v115, v118, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_and_b32_e32 v115, 7, v43
	v_lshlrev_b32_e32 v116, 8, v42
	v_bfe_u32 v117, v42, 24, 7
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cvt_f32_ubyte0_e32 v115, v115
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v116, 0x80000000, v116, v108
	v_and_b32_e32 v118, 0x7f, v43
	v_lshl_add_u32 v108, v117, 20, 0x3c000000
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_lshl_add_u32 v120, v118, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v108, v114, v108, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v115, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_bfe_u32 v115, v43, 8, 7
	v_cvt_f32_ubyte0_e32 v120, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	v_mul_f32_e32 v118, 0x3b000000, v120
	v_lshlrev_b32_e32 v120, 24, v43
	v_and_or_b32 v121, 0x80000000, v42, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_bfe_u32 v108, v43, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v114, 0x80000000, v120, v114
	v_cvt_f32_ubyte0_e32 v108, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, v118, v117, vcc_lo
	v_bfe_u32 v118, v43, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_mul_f32_e32 v108, 0x3b000000, v108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v120, v118, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v117, vcc_lo
	v_bfe_u32 v117, v43, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_cvt_f32_ubyte0_e32 v117, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v108, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_lshl_add_u32 v120, v123, 20, 0x3c000000
	v_dual_mul_f32 v117, 0x3b000000, v117 :: v_dual_and_b32 v118, 7, v44
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v118, v118
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v117, v117, v120 :: v_dual_lshlrev_b32 v120, 8, v43
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_mul_f32_e32 v118, 0x3b000000, v118
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v120, 0x80000000, v120, v108
	v_fma_f32 v108, v113, v107, 0
	v_fma_f32 v113, v113, v106, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v117, 0x7fc00000, v117 :: v_dual_fmac_f32 v108, v109, v102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v113, v109, v105
	v_and_or_b32 v117, 0x80000000, v43, v117
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v108, v110, v100
	v_fmac_f32_e32 v113, v110, v104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v113, v119, v103 :: v_dual_lshlrev_b32 v110, 16, v44
	v_fmac_f32_e32 v113, v111, v101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v113, v112, v99
	v_fmac_f32_e32 v113, v116, v97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v113, v121, v95
	v_dual_fmac_f32 v113, v114, v93 :: v_dual_lshlrev_b32 v122, 16, v43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v115, 0x80000000, v122, v115
	v_fmac_f32_e32 v113, v115, v90
	v_fmac_f32_e32 v108, v119, v98
	v_bfe_u32 v119, v44, 16, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v113, v120, v92
	v_and_b32_e32 v122, 0x7f, v44
	v_dual_fmac_f32 v108, v111, v96 :: v_dual_fmac_f32 v113, v117, v89
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v123, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_fmac_f32_e32 v108, v112, v94
	v_bfe_u32 v112, v44, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, v118, v123, vcc_lo
	v_bfe_u32 v123, v44, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_fmac_f32_e32 v108, v116, v91
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v122, v123, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, 0x7fc00000, v118, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_fmac_f32_e32 v108, v121, v88
	v_bfe_u32 v121, v54, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v124, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_bfe_u32 v122, v44, 16, 7
	v_fmac_f32_e32 v108, v114, v84
	v_lshlrev_b32_e32 v114, 8, v44
	v_bfe_u32 v123, v54, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_lshl_add_u32 v111, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_fmac_f32_e32 v108, v115, v82
	v_bfe_u32 v115, v53, 8, 3
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_cvt_f32_ubyte0_e32 v110, v119
	v_bfe_u32 v119, v44, 24, 3
	v_fmac_f32_e32 v108, v120, v81
	v_cvt_f32_ubyte0_e32 v115, v115
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_cvt_f32_ubyte0_e32 v119, v119
	s_delay_alu instid0(VALU_DEP_4)
	v_fmac_f32_e32 v108, v117, v80
	v_bfe_u32 v117, v53, 8, 7
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_lshl_add_u32 v111, v112, 20, 0x3c000000
	v_mul_f32_e32 v116, 0x3b000000, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v110, 0x80000000, v114, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v116, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_and_b32_e32 v112, 7, v53
	v_and_b32_e32 v114, 0x7f, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v112, v112
	v_lshl_add_u32 v116, v114, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v111, 0x80000000, v44, v111
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v112, v112, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_lshl_add_u32 v116, v117, 20, 0x3c000000
	v_bfe_u32 v114, v53, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v119, v114, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v117, 16, v53
	v_and_or_b32 v118, 0x80000000, v125, v118
	v_lshlrev_b32_e32 v116, 24, v53
	v_bfe_u32 v125, v55, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	v_fmac_f32_e32 v108, v118, v79
	v_fmac_f32_e32 v113, v118, v85
	v_bfe_u32 v118, v53, 16, 3
	v_and_or_b32 v112, 0x80000000, v116, v112
	v_and_or_b32 v115, 0x80000000, v117, v115
	v_fmac_f32_e32 v108, v109, v78
	v_fmac_f32_e32 v113, v109, v83
	v_cvt_f32_ubyte0_e32 v118, v118
	v_bfe_u32 v116, v53, 24, 3
	v_lshlrev_b32_e32 v117, 8, v53
	v_fma_f32 v107, v112, v107, 0
	v_fma_f32 v106, v112, v106, 0
	v_mul_f32_e32 v118, 0x3b000000, v118
	v_cvt_f32_ubyte0_e32 v116, v116
	v_dual_fmac_f32 v113, v110, v86 :: v_dual_and_b32 v112, 0x7f, v56
	v_fmac_f32_e32 v107, v115, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v118, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_bfe_u32 v118, v53, 24, 7
	v_and_b32_e32 v119, 0x7f, v54
	v_dual_mul_f32 v116, 0x3b000000, v116 :: v_dual_fmac_f32 v113, v111, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_lshl_add_u32 v120, v119, 20, 0x3c000000
	v_fmac_f32_e32 v106, v115, v105
	v_lshl_add_u32 v102, v112, 20, 0x3c000000
	v_and_or_b32 v109, 0x80000000, v117, v109
	v_and_b32_e32 v114, 7, v54
	v_lshl_add_u32 v117, v118, 20, 0x3c000000
	v_bfe_u32 v115, v56, 8, 3
	v_add_f32_e32 v73, v73, v113
	v_fmac_f32_e32 v107, v109, v100
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v116, v117, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_bfe_u32 v117, v54, 8, 7
	v_fmac_f32_e32 v106, v109, v104
	v_mul_f32_e32 v114, 0x3b000000, v114
	v_fmac_f32_e32 v108, v110, v77
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v114, v114, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_cvt_f32_ubyte0_e32 v120, v121
	v_lshl_add_u32 v118, v117, 20, 0x3c000000
	v_bfe_u32 v121, v54, 16, 3
	v_fmac_f32_e32 v108, v111, v76
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, 0x7fc00000, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_dual_mul_f32 v119, 0x3b000000, v120 :: v_dual_lshlrev_b32 v120, 24, v54
	v_add_f32_e32 v74, v74, v108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v116, 0x80000000, v53, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_fmac_f32_e32 v107, v116, v98
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v114, 0x80000000, v120, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, v119, v118, vcc_lo
	v_bfe_u32 v119, v54, 16, 7
	v_cvt_f32_ubyte0_e32 v120, v121
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_bfe_u32 v121, v54, 24, 3
	v_fmac_f32_e32 v106, v116, v103
	v_lshl_add_u32 v122, v119, 20, 0x3c000000
	v_mul_f32_e32 v120, 0x3b000000, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, 0x7fc00000, v118, vcc_lo
	v_lshlrev_b32_e32 v118, 16, v54
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_cvt_f32_ubyte0_e32 v98, v115
	v_fmac_f32_e32 v107, v114, v96
	v_fmac_f32_e32 v106, v114, v101
	v_and_or_b32 v117, 0x80000000, v118, v117
	v_cvt_f32_ubyte0_e32 v118, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, v120, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_lshl_add_u32 v121, v123, 20, 0x3c000000
	v_and_b32_e32 v122, 7, v55
	v_mul_f32_e32 v118, 0x3b000000, v118
	v_mul_f32_e32 v98, 0x3b000000, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v119, 0x7fc00000, v120, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_and_b32_e32 v120, 0x7f, v55
	v_cvt_f32_ubyte0_e32 v122, v122
	v_fmac_f32_e32 v107, v117, v94
	v_fmac_f32_e32 v106, v117, v99
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v118, v118, v121 :: v_dual_lshlrev_b32 v121, 8, v54
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_lshl_add_u32 v124, v120, 20, 0x3c000000
	v_mul_f32_e32 v122, 0x3b000000, v122
	v_bfe_u32 v123, v55, 8, 7
	v_and_or_b32 v119, 0x80000000, v121, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, 0x7fc00000, v118, vcc_lo
	v_bfe_u32 v121, v55, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v120
	v_lshlrev_b32_e32 v101, 24, v56
	v_fmac_f32_e32 v107, v119, v91
	v_and_or_b32 v118, 0x80000000, v54, v118
	v_cvt_f32_ubyte0_e32 v121, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v120
	v_lshl_add_u32 v124, v123, 20, 0x3c000000
	v_fmac_f32_e32 v106, v119, v97
	v_mul_f32_e32 v121, 0x3b000000, v121
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v107, v118, v88 :: v_dual_cndmask_b32 v120, 0x7fc00000, v122
	v_bfe_u32 v122, v55, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_fmac_f32_e32 v106, v118, v95
	v_bfe_u32 v88, v56, 16, 7
	v_and_or_b32 v120, 0x80000000, v126, v120
	v_cvt_f32_ubyte0_e32 v122, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v121, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_lshl_add_u32 v124, v125, 20, 0x3c000000
	v_bfe_u32 v123, v55, 24, 7
	v_dual_mul_f32 v122, 0x3b000000, v122 :: v_dual_fmac_f32 v107, v120, v84
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v125
	v_lshl_add_u32 v128, v123, 20, 0x3c000000
	v_fmac_f32_e32 v106, v120, v93
	v_lshl_add_u32 v84, v88, 20, 0x3c000000
	v_lshlrev_b32_e32 v97, 16, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v124, vcc_lo
	v_lshlrev_b32_e32 v124, 16, v55
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v125
	v_lshlrev_b32_e32 v125, 8, v55
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v121, 0x80000000, v124, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_dual_fmac_f32 v107, v121, v82 :: v_dual_and_b32 v124, 7, v56
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v122, 0x80000000, v125, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v127, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_cvt_f32_ubyte0_e32 v124, v124
	v_dual_fmac_f32 v106, v121, v90 :: v_dual_fmac_f32 v107, v122, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v126, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v105, 0x3b000000, v124
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_fmac_f32_e32 v106, v122, v92
	v_and_or_b32 v123, 0x80000000, v55, v123
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v105, v102, vcc_lo
	v_bfe_u32 v102, v56, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_fmac_f32_e32 v107, v123, v80
	v_fmac_f32_e32 v106, v123, v89
	v_lshlrev_b32_e32 v80, 8, v56
	v_lshl_add_u32 v96, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v98, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_and_or_b32 v96, 0x80000000, v101, v100
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v91, 0x7fc00000, v94, vcc_lo
	v_bfe_u32 v94, v56, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v88
	v_fmac_f32_e32 v107, v96, v79
	v_fmac_f32_e32 v106, v96, v85
	v_and_or_b32 v91, 0x80000000, v97, v91
	v_cvt_f32_ubyte0_e32 v94, v94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v107, v91, v78
	v_mul_f32_e32 v93, 0x3b000000, v94
	v_bfe_u32 v94, v56, 24, 3
	v_fmac_f32_e32 v106, v91, v83
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v82, v93, v84, vcc_lo
	v_bfe_u32 v84, v56, 24, 7
	v_cvt_f32_ubyte0_e32 v90, v94
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v88
	v_mul_f32_e32 v88, 0x3b000000, v90
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v81, 0x7fc00000, v82, vcc_lo
	v_lshl_add_u32 v82, v84, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v79, 0x80000000, v80, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v82, v88, v82, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v107, v79, v77
	v_fmac_f32_e32 v106, v79, v86
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v80, 0x7fc00000, v82, vcc_lo
	v_and_or_b32 v78, 0x80000000, v56, v80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v107, v78, v76
	v_fmac_f32_e32 v106, v78, v87
	v_or_b32_e32 v76, 64, v75
	v_add_f32_e32 v72, v72, v107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add_f32_e32 v0, v0, v106
	v_cmpx_gt_i32_e64 s16, v76
	s_cbranch_execz .LBB69_18
; %bb.26:                               ;   in Loop: Header=BB69_21 Depth=1
	v_lshl_add_u32 v80, v76, 5, 0
	s_wait_loadcnt 0x3
	v_and_b32_e32 v83, 7, v45
	v_bfe_u32 v124, v48, 8, 3
	v_bfe_u32 v117, v46, 8, 7
	v_bfe_u32 v121, v47, 8, 3
	ds_load_b128 v[76:79], v80
	ds_load_b128 v[103:106], v80 offset:16
	v_lshl_add_u32 v80, s17, 1, v80
	v_cvt_f32_ubyte0_e32 v87, v83
	v_cvt_f32_ubyte0_e32 v124, v124
	v_bfe_u32 v123, v47, 24, 7
	ds_load_b128 v[108:111], v80
	ds_load_b128 v[112:115], v80 offset:16
	s_wait_loadcnt 0x2
	v_bfe_u32 v127, v59, 24, 3
	v_lshlrev_b32_e32 v126, 24, v59
	v_or_b32_e32 v75, 0x60, v75
	s_mov_b32 s13, exec_lo
	v_lshlrev_b32_e32 v125, 24, v48
	v_cvt_f32_ubyte0_e32 v127, v127
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_mul_f32 v127, 0x3b000000, v127 :: v_dual_lshlrev_b32 v100, 16, v77
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v84, 16, v103
	v_and_b32_e32 v82, 0xffff0000, v103
	v_lshlrev_b32_e32 v81, 16, v104
	v_and_b32_e32 v80, 0xffff0000, v104
	v_and_b32_e32 v98, 0xffff0000, v77
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v104, 16, v109
	v_and_b32_e32 v103, 0xffff0000, v109
	v_bfe_u32 v109, v45, 8, 3
	v_and_b32_e32 v94, 0xffff0000, v78
	v_lshlrev_b32_e32 v91, 16, v79
	v_and_b32_e32 v88, 0xffff0000, v79
	v_lshlrev_b32_e32 v79, 16, v105
	v_cvt_f32_ubyte0_e32 v109, v109
	v_lshlrev_b32_e32 v96, 16, v78
	v_lshlrev_b32_e32 v77, 16, v106
	v_and_b32_e32 v99, 0xffff0000, v110
	v_lshlrev_b32_e32 v97, 16, v111
	v_and_b32_e32 v95, 0xffff0000, v111
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v85, 16, v114
	v_mul_f32_e32 v111, 0x3b000000, v87
	v_lshlrev_b32_e32 v107, 16, v76
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_and_b32_e32 v102, 0xffff0000, v76
	v_and_b32_e32 v76, 0xffff0000, v106
	v_lshlrev_b32_e32 v106, 16, v108
	v_mul_f32_e32 v124, 0x3b000000, v124
	v_and_b32_e32 v78, 0xffff0000, v105
	v_and_b32_e32 v105, 0xffff0000, v108
	v_and_b32_e32 v108, 0x7f, v45
	v_lshlrev_b32_e32 v101, 16, v110
	v_lshlrev_b32_e32 v93, 16, v112
	v_and_b32_e32 v90, 0xffff0000, v112
	v_bfe_u32 v112, v45, 8, 7
	v_lshl_add_u32 v110, v108, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_lshlrev_b32_e32 v92, 16, v113
	v_and_b32_e32 v89, 0xffff0000, v113
	v_bfe_u32 v113, v45, 16, 3
	v_and_b32_e32 v83, 0xffff0000, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v111, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshl_add_u32 v111, v112, 20, 0x3c000000
	v_lshlrev_b32_e32 v114, 16, v45
	v_lshlrev_b32_e32 v86, 16, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_bfe_u32 v110, v45, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v111, vcc_lo
	v_cvt_f32_ubyte0_e32 v111, v113
	v_lshlrev_b32_e32 v113, 24, v45
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_lshl_add_u32 v112, v110, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_and_or_b32 v113, 0x80000000, v113, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_bfe_u32 v108, v45, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v109, 0x80000000, v114, v109
	v_cvt_f32_ubyte0_e32 v108, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v112, vcc_lo
	v_bfe_u32 v112, v45, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v110
	v_and_b32_e32 v87, 0xffff0000, v115
	v_mul_f32_e32 v108, 0x3b000000, v108
	v_and_b32_e32 v114, 7, v46
	v_lshl_add_u32 v115, v112, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v108, v108, v115 :: v_dual_lshlrev_b32 v111, 8, v45
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v110, 0x80000000, v111, v110
	v_cvt_f32_ubyte0_e32 v111, v114
	v_bfe_u32 v115, v46, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_and_b32_e32 v116, 0x7f, v46
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_cvt_f32_ubyte0_e32 v112, v115
	v_bfe_u32 v115, v46, 16, 3
	v_and_or_b32 v119, 0x80000000, v45, v108
	v_lshl_add_u32 v114, v116, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_cvt_f32_ubyte0_e32 v115, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v114, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshl_add_u32 v114, v117, 20, 0x3c000000
	v_bfe_u32 v116, v46, 16, 7
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_lshl_add_u32 v118, v116, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v114, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v114, 24, v46
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_cndmask_b32 v112, 0x7fc00000, v112 :: v_dual_lshlrev_b32 v117, 16, v46
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_and_or_b32 v111, 0x80000000, v114, v111
	v_bfe_u32 v114, v46, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v117, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v115, v118, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_and_b32_e32 v115, 7, v47
	v_lshlrev_b32_e32 v116, 8, v46
	v_bfe_u32 v117, v46, 24, 7
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cvt_f32_ubyte0_e32 v115, v115
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v116, 0x80000000, v116, v108
	v_and_b32_e32 v118, 0x7f, v47
	v_lshl_add_u32 v108, v117, 20, 0x3c000000
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_lshl_add_u32 v120, v118, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v108, v114, v108, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v115, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_bfe_u32 v115, v47, 8, 7
	v_cvt_f32_ubyte0_e32 v120, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	v_mul_f32_e32 v118, 0x3b000000, v120
	v_lshlrev_b32_e32 v120, 24, v47
	v_and_or_b32 v121, 0x80000000, v46, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_bfe_u32 v108, v47, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v114, 0x80000000, v120, v114
	v_cvt_f32_ubyte0_e32 v108, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, v118, v117, vcc_lo
	v_bfe_u32 v118, v47, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_mul_f32_e32 v108, 0x3b000000, v108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v120, v118, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v117, vcc_lo
	v_bfe_u32 v117, v47, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_cvt_f32_ubyte0_e32 v117, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v108, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_lshl_add_u32 v120, v123, 20, 0x3c000000
	v_dual_mul_f32 v117, 0x3b000000, v117 :: v_dual_and_b32 v118, 7, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v118, v118
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v117, v117, v120 :: v_dual_lshlrev_b32 v120, 8, v47
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_mul_f32_e32 v118, 0x3b000000, v118
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v120, 0x80000000, v120, v108
	v_fma_f32 v108, v113, v107, 0
	v_fma_f32 v113, v113, v106, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v117, 0x7fc00000, v117 :: v_dual_fmac_f32 v108, v109, v102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v113, v109, v105
	v_and_or_b32 v117, 0x80000000, v47, v117
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v108, v110, v100
	v_fmac_f32_e32 v113, v110, v104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v113, v119, v103 :: v_dual_lshlrev_b32 v110, 16, v48
	v_fmac_f32_e32 v113, v111, v101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v113, v112, v99
	v_fmac_f32_e32 v113, v116, v97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v113, v121, v95
	v_dual_fmac_f32 v113, v114, v93 :: v_dual_lshlrev_b32 v122, 16, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v115, 0x80000000, v122, v115
	v_fmac_f32_e32 v113, v115, v90
	v_fmac_f32_e32 v108, v119, v98
	v_bfe_u32 v119, v48, 16, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v113, v120, v92
	v_and_b32_e32 v122, 0x7f, v48
	v_dual_fmac_f32 v108, v111, v96 :: v_dual_fmac_f32 v113, v117, v89
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v123, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_fmac_f32_e32 v108, v112, v94
	v_bfe_u32 v112, v48, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, v118, v123, vcc_lo
	v_bfe_u32 v123, v48, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_fmac_f32_e32 v108, v116, v91
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v122, v123, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, 0x7fc00000, v118, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_fmac_f32_e32 v108, v121, v88
	v_bfe_u32 v121, v58, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v124, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_bfe_u32 v122, v48, 16, 7
	v_fmac_f32_e32 v108, v114, v84
	v_lshlrev_b32_e32 v114, 8, v48
	v_bfe_u32 v123, v58, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_lshl_add_u32 v111, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_fmac_f32_e32 v108, v115, v82
	v_bfe_u32 v115, v57, 8, 3
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_cvt_f32_ubyte0_e32 v110, v119
	v_bfe_u32 v119, v48, 24, 3
	v_fmac_f32_e32 v108, v120, v81
	v_cvt_f32_ubyte0_e32 v115, v115
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_cvt_f32_ubyte0_e32 v119, v119
	s_delay_alu instid0(VALU_DEP_4)
	v_fmac_f32_e32 v108, v117, v80
	v_bfe_u32 v117, v57, 8, 7
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_lshl_add_u32 v111, v112, 20, 0x3c000000
	v_mul_f32_e32 v116, 0x3b000000, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v110, 0x80000000, v114, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v116, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_and_b32_e32 v112, 7, v57
	v_and_b32_e32 v114, 0x7f, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v112, v112
	v_lshl_add_u32 v116, v114, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v111, 0x80000000, v48, v111
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v112, v112, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_lshl_add_u32 v116, v117, 20, 0x3c000000
	v_bfe_u32 v114, v57, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v119, v114, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v117, 16, v57
	v_and_or_b32 v118, 0x80000000, v125, v118
	v_lshlrev_b32_e32 v116, 24, v57
	v_bfe_u32 v125, v59, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	v_fmac_f32_e32 v108, v118, v79
	v_fmac_f32_e32 v113, v118, v85
	v_bfe_u32 v118, v57, 16, 3
	v_and_or_b32 v112, 0x80000000, v116, v112
	v_and_or_b32 v115, 0x80000000, v117, v115
	v_fmac_f32_e32 v108, v109, v78
	v_fmac_f32_e32 v113, v109, v83
	v_cvt_f32_ubyte0_e32 v118, v118
	v_bfe_u32 v116, v57, 24, 3
	v_lshlrev_b32_e32 v117, 8, v57
	v_fma_f32 v107, v112, v107, 0
	v_fma_f32 v106, v112, v106, 0
	v_mul_f32_e32 v118, 0x3b000000, v118
	v_cvt_f32_ubyte0_e32 v116, v116
	v_dual_fmac_f32 v113, v110, v86 :: v_dual_and_b32 v112, 0x7f, v60
	v_fmac_f32_e32 v107, v115, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v118, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_bfe_u32 v118, v57, 24, 7
	v_and_b32_e32 v119, 0x7f, v58
	v_dual_mul_f32 v116, 0x3b000000, v116 :: v_dual_fmac_f32 v113, v111, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_lshl_add_u32 v120, v119, 20, 0x3c000000
	v_fmac_f32_e32 v106, v115, v105
	v_lshl_add_u32 v102, v112, 20, 0x3c000000
	v_and_or_b32 v109, 0x80000000, v117, v109
	v_and_b32_e32 v114, 7, v58
	v_lshl_add_u32 v117, v118, 20, 0x3c000000
	v_bfe_u32 v115, v60, 8, 3
	v_add_f32_e32 v73, v73, v113
	v_fmac_f32_e32 v107, v109, v100
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v116, v117, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_bfe_u32 v117, v58, 8, 7
	v_fmac_f32_e32 v106, v109, v104
	v_mul_f32_e32 v114, 0x3b000000, v114
	v_fmac_f32_e32 v108, v110, v77
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v114, v114, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_cvt_f32_ubyte0_e32 v120, v121
	v_lshl_add_u32 v118, v117, 20, 0x3c000000
	v_bfe_u32 v121, v58, 16, 3
	v_fmac_f32_e32 v108, v111, v76
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, 0x7fc00000, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_dual_mul_f32 v119, 0x3b000000, v120 :: v_dual_lshlrev_b32 v120, 24, v58
	v_add_f32_e32 v74, v74, v108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v116, 0x80000000, v57, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_fmac_f32_e32 v107, v116, v98
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v114, 0x80000000, v120, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, v119, v118, vcc_lo
	v_bfe_u32 v119, v58, 16, 7
	v_cvt_f32_ubyte0_e32 v120, v121
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_bfe_u32 v121, v58, 24, 3
	v_fmac_f32_e32 v106, v116, v103
	v_lshl_add_u32 v122, v119, 20, 0x3c000000
	v_mul_f32_e32 v120, 0x3b000000, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, 0x7fc00000, v118, vcc_lo
	v_lshlrev_b32_e32 v118, 16, v58
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_cvt_f32_ubyte0_e32 v98, v115
	v_fmac_f32_e32 v107, v114, v96
	v_fmac_f32_e32 v106, v114, v101
	v_and_or_b32 v117, 0x80000000, v118, v117
	v_cvt_f32_ubyte0_e32 v118, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, v120, v122, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_lshl_add_u32 v121, v123, 20, 0x3c000000
	v_and_b32_e32 v122, 7, v59
	v_mul_f32_e32 v118, 0x3b000000, v118
	v_mul_f32_e32 v98, 0x3b000000, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v119, 0x7fc00000, v120, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_and_b32_e32 v120, 0x7f, v59
	v_cvt_f32_ubyte0_e32 v122, v122
	v_fmac_f32_e32 v107, v117, v94
	v_fmac_f32_e32 v106, v117, v99
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v118, v118, v121 :: v_dual_lshlrev_b32 v121, 8, v58
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_lshl_add_u32 v124, v120, 20, 0x3c000000
	v_mul_f32_e32 v122, 0x3b000000, v122
	v_bfe_u32 v123, v59, 8, 7
	v_and_or_b32 v119, 0x80000000, v121, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, 0x7fc00000, v118, vcc_lo
	v_bfe_u32 v121, v59, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v120
	v_lshlrev_b32_e32 v101, 24, v60
	v_fmac_f32_e32 v107, v119, v91
	v_and_or_b32 v118, 0x80000000, v58, v118
	v_cvt_f32_ubyte0_e32 v121, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v120
	v_lshl_add_u32 v124, v123, 20, 0x3c000000
	v_fmac_f32_e32 v106, v119, v97
	v_mul_f32_e32 v121, 0x3b000000, v121
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v107, v118, v88 :: v_dual_cndmask_b32 v120, 0x7fc00000, v122
	v_bfe_u32 v122, v59, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_fmac_f32_e32 v106, v118, v95
	v_bfe_u32 v88, v60, 16, 7
	v_and_or_b32 v120, 0x80000000, v126, v120
	v_cvt_f32_ubyte0_e32 v122, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v121, v124, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_lshl_add_u32 v124, v125, 20, 0x3c000000
	v_bfe_u32 v123, v59, 24, 7
	v_dual_mul_f32 v122, 0x3b000000, v122 :: v_dual_fmac_f32 v107, v120, v84
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v125
	v_lshl_add_u32 v128, v123, 20, 0x3c000000
	v_fmac_f32_e32 v106, v120, v93
	v_lshl_add_u32 v84, v88, 20, 0x3c000000
	v_lshlrev_b32_e32 v97, 16, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, v122, v124, vcc_lo
	v_lshlrev_b32_e32 v124, 16, v59
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v125
	v_lshlrev_b32_e32 v125, 8, v59
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v121, 0x80000000, v124, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v123
	v_dual_fmac_f32 v107, v121, v82 :: v_dual_and_b32 v124, 7, v60
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v122, 0x80000000, v125, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v126, v127, v128, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v123
	v_cvt_f32_ubyte0_e32 v124, v124
	v_dual_fmac_f32 v106, v121, v90 :: v_dual_fmac_f32 v107, v122, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v123, 0x7fc00000, v126, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v105, 0x3b000000, v124
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_fmac_f32_e32 v106, v122, v92
	v_and_or_b32 v123, 0x80000000, v59, v123
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v105, v102, vcc_lo
	v_bfe_u32 v102, v60, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_fmac_f32_e32 v107, v123, v80
	v_fmac_f32_e32 v106, v123, v89
	v_lshlrev_b32_e32 v80, 8, v60
	v_lshl_add_u32 v96, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v98, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_and_or_b32 v96, 0x80000000, v101, v100
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v91, 0x7fc00000, v94, vcc_lo
	v_bfe_u32 v94, v60, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v88
	v_fmac_f32_e32 v107, v96, v79
	v_fmac_f32_e32 v106, v96, v85
	v_and_or_b32 v91, 0x80000000, v97, v91
	v_cvt_f32_ubyte0_e32 v94, v94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v107, v91, v78
	v_mul_f32_e32 v93, 0x3b000000, v94
	v_bfe_u32 v94, v60, 24, 3
	v_fmac_f32_e32 v106, v91, v83
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v82, v93, v84, vcc_lo
	v_bfe_u32 v84, v60, 24, 7
	v_cvt_f32_ubyte0_e32 v90, v94
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v88
	v_mul_f32_e32 v88, 0x3b000000, v90
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v81, 0x7fc00000, v82, vcc_lo
	v_lshl_add_u32 v82, v84, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v79, 0x80000000, v80, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v82, v88, v82, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v107, v79, v77
	v_fmac_f32_e32 v106, v79, v86
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v80, 0x7fc00000, v82, vcc_lo
	v_and_or_b32 v78, 0x80000000, v60, v80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v107, v78, v76
	v_fmac_f32_e32 v106, v78, v87
	v_add_f32_e32 v72, v72, v107
	s_delay_alu instid0(VALU_DEP_2)
	v_add_f32_e32 v0, v0, v106
	v_cmpx_gt_i32_e64 s16, v75
	s_cbranch_execz .LBB69_17
; %bb.27:                               ;   in Loop: Header=BB69_21 Depth=1
	v_lshl_add_u32 v79, v75, 5, 0
	s_wait_loadcnt 0x1
	v_and_b32_e32 v82, 7, v49
	v_bfe_u32 v123, v52, 8, 3
	v_bfe_u32 v116, v50, 8, 7
	v_bfe_u32 v120, v51, 8, 3
	ds_load_b128 v[75:78], v79
	ds_load_b128 v[102:105], v79 offset:16
	v_lshl_add_u32 v79, s17, 1, v79
	v_cvt_f32_ubyte0_e32 v86, v82
	v_cvt_f32_ubyte0_e32 v123, v123
	v_bfe_u32 v122, v51, 24, 7
	ds_load_b128 v[107:110], v79
	ds_load_b128 v[111:114], v79 offset:16
	s_wait_loadcnt 0x0
	v_bfe_u32 v126, v63, 24, 3
	v_lshlrev_b32_e32 v124, 24, v52
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v126, v126
	s_wait_dscnt 0x3
	v_dual_mul_f32 v126, 0x3b000000, v126 :: v_dual_lshlrev_b32 v99, 16, v76
	s_wait_dscnt 0x2
	v_lshlrev_b32_e32 v83, 16, v102
	v_and_b32_e32 v81, 0xffff0000, v102
	v_lshlrev_b32_e32 v80, 16, v103
	v_and_b32_e32 v79, 0xffff0000, v103
	v_and_b32_e32 v97, 0xffff0000, v76
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v103, 16, v108
	v_and_b32_e32 v102, 0xffff0000, v108
	v_bfe_u32 v108, v49, 8, 3
	v_and_b32_e32 v93, 0xffff0000, v77
	v_lshlrev_b32_e32 v90, 16, v78
	v_and_b32_e32 v87, 0xffff0000, v78
	v_lshlrev_b32_e32 v78, 16, v104
	v_cvt_f32_ubyte0_e32 v108, v108
	v_lshlrev_b32_e32 v95, 16, v77
	v_lshlrev_b32_e32 v76, 16, v105
	v_lshlrev_b32_e32 v100, 16, v109
	v_lshlrev_b32_e32 v96, 16, v110
	v_and_b32_e32 v94, 0xffff0000, v110
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v84, 16, v113
	v_mul_f32_e32 v110, 0x3b000000, v86
	v_lshlrev_b32_e32 v106, 16, v75
	v_mul_f32_e32 v108, 0x3b000000, v108
	v_and_b32_e32 v101, 0xffff0000, v75
	v_and_b32_e32 v75, 0xffff0000, v105
	v_lshlrev_b32_e32 v105, 16, v107
	v_mul_f32_e32 v123, 0x3b000000, v123
	v_and_b32_e32 v77, 0xffff0000, v104
	v_and_b32_e32 v104, 0xffff0000, v107
	v_and_b32_e32 v107, 0x7f, v49
	v_and_b32_e32 v98, 0xffff0000, v109
	v_lshlrev_b32_e32 v92, 16, v111
	v_and_b32_e32 v89, 0xffff0000, v111
	v_bfe_u32 v111, v49, 8, 7
	v_lshl_add_u32 v109, v107, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_lshlrev_b32_e32 v91, 16, v112
	v_and_b32_e32 v88, 0xffff0000, v112
	v_bfe_u32 v112, v49, 16, 3
	v_and_b32_e32 v82, 0xffff0000, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v110, v109, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_lshl_add_u32 v110, v111, 20, 0x3c000000
	v_lshlrev_b32_e32 v113, 16, v49
	v_lshlrev_b32_e32 v85, 16, v114
	v_and_b32_e32 v115, 0x7f, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v109, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_bfe_u32 v109, v49, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v108, v110, vcc_lo
	v_cvt_f32_ubyte0_e32 v110, v112
	v_lshlrev_b32_e32 v112, 24, v49
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v111, v109, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_and_or_b32 v112, 0x80000000, v112, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_bfe_u32 v107, v49, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v108, 0x80000000, v113, v108
	v_cvt_f32_ubyte0_e32 v107, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v111, vcc_lo
	v_bfe_u32 v111, v49, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_and_b32_e32 v86, 0xffff0000, v114
	v_and_b32_e32 v113, 7, v50
	v_mul_f32_e32 v107, 0x3b000000, v107
	v_lshl_add_u32 v114, v111, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v109, 0x7fc00000, v110 :: v_dual_lshlrev_b32 v110, 8, v49
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_cvt_f32_ubyte0_e32 v110, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v114, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v113, v115, 20, 0x3c000000
	v_bfe_u32 v114, v50, 8, 3
	v_mul_f32_e32 v110, 0x3b000000, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_cvt_f32_ubyte0_e32 v111, v114
	v_bfe_u32 v114, v50, 16, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v118, 0x80000000, v49, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_bfe_u32 v115, v50, 16, 7
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v114, 0x3b000000, v114 :: v_dual_cndmask_b32 v111, v111, v113
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v113, 24, v50
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_cndmask_b32 v111, 0x7fc00000, v111 :: v_dual_lshlrev_b32 v116, 16, v50
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_and_or_b32 v110, 0x80000000, v113, v110
	v_bfe_u32 v113, v50, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v111, 0x80000000, v116, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v114, v117, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshlrev_b32_e32 v115, 8, v50
	v_bfe_u32 v116, v50, 24, 7
	v_cvt_f32_ubyte0_e32 v113, v113
	v_and_b32_e32 v114, 7, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_mul_f32_e32 v113, 0x3b000000, v113
	v_cvt_f32_ubyte0_e32 v114, v114
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_and_or_b32 v115, 0x80000000, v115, v107
	v_lshl_add_u32 v107, v116, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v114, 0x3b000000, v114 :: v_dual_cndmask_b32 v107, v113, v107
	v_and_b32_e32 v117, 0x7f, v51
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v119, v117, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v114, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_bfe_u32 v114, v51, 8, 7
	v_cvt_f32_ubyte0_e32 v119, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshl_add_u32 v116, v114, 20, 0x3c000000
	v_mul_f32_e32 v117, 0x3b000000, v119
	v_lshlrev_b32_e32 v119, 24, v51
	v_and_or_b32 v120, 0x80000000, v50, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_bfe_u32 v107, v51, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v113, 0x80000000, v119, v113
	v_cvt_f32_ubyte0_e32 v107, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v117, v116, vcc_lo
	v_bfe_u32 v117, v51, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_mul_f32_e32 v107, 0x3b000000, v107
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v119, v117, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v116, vcc_lo
	v_bfe_u32 v116, v51, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_cvt_f32_ubyte0_e32 v116, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshl_add_u32 v119, v122, 20, 0x3c000000
	v_and_b32_e32 v117, 7, v52
	v_mul_f32_e32 v116, 0x3b000000, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_cvt_f32_ubyte0_e32 v117, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v116, v119, vcc_lo
	v_lshlrev_b32_e32 v119, 8, v51
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_mul_f32_e32 v117, 0x3b000000, v117
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_and_or_b32 v119, 0x80000000, v119, v107
	v_fma_f32 v107, v112, v106, 0
	v_fma_f32 v112, v112, v105, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v116, 0x7fc00000, v116 :: v_dual_fmac_f32 v107, v108, v101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v112, v108, v104
	v_and_or_b32 v116, 0x80000000, v51, v116
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v107, v109, v99
	v_dual_fmac_f32 v112, v109, v103 :: v_dual_fmac_f32 v107, v118, v97
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v112, v118, v102
	v_bfe_u32 v118, v52, 16, 3
	v_fmac_f32_e32 v107, v110, v95
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v112, v110, v100
	v_dual_fmac_f32 v112, v111, v98 :: v_dual_lshlrev_b32 v121, 16, v51
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v112, v115, v96
	v_and_or_b32 v114, 0x80000000, v121, v114
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v112, v120, v94
	v_fmac_f32_e32 v112, v113, v92
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v112, v114, v89 :: v_dual_and_b32 v121, 0x7f, v52
	v_fmac_f32_e32 v112, v119, v91
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v122, v121, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v121
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v112, v116, v88 :: v_dual_cndmask_b32 v117, v117, v122
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v121
	v_bfe_u32 v122, v52, 8, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v117, 0x7fc00000, v117, vcc_lo
	v_lshl_add_u32 v121, v122, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v117, 0x80000000, v124, v117
	v_bfe_u32 v124, v63, 16, 7
	v_dual_fmac_f32 v112, v117, v84 :: v_dual_fmac_f32 v107, v111, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v123, v121, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_bfe_u32 v121, v52, 16, 7
	v_bfe_u32 v111, v52, 24, 7
	v_fmac_f32_e32 v107, v115, v90
	v_bfe_u32 v122, v62, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_lshl_add_u32 v110, v121, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v121
	v_fmac_f32_e32 v107, v120, v87
	v_bfe_u32 v120, v62, 8, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v107, v113, v83
	v_lshlrev_b32_e32 v113, 8, v52
	v_fmac_f32_e32 v107, v114, v81
	v_bfe_u32 v114, v61, 8, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v107, v119, v80
	v_cvt_f32_ubyte0_e32 v114, v114
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v107, v116, v79 :: v_dual_mul_f32 v114, 0x3b000000, v114
	v_lshlrev_b32_e32 v109, 16, v52
	v_bfe_u32 v116, v61, 8, 7
	v_fmac_f32_e32 v107, v117, v78
	v_bfe_u32 v117, v61, 16, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v108, 0x80000000, v109, v108
	v_cvt_f32_ubyte0_e32 v109, v118
	v_bfe_u32 v118, v52, 24, 3
	v_cvt_f32_ubyte0_e32 v117, v117
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v107, v108, v77
	v_mul_f32_e32 v109, 0x3b000000, v109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v118, v118
	v_dual_fmac_f32 v112, v108, v82 :: v_dual_mul_f32 v117, 0x3b000000, v117
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v109, v109, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v121
	v_lshl_add_u32 v110, v111, 20, 0x3c000000
	v_mul_f32_e32 v115, 0x3b000000, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v109, 0x80000000, v113, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v115, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_and_b32_e32 v111, 7, v61
	v_and_b32_e32 v113, 0x7f, v61
	v_dual_fmac_f32 v112, v109, v85 :: v_dual_lshlrev_b32 v125, 24, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cvt_f32_ubyte0_e32 v111, v111
	v_lshl_add_u32 v115, v113, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v113
	v_fmac_f32_e32 v107, v109, v76
	v_and_or_b32 v110, 0x80000000, v52, v110
	v_mul_f32_e32 v111, 0x3b000000, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v107, v110, v75
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v115, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v113
	v_lshl_add_u32 v115, v116, 20, 0x3c000000
	v_bfe_u32 v113, v61, 16, 7
	v_fmac_f32_e32 v112, v110, v86
	v_add_f32_e32 v74, v74, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v118, v113, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_add_f32 v73, v73, v112 :: v_dual_cndmask_b32 v114, v114, v115
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v115, 24, v61
	v_lshlrev_b32_e32 v116, 16, v61
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v113
	v_and_or_b32 v111, 0x80000000, v115, v111
	v_bfe_u32 v115, v61, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v114, 0x80000000, v116, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v117, v118, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v113
	v_and_b32_e32 v113, 7, v62
	v_lshlrev_b32_e32 v116, 8, v61
	v_bfe_u32 v117, v61, 24, 7
	v_cvt_f32_ubyte0_e32 v115, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_and_b32_e32 v118, 0x7f, v62
	v_cvt_f32_ubyte0_e32 v113, v113
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_and_or_b32 v108, 0x80000000, v116, v108
	v_lshl_add_u32 v116, v117, 20, 0x3c000000
	v_lshl_add_u32 v119, v118, 20, 0x3c000000
	v_mul_f32_e32 v113, 0x3b000000, v113
	v_fma_f32 v106, v111, v106, 0
	v_fma_f32 v105, v111, v105, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v116, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_bfe_u32 v116, v62, 8, 7
	v_fmac_f32_e32 v106, v114, v101
	v_fmac_f32_e32 v105, v114, v104
	v_and_b32_e32 v111, 0x7f, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v113, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_cvt_f32_ubyte0_e32 v119, v120
	v_lshl_add_u32 v117, v116, 20, 0x3c000000
	v_bfe_u32 v120, v62, 16, 3
	v_fmac_f32_e32 v106, v108, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_dual_mul_f32 v118, 0x3b000000, v119 :: v_dual_lshlrev_b32 v119, 24, v62
	v_fmac_f32_e32 v105, v108, v103
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v115, 0x80000000, v61, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v101, v111, 20, 0x3c000000
	v_bfe_u32 v114, v64, 8, 3
	v_fmac_f32_e32 v106, v115, v97
	v_and_or_b32 v113, 0x80000000, v119, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, v118, v117, vcc_lo
	v_bfe_u32 v118, v62, 16, 7
	v_cvt_f32_ubyte0_e32 v119, v120
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_bfe_u32 v120, v62, 24, 3
	v_fmac_f32_e32 v105, v115, v102
	v_lshl_add_u32 v121, v118, 20, 0x3c000000
	v_mul_f32_e32 v119, 0x3b000000, v119
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v116, 0x7fc00000, v117 :: v_dual_lshlrev_b32 v117, 16, v62
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_cvt_f32_ubyte0_e32 v97, v114
	v_fmac_f32_e32 v106, v113, v95
	v_fmac_f32_e32 v105, v113, v100
	v_and_or_b32 v116, 0x80000000, v117, v116
	v_cvt_f32_ubyte0_e32 v117, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v119, v119, v121, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_lshl_add_u32 v120, v122, 20, 0x3c000000
	v_and_b32_e32 v121, 7, v63
	v_mul_f32_e32 v117, 0x3b000000, v117
	v_mul_f32_e32 v97, 0x3b000000, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v118, 0x7fc00000, v119, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_and_b32_e32 v119, 0x7f, v63
	v_cvt_f32_ubyte0_e32 v121, v121
	v_fmac_f32_e32 v106, v116, v93
	v_fmac_f32_e32 v105, v116, v98
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v117, v117, v120 :: v_dual_lshlrev_b32 v120, 8, v62
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_lshl_add_u32 v123, v119, 20, 0x3c000000
	v_mul_f32_e32 v121, 0x3b000000, v121
	v_bfe_u32 v122, v63, 8, 7
	v_and_or_b32 v118, 0x80000000, v120, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, 0x7fc00000, v117, vcc_lo
	v_bfe_u32 v120, v63, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_lshlrev_b32_e32 v100, 24, v64
	v_fmac_f32_e32 v106, v118, v90
	v_and_or_b32 v117, 0x80000000, v62, v117
	v_cvt_f32_ubyte0_e32 v120, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, v121, v123, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_lshl_add_u32 v123, v122, 20, 0x3c000000
	v_fmac_f32_e32 v105, v118, v96
	v_mul_f32_e32 v120, 0x3b000000, v120
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v106, v117, v87 :: v_dual_cndmask_b32 v119, 0x7fc00000, v121
	v_bfe_u32 v121, v63, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_fmac_f32_e32 v105, v117, v94
	v_bfe_u32 v87, v64, 16, 7
	v_and_or_b32 v119, 0x80000000, v125, v119
	v_cvt_f32_ubyte0_e32 v121, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, v120, v123, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_lshl_add_u32 v123, v124, 20, 0x3c000000
	v_bfe_u32 v122, v63, 24, 7
	v_dual_mul_f32 v121, 0x3b000000, v121 :: v_dual_fmac_f32 v106, v119, v83
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v120, 0x7fc00000, v120, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v124
	v_lshl_add_u32 v127, v122, 20, 0x3c000000
	v_fmac_f32_e32 v105, v119, v92
	v_lshl_add_u32 v83, v87, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v121, v121, v123 :: v_dual_lshlrev_b32 v96, 16, v64
	v_lshlrev_b32_e32 v123, 16, v63
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v124
	v_lshlrev_b32_e32 v124, 8, v63
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v120, 0x80000000, v123, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v121, 0x7fc00000, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v122
	v_dual_fmac_f32 v106, v120, v81 :: v_dual_and_b32 v123, 7, v64
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v121, 0x80000000, v124, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v125, v126, v127, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v122
	v_cvt_f32_ubyte0_e32 v123, v123
	v_dual_fmac_f32 v105, v120, v89 :: v_dual_fmac_f32 v106, v121, v80
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v122, 0x7fc00000, v125, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v104, 0x3b000000, v123
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_fmac_f32_e32 v105, v121, v91
	v_and_or_b32 v122, 0x80000000, v63, v122
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v104, v101, vcc_lo
	v_bfe_u32 v101, v64, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_fmac_f32_e32 v106, v122, v79
	v_fmac_f32_e32 v105, v122, v88
	v_lshlrev_b32_e32 v79, 8, v64
	v_lshl_add_u32 v95, v101, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v97, v95, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_and_or_b32 v95, 0x80000000, v100, v99
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v90, 0x7fc00000, v93, vcc_lo
	v_bfe_u32 v93, v64, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v87
	v_fmac_f32_e32 v106, v95, v78
	v_fmac_f32_e32 v105, v95, v84
	v_and_or_b32 v90, 0x80000000, v96, v90
	v_cvt_f32_ubyte0_e32 v93, v93
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v106, v90, v77
	v_mul_f32_e32 v92, 0x3b000000, v93
	v_bfe_u32 v93, v64, 24, 3
	v_fmac_f32_e32 v105, v90, v82
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v81, v92, v83, vcc_lo
	v_bfe_u32 v83, v64, 24, 7
	v_cvt_f32_ubyte0_e32 v89, v93
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v87
	v_mul_f32_e32 v87, 0x3b000000, v89
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v80, 0x7fc00000, v81, vcc_lo
	v_lshl_add_u32 v81, v83, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v78, 0x80000000, v79, v80
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v81, v87, v81, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v106, v78, v76
	v_fmac_f32_e32 v105, v78, v85
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v79, 0x7fc00000, v81, vcc_lo
	v_and_or_b32 v77, 0x80000000, v64, v79
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v106, v77, v75
	v_fmac_f32_e32 v105, v77, v86
	v_add_f32_e32 v72, v72, v106
	s_delay_alu instid0(VALU_DEP_2)
	v_add_f32_e32 v0, v0, v105
	s_branch .LBB69_17
.LBB69_28:
	s_wait_loadcnt 0x7
	v_mbcnt_lo_u32_b32 v33, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v34, 16, v33
	v_xor_b32_e32 v36, 8, v33
	s_wait_loadcnt 0x6
	v_xor_b32_e32 v37, 4, v33
	v_cmp_gt_i32_e32 vcc_lo, 32, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v34, v33, v34, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v36
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v36, v33, v36, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v37
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v37, v33, v37 :: v_dual_lshlrev_b32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v37
	v_lshlrev_b32_e32 v35, 2, v34
	ds_bpermute_b32 v34, v35, v74
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v74, v34
	ds_bpermute_b32 v38, v36, v34
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v38
	v_xor_b32_e32 v38, 2, v33
	ds_bpermute_b32 v39, v37, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v38
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v38, v33, v38, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v38, 2, v38
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v39
	v_xor_b32_e32 v39, 1, v33
	ds_bpermute_b32 v40, v38, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v39
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v33, v33, v39, vcc_lo
	v_cmp_eq_u32_e32 vcc_lo, 0, v71
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_add_f32 v40, v34, v40 :: v_dual_lshlrev_b32 v39, 2, v33
	v_lshlrev_b64_e32 v[33:34], 1, v[65:66]
	s_wait_loadcnt 0x5
	ds_bpermute_b32 v41, v39, v40
	s_wait_kmcnt 0x0
	v_add_co_u32 v33, s0, s6, v33
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v34, null, s7, v34, s0
	s_and_saveexec_b32 s5, vcc_lo
	s_cbranch_execz .LBB69_34
; %bb.29:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s1, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e64 s0, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s8, s0
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s8
; %bb.30:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.31:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.32:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.33:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	global_store_b16 v[33:34], v40, off
.LBB69_34:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	ds_bpermute_b32 v40, v35, v73
	s_mov_b32 s0, 0
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v73, v40
	ds_bpermute_b32 v41, v36, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v37, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v38, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v39, v40
	s_and_saveexec_b32 s5, vcc_lo
	s_cbranch_execz .LBB69_40
; %bb.35:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s1, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.36:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.37:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.38:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.39:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshl_b64 s[8:9], s[10:11], 1
	s_and_b32 s0, s2, exec_lo
	s_wait_alu 0xfffe
	v_add_co_u32 v41, vcc_lo, v33, s8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v42, null, s9, v34, vcc_lo
	global_store_b16 v[41:42], v40, off
.LBB69_40:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	ds_bpermute_b32 v40, v35, v72
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v72, v40
	ds_bpermute_b32 v41, v36, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v37, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v38, v40
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	ds_bpermute_b32 v41, v39, v40
	s_and_saveexec_b32 s5, s0
	s_cbranch_execz .LBB69_46
; %bb.41:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s1, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s8, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s8, exec_lo, s8
; %bb.42:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.43:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s8, s8
; %bb.44:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.45:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
	global_store_b16 v[33:34], v40, off offset:2
.LBB69_46:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	ds_bpermute_b32 v35, v35, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v36, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v37, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v38, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v39, v0
	s_and_saveexec_b32 s5, s0
	s_cbranch_execz .LBB69_52
; %bb.47:
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v35, s1, v0
	v_and_b32_e32 v0, 0x7fffffff, v35
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.48:
	v_bfe_u32 v0, v35, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v35, v0, 0x7fff
                                        ; implicit-def: $vgpr35
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.49:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.50:
	v_lshrrev_b32_e32 v0, 16, v35
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.51:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshl_b64 s[8:9], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v33, vcc_lo, v33, s8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v34, null, s9, v34, vcc_lo
	global_store_b16 v[33:34], v0, off offset:2
.LBB69_52:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	s_mov_b32 s5, 0
.LBB69_53:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s5
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB69_91
; %bb.54:
	s_wait_dscnt 0x0
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v35, 0
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v33, 0
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB69_67
; %bb.55:
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v0, 0
	s_max_i32 s0, s3, 1
	s_mov_b32 s3, 0
	s_wait_alu 0xfffe
	s_lshl_b32 s0, s0, 7
	s_branch .LBB69_60
.LBB69_56:                              ;   in Loop: Header=BB69_60 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
.LBB69_57:                              ;   in Loop: Header=BB69_60 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s8
.LBB69_58:                              ;   in Loop: Header=BB69_60 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB69_59:                              ;   in Loop: Header=BB69_60 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_addk_co_i32 s3, 0x80
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s0, s3
	s_cbranch_scc0 .LBB69_67
.LBB69_60:                              ; =>This Inner Loop Header: Depth=1
	s_cmp_eq_u32 s3, 0
	s_mov_b32 s4, 0
	s_cbranch_scc1 .LBB69_62
; %bb.61:                               ;   in Loop: Header=BB69_60 Depth=1
	s_wait_loadcnt 0x5
	v_add_nc_u32_e32 v10, s3, v71
	s_mov_b32 s4, s3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s16, v10
	v_add_nc_u32_e32 v3, 32, v10
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, 0, v10, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v3
	v_add_nc_u32_e32 v4, 64, v10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_ashrrev_i32_e32 v2, 31, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v4
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[1:2], 4, v[1:2]
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, 0, v4, vcc_lo
	v_ashrrev_i32_e32 v4, 31, v3
	s_wait_loadcnt 0x4
	v_add_nc_u32_e32 v15, 0x60, v10
	v_add_co_u32 v5, vcc_lo, v67, v1
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[11:12], 4, v[3:4]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, v68, v2, vcc_lo
	v_add_co_u32 v7, vcc_lo, v69, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, v70, v2, vcc_lo
	v_add_co_u32 v13, vcc_lo, v67, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v14, null, v68, v12, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s16, v15
	v_ashrrev_i32_e32 v10, 31, v9
	s_clause 0x1
	global_load_b128 v[1:4], v[5:6], off th:TH_LOAD_NT
	global_load_b128 v[5:8], v[7:8], off th:TH_LOAD_NT
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v15, 0, v15, vcc_lo
	v_lshlrev_b64_e32 v[9:10], 4, v[9:10]
	s_wait_loadcnt 0x5
	v_add_co_u32 v17, vcc_lo, v69, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, v70, v12, vcc_lo
	v_ashrrev_i32_e32 v16, 31, v15
	v_add_co_u32 v19, vcc_lo, v67, v9
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v20, null, v68, v10, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[11:12], 4, v[15:16]
	s_wait_loadcnt 0x4
	v_add_co_u32 v21, vcc_lo, v69, v9
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v22, null, v70, v10, vcc_lo
	s_wait_loadcnt 0x3
	v_add_co_u32 v25, vcc_lo, v67, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, v68, v12, vcc_lo
	s_wait_loadcnt 0x2
	v_add_co_u32 v29, vcc_lo, v69, v11
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v30, null, v70, v12, vcc_lo
	s_clause 0x5
	global_load_b128 v[9:12], v[13:14], off th:TH_LOAD_NT
	global_load_b128 v[13:16], v[17:18], off th:TH_LOAD_NT
	global_load_b128 v[17:20], v[19:20], off th:TH_LOAD_NT
	global_load_b128 v[21:24], v[21:22], off th:TH_LOAD_NT
	global_load_b128 v[25:28], v[25:26], off th:TH_LOAD_NT
	global_load_b128 v[29:32], v[29:30], off th:TH_LOAD_NT
.LBB69_62:                              ;   in Loop: Header=BB69_60 Depth=1
	s_wait_alu 0xfffe
	v_or_b32_e32 v36, s4, v71
	s_mov_b32 s4, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s16, v36
	s_cbranch_execz .LBB69_59
; %bb.63:                               ;   in Loop: Header=BB69_60 Depth=1
	s_wait_loadcnt 0x3
	v_lshl_add_u32 v45, v36, 5, 0
	v_perm_b32 v46, 0, v1, 0x10c000c
	s_wait_loadcnt 0x1
	v_perm_b32 v49, 0, v1, 0x30c020c
	v_perm_b32 v50, 0, v2, 0x10c000c
	v_perm_b32 v52, 0, v2, 0x30c020c
	v_lshl_add_u32 v51, s17, 1, v45
	ds_load_b128 v[37:40], v45
	v_lshrrev_b32_e32 v58, 1, v46
	v_and_b32_e32 v59, 0x80008000, v46
	v_lshrrev_b32_e32 v60, 1, v49
	ds_load_b128 v[41:44], v51
	v_and_b32_e32 v49, 0x80008000, v49
	ds_load_b128 v[45:48], v45 offset:16
	v_and_or_b32 v58, 0x3f803f80, v58, v59
	s_wait_loadcnt 0x0
	v_lshrrev_b32_e32 v61, 1, v50
	v_and_b32_e32 v59, 0x80008000, v50
	v_lshrrev_b32_e32 v62, 1, v52
	v_and_b32_e32 v63, 0x80008000, v52
	v_and_or_b32 v60, 0x3f803f80, v60, v49
	ds_load_b128 v[49:52], v51 offset:16
	v_perm_b32 v53, 0, v3, 0x10c000c
	v_perm_b32 v54, 0, v3, 0x30c020c
	v_perm_b32 v56, 0, v4, 0x30c020c
	v_and_or_b32 v59, 0x3f803f80, v61, v59
	v_perm_b32 v55, 0, v4, 0x10c000c
	v_perm_b32 v57, 0, v5, 0x10c000c
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v0, v58, v37, v0
	v_lshrrev_b32_e32 v64, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_and_or_b32 v61, 0x3f803f80, v62, v63
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v35, v58, v41, v35
	v_dot2_f32_f16 v0, v60, v38, v0
	v_lshrrev_b32_e32 v58, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_and_or_b32 v53, 0x3f803f80, v64, v53
	v_dot2_f32_f16 v35, v60, v42, v35
	v_dot2_f32_f16 v0, v59, v39, v0
	v_lshrrev_b32_e32 v60, 1, v55
	v_and_b32_e32 v55, 0x80008000, v55
	v_and_or_b32 v54, 0x3f803f80, v58, v54
	v_dot2_f32_f16 v35, v59, v43, v35
	v_lshrrev_b32_e32 v59, 1, v56
	v_and_b32_e32 v56, 0x80008000, v56
	v_dot2_f32_f16 v0, v61, v40, v0
	v_perm_b32 v58, 0, v5, 0x30c020c
	v_dot2_f32_f16 v35, v61, v44, v35
	v_and_or_b32 v55, 0x3f803f80, v60, v55
	v_and_or_b32 v56, 0x3f803f80, v59, v56
	v_lshrrev_b32_e32 v59, 1, v57
	v_and_b32_e32 v57, 0x80008000, v57
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v53, v45, v0
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v35, v53, v49, v35
	v_perm_b32 v53, 0, v6, 0x10c000c
	v_lshrrev_b32_e32 v60, 1, v58
	v_and_b32_e32 v58, 0x80008000, v58
	v_and_or_b32 v57, 0x3f803f80, v59, v57
	v_dot2_f32_f16 v0, v54, v46, v0
	v_lshrrev_b32_e32 v61, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_dot2_f32_f16 v35, v54, v50, v35
	v_perm_b32 v54, 0, v6, 0x30c020c
	v_and_or_b32 v58, 0x3f803f80, v60, v58
	v_dot2_f32_f16 v34, v57, v37, v34
	v_dot2_f32_f16 v33, v57, v41, v33
	v_and_or_b32 v53, 0x3f803f80, v61, v53
	v_perm_b32 v59, 0, v7, 0x10c000c
	v_lshrrev_b32_e32 v60, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_dot2_f32_f16 v34, v58, v38, v34
	v_dot2_f32_f16 v33, v58, v42, v33
	v_lshrrev_b32_e32 v37, 1, v59
	v_and_b32_e32 v41, 0x80008000, v59
	v_and_or_b32 v54, 0x3f803f80, v60, v54
	v_perm_b32 v38, 0, v7, 0x30c020c
	v_dot2_f32_f16 v34, v53, v39, v34
	v_dot2_f32_f16 v33, v53, v43, v33
	v_and_or_b32 v37, 0x3f803f80, v37, v41
	v_perm_b32 v41, 0, v8, 0x10c000c
	v_lshrrev_b32_e32 v39, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_dot2_f32_f16 v34, v54, v40, v34
	v_dot2_f32_f16 v33, v54, v44, v33
	v_lshrrev_b32_e32 v42, 1, v41
	v_and_b32_e32 v40, 0x80008000, v41
	v_perm_b32 v41, 0, v8, 0x30c020c
	v_and_or_b32 v38, 0x3f803f80, v39, v38
	v_dot2_f32_f16 v34, v37, v45, v34
	v_dot2_f32_f16 v33, v37, v49, v33
	v_and_or_b32 v37, 0x3f803f80, v42, v40
	v_lshrrev_b32_e32 v39, 1, v41
	v_and_b32_e32 v40, 0x80008000, v41
	v_dot2_f32_f16 v34, v38, v46, v34
	v_dot2_f32_f16 v33, v38, v50, v33
	v_dot2_f32_f16 v0, v55, v47, v0
	v_dot2_f32_f16 v35, v55, v51, v35
	v_and_or_b32 v38, 0x3f803f80, v39, v40
	v_dot2_f32_f16 v34, v37, v47, v34
	v_dot2_f32_f16 v33, v37, v51, v33
	v_or_b32_e32 v37, 32, v36
	v_dot2_f32_f16 v0, v56, v48, v0
	v_dot2_f32_f16 v35, v56, v52, v35
	v_dot2_f32_f16 v34, v38, v48, v34
	v_dot2_f32_f16 v33, v38, v52, v33
	s_mov_b32 s5, exec_lo
	v_cmpx_gt_i32_e64 s16, v37
	s_cbranch_execz .LBB69_58
; %bb.64:                               ;   in Loop: Header=BB69_60 Depth=1
	v_lshl_add_u32 v45, v37, 5, 0
	v_perm_b32 v46, 0, v9, 0x10c000c
	v_perm_b32 v49, 0, v9, 0x30c020c
	v_perm_b32 v50, 0, v10, 0x10c000c
	v_perm_b32 v52, 0, v10, 0x30c020c
	v_lshl_add_u32 v51, s17, 1, v45
	ds_load_b128 v[37:40], v45
	v_lshrrev_b32_e32 v58, 1, v46
	v_and_b32_e32 v59, 0x80008000, v46
	v_lshrrev_b32_e32 v60, 1, v49
	ds_load_b128 v[41:44], v51
	v_and_b32_e32 v49, 0x80008000, v49
	ds_load_b128 v[45:48], v45 offset:16
	v_and_or_b32 v58, 0x3f803f80, v58, v59
	v_lshrrev_b32_e32 v61, 1, v50
	v_and_b32_e32 v59, 0x80008000, v50
	v_lshrrev_b32_e32 v62, 1, v52
	v_and_b32_e32 v63, 0x80008000, v52
	v_and_or_b32 v60, 0x3f803f80, v60, v49
	ds_load_b128 v[49:52], v51 offset:16
	v_perm_b32 v53, 0, v11, 0x10c000c
	v_perm_b32 v54, 0, v11, 0x30c020c
	v_perm_b32 v56, 0, v12, 0x30c020c
	v_and_or_b32 v59, 0x3f803f80, v61, v59
	v_perm_b32 v55, 0, v12, 0x10c000c
	v_perm_b32 v57, 0, v13, 0x10c000c
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v0, v58, v37, v0
	v_lshrrev_b32_e32 v64, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_and_or_b32 v61, 0x3f803f80, v62, v63
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v35, v58, v41, v35
	v_dot2_f32_f16 v0, v60, v38, v0
	v_lshrrev_b32_e32 v58, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_and_or_b32 v53, 0x3f803f80, v64, v53
	v_dot2_f32_f16 v35, v60, v42, v35
	v_dot2_f32_f16 v0, v59, v39, v0
	v_lshrrev_b32_e32 v60, 1, v55
	v_and_b32_e32 v55, 0x80008000, v55
	v_and_or_b32 v54, 0x3f803f80, v58, v54
	v_dot2_f32_f16 v35, v59, v43, v35
	v_lshrrev_b32_e32 v59, 1, v56
	v_and_b32_e32 v56, 0x80008000, v56
	v_dot2_f32_f16 v0, v61, v40, v0
	v_perm_b32 v58, 0, v13, 0x30c020c
	v_dot2_f32_f16 v35, v61, v44, v35
	v_and_or_b32 v55, 0x3f803f80, v60, v55
	v_and_or_b32 v56, 0x3f803f80, v59, v56
	v_lshrrev_b32_e32 v59, 1, v57
	v_and_b32_e32 v57, 0x80008000, v57
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v53, v45, v0
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v35, v53, v49, v35
	v_perm_b32 v53, 0, v14, 0x10c000c
	v_lshrrev_b32_e32 v60, 1, v58
	v_and_b32_e32 v58, 0x80008000, v58
	v_and_or_b32 v57, 0x3f803f80, v59, v57
	v_dot2_f32_f16 v0, v54, v46, v0
	v_lshrrev_b32_e32 v61, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_dot2_f32_f16 v35, v54, v50, v35
	v_perm_b32 v54, 0, v14, 0x30c020c
	v_and_or_b32 v58, 0x3f803f80, v60, v58
	v_dot2_f32_f16 v34, v57, v37, v34
	v_dot2_f32_f16 v33, v57, v41, v33
	v_and_or_b32 v53, 0x3f803f80, v61, v53
	v_perm_b32 v59, 0, v15, 0x10c000c
	v_lshrrev_b32_e32 v60, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_dot2_f32_f16 v34, v58, v38, v34
	v_dot2_f32_f16 v33, v58, v42, v33
	v_lshrrev_b32_e32 v37, 1, v59
	v_and_b32_e32 v41, 0x80008000, v59
	v_and_or_b32 v54, 0x3f803f80, v60, v54
	v_perm_b32 v38, 0, v15, 0x30c020c
	v_dot2_f32_f16 v34, v53, v39, v34
	v_dot2_f32_f16 v33, v53, v43, v33
	v_and_or_b32 v37, 0x3f803f80, v37, v41
	v_perm_b32 v41, 0, v16, 0x10c000c
	v_lshrrev_b32_e32 v39, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_dot2_f32_f16 v34, v54, v40, v34
	v_dot2_f32_f16 v33, v54, v44, v33
	v_lshrrev_b32_e32 v42, 1, v41
	v_and_b32_e32 v40, 0x80008000, v41
	v_perm_b32 v41, 0, v16, 0x30c020c
	v_and_or_b32 v38, 0x3f803f80, v39, v38
	v_dot2_f32_f16 v34, v37, v45, v34
	v_dot2_f32_f16 v33, v37, v49, v33
	v_and_or_b32 v37, 0x3f803f80, v42, v40
	v_lshrrev_b32_e32 v39, 1, v41
	v_and_b32_e32 v40, 0x80008000, v41
	v_dot2_f32_f16 v34, v38, v46, v34
	v_dot2_f32_f16 v33, v38, v50, v33
	v_dot2_f32_f16 v0, v55, v47, v0
	v_dot2_f32_f16 v35, v55, v51, v35
	v_and_or_b32 v38, 0x3f803f80, v39, v40
	v_dot2_f32_f16 v34, v37, v47, v34
	v_dot2_f32_f16 v33, v37, v51, v33
	v_or_b32_e32 v37, 64, v36
	v_dot2_f32_f16 v0, v56, v48, v0
	v_dot2_f32_f16 v35, v56, v52, v35
	v_dot2_f32_f16 v34, v38, v48, v34
	v_dot2_f32_f16 v33, v38, v52, v33
	s_mov_b32 s8, exec_lo
	v_cmpx_gt_i32_e64 s16, v37
	s_cbranch_execz .LBB69_57
; %bb.65:                               ;   in Loop: Header=BB69_60 Depth=1
	v_lshl_add_u32 v45, v37, 5, 0
	v_perm_b32 v46, 0, v17, 0x10c000c
	v_perm_b32 v49, 0, v17, 0x30c020c
	v_perm_b32 v50, 0, v18, 0x10c000c
	v_perm_b32 v52, 0, v18, 0x30c020c
	v_lshl_add_u32 v51, s17, 1, v45
	ds_load_b128 v[37:40], v45
	v_lshrrev_b32_e32 v58, 1, v46
	v_and_b32_e32 v59, 0x80008000, v46
	v_lshrrev_b32_e32 v60, 1, v49
	ds_load_b128 v[41:44], v51
	v_and_b32_e32 v49, 0x80008000, v49
	ds_load_b128 v[45:48], v45 offset:16
	v_and_or_b32 v58, 0x3f803f80, v58, v59
	v_lshrrev_b32_e32 v61, 1, v50
	v_and_b32_e32 v59, 0x80008000, v50
	v_lshrrev_b32_e32 v62, 1, v52
	v_and_b32_e32 v63, 0x80008000, v52
	v_and_or_b32 v60, 0x3f803f80, v60, v49
	ds_load_b128 v[49:52], v51 offset:16
	v_perm_b32 v53, 0, v19, 0x10c000c
	v_perm_b32 v54, 0, v19, 0x30c020c
	v_perm_b32 v56, 0, v20, 0x30c020c
	v_and_or_b32 v59, 0x3f803f80, v61, v59
	v_perm_b32 v55, 0, v20, 0x10c000c
	v_perm_b32 v57, 0, v21, 0x10c000c
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v0, v58, v37, v0
	v_lshrrev_b32_e32 v64, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_and_or_b32 v61, 0x3f803f80, v62, v63
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v35, v58, v41, v35
	v_dot2_f32_f16 v0, v60, v38, v0
	v_lshrrev_b32_e32 v58, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_and_or_b32 v53, 0x3f803f80, v64, v53
	v_dot2_f32_f16 v35, v60, v42, v35
	v_dot2_f32_f16 v0, v59, v39, v0
	v_lshrrev_b32_e32 v60, 1, v55
	v_and_b32_e32 v55, 0x80008000, v55
	v_and_or_b32 v54, 0x3f803f80, v58, v54
	v_dot2_f32_f16 v35, v59, v43, v35
	v_lshrrev_b32_e32 v59, 1, v56
	v_and_b32_e32 v56, 0x80008000, v56
	v_dot2_f32_f16 v0, v61, v40, v0
	v_perm_b32 v58, 0, v21, 0x30c020c
	v_dot2_f32_f16 v35, v61, v44, v35
	v_and_or_b32 v55, 0x3f803f80, v60, v55
	v_and_or_b32 v56, 0x3f803f80, v59, v56
	v_lshrrev_b32_e32 v59, 1, v57
	v_and_b32_e32 v57, 0x80008000, v57
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v53, v45, v0
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v35, v53, v49, v35
	v_perm_b32 v53, 0, v22, 0x10c000c
	v_lshrrev_b32_e32 v60, 1, v58
	v_and_b32_e32 v58, 0x80008000, v58
	v_and_or_b32 v57, 0x3f803f80, v59, v57
	v_dot2_f32_f16 v0, v54, v46, v0
	v_lshrrev_b32_e32 v61, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_dot2_f32_f16 v35, v54, v50, v35
	v_perm_b32 v54, 0, v22, 0x30c020c
	v_and_or_b32 v58, 0x3f803f80, v60, v58
	v_dot2_f32_f16 v34, v57, v37, v34
	v_dot2_f32_f16 v33, v57, v41, v33
	v_and_or_b32 v53, 0x3f803f80, v61, v53
	v_perm_b32 v59, 0, v23, 0x10c000c
	v_lshrrev_b32_e32 v60, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_dot2_f32_f16 v34, v58, v38, v34
	v_dot2_f32_f16 v33, v58, v42, v33
	v_lshrrev_b32_e32 v37, 1, v59
	v_and_b32_e32 v41, 0x80008000, v59
	v_and_or_b32 v54, 0x3f803f80, v60, v54
	v_perm_b32 v38, 0, v23, 0x30c020c
	v_dot2_f32_f16 v34, v53, v39, v34
	v_dot2_f32_f16 v33, v53, v43, v33
	v_and_or_b32 v37, 0x3f803f80, v37, v41
	v_perm_b32 v41, 0, v24, 0x10c000c
	v_lshrrev_b32_e32 v39, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_dot2_f32_f16 v34, v54, v40, v34
	v_dot2_f32_f16 v33, v54, v44, v33
	v_lshrrev_b32_e32 v42, 1, v41
	v_and_b32_e32 v40, 0x80008000, v41
	v_perm_b32 v41, 0, v24, 0x30c020c
	v_and_or_b32 v38, 0x3f803f80, v39, v38
	v_dot2_f32_f16 v34, v37, v45, v34
	v_dot2_f32_f16 v33, v37, v49, v33
	v_and_or_b32 v37, 0x3f803f80, v42, v40
	v_lshrrev_b32_e32 v39, 1, v41
	v_and_b32_e32 v40, 0x80008000, v41
	v_dot2_f32_f16 v34, v38, v46, v34
	v_dot2_f32_f16 v33, v38, v50, v33
	v_dot2_f32_f16 v0, v55, v47, v0
	v_dot2_f32_f16 v35, v55, v51, v35
	v_and_or_b32 v38, 0x3f803f80, v39, v40
	v_dot2_f32_f16 v34, v37, v47, v34
	v_dot2_f32_f16 v33, v37, v51, v33
	v_or_b32_e32 v36, 0x60, v36
	v_dot2_f32_f16 v0, v56, v48, v0
	v_dot2_f32_f16 v35, v56, v52, v35
	v_dot2_f32_f16 v34, v38, v48, v34
	v_dot2_f32_f16 v33, v38, v52, v33
	s_mov_b32 s9, exec_lo
	v_cmpx_gt_i32_e64 s16, v36
	s_cbranch_execz .LBB69_56
; %bb.66:                               ;   in Loop: Header=BB69_60 Depth=1
	v_lshl_add_u32 v44, v36, 5, 0
	v_perm_b32 v45, 0, v25, 0x10c000c
	v_perm_b32 v48, 0, v25, 0x30c020c
	v_perm_b32 v49, 0, v26, 0x10c000c
	v_perm_b32 v51, 0, v26, 0x30c020c
	v_lshl_add_u32 v50, s17, 1, v44
	ds_load_b128 v[36:39], v44
	v_lshrrev_b32_e32 v57, 1, v45
	v_and_b32_e32 v58, 0x80008000, v45
	v_lshrrev_b32_e32 v59, 1, v48
	ds_load_b128 v[40:43], v50
	v_and_b32_e32 v48, 0x80008000, v48
	ds_load_b128 v[44:47], v44 offset:16
	v_and_or_b32 v57, 0x3f803f80, v57, v58
	v_lshrrev_b32_e32 v60, 1, v49
	v_and_b32_e32 v58, 0x80008000, v49
	v_lshrrev_b32_e32 v61, 1, v51
	v_and_b32_e32 v62, 0x80008000, v51
	v_and_or_b32 v59, 0x3f803f80, v59, v48
	ds_load_b128 v[48:51], v50 offset:16
	v_perm_b32 v52, 0, v27, 0x10c000c
	v_perm_b32 v53, 0, v27, 0x30c020c
	v_perm_b32 v55, 0, v28, 0x30c020c
	v_and_or_b32 v58, 0x3f803f80, v60, v58
	v_perm_b32 v54, 0, v28, 0x10c000c
	v_perm_b32 v56, 0, v29, 0x10c000c
	s_wait_dscnt 0x3
	v_dot2_f32_f16 v0, v57, v36, v0
	v_lshrrev_b32_e32 v63, 1, v52
	v_and_b32_e32 v52, 0x80008000, v52
	v_and_or_b32 v60, 0x3f803f80, v61, v62
	s_wait_dscnt 0x2
	v_dot2_f32_f16 v35, v57, v40, v35
	v_dot2_f32_f16 v0, v59, v37, v0
	v_lshrrev_b32_e32 v57, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_and_or_b32 v52, 0x3f803f80, v63, v52
	v_dot2_f32_f16 v35, v59, v41, v35
	v_dot2_f32_f16 v0, v58, v38, v0
	v_lshrrev_b32_e32 v59, 1, v54
	v_and_b32_e32 v54, 0x80008000, v54
	v_and_or_b32 v53, 0x3f803f80, v57, v53
	v_dot2_f32_f16 v35, v58, v42, v35
	v_lshrrev_b32_e32 v58, 1, v55
	v_and_b32_e32 v55, 0x80008000, v55
	v_dot2_f32_f16 v0, v60, v39, v0
	v_perm_b32 v57, 0, v29, 0x30c020c
	v_dot2_f32_f16 v35, v60, v43, v35
	v_and_or_b32 v54, 0x3f803f80, v59, v54
	v_and_or_b32 v55, 0x3f803f80, v58, v55
	v_lshrrev_b32_e32 v58, 1, v56
	v_and_b32_e32 v56, 0x80008000, v56
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v52, v44, v0
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v35, v52, v48, v35
	v_perm_b32 v52, 0, v30, 0x10c000c
	v_lshrrev_b32_e32 v59, 1, v57
	v_and_b32_e32 v57, 0x80008000, v57
	v_and_or_b32 v56, 0x3f803f80, v58, v56
	v_dot2_f32_f16 v0, v53, v45, v0
	v_lshrrev_b32_e32 v60, 1, v52
	v_and_b32_e32 v52, 0x80008000, v52
	v_dot2_f32_f16 v35, v53, v49, v35
	v_perm_b32 v53, 0, v30, 0x30c020c
	v_and_or_b32 v57, 0x3f803f80, v59, v57
	v_dot2_f32_f16 v34, v56, v36, v34
	v_dot2_f32_f16 v33, v56, v40, v33
	v_and_or_b32 v52, 0x3f803f80, v60, v52
	v_perm_b32 v58, 0, v31, 0x10c000c
	v_lshrrev_b32_e32 v59, 1, v53
	v_and_b32_e32 v53, 0x80008000, v53
	v_dot2_f32_f16 v34, v57, v37, v34
	v_dot2_f32_f16 v33, v57, v41, v33
	v_lshrrev_b32_e32 v36, 1, v58
	v_and_b32_e32 v40, 0x80008000, v58
	v_and_or_b32 v53, 0x3f803f80, v59, v53
	v_perm_b32 v37, 0, v31, 0x30c020c
	v_dot2_f32_f16 v34, v52, v38, v34
	v_dot2_f32_f16 v33, v52, v42, v33
	v_and_or_b32 v36, 0x3f803f80, v36, v40
	v_perm_b32 v40, 0, v32, 0x10c000c
	v_lshrrev_b32_e32 v38, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	v_dot2_f32_f16 v34, v53, v39, v34
	v_dot2_f32_f16 v33, v53, v43, v33
	v_lshrrev_b32_e32 v41, 1, v40
	v_and_b32_e32 v39, 0x80008000, v40
	v_perm_b32 v40, 0, v32, 0x30c020c
	v_and_or_b32 v37, 0x3f803f80, v38, v37
	v_dot2_f32_f16 v34, v36, v44, v34
	v_dot2_f32_f16 v33, v36, v48, v33
	v_and_or_b32 v36, 0x3f803f80, v41, v39
	v_lshrrev_b32_e32 v38, 1, v40
	v_and_b32_e32 v39, 0x80008000, v40
	v_dot2_f32_f16 v34, v37, v45, v34
	v_dot2_f32_f16 v33, v37, v49, v33
	v_dot2_f32_f16 v0, v54, v46, v0
	v_dot2_f32_f16 v35, v54, v50, v35
	v_and_or_b32 v37, 0x3f803f80, v38, v39
	v_dot2_f32_f16 v34, v36, v46, v34
	v_dot2_f32_f16 v33, v36, v50, v33
	v_dot2_f32_f16 v0, v55, v47, v0
	v_dot2_f32_f16 v35, v55, v51, v35
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v34, v37, v47, v34
	v_dot2_f32_f16 v33, v37, v51, v33
	s_branch .LBB69_56
.LBB69_67:
	s_wait_loadcnt 0x7
	v_mbcnt_lo_u32_b32 v1, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_xor_b32_e32 v2, 16, v1
	v_xor_b32_e32 v3, 8, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo
	v_lshlrev_b32_e32 v3, 2, v3
	v_lshlrev_b32_e32 v2, 2, v2
	ds_bpermute_b32 v4, v2, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v4
	v_xor_b32_e32 v4, 4, v1
	s_wait_loadcnt 0x6
	ds_bpermute_b32 v5, v3, v0
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v5
	v_xor_b32_e32 v5, 2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo
	v_lshlrev_b32_e32 v5, 2, v5
	v_lshlrev_b32_e32 v4, 2, v4
	ds_bpermute_b32 v6, v4, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v6
	v_xor_b32_e32 v6, 1, v1
	ds_bpermute_b32 v7, v5, v0
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo
	v_cmp_eq_u32_e32 vcc_lo, 0, v71
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_add_f32 v7, v0, v7 :: v_dual_lshlrev_b32 v6, 2, v1
	v_lshlrev_b64_e32 v[0:1], 1, v[65:66]
	ds_bpermute_b32 v8, v6, v7
	s_wait_kmcnt 0x0
	v_add_co_u32 v0, s0, s6, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v1, null, s7, v1, s0
	s_and_saveexec_b32 s3, vcc_lo
	s_cbranch_execz .LBB69_73
; %bb.68:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s1, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e64 s0, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s4, s0
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s4
; %bb.69:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.70:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.71:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.72:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	global_store_b16 v[0:1], v7, off
.LBB69_73:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v7, v2, v35
	s_mov_b32 s0, 0
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v35, v7
	ds_bpermute_b32 v8, v3, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v4, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v5, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v6, v7
	s_and_saveexec_b32 s3, vcc_lo
	s_cbranch_execz .LBB69_79
; %bb.74:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s1, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.75:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.76:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.77:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.78:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshl_b64 s[4:5], s[10:11], 1
	s_and_b32 s0, s2, exec_lo
	s_wait_alu 0xfffe
	v_add_co_u32 v8, vcc_lo, v0, s4
	s_wait_loadcnt 0x5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v9, null, s5, v1, vcc_lo
	global_store_b16 v[8:9], v7, off
.LBB69_79:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	ds_bpermute_b32 v7, v2, v34
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v34, v7
	ds_bpermute_b32 v8, v3, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v4, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v5, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v6, v7
	s_and_saveexec_b32 s2, s0
	s_cbranch_execz .LBB69_85
; %bb.80:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s1, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.81:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.82:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.83:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.84:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	global_store_b16 v[0:1], v7, off offset:2
.LBB69_85:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	ds_bpermute_b32 v2, v2, v33
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v33, v2
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v6, v2
	s_and_b32 exec_lo, exec_lo, s0
	s_cbranch_execz .LBB69_91
; %bb.86:
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, 0x47800000, v2
	v_mul_f32_e32 v3, s1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.87:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.88:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.89:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.90:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_lshl_b64 s[0:1], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v0, vcc_lo, v0, s0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo
	global_store_b16 v[0:1], v2, off offset:2
.LBB69_91:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 296
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 129
		.amdhsa_next_free_sgpr 23
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 200
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,"axG",@progbits,_ZN12_GLOBAL__N_115fp8_gemv_kernelILi2ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,comdat
.Lfunc_end69:
