_ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii: ; @_ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
; %bb.0:
	s_clause 0x2
	s_load_b64 s[14:15], s[0:1], 0x20
	s_load_b32 s3, s[0:1], 0x34
	s_load_b128 s[16:19], s[0:1], 0x0
	s_mov_b32 s2, ttmp9
	s_load_b64 s[10:11], s[0:1], 0x10
	v_and_b32_e32 v75, 31, v0
	s_wait_kmcnt 0x0
	s_ashr_i32 s6, s15, 31
	s_and_b32 s20, s3, 0xffff
	s_lshr_b32 s4, s6, 29
	s_ashr_i32 s5, s14, 31
	s_add_co_i32 s3, s15, s4
	s_mov_b32 s4, s14
	s_ashr_i32 s21, s3, 3
	s_mov_b32 s3, 0
	v_cmp_gt_i32_e64 s9, s21, v0
	s_lshl_b64 s[2:3], s[2:3], 4
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_mov_b32 v70, s3 :: v_dual_add_nc_u32 v41, s20, v0
	v_cndmask_b32_e64 v1, 0, v0, s9
	v_cmp_gt_i32_e64 s8, s21, v41
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshlrev_b32_e32 v1, 4, v1
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v2, 0, v41, s8
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v2, 4, v2
	s_clause 0x1
	global_load_b128 v[37:40], v1, s[16:17]
	global_load_b128 v[33:36], v2, s[16:17]
	v_lshrrev_b32_e32 v1, 4, v0
	v_mov_b32_e32 v2, s3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v69, v1, 14, s2
	v_or_b32_e32 v1, 1, v69
	v_cmp_gt_i64_e64 s7, s[4:5], v[69:70]
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_gt_i64_e64 s2, s[4:5], v[1:2]
	v_cndmask_b32_e64 v3, 0, v69, s7
	v_cndmask_b32_e64 v2, 0, s3, s7
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cndmask_b32_e64 v1, 0, v1, s2
	v_mul_lo_u32 v4, v3, s6
	v_mad_co_u64_u32 v[71:72], null, v3, s15, s[18:19]
	v_cndmask_b32_e64 v3, 0, s3, s2
	v_mul_lo_u32 v2, v2, s15
	v_mul_lo_u32 v5, v1, s6
	v_mad_co_u64_u32 v[73:74], null, v1, s15, s[18:19]
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_mul_lo_u32 v1, v3, s15
	s_lshr_b32 s3, s6, 28
	s_wait_alu 0xfffe
	s_add_co_i32 s3, s15, s3
	v_add3_u32 v72, v2, v72, v4
	s_wait_alu 0xfffe
	s_ashr_i32 s14, s3, 4
	s_delay_alu instid0(VALU_DEP_2)
	v_add3_u32 v74, v1, v74, v5
	; sched_barrier mask(0x00000000)
	s_wait_alu 0xfffe
	v_cmp_gt_i32_e64 s6, s14, v75
	v_or_b32_e32 v78, 32, v75
	v_or_b32_e32 v77, 64, v75
	v_or_b32_e32 v76, 0x60, v75
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v1, 0, v75, s6
	v_cmp_gt_i32_e64 s5, s14, v78
	v_cmp_gt_i32_e64 s4, s14, v77
	v_cmp_gt_i32_e64 s3, s14, v76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v3, 4, v1
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v5, 0, v78, s5
	v_cndmask_b32_e64 v8, 0, v76, s3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_co_u32 v1, vcc_lo, v71, v3
	v_add_co_ci_u32_e64 v2, null, 0, v72, vcc_lo
	v_add_co_u32 v3, vcc_lo, v73, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v74, vcc_lo
	s_clause 0x1
	global_load_b128 v[29:32], v[1:2], off th:TH_LOAD_NT
	global_load_b128 v[25:28], v[3:4], off th:TH_LOAD_NT
	v_cndmask_b32_e64 v3, 0, v77, s4
	v_lshlrev_b32_e32 v5, 4, v5
	v_lshlrev_b32_e32 v9, 4, v8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v7, 4, v3
	v_add_co_u32 v1, vcc_lo, v71, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v72, vcc_lo
	v_add_co_u32 v3, vcc_lo, v73, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v74, vcc_lo
	v_add_co_u32 v5, vcc_lo, v71, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v72, vcc_lo
	v_add_co_u32 v7, vcc_lo, v73, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, 0, v74, vcc_lo
	v_add_co_u32 v42, vcc_lo, v71, v9
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v43, null, 0, v72, vcc_lo
	v_add_co_u32 v44, vcc_lo, v73, v9
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v45, null, 0, v74, vcc_lo
	s_clause 0x5
	global_load_b128 v[21:24], v[1:2], off th:TH_LOAD_NT
	global_load_b128 v[17:20], v[3:4], off th:TH_LOAD_NT
	global_load_b128 v[13:16], v[5:6], off th:TH_LOAD_NT
	global_load_b128 v[9:12], v[7:8], off th:TH_LOAD_NT
	global_load_b128 v[5:8], v[42:43], off th:TH_LOAD_NT
	global_load_b128 v[1:4], v[44:45], off th:TH_LOAD_NT
	s_load_b64 s[18:19], s[10:11], 0x0
	v_mov_b32_e32 v42, 0
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s19, 0
	s_cselect_b32 s23, -1, 0
	s_cmp_ngt_f32 s19, 0
	s_cselect_b32 s22, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 vcc_lo, exec_lo, s22
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB57_14
; %bb.1:
	s_and_saveexec_b32 s10, s9
	s_cbranch_execnz .LBB57_15
.LBB57_2:
	s_or_b32 exec_lo, exec_lo, s10
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s23
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB57_16
.LBB57_3:
	s_and_saveexec_b32 s9, s8
	s_cbranch_execz .LBB57_5
.LBB57_4:
	s_wait_loadcnt 0x9
	v_lshl_add_u32 v37, v41, 4, 0
	s_wait_loadcnt 0x8
	ds_store_b128 v37, v[33:36]
.LBB57_5:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_load_b64 s[10:11], s[0:1], 0x18
	s_wait_loadcnt 0x9
	v_add_nc_u32_e32 v39, s20, v41
	s_mov_b32 s12, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s21, v39
	s_cbranch_execz .LBB57_10
; %bb.6:
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v33, 4, v39
	v_lshlrev_b32_e32 v0, 4, v0
	s_lshl_b32 s0, s20, 5
	s_mov_b32 s13, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_co_u32 v33, s1, s16, v33
	v_add_co_ci_u32_e64 v34, null, s17, 0, s1
	v_add3_u32 v0, 0, s0, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_add_co_u32 v37, vcc_lo, v33, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, 0, v34, vcc_lo
	s_lshl_b32 s16, s20, 4
	s_mov_b32 s17, 0xc3e00000
	s_branch .LBB57_8
.LBB57_7:                               ;   in Loop: Header=BB57_8 Depth=1
	v_add_nc_u32_e32 v39, s20, v39
	v_add_co_u32 v37, s0, v37, s16
	s_wait_loadcnt 0x0
	ds_store_b128 v0, v[33:36]
	v_add_nc_u32_e32 v0, s16, v0
	v_cmp_le_i32_e32 vcc_lo, s21, v39
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v38, s0
	s_or_b32 s13, vcc_lo, s13
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s13
	s_cbranch_execz .LBB57_10
.LBB57_8:                               ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[33:36], v[37:38], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s23
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB57_7
; %bb.9:                                ;   in Loop: Header=BB57_8 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v43, 16, v34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_div_scale_f32 v54, s1, v43, s19, v43
	v_lshlrev_b32_e32 v40, 16, v33
	v_and_b32_e32 v33, 0xffff0000, v33
	v_div_scale_f32 v47, null, s19, s19, v43
	v_div_scale_f32 v41, null, s19, s19, v40
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_scale_f32 v42, null, s19, s19, v33
	v_rcp_f32_e32 v50, v47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v45, v41
	v_div_scale_f32 v49, vcc_lo, v40, s19, v40
	v_rcp_f32_e32 v46, v42
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v51, -v41, v45, 1.0
	v_and_b32_e32 v34, 0xffff0000, v34
	v_fma_f32 v52, -v42, v46, 1.0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v45, v51, v45 :: v_dual_lshlrev_b32 v44, 16, v35
	v_div_scale_f32 v51, null, s19, s19, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v46, v52, v46
	v_div_scale_f32 v53, s0, v33, s19, v33
	v_fma_f32 v52, -v47, v50, 1.0
	v_mul_f32_e32 v55, v49, v45
	v_dual_mul_f32 v56, v53, v46 :: v_dual_and_b32 v35, 0xffff0000, v35
	v_div_scale_f32 v57, null, s19, s19, v44
	s_delay_alu instid0(VALU_DEP_3)
	v_fma_f32 v59, -v41, v55, v49
	v_fmac_f32_e32 v50, v52, v50
	v_lshlrev_b32_e32 v48, 16, v36
	v_fma_f32 v52, -v42, v56, v53
	v_rcp_f32_e32 v58, v51
	v_fmac_f32_e32 v55, v59, v45
	v_mul_f32_e32 v59, v54, v50
	v_div_scale_f32 v60, s8, v34, s19, v34
	v_fmac_f32_e32 v56, v52, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v41, -v41, v55, v49
	v_fma_f32 v49, -v47, v59, v54
	v_and_b32_e32 v36, 0xffff0000, v36
	v_rcp_f32_e32 v52, v57
	v_fma_f32 v42, -v42, v56, v53
	s_wait_alu 0xfffd
	v_div_fmas_f32 v41, v41, v45, v55
	v_div_scale_f32 v45, null, s19, s19, v35
	v_fmac_f32_e32 v59, v49, v50
	s_mov_b32 vcc_lo, s0
	s_delay_alu instid0(VALU_DEP_3)
	v_div_fixup_f32 v40, v41, s19, v40
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v46, v56
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v46, -v47, v59, v54
	v_rcp_f32_e32 v47, v45
	v_fma_f32 v41, -v57, v52, 1.0
	v_fma_f32 v61, -v51, v58, 1.0
	v_div_fixup_f32 v33, v42, s19, v33
	v_div_scale_f32 v55, null, s19, s19, v36
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v52, v41, v52
	v_div_scale_f32 v41, s0, v44, s19, v44
	v_med3_num_f32 v40, v40, s17, 0x43e00000
	v_fma_f32 v53, -v45, v47, 1.0
	v_med3_num_f32 v33, v33, s17, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v47, v53, v47
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v46, v50, v59
	s_mov_b32 vcc_lo, s8
	v_div_scale_f32 v50, null, s19, s19, v48
	v_div_scale_f32 v53, s1, v35, s19, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v43, v46, s19, v43
	v_mul_f32_e32 v46, v41, v52
	v_rcp_f32_e32 v54, v50
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v43, v43, s17, 0x43e00000
	v_fma_f32 v59, -v57, v46, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v46, v59, v52
	v_div_scale_f32 v59, s8, v36, s19, v36
	v_fmac_f32_e32 v58, v61, v58
	v_fma_f32 v56, -v50, v54, 1.0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v41, -v57, v46, v41
	v_mul_f32_e32 v42, v60, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v54, v56, v54
	v_div_scale_f32 v56, s9, v48, s19, v48
	v_fma_f32 v49, -v51, v42, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v42, v49, v58
	v_rcp_f32_e32 v49, v55
	v_fma_f32 v51, -v51, v42, v60
	v_mul_f32_e32 v60, v53, v47
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fmas_f32 v42, v51, v58, v42
	v_fma_f32 v51, -v45, v60, v53
	v_mul_f32_e32 v58, v56, v54
	s_delay_alu instid0(TRANS32_DEP_1)
	v_fma_f32 v61, -v55, v49, 1.0
	s_mov_b32 vcc_lo, s0
	v_div_fixup_f32 v34, v42, s19, v34
	v_fmac_f32_e32 v60, v51, v47
	v_fma_f32 v42, -v50, v58, v56
	v_fmac_f32_e32 v49, v61, v49
	s_wait_alu 0xfffe
	v_div_fmas_f32 v41, v41, v52, v46
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v45, -v45, v60, v53
	v_dual_fmac_f32 v58, v42, v54 :: v_dual_mul_f32 v51, v59, v49
	v_med3_num_f32 v34, v34, s17, 0x43e00000
	v_div_fixup_f32 v41, v41, s19, v44
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v45, v47, v60
	v_mov_b32_e32 v45, 0
	v_fma_f32 v46, -v55, v51, v59
	v_fma_f32 v44, -v50, v58, v56
	v_med3_num_f32 v41, v41, s17, 0x43e00000
	v_div_fixup_f32 v35, v42, s19, v35
	v_cvt_pk_fp8_f32 v45, v40, v33
	v_mov_b32_e32 v33, 0
	v_fmac_f32_e32 v51, v46, v49
	s_mov_b32 vcc_lo, s9
	v_med3_num_f32 v35, v35, s17, 0x43e00000
	v_cvt_pk_fp8_f32 v45, v43, v34 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v42, -v55, v51, v59
	v_cvt_pk_fp8_f32 v33, v41, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_perm_b32 v35, 0, v45, 0x30c020c
	v_perm_b32 v34, 0, v45, 0x10c000c
	v_lshrrev_b32_e32 v41, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	s_wait_alu 0xfffe
	v_div_fmas_f32 v44, v44, v54, v58
	s_mov_b32 vcc_lo, s8
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v49, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fixup_f32 v44, v44, s19, v48
	v_div_fixup_f32 v36, v42, s19, v36
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v40, v44, s17, 0x43e00000
	v_med3_num_f32 v36, v36, s17, 0x43e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v33, v40, v36 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v36, 1, v34
	v_and_b32_e32 v34, 0x80008000, v34
	v_perm_b32 v40, 0, v33, 0x10c000c
	v_perm_b32 v33, 0, v33, 0x30c020c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v42, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_lshrrev_b32_e32 v43, 1, v33
	v_and_b32_e32 v44, 0x80008000, v33
	v_and_or_b32 v33, 0x3f803f80, v36, v34
	v_and_or_b32 v34, 0x3f803f80, v41, v35
	v_and_or_b32 v35, 0x3f803f80, v42, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v36, 0x3f803f80, v43, v44
	s_branch .LBB57_7
.LBB57_10:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s0, s7
	s_cbranch_execz .LBB57_74
; %bb.11:
	s_and_b32 s0, s23, exec_lo
	s_cselect_b32 s0, s19, 1.0
	s_add_co_i32 s1, s14, 31
	s_mov_b32 s9, -1
	s_wait_alu 0xfffe
	s_ashr_i32 s7, s1, 31
	s_wait_alu 0xfffe
	s_lshr_b32 s7, s7, 27
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, s7
	s_wait_alu 0xfffe
	s_ashr_i32 s1, s1, 5
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, 3
	s_wait_alu 0xfffe
	s_lshr_b32 s7, s1, 30
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, s7
	s_wait_alu 0xfffe
	s_ashr_i32 s7, s1, 2
	s_cmp_gt_i32 s15, 15
	s_mul_f32 s1, s18, s0
	s_cselect_b32 s8, -1, 0
	s_and_b32 vcc_lo, exec_lo, s22
	s_wait_alu 0xfffe
	v_cndmask_b32_e64 v0, 0, 1, s8
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_ne_u32_e64 s0, 1, v0
	s_cbranch_vccz .LBB57_41
; %bb.12:
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v0, 0
	s_and_b32 vcc_lo, exec_lo, s0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB57_28
; %bb.13:
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v79, 0
	v_dual_mov_b32 v41, v21 :: v_dual_mov_b32 v36, v32
	v_dual_mov_b32 v35, v31 :: v_dual_mov_b32 v34, v30
	v_dual_mov_b32 v33, v29 :: v_dual_mov_b32 v42, v22
	v_dual_mov_b32 v43, v23 :: v_dual_mov_b32 v44, v24
	v_dual_mov_b32 v45, v13 :: v_dual_mov_b32 v46, v14
	v_dual_mov_b32 v47, v15 :: v_dual_mov_b32 v48, v16
	v_dual_mov_b32 v49, v5 :: v_dual_mov_b32 v50, v6
	v_dual_mov_b32 v51, v7 :: v_dual_mov_b32 v52, v8
	v_dual_mov_b32 v37, v25 :: v_dual_mov_b32 v38, v26
	v_dual_mov_b32 v39, v27 :: v_dual_mov_b32 v40, v28
	v_dual_mov_b32 v53, v17 :: v_dual_mov_b32 v54, v18
	v_dual_mov_b32 v55, v19 :: v_dual_mov_b32 v56, v20
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v58, v10
	v_dual_mov_b32 v59, v11 :: v_dual_mov_b32 v60, v12
	v_dual_mov_b32 v61, v1 :: v_dual_mov_b32 v62, v2
	v_dual_mov_b32 v63, v3 :: v_dual_mov_b32 v64, v4
	s_max_i32 s0, s7, 1
	s_mov_b32 s9, 0
	s_wait_alu 0xfffe
	s_lshl_b32 s0, s0, 7
	s_branch .LBB57_21
.LBB57_14:
	s_wait_loadcnt 0x9
	v_lshlrev_b32_e32 v44, 16, v38
	v_lshlrev_b32_e32 v43, 16, v37
	s_mov_b32 s24, 0xc3e00000
	v_lshlrev_b32_e32 v62, 16, v40
	v_and_b32_e32 v40, 0xffff0000, v40
	v_div_scale_f32 v47, null, s19, s19, v44
	v_div_scale_f32 v45, null, s19, s19, v43
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_rcp_f32_e32 v50, v47
	v_rcp_f32_e32 v48, v45
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v57, -v47, v50, 1.0
	v_and_b32_e32 v37, 0xffff0000, v37
	v_fma_f32 v54, -v45, v48, 1.0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v50, v57, v50
	v_div_scale_f32 v46, null, s19, s19, v37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v48, v54, v48
	v_div_scale_f32 v52, vcc_lo, v43, s19, v43
	v_rcp_f32_e32 v49, v46
	v_and_b32_e32 v38, 0xffff0000, v38
	v_div_scale_f32 v53, s10, v37, s19, v37
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v55, -v46, v49, 1.0
	v_fmac_f32_e32 v49, v55, v49
	v_div_scale_f32 v56, s11, v44, s19, v44
	v_mul_f32_e32 v55, v52, v48
	v_div_scale_f32 v54, null, s19, s19, v38
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v59, v56, v50
	v_mul_f32_e32 v57, v53, v49
	v_fma_f32 v60, -v45, v55, v52
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_rcp_f32_e32 v58, v54
	v_fma_f32 v63, -v47, v59, v56
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v61, -v46, v57, v53
	v_fmac_f32_e32 v55, v60, v48
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v59, v63, v50
	v_fma_f32 v45, -v45, v55, v52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_fma_f32 v60, -v54, v58, 1.0
	v_lshlrev_b32_e32 v51, 16, v39
	v_fma_f32 v47, -v47, v59, v56
	v_div_scale_f32 v52, s12, v38, s19, v38
	s_wait_alu 0xfffd
	v_div_fmas_f32 v45, v45, v48, v55
	s_mov_b32 vcc_lo, s10
	v_fmac_f32_e32 v58, v60, v58
	v_div_scale_f32 v56, s10, v51, s19, v51
	v_fmac_f32_e32 v57, v61, v49
	v_div_fixup_f32 v43, v45, s19, v43
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v46, -v46, v57, v53
	v_div_scale_f32 v53, null, s19, s19, v51
	v_med3_num_f32 v43, v43, s24, 0x43e00000
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fmas_f32 v46, v46, v49, v57
	v_rcp_f32_e32 v48, v53
	s_mov_b32 vcc_lo, s11
	v_div_scale_f32 v57, null, s19, s19, v40
	s_delay_alu instid0(VALU_DEP_2)
	v_div_fixup_f32 v37, v46, s19, v37
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v47, v50, v59
	v_div_scale_f32 v50, null, s19, s19, v62
	v_rcp_f32_e32 v60, v57
	s_mov_b32 vcc_lo, s12
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_fma_f32 v47, -v53, v48, 1.0
	v_and_b32_e32 v39, 0xffff0000, v39
	v_div_fixup_f32 v44, v46, s19, v44
	v_med3_num_f32 v37, v37, s24, 0x43e00000
	v_fmac_f32_e32 v48, v47, v48
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)
	v_div_scale_f32 v49, null, s19, s19, v39
	v_rcp_f32_e32 v47, v50
	v_fma_f32 v63, -v57, v60, 1.0
	v_med3_num_f32 v44, v44, s24, 0x43e00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v55, v49
	v_fmac_f32_e32 v60, v63, v60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v59, -v49, v55, 1.0
	v_fmac_f32_e32 v55, v59, v55
	v_div_scale_f32 v59, s11, v39, s19, v39
	v_mul_f32_e32 v45, v52, v58
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v46, -v54, v45, v52
	v_dual_fmac_f32 v45, v46, v58 :: v_dual_mul_f32 v46, v56, v48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v52, -v54, v45, v52
	v_fma_f32 v54, -v50, v47, 1.0
	v_fma_f32 v61, -v53, v46, v56
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fmas_f32 v45, v52, v58, v45
	v_fmac_f32_e32 v47, v54, v47
	v_div_scale_f32 v54, s13, v62, s19, v62
	v_fmac_f32_e32 v46, v61, v48
	v_mul_f32_e32 v52, v59, v55
	v_div_scale_f32 v61, s12, v40, s19, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v58, v54, v47
	v_div_fixup_f32 v38, v45, s19, v38
	v_fma_f32 v45, -v53, v46, v56
	v_fma_f32 v53, -v49, v52, v59
	s_mov_b32 vcc_lo, s10
	v_fma_f32 v56, -v50, v58, v54
	v_mul_f32_e32 v63, v61, v60
	s_wait_alu 0xfffe
	v_div_fmas_f32 v45, v45, v48, v46
	s_mov_b32 vcc_lo, s11
	v_med3_num_f32 v38, v38, s24, 0x43e00000
	v_fmac_f32_e32 v58, v56, v47
	v_fma_f32 v46, -v57, v63, v61
	v_fmac_f32_e32 v52, v53, v55
	v_div_fixup_f32 v45, v45, s19, v51
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v63, v46, v60
	v_fma_f32 v48, -v49, v52, v59
	v_fma_f32 v46, -v50, v58, v54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_med3_num_f32 v45, v45, s24, 0x43e00000
	v_fma_f32 v49, -v57, v63, v61
	s_wait_alu 0xfffe
	v_div_fmas_f32 v48, v48, v55, v52
	s_mov_b32 vcc_lo, s13
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v46, v47, v58
	s_mov_b32 vcc_lo, s12
	v_div_fixup_f32 v39, v48, s19, v39
	s_wait_alu 0xfffe
	v_div_fmas_f32 v47, v49, v60, v63
	v_mov_b32_e32 v49, 0
	v_div_fixup_f32 v46, v46, s19, v62
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fixup_f32 v40, v47, s19, v40
	v_cvt_pk_fp8_f32 v49, v43, v37
	v_med3_num_f32 v37, v39, s24, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_med3_num_f32 v39, v46, s24, 0x43e00000
	v_med3_num_f32 v40, v40, s24, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_pk_fp8_f32 v49, v44, v38 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v42, v45, v37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_perm_b32 v37, 0, v49, 0x10c000c
	v_cvt_pk_fp8_f32 v42, v39, v40 op_sel:[0,0,1]
	v_perm_b32 v38, 0, v49, 0x30c020c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v39, 1, v37
	v_perm_b32 v40, 0, v42, 0x10c000c
	v_perm_b32 v42, 0, v42, 0x30c020c
	v_and_b32_e32 v37, 0x80008000, v37
	v_lshrrev_b32_e32 v43, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_lshrrev_b32_e32 v44, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_lshrrev_b32_e32 v45, 1, v42
	v_and_b32_e32 v42, 0x80008000, v42
	v_and_or_b32 v37, 0x3f803f80, v39, v37
	v_and_or_b32 v38, 0x3f803f80, v43, v38
	v_and_or_b32 v39, 0x3f803f80, v44, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v40, 0x3f803f80, v45, v42
	s_and_saveexec_b32 s10, s9
	s_cbranch_execz .LBB57_2
.LBB57_15:
	v_lshl_add_u32 v42, v0, 4, 0
	s_wait_loadcnt 0x9
	ds_store_b128 v42, v[37:40]
	s_or_b32 exec_lo, exec_lo, s10
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s23
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB57_3
.LBB57_16:
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v37, 16, v33
	v_lshlrev_b32_e32 v44, 16, v35
	s_mov_b32 s13, 0xc3e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v38, null, s19, s19, v37
	v_rcp_f32_e32 v42, v38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v48, -v38, v42, 1.0
	v_fmac_f32_e32 v42, v48, v42
	v_div_scale_f32 v50, vcc_lo, v37, s19, v37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v52, v50, v42 :: v_dual_and_b32 v33, 0xffff0000, v33
	v_div_scale_f32 v39, null, s19, s19, v33
	v_div_scale_f32 v51, s9, v33, s19, v33
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v43, v39
	v_fma_f32 v49, -v39, v43, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v43, v49, v43 :: v_dual_lshlrev_b32 v40, 16, v34
	v_div_scale_f32 v45, null, s19, s19, v40
	v_and_b32_e32 v34, 0xffff0000, v34
	v_div_scale_f32 v54, s10, v40, s19, v40
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_rcp_f32_e32 v47, v45
	v_mul_f32_e32 v53, v51, v43
	v_div_scale_f32 v48, null, s19, s19, v34
	v_div_scale_f32 v57, s11, v34, s19, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v56, -v39, v53, v51
	v_rcp_f32_e32 v55, v48
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fma_f32 v49, -v45, v47, 1.0
	v_lshlrev_b32_e32 v46, 16, v36
	v_dual_fmac_f32 v53, v56, v43 :: v_dual_and_b32 v36, 0xffff0000, v36
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v47, v49, v47
	v_fma_f32 v49, -v38, v52, v50
	v_and_b32_e32 v35, 0xffff0000, v35
	v_fma_f32 v39, -v39, v53, v51
	v_div_scale_f32 v51, null, s19, s19, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v52, v49, v42
	v_div_scale_f32 v49, null, s19, s19, v44
	v_fma_f32 v56, -v48, v55, 1.0
	v_fma_f32 v38, -v38, v52, v50
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_div_fmas_f32 v38, v38, v42, v52
	s_mov_b32 vcc_lo, s9
	v_rcp_f32_e32 v42, v49
	s_wait_alu 0xfffe
	v_div_fmas_f32 v39, v39, v43, v53
	v_rcp_f32_e32 v53, v51
	v_fmac_f32_e32 v55, v56, v55
	v_div_fixup_f32 v37, v38, s19, v37
	v_div_scale_f32 v38, null, s19, s19, v35
	v_div_fixup_f32 v33, v39, s19, v33
	s_mov_b32 vcc_lo, s10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_med3_num_f32 v37, v37, s13, 0x43e00000
	v_fma_f32 v56, -v51, v53, 1.0
	v_mul_f32_e32 v58, v54, v47
	v_med3_num_f32 v33, v33, s13, 0x43e00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v53, v56, v53
	v_fma_f32 v50, -v45, v58, v54
	v_div_scale_f32 v56, s12, v46, s19, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v58, v50, v47
	v_rcp_f32_e32 v50, v38
	v_fma_f32 v43, -v45, v58, v54
	v_fma_f32 v45, -v49, v42, 1.0
	v_div_scale_f32 v54, null, s19, s19, v36
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fmas_f32 v43, v43, v47, v58
	v_fmac_f32_e32 v42, v45, v42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_fma_f32 v52, -v38, v50, 1.0
	v_mul_f32_e32 v39, v57, v55
	v_div_scale_f32 v45, s9, v44, s19, v44
	v_div_fixup_f32 v40, v43, s19, v40
	v_fmac_f32_e32 v50, v52, v50
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fma_f32 v47, -v48, v39, v57
	v_div_scale_f32 v52, s10, v35, s19, v35
	v_mul_f32_e32 v43, v45, v42
	s_mov_b32 vcc_lo, s11
	v_dual_fmac_f32 v39, v47, v55 :: v_dual_mul_f32 v58, v52, v50
	v_rcp_f32_e32 v47, v54
	v_med3_num_f32 v40, v40, s13, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fma_f32 v48, -v48, v39, v57
	v_fma_f32 v57, -v49, v43, v45
	s_wait_alu 0xfffe
	v_div_fmas_f32 v39, v48, v55, v39
	v_fma_f32 v48, -v38, v58, v52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fma_f32 v59, -v54, v47, 1.0
	v_fmac_f32_e32 v43, v57, v42
	v_div_scale_f32 v57, s11, v36, s19, v36
	v_dual_fmac_f32 v58, v48, v50 :: v_dual_fmac_f32 v47, v59, v47
	v_mul_f32_e32 v55, v56, v53
	v_div_fixup_f32 v34, v39, s19, v34
	v_fma_f32 v39, -v49, v43, v45
	s_mov_b32 vcc_lo, s9
	v_mul_f32_e32 v48, v57, v47
	v_fma_f32 v45, -v51, v55, v56
	v_fma_f32 v38, -v38, v58, v52
	s_wait_alu 0xfffe
	v_div_fmas_f32 v39, v39, v42, v43
	s_mov_b32 vcc_lo, s10
	v_fma_f32 v42, -v54, v48, v57
	v_fmac_f32_e32 v55, v45, v53
	s_wait_alu 0xfffe
	v_div_fmas_f32 v38, v38, v50, v58
	s_mov_b32 vcc_lo, s12
	v_div_fixup_f32 v39, v39, s19, v44
	v_fmac_f32_e32 v48, v42, v47
	v_fma_f32 v42, -v51, v55, v56
	v_div_fixup_f32 v35, v38, s19, v35
	v_mov_b32_e32 v43, 0
	v_med3_num_f32 v39, v39, s13, 0x43e00000
	v_fma_f32 v38, -v54, v48, v57
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v53, v55
	s_mov_b32 vcc_lo, s11
	v_med3_num_f32 v35, v35, s13, 0x43e00000
	v_cvt_pk_fp8_f32 v43, v37, v33
	s_wait_alu 0xfffe
	v_div_fmas_f32 v38, v38, v47, v48
	v_div_fixup_f32 v42, v42, s19, v46
	v_mov_b32_e32 v33, 0
	v_med3_num_f32 v34, v34, s13, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v36, v38, s19, v36
	v_med3_num_f32 v37, v42, s13, 0x43e00000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_pk_fp8_f32 v33, v39, v35
	v_cvt_pk_fp8_f32 v43, v40, v34 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v36, v36, s13, 0x43e00000
	v_perm_b32 v34, 0, v43, 0x10c000c
	v_perm_b32 v35, 0, v43, 0x30c020c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v33, v37, v36 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v36, 1, v34
	v_and_b32_e32 v34, 0x80008000, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_perm_b32 v37, 0, v33, 0x10c000c
	v_perm_b32 v33, 0, v33, 0x30c020c
	v_lshrrev_b32_e32 v38, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	v_lshrrev_b32_e32 v39, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	v_lshrrev_b32_e32 v40, 1, v33
	v_and_b32_e32 v42, 0x80008000, v33
	v_and_or_b32 v33, 0x3f803f80, v36, v34
	v_and_or_b32 v34, 0x3f803f80, v38, v35
	v_and_or_b32 v35, 0x3f803f80, v39, v37
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v36, 0x3f803f80, v40, v42
	s_and_saveexec_b32 s9, s8
	s_cbranch_execnz .LBB57_4
	s_branch .LBB57_5
.LBB57_17:                              ;   in Loop: Header=BB57_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
.LBB57_18:                              ;   in Loop: Header=BB57_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s16
.LBB57_19:                              ;   in Loop: Header=BB57_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
.LBB57_20:                              ;   in Loop: Header=BB57_21 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	s_addk_co_i32 s9, 0x80
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s0, s9
	s_cbranch_scc0 .LBB57_28
.LBB57_21:                              ; =>This Inner Loop Header: Depth=1
	s_cmp_eq_u32 s9, 0
	s_mov_b32 s12, 0
	s_cbranch_scc1 .LBB57_23
; %bb.22:                               ;   in Loop: Header=BB57_21 Depth=1
	s_wait_loadcnt 0x5
	v_add_nc_u32_e32 v42, s9, v75
	s_mov_b32 s12, s9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, s14, v42
	v_add_nc_u32_e32 v35, 32, v42
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v33, 0, v42, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s14, v35
	v_add_nc_u32_e32 v36, 64, v42
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_ashrrev_i32_e32 v34, 31, v33
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v35, 0, v35, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s14, v36
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[33:34], 4, v[33:34]
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v41, 0, v36, vcc_lo
	v_ashrrev_i32_e32 v36, 31, v35
	s_wait_loadcnt 0x3
	v_add_nc_u32_e32 v47, 0x60, v42
	v_add_co_u32 v37, vcc_lo, v71, v33
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b64_e32 v[43:44], 4, v[35:36]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, v72, v34, vcc_lo
	v_add_co_u32 v39, vcc_lo, v73, v33
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v40, null, v74, v34, vcc_lo
	v_add_co_u32 v45, vcc_lo, v71, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v46, null, v72, v44, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s14, v47
	v_ashrrev_i32_e32 v42, 31, v41
	s_clause 0x1
	global_load_b128 v[33:36], v[37:38], off th:TH_LOAD_NT
	global_load_b128 v[37:40], v[39:40], off th:TH_LOAD_NT
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v47, 0, v47, vcc_lo
	v_lshlrev_b64_e32 v[41:42], 4, v[41:42]
	s_wait_loadcnt 0x3
	v_add_co_u32 v49, vcc_lo, v73, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v50, null, v74, v44, vcc_lo
	v_ashrrev_i32_e32 v48, 31, v47
	v_add_co_u32 v51, vcc_lo, v71, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v52, null, v72, v42, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshlrev_b64_e32 v[43:44], 4, v[47:48]
	v_add_co_u32 v57, vcc_lo, v73, v41
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v58, null, v74, v42, vcc_lo
	s_wait_loadcnt 0x2
	v_add_co_u32 v61, vcc_lo, v71, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v62, null, v72, v44, vcc_lo
	v_add_co_u32 v63, vcc_lo, v73, v43
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v64, null, v74, v44, vcc_lo
	s_clause 0x5
	global_load_b128 v[41:44], v[45:46], off th:TH_LOAD_NT
	global_load_b128 v[53:56], v[49:50], off th:TH_LOAD_NT
	global_load_b128 v[45:48], v[51:52], off th:TH_LOAD_NT
	global_load_b128 v[57:60], v[57:58], off th:TH_LOAD_NT
	global_load_b128 v[49:52], v[61:62], off th:TH_LOAD_NT
	global_load_b128 v[61:64], v[63:64], off th:TH_LOAD_NT
.LBB57_23:                              ;   in Loop: Header=BB57_21 Depth=1
	s_wait_alu 0xfffe
	v_or_b32_e32 v80, s12, v75
	s_mov_b32 s12, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s14, v80
	s_cbranch_execz .LBB57_20
; %bb.24:                               ;   in Loop: Header=BB57_21 Depth=1
	v_lshl_add_u32 v65, v80, 5, 0
	s_wait_loadcnt 0x7
	v_bfe_u32 v98, v33, 8, 3
	v_and_b32_e32 v108, 0x7f, v36
	v_and_b32_e32 v97, 0x7f, v33
	v_bfe_u32 v101, v34, 8, 7
	ds_load_b128 v[93:96], v65
	ds_load_b128 v[65:68], v65 offset:16
	v_lshl_add_u32 v109, v108, 20, 0x3c000000
	v_lshl_add_u32 v82, v97, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	v_bfe_u32 v102, v34, 16, 3
	v_lshlrev_b32_e32 v103, 16, v34
	v_and_b32_e32 v105, 0x7f, v35
	v_bfe_u32 v106, v35, 8, 7
	s_wait_loadcnt 0x6
	v_bfe_u32 v111, v39, 8, 3
	s_mov_b32 s13, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v111, v111
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v91, 16, v94
	v_and_b32_e32 v90, 0xffff0000, v94
	v_cvt_f32_ubyte0_e32 v94, v98
	v_and_b32_e32 v81, 7, v33
	v_lshlrev_b32_e32 v87, 16, v96
	v_and_b32_e32 v86, 0xffff0000, v96
	v_bfe_u32 v96, v33, 16, 3
	v_mul_f32_e32 v94, 0x3b000000, v94
	v_cvt_f32_ubyte0_e32 v81, v81
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v83, 16, v66
	v_and_b32_e32 v88, 0xffff0000, v95
	v_cvt_f32_ubyte0_e32 v96, v96
	v_and_b32_e32 v92, 0xffff0000, v93
	v_mul_f32_e32 v81, 0x3b000000, v81
	v_lshlrev_b32_e32 v98, 24, v33
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v96, 0x3b000000, v96 :: v_dual_lshlrev_b32 v89, 16, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v81, v82, vcc_lo
	v_and_b32_e32 v82, 0xffff0000, v66
	v_lshlrev_b32_e32 v81, 16, v67
	v_and_b32_e32 v66, 0xffff0000, v67
	v_lshlrev_b32_e32 v67, 16, v93
	v_bfe_u32 v93, v33, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v97, v93, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v93
	v_bfe_u32 v99, v33, 16, 7
	v_and_or_b32 v95, 0x80000000, v98, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v94, v97, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v93
	v_lshl_add_u32 v97, v99, 20, 0x3c000000
	v_bfe_u32 v98, v33, 24, 7
	v_fma_f32 v95, v95, v67, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v94, vcc_lo
	v_bfe_u32 v94, v33, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_lshl_add_u32 v100, v98, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v94, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v96, v97, vcc_lo
	v_lshlrev_b32_e32 v97, 16, v33
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_lshlrev_b32_e32 v85, 16, v65
	v_dual_mul_f32 v94, 0x3b000000, v94 :: v_dual_lshlrev_b32 v99, 8, v33
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v97, v93
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v96, 0x7fc00000, v96 :: v_dual_and_b32 v97, 7, v34
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	v_dual_fmac_f32 v95, v93, v92 :: v_dual_and_b32 v84, 0xffff0000, v65
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v96, 0x80000000, v99, v96
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v94, v94, v100 :: v_dual_and_b32 v99, 0x7f, v34
	v_cvt_f32_ubyte0_e32 v97, v97
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_bfe_u32 v100, v34, 8, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v98, v99, 20, 0x3c000000
	v_fmac_f32_e32 v95, v96, v91
	v_mul_f32_e32 v97, 0x3b000000, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v94, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_cvt_f32_ubyte0_e32 v100, v100
	v_lshlrev_b32_e32 v96, 24, v36
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v94, 0x80000000, v33, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, v97, v98, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_lshl_add_u32 v98, v101, 20, 0x3c000000
	v_mul_f32_e32 v100, 0x3b000000, v100
	v_bfe_u32 v99, v34, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, 0x7fc00000, v97, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v98, v100, v98 :: v_dual_lshlrev_b32 v65, 16, v68
	v_cvt_f32_ubyte0_e32 v100, v102
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_lshl_add_u32 v101, v99, 20, 0x3c000000
	v_lshlrev_b32_e32 v102, 24, v34
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, 0x7fc00000, v98, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_and_or_b32 v98, 0x80000000, v103, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v101, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_bfe_u32 v101, v34, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_cndmask_b32 v99, 0x7fc00000, v100 :: v_dual_lshlrev_b32 v100, 8, v34
	v_and_or_b32 v97, 0x80000000, v102, v97
	v_bfe_u32 v102, v34, 24, 3
	v_lshl_add_u32 v104, v101, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_and_or_b32 v99, 0x80000000, v100, v99
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v102, v102
	v_mul_f32_e32 v102, 0x3b000000, v102
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v102, v102, v104, vcc_lo
	v_bfe_u32 v104, v35, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v102, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v102, v104
	v_and_b32_e32 v103, 7, v35
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_bfe_u32 v104, v35, 16, 3
	v_and_or_b32 v101, 0x80000000, v34, v101
	v_mul_f32_e32 v102, 0x3b000000, v102
	v_cvt_f32_ubyte0_e32 v100, v103
	v_lshl_add_u32 v103, v105, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v104, v104
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_bfe_u32 v105, v35, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, v102, v103, vcc_lo
	v_lshlrev_b32_e32 v103, 24, v35
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshlrev_b32_e32 v106, 16, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v100, 0x80000000, v103, v100
	v_bfe_u32 v103, v35, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_cvt_f32_ubyte0_e32 v103, v103
	v_mul_f32_e32 v104, 0x3b000000, v104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v102, 0x80000000, v106, v102
	v_lshlrev_b32_e32 v106, 8, v35
	v_mul_f32_e32 v103, 0x3b000000, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v104, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_and_b32_e32 v105, 7, v36
	v_bfe_u32 v107, v35, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v105, v105
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v104, 0x80000000, v106, v104
	v_lshl_add_u32 v106, v107, 20, 0x3c000000
	v_mul_f32_e32 v105, 0x3b000000, v105
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v103, v103, v106, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_bfe_u32 v106, v36, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v109, vcc_lo
	v_fmac_f32_e32 v95, v94, v90
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v95, v97, v89
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_bfe_u32 v97, v36, 16, 7
	v_dual_fmac_f32 v95, v98, v88 :: v_dual_lshlrev_b32 v108, 8, v38
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v105, vcc_lo
	v_bfe_u32 v105, v36, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	v_fmac_f32_e32 v95, v99, v87
	v_bfe_u32 v99, v36, 24, 3
	v_lshl_add_u32 v98, v97, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v105, v105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v95, v101, v86
	v_cvt_f32_ubyte0_e32 v99, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_dual_fmac_f32 v95, v100, v85 :: v_dual_lshlrev_b32 v100, 8, v36
	v_and_or_b32 v94, 0x80000000, v96, v103
	v_bfe_u32 v96, v36, 16, 3
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_mul_f32_e32 v99, 0x3b000000, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v96, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, v105, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_and_b32_e32 v105, 0x7f, v38
	v_bfe_u32 v106, v38, 8, 7
	v_mul_f32_e32 v96, 0x3b000000, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v96, v98, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_bfe_u32 v97, v36, 24, 7
	v_lshlrev_b32_e32 v98, 16, v36
	v_and_or_b32 v93, 0x80000000, v35, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, 0x7fc00000, v96, vcc_lo
	v_lshl_add_u32 v101, v97, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v96, 0x80000000, v100, v96
	v_and_b32_e32 v100, 7, v37
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v99, v101, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_and_b32_e32 v101, 0x7f, v37
	v_cvt_f32_ubyte0_e32 v100, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, 0x7fc00000, v99, vcc_lo
	v_bfe_u32 v99, v37, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v99, v99
	v_mul_f32_e32 v99, 0x3b000000, v99
	v_fmac_f32_e32 v95, v102, v84
	v_bfe_u32 v102, v37, 8, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v95, v104, v83
	v_fmac_f32_e32 v95, v93, v82
	v_lshl_add_u32 v93, v101, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v95, v94, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v100, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_lshl_add_u32 v94, v102, 20, 0x3c000000
	v_bfe_u32 v100, v37, 16, 3
	v_lshlrev_b32_e32 v101, 24, v37
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v93, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_cvt_f32_ubyte0_e32 v100, v100
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v101, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v99, v94, vcc_lo
	v_bfe_u32 v99, v37, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_mul_f32_e32 v100, 0x3b000000, v100
	v_bfe_u32 v101, v37, 24, 3
	v_fma_f32 v67, v93, v67, 0
	v_lshl_add_u32 v102, v99, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v94, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_cvt_f32_ubyte0_e32 v101, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v102, vcc_lo
	v_bfe_u32 v102, v37, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_mul_f32_e32 v101, 0x3b000000, v101
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v104, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_lshlrev_b32_e32 v100, 8, v37
	v_and_or_b32 v98, 0x80000000, v98, v103
	v_lshlrev_b32_e32 v103, 16, v37
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, v101, v104, vcc_lo
	v_bfe_u32 v104, v38, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_and_or_b32 v94, 0x80000000, v103, v94
	v_and_or_b32 v99, 0x80000000, v100, v99
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v102, v104
	v_bfe_u32 v104, v38, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v101, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_dual_fmac_f32 v67, v94, v92 :: v_dual_mul_f32 v102, 0x3b000000, v102
	v_cvt_f32_ubyte0_e32 v104, v104
	v_lshlrev_b32_e32 v94, 8, v39
	v_and_or_b32 v101, 0x80000000, v37, v101
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v99, v91
	v_and_b32_e32 v99, 0x7f, v40
	v_dual_mul_f32 v104, 0x3b000000, v104 :: v_dual_and_b32 v103, 7, v38
	v_fmac_f32_e32 v67, v101, v90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v100, v103
	v_lshl_add_u32 v103, v105, 20, 0x3c000000
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v100, v100, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_bfe_u32 v105, v38, 16, 7
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v98, v66 :: v_dual_cndmask_b32 v100, 0x7fc00000, v100
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v96, v65 :: v_dual_cndmask_b32 v102, v102, v103
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshlrev_b32_e32 v106, 16, v38
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_and_or_b32 v102, 0x80000000, v106, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v104, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshlrev_b32_e32 v103, 24, v38
	v_and_b32_e32 v105, 7, v39
	v_bfe_u32 v106, v38, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	v_and_or_b32 v100, 0x80000000, v103, v100
	v_bfe_u32 v103, v38, 24, 3
	v_cvt_f32_ubyte0_e32 v105, v105
	v_lshl_add_u32 v109, v106, 20, 0x3c000000
	v_and_or_b32 v104, 0x80000000, v108, v104
	v_bfe_u32 v108, v39, 24, 3
	v_cvt_f32_ubyte0_e32 v103, v103
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	v_fmac_f32_e32 v67, v100, v89
	v_lshl_add_u32 v100, v99, 20, 0x3c000000
	v_and_b32_e32 v107, 0x7f, v39
	v_cvt_f32_ubyte0_e32 v108, v108
	v_mul_f32_e32 v103, 0x3b000000, v103
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_bfe_u32 v89, v40, 8, 7
	v_lshl_add_u32 v110, v107, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v108, 0x3b000000, v108 :: v_dual_cndmask_b32 v103, v103, v109
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_bfe_u32 v109, v39, 8, 7
	v_fmac_f32_e32 v67, v102, v88
	v_lshl_add_u32 v88, v89, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshl_add_u32 v106, v109, 20, 0x3c000000
	v_mul_f32_e32 v110, 0x3b000000, v111
	v_bfe_u32 v111, v39, 24, 7
	v_fmac_f32_e32 v67, v104, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_lshl_add_u32 v93, v111, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v103, 0x80000000, v38, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_fmac_f32_e32 v67, v103, v86
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v110, v106, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_lshlrev_b32_e32 v107, 24, v39
	v_bfe_u32 v109, v39, 16, 7
	v_lshlrev_b32_e32 v110, 16, v39
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	v_and_or_b32 v105, 0x80000000, v107, v105
	v_bfe_u32 v107, v39, 16, 3
	v_lshl_add_u32 v112, v109, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v67, v105, v85
	v_cvt_f32_ubyte0_e32 v107, v107
	v_bfe_u32 v85, v40, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v107, 0x3b000000, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, v108, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v93, 0x80000000, v94, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v91, 0x7fc00000, v92, vcc_lo
	v_and_b32_e32 v94, 7, v40
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_and_or_b32 v92, 0x80000000, v110, v106
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v90, 0x80000000, v39, v91
	v_bfe_u32 v91, v40, 8, 3
	v_cvt_f32_ubyte0_e32 v94, v94
	v_fmac_f32_e32 v67, v92, v84
	v_lshl_add_u32 v84, v85, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v91, v91
	v_dual_mul_f32 v94, 0x3b000000, v94 :: v_dual_fmac_f32 v67, v93, v83
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v91, 0x3b000000, v91 :: v_dual_cndmask_b32 v94, v94, v100
	v_cmp_lt_u32_e32 vcc_lo, 7, v89
	v_fmac_f32_e32 v67, v90, v82
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v87, v91, v88, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v88, 0x7fc00000, v94 :: v_dual_lshlrev_b32 v91, 24, v40
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v89
	v_lshlrev_b32_e32 v89, 16, v40
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v88, 0x80000000, v91, v88
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v86, 0x7fc00000, v87, vcc_lo
	v_bfe_u32 v87, v40, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v85
	v_bfe_u32 v91, v40, 24, 7
	v_fmac_f32_e32 v67, v88, v81
	v_and_or_b32 v86, 0x80000000, v89, v86
	v_cvt_f32_ubyte0_e32 v87, v87
	v_bfe_u32 v89, v40, 24, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v86, v66
	v_mul_f32_e32 v87, 0x3b000000, v87
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v89, v89
	v_and_b32_e32 v66, 0xffff0000, v68
	v_and_or_b32 v68, 0x80000000, v36, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v83, v87, v84, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v85
	v_lshl_add_u32 v84, v91, 20, 0x3c000000
	v_mul_f32_e32 v87, 0x3b000000, v89
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v68, v66 :: v_dual_cndmask_b32 v82, 0x7fc00000, v83
	v_cmp_lt_u32_e32 vcc_lo, 7, v91
	v_lshlrev_b32_e32 v83, 8, v40
	s_delay_alu instid0(VALU_DEP_3)
	v_add_f32_e32 v79, v79, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v84, v87, v84, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v91
	v_and_or_b32 v81, 0x80000000, v83, v82
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v82, 0x7fc00000, v84 :: v_dual_fmac_f32 v67, v81, v65
	v_or_b32_e32 v65, 32, v80
	v_and_or_b32 v82, 0x80000000, v40, v82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v82, v66
	v_add_f32_e32 v0, v0, v67
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s14, v65
	s_cbranch_execz .LBB57_19
; %bb.25:                               ;   in Loop: Header=BB57_21 Depth=1
	v_lshl_add_u32 v65, v65, 5, 0
	s_wait_loadcnt 0x5
	v_bfe_u32 v98, v41, 8, 3
	v_and_b32_e32 v108, 0x7f, v44
	v_and_b32_e32 v97, 0x7f, v41
	v_bfe_u32 v101, v42, 8, 7
	ds_load_b128 v[93:96], v65
	ds_load_b128 v[65:68], v65 offset:16
	v_lshl_add_u32 v109, v108, 20, 0x3c000000
	v_lshl_add_u32 v82, v97, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	v_bfe_u32 v102, v42, 16, 3
	v_lshlrev_b32_e32 v103, 16, v42
	v_and_b32_e32 v105, 0x7f, v43
	v_bfe_u32 v106, v43, 8, 7
	s_wait_loadcnt 0x4
	v_bfe_u32 v111, v55, 8, 3
	s_mov_b32 s16, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v111, v111
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v91, 16, v94
	v_and_b32_e32 v90, 0xffff0000, v94
	v_cvt_f32_ubyte0_e32 v94, v98
	v_and_b32_e32 v81, 7, v41
	v_lshlrev_b32_e32 v87, 16, v96
	v_and_b32_e32 v86, 0xffff0000, v96
	v_bfe_u32 v96, v41, 16, 3
	v_mul_f32_e32 v94, 0x3b000000, v94
	v_cvt_f32_ubyte0_e32 v81, v81
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v83, 16, v66
	v_and_b32_e32 v88, 0xffff0000, v95
	v_cvt_f32_ubyte0_e32 v96, v96
	v_and_b32_e32 v92, 0xffff0000, v93
	v_mul_f32_e32 v81, 0x3b000000, v81
	v_lshlrev_b32_e32 v98, 24, v41
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v96, 0x3b000000, v96 :: v_dual_lshlrev_b32 v89, 16, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v81, v82, vcc_lo
	v_and_b32_e32 v82, 0xffff0000, v66
	v_lshlrev_b32_e32 v81, 16, v67
	v_and_b32_e32 v66, 0xffff0000, v67
	v_lshlrev_b32_e32 v67, 16, v93
	v_bfe_u32 v93, v41, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v97, v93, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v93
	v_bfe_u32 v99, v41, 16, 7
	v_and_or_b32 v95, 0x80000000, v98, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v94, v97, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v93
	v_lshl_add_u32 v97, v99, 20, 0x3c000000
	v_bfe_u32 v98, v41, 24, 7
	v_fma_f32 v95, v95, v67, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v94, vcc_lo
	v_bfe_u32 v94, v41, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_lshl_add_u32 v100, v98, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v94, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v96, v97, vcc_lo
	v_lshlrev_b32_e32 v97, 16, v41
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_lshlrev_b32_e32 v85, 16, v65
	v_dual_mul_f32 v94, 0x3b000000, v94 :: v_dual_lshlrev_b32 v99, 8, v41
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v97, v93
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v96, 0x7fc00000, v96 :: v_dual_and_b32 v97, 7, v42
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	v_dual_fmac_f32 v95, v93, v92 :: v_dual_and_b32 v84, 0xffff0000, v65
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v96, 0x80000000, v99, v96
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v94, v94, v100 :: v_dual_and_b32 v99, 0x7f, v42
	v_cvt_f32_ubyte0_e32 v97, v97
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_bfe_u32 v100, v42, 8, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v98, v99, 20, 0x3c000000
	v_fmac_f32_e32 v95, v96, v91
	v_mul_f32_e32 v97, 0x3b000000, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v94, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_cvt_f32_ubyte0_e32 v100, v100
	v_lshlrev_b32_e32 v96, 24, v44
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v94, 0x80000000, v41, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, v97, v98, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_lshl_add_u32 v98, v101, 20, 0x3c000000
	v_mul_f32_e32 v100, 0x3b000000, v100
	v_bfe_u32 v99, v42, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, 0x7fc00000, v97, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v98, v100, v98 :: v_dual_lshlrev_b32 v65, 16, v68
	v_cvt_f32_ubyte0_e32 v100, v102
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_lshl_add_u32 v101, v99, 20, 0x3c000000
	v_lshlrev_b32_e32 v102, 24, v42
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, 0x7fc00000, v98, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_and_or_b32 v98, 0x80000000, v103, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v101, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_bfe_u32 v101, v42, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_cndmask_b32 v99, 0x7fc00000, v100 :: v_dual_lshlrev_b32 v100, 8, v42
	v_and_or_b32 v97, 0x80000000, v102, v97
	v_bfe_u32 v102, v42, 24, 3
	v_lshl_add_u32 v104, v101, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_and_or_b32 v99, 0x80000000, v100, v99
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v102, v102
	v_mul_f32_e32 v102, 0x3b000000, v102
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v102, v102, v104, vcc_lo
	v_bfe_u32 v104, v43, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v102, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v102, v104
	v_and_b32_e32 v103, 7, v43
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_bfe_u32 v104, v43, 16, 3
	v_and_or_b32 v101, 0x80000000, v42, v101
	v_mul_f32_e32 v102, 0x3b000000, v102
	v_cvt_f32_ubyte0_e32 v100, v103
	v_lshl_add_u32 v103, v105, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v104, v104
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_bfe_u32 v105, v43, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, v102, v103, vcc_lo
	v_lshlrev_b32_e32 v103, 24, v43
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshlrev_b32_e32 v106, 16, v43
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v100, 0x80000000, v103, v100
	v_bfe_u32 v103, v43, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_cvt_f32_ubyte0_e32 v103, v103
	v_mul_f32_e32 v104, 0x3b000000, v104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v102, 0x80000000, v106, v102
	v_lshlrev_b32_e32 v106, 8, v43
	v_mul_f32_e32 v103, 0x3b000000, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v104, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_and_b32_e32 v105, 7, v44
	v_bfe_u32 v107, v43, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v105, v105
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v104, 0x80000000, v106, v104
	v_lshl_add_u32 v106, v107, 20, 0x3c000000
	v_mul_f32_e32 v105, 0x3b000000, v105
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v103, v103, v106, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_bfe_u32 v106, v44, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v109, vcc_lo
	v_fmac_f32_e32 v95, v94, v90
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v95, v97, v89
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_bfe_u32 v97, v44, 16, 7
	v_dual_fmac_f32 v95, v98, v88 :: v_dual_lshlrev_b32 v108, 8, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v105, vcc_lo
	v_bfe_u32 v105, v44, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	v_fmac_f32_e32 v95, v99, v87
	v_bfe_u32 v99, v44, 24, 3
	v_lshl_add_u32 v98, v97, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v105, v105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v95, v101, v86
	v_cvt_f32_ubyte0_e32 v99, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_dual_fmac_f32 v95, v100, v85 :: v_dual_lshlrev_b32 v100, 8, v44
	v_and_or_b32 v94, 0x80000000, v96, v103
	v_bfe_u32 v96, v44, 16, 3
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_mul_f32_e32 v99, 0x3b000000, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v96, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, v105, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_and_b32_e32 v105, 0x7f, v54
	v_bfe_u32 v106, v54, 8, 7
	v_mul_f32_e32 v96, 0x3b000000, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v96, v98, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_bfe_u32 v97, v44, 24, 7
	v_lshlrev_b32_e32 v98, 16, v44
	v_and_or_b32 v93, 0x80000000, v43, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, 0x7fc00000, v96, vcc_lo
	v_lshl_add_u32 v101, v97, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v96, 0x80000000, v100, v96
	v_and_b32_e32 v100, 7, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v99, v101, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_and_b32_e32 v101, 0x7f, v53
	v_cvt_f32_ubyte0_e32 v100, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, 0x7fc00000, v99, vcc_lo
	v_bfe_u32 v99, v53, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v99, v99
	v_mul_f32_e32 v99, 0x3b000000, v99
	v_fmac_f32_e32 v95, v102, v84
	v_bfe_u32 v102, v53, 8, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v95, v104, v83
	v_fmac_f32_e32 v95, v93, v82
	v_lshl_add_u32 v93, v101, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v95, v94, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v100, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_lshl_add_u32 v94, v102, 20, 0x3c000000
	v_bfe_u32 v100, v53, 16, 3
	v_lshlrev_b32_e32 v101, 24, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v93, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_cvt_f32_ubyte0_e32 v100, v100
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v101, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v99, v94, vcc_lo
	v_bfe_u32 v99, v53, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_mul_f32_e32 v100, 0x3b000000, v100
	v_bfe_u32 v101, v53, 24, 3
	v_fma_f32 v67, v93, v67, 0
	v_lshl_add_u32 v102, v99, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v94, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_cvt_f32_ubyte0_e32 v101, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v102, vcc_lo
	v_bfe_u32 v102, v53, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_mul_f32_e32 v101, 0x3b000000, v101
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v104, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_lshlrev_b32_e32 v100, 8, v53
	v_and_or_b32 v98, 0x80000000, v98, v103
	v_lshlrev_b32_e32 v103, 16, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, v101, v104, vcc_lo
	v_bfe_u32 v104, v54, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_and_or_b32 v94, 0x80000000, v103, v94
	v_and_or_b32 v99, 0x80000000, v100, v99
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v102, v104
	v_bfe_u32 v104, v54, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v101, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_dual_fmac_f32 v67, v94, v92 :: v_dual_mul_f32 v102, 0x3b000000, v102
	v_cvt_f32_ubyte0_e32 v104, v104
	v_lshlrev_b32_e32 v94, 8, v55
	v_and_or_b32 v101, 0x80000000, v53, v101
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v99, v91
	v_and_b32_e32 v99, 0x7f, v56
	v_dual_mul_f32 v104, 0x3b000000, v104 :: v_dual_and_b32 v103, 7, v54
	v_fmac_f32_e32 v67, v101, v90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v100, v103
	v_lshl_add_u32 v103, v105, 20, 0x3c000000
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v100, v100, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_bfe_u32 v105, v54, 16, 7
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v98, v66 :: v_dual_cndmask_b32 v100, 0x7fc00000, v100
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v96, v65 :: v_dual_cndmask_b32 v102, v102, v103
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshlrev_b32_e32 v106, 16, v54
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_and_or_b32 v102, 0x80000000, v106, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v104, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshlrev_b32_e32 v103, 24, v54
	v_and_b32_e32 v105, 7, v55
	v_bfe_u32 v106, v54, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	v_and_or_b32 v100, 0x80000000, v103, v100
	v_bfe_u32 v103, v54, 24, 3
	v_cvt_f32_ubyte0_e32 v105, v105
	v_lshl_add_u32 v109, v106, 20, 0x3c000000
	v_and_or_b32 v104, 0x80000000, v108, v104
	v_bfe_u32 v108, v55, 24, 3
	v_cvt_f32_ubyte0_e32 v103, v103
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	v_fmac_f32_e32 v67, v100, v89
	v_lshl_add_u32 v100, v99, 20, 0x3c000000
	v_and_b32_e32 v107, 0x7f, v55
	v_cvt_f32_ubyte0_e32 v108, v108
	v_mul_f32_e32 v103, 0x3b000000, v103
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_bfe_u32 v89, v56, 8, 7
	v_lshl_add_u32 v110, v107, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v108, 0x3b000000, v108 :: v_dual_cndmask_b32 v103, v103, v109
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_bfe_u32 v109, v55, 8, 7
	v_fmac_f32_e32 v67, v102, v88
	v_lshl_add_u32 v88, v89, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshl_add_u32 v106, v109, 20, 0x3c000000
	v_mul_f32_e32 v110, 0x3b000000, v111
	v_bfe_u32 v111, v55, 24, 7
	v_fmac_f32_e32 v67, v104, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_lshl_add_u32 v93, v111, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v103, 0x80000000, v54, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_fmac_f32_e32 v67, v103, v86
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v110, v106, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_lshlrev_b32_e32 v107, 24, v55
	v_bfe_u32 v109, v55, 16, 7
	v_lshlrev_b32_e32 v110, 16, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	v_and_or_b32 v105, 0x80000000, v107, v105
	v_bfe_u32 v107, v55, 16, 3
	v_lshl_add_u32 v112, v109, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v67, v105, v85
	v_cvt_f32_ubyte0_e32 v107, v107
	v_bfe_u32 v85, v56, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v107, 0x3b000000, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, v108, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v93, 0x80000000, v94, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v91, 0x7fc00000, v92, vcc_lo
	v_and_b32_e32 v94, 7, v56
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_and_or_b32 v92, 0x80000000, v110, v106
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v90, 0x80000000, v55, v91
	v_bfe_u32 v91, v56, 8, 3
	v_cvt_f32_ubyte0_e32 v94, v94
	v_fmac_f32_e32 v67, v92, v84
	v_lshl_add_u32 v84, v85, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v91, v91
	v_dual_mul_f32 v94, 0x3b000000, v94 :: v_dual_fmac_f32 v67, v93, v83
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v91, 0x3b000000, v91 :: v_dual_cndmask_b32 v94, v94, v100
	v_cmp_lt_u32_e32 vcc_lo, 7, v89
	v_fmac_f32_e32 v67, v90, v82
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v87, v91, v88, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v88, 0x7fc00000, v94 :: v_dual_lshlrev_b32 v91, 24, v56
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v89
	v_lshlrev_b32_e32 v89, 16, v56
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v88, 0x80000000, v91, v88
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v86, 0x7fc00000, v87, vcc_lo
	v_bfe_u32 v87, v56, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v85
	v_bfe_u32 v91, v56, 24, 7
	v_fmac_f32_e32 v67, v88, v81
	v_and_or_b32 v86, 0x80000000, v89, v86
	v_cvt_f32_ubyte0_e32 v87, v87
	v_bfe_u32 v89, v56, 24, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v86, v66
	v_mul_f32_e32 v87, 0x3b000000, v87
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v89, v89
	v_and_b32_e32 v66, 0xffff0000, v68
	v_and_or_b32 v68, 0x80000000, v44, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v83, v87, v84, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v85
	v_lshl_add_u32 v84, v91, 20, 0x3c000000
	v_mul_f32_e32 v87, 0x3b000000, v89
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v68, v66 :: v_dual_cndmask_b32 v82, 0x7fc00000, v83
	v_cmp_lt_u32_e32 vcc_lo, 7, v91
	v_lshlrev_b32_e32 v83, 8, v56
	s_delay_alu instid0(VALU_DEP_3)
	v_add_f32_e32 v79, v79, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v84, v87, v84, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v91
	v_and_or_b32 v81, 0x80000000, v83, v82
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v82, 0x7fc00000, v84 :: v_dual_fmac_f32 v67, v81, v65
	v_or_b32_e32 v65, 64, v80
	v_and_or_b32 v82, 0x80000000, v56, v82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v82, v66
	v_add_f32_e32 v0, v0, v67
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s14, v65
	s_cbranch_execz .LBB57_18
; %bb.26:                               ;   in Loop: Header=BB57_21 Depth=1
	v_lshl_add_u32 v65, v65, 5, 0
	s_wait_loadcnt 0x3
	v_bfe_u32 v98, v45, 8, 3
	v_and_b32_e32 v108, 0x7f, v48
	v_and_b32_e32 v97, 0x7f, v45
	v_bfe_u32 v101, v46, 8, 7
	ds_load_b128 v[93:96], v65
	ds_load_b128 v[65:68], v65 offset:16
	v_lshl_add_u32 v109, v108, 20, 0x3c000000
	v_lshl_add_u32 v82, v97, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	v_bfe_u32 v102, v46, 16, 3
	v_lshlrev_b32_e32 v103, 16, v46
	v_and_b32_e32 v105, 0x7f, v47
	v_bfe_u32 v106, v47, 8, 7
	s_wait_loadcnt 0x2
	v_bfe_u32 v111, v59, 8, 3
	s_mov_b32 s17, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v111, v111
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v91, 16, v94
	v_and_b32_e32 v90, 0xffff0000, v94
	v_cvt_f32_ubyte0_e32 v94, v98
	v_and_b32_e32 v81, 7, v45
	v_lshlrev_b32_e32 v87, 16, v96
	v_and_b32_e32 v86, 0xffff0000, v96
	v_bfe_u32 v96, v45, 16, 3
	v_mul_f32_e32 v94, 0x3b000000, v94
	v_cvt_f32_ubyte0_e32 v81, v81
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v83, 16, v66
	v_and_b32_e32 v88, 0xffff0000, v95
	v_cvt_f32_ubyte0_e32 v96, v96
	v_and_b32_e32 v92, 0xffff0000, v93
	v_mul_f32_e32 v81, 0x3b000000, v81
	v_lshlrev_b32_e32 v98, 24, v45
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v96, 0x3b000000, v96 :: v_dual_lshlrev_b32 v89, 16, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v81, v82, vcc_lo
	v_and_b32_e32 v82, 0xffff0000, v66
	v_lshlrev_b32_e32 v81, 16, v67
	v_and_b32_e32 v66, 0xffff0000, v67
	v_lshlrev_b32_e32 v67, 16, v93
	v_bfe_u32 v93, v45, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v97, v93, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v93
	v_bfe_u32 v99, v45, 16, 7
	v_and_or_b32 v95, 0x80000000, v98, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v94, v97, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v93
	v_lshl_add_u32 v97, v99, 20, 0x3c000000
	v_bfe_u32 v98, v45, 24, 7
	v_fma_f32 v95, v95, v67, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v94, vcc_lo
	v_bfe_u32 v94, v45, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_lshl_add_u32 v100, v98, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v94, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v96, v97, vcc_lo
	v_lshlrev_b32_e32 v97, 16, v45
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_lshlrev_b32_e32 v85, 16, v65
	v_dual_mul_f32 v94, 0x3b000000, v94 :: v_dual_lshlrev_b32 v99, 8, v45
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v97, v93
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v96, 0x7fc00000, v96 :: v_dual_and_b32 v97, 7, v46
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	v_dual_fmac_f32 v95, v93, v92 :: v_dual_and_b32 v84, 0xffff0000, v65
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v96, 0x80000000, v99, v96
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v94, v94, v100 :: v_dual_and_b32 v99, 0x7f, v46
	v_cvt_f32_ubyte0_e32 v97, v97
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_bfe_u32 v100, v46, 8, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v98, v99, 20, 0x3c000000
	v_fmac_f32_e32 v95, v96, v91
	v_mul_f32_e32 v97, 0x3b000000, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v94, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_cvt_f32_ubyte0_e32 v100, v100
	v_lshlrev_b32_e32 v96, 24, v48
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v94, 0x80000000, v45, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, v97, v98, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_lshl_add_u32 v98, v101, 20, 0x3c000000
	v_mul_f32_e32 v100, 0x3b000000, v100
	v_bfe_u32 v99, v46, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, 0x7fc00000, v97, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v98, v100, v98 :: v_dual_lshlrev_b32 v65, 16, v68
	v_cvt_f32_ubyte0_e32 v100, v102
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_lshl_add_u32 v101, v99, 20, 0x3c000000
	v_lshlrev_b32_e32 v102, 24, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, 0x7fc00000, v98, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_and_or_b32 v98, 0x80000000, v103, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v101, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_bfe_u32 v101, v46, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_cndmask_b32 v99, 0x7fc00000, v100 :: v_dual_lshlrev_b32 v100, 8, v46
	v_and_or_b32 v97, 0x80000000, v102, v97
	v_bfe_u32 v102, v46, 24, 3
	v_lshl_add_u32 v104, v101, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_and_or_b32 v99, 0x80000000, v100, v99
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v102, v102
	v_mul_f32_e32 v102, 0x3b000000, v102
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v102, v102, v104, vcc_lo
	v_bfe_u32 v104, v47, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v102, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v102, v104
	v_and_b32_e32 v103, 7, v47
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_bfe_u32 v104, v47, 16, 3
	v_and_or_b32 v101, 0x80000000, v46, v101
	v_mul_f32_e32 v102, 0x3b000000, v102
	v_cvt_f32_ubyte0_e32 v100, v103
	v_lshl_add_u32 v103, v105, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v104, v104
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_bfe_u32 v105, v47, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, v102, v103, vcc_lo
	v_lshlrev_b32_e32 v103, 24, v47
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshlrev_b32_e32 v106, 16, v47
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v100, 0x80000000, v103, v100
	v_bfe_u32 v103, v47, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_cvt_f32_ubyte0_e32 v103, v103
	v_mul_f32_e32 v104, 0x3b000000, v104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v102, 0x80000000, v106, v102
	v_lshlrev_b32_e32 v106, 8, v47
	v_mul_f32_e32 v103, 0x3b000000, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v104, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_and_b32_e32 v105, 7, v48
	v_bfe_u32 v107, v47, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v105, v105
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v104, 0x80000000, v106, v104
	v_lshl_add_u32 v106, v107, 20, 0x3c000000
	v_mul_f32_e32 v105, 0x3b000000, v105
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v103, v103, v106, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_bfe_u32 v106, v48, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v109, vcc_lo
	v_fmac_f32_e32 v95, v94, v90
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v95, v97, v89
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_bfe_u32 v97, v48, 16, 7
	v_dual_fmac_f32 v95, v98, v88 :: v_dual_lshlrev_b32 v108, 8, v58
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v105, vcc_lo
	v_bfe_u32 v105, v48, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	v_fmac_f32_e32 v95, v99, v87
	v_bfe_u32 v99, v48, 24, 3
	v_lshl_add_u32 v98, v97, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v105, v105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v95, v101, v86
	v_cvt_f32_ubyte0_e32 v99, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_dual_fmac_f32 v95, v100, v85 :: v_dual_lshlrev_b32 v100, 8, v48
	v_and_or_b32 v94, 0x80000000, v96, v103
	v_bfe_u32 v96, v48, 16, 3
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_mul_f32_e32 v99, 0x3b000000, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v96, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, v105, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_and_b32_e32 v105, 0x7f, v58
	v_bfe_u32 v106, v58, 8, 7
	v_mul_f32_e32 v96, 0x3b000000, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, v96, v98, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_bfe_u32 v97, v48, 24, 7
	v_lshlrev_b32_e32 v98, 16, v48
	v_and_or_b32 v93, 0x80000000, v47, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, 0x7fc00000, v96, vcc_lo
	v_lshl_add_u32 v101, v97, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v96, 0x80000000, v100, v96
	v_and_b32_e32 v100, 7, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v99, v101, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_and_b32_e32 v101, 0x7f, v57
	v_cvt_f32_ubyte0_e32 v100, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, 0x7fc00000, v99, vcc_lo
	v_bfe_u32 v99, v57, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v99, v99
	v_mul_f32_e32 v99, 0x3b000000, v99
	v_fmac_f32_e32 v95, v102, v84
	v_bfe_u32 v102, v57, 8, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v95, v104, v83
	v_fmac_f32_e32 v95, v93, v82
	v_lshl_add_u32 v93, v101, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v95, v94, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v100, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_lshl_add_u32 v94, v102, 20, 0x3c000000
	v_bfe_u32 v100, v57, 16, 3
	v_lshlrev_b32_e32 v101, 24, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v93, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_cvt_f32_ubyte0_e32 v100, v100
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v101, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v99, v94, vcc_lo
	v_bfe_u32 v99, v57, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_mul_f32_e32 v100, 0x3b000000, v100
	v_bfe_u32 v101, v57, 24, 3
	v_fma_f32 v67, v93, v67, 0
	v_lshl_add_u32 v102, v99, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v94, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_cvt_f32_ubyte0_e32 v101, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v102, vcc_lo
	v_bfe_u32 v102, v57, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_mul_f32_e32 v101, 0x3b000000, v101
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v104, v102, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_lshlrev_b32_e32 v100, 8, v57
	v_and_or_b32 v98, 0x80000000, v98, v103
	v_lshlrev_b32_e32 v103, 16, v57
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, v101, v104, vcc_lo
	v_bfe_u32 v104, v58, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_and_or_b32 v94, 0x80000000, v103, v94
	v_and_or_b32 v99, 0x80000000, v100, v99
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v102, v104
	v_bfe_u32 v104, v58, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v101, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_dual_fmac_f32 v67, v94, v92 :: v_dual_mul_f32 v102, 0x3b000000, v102
	v_cvt_f32_ubyte0_e32 v104, v104
	v_lshlrev_b32_e32 v94, 8, v59
	v_and_or_b32 v101, 0x80000000, v57, v101
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v99, v91
	v_and_b32_e32 v99, 0x7f, v60
	v_dual_mul_f32 v104, 0x3b000000, v104 :: v_dual_and_b32 v103, 7, v58
	v_fmac_f32_e32 v67, v101, v90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v100, v103
	v_lshl_add_u32 v103, v105, 20, 0x3c000000
	v_mul_f32_e32 v100, 0x3b000000, v100
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v100, v100, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshl_add_u32 v103, v106, 20, 0x3c000000
	v_bfe_u32 v105, v58, 16, 7
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v98, v66 :: v_dual_cndmask_b32 v100, 0x7fc00000, v100
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v96, v65 :: v_dual_cndmask_b32 v102, v102, v103
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshlrev_b32_e32 v106, 16, v58
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_and_or_b32 v102, 0x80000000, v106, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v104, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshlrev_b32_e32 v103, 24, v58
	v_and_b32_e32 v105, 7, v59
	v_bfe_u32 v106, v58, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	v_and_or_b32 v100, 0x80000000, v103, v100
	v_bfe_u32 v103, v58, 24, 3
	v_cvt_f32_ubyte0_e32 v105, v105
	v_lshl_add_u32 v109, v106, 20, 0x3c000000
	v_and_or_b32 v104, 0x80000000, v108, v104
	v_bfe_u32 v108, v59, 24, 3
	v_cvt_f32_ubyte0_e32 v103, v103
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	v_fmac_f32_e32 v67, v100, v89
	v_lshl_add_u32 v100, v99, 20, 0x3c000000
	v_and_b32_e32 v107, 0x7f, v59
	v_cvt_f32_ubyte0_e32 v108, v108
	v_mul_f32_e32 v103, 0x3b000000, v103
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_bfe_u32 v89, v60, 8, 7
	v_lshl_add_u32 v110, v107, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v108, 0x3b000000, v108 :: v_dual_cndmask_b32 v103, v103, v109
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_bfe_u32 v109, v59, 8, 7
	v_fmac_f32_e32 v67, v102, v88
	v_lshl_add_u32 v88, v89, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_lshl_add_u32 v106, v109, 20, 0x3c000000
	v_mul_f32_e32 v110, 0x3b000000, v111
	v_bfe_u32 v111, v59, 24, 7
	v_fmac_f32_e32 v67, v104, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_lshl_add_u32 v93, v111, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v103, 0x80000000, v58, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_fmac_f32_e32 v67, v103, v86
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v110, v106, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_lshlrev_b32_e32 v107, 24, v59
	v_bfe_u32 v109, v59, 16, 7
	v_lshlrev_b32_e32 v110, 16, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	v_and_or_b32 v105, 0x80000000, v107, v105
	v_bfe_u32 v107, v59, 16, 3
	v_lshl_add_u32 v112, v109, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v67, v105, v85
	v_cvt_f32_ubyte0_e32 v107, v107
	v_bfe_u32 v85, v60, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v107, 0x3b000000, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, v108, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v93, 0x80000000, v94, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v91, 0x7fc00000, v92, vcc_lo
	v_and_b32_e32 v94, 7, v60
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_and_or_b32 v92, 0x80000000, v110, v106
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v90, 0x80000000, v59, v91
	v_bfe_u32 v91, v60, 8, 3
	v_cvt_f32_ubyte0_e32 v94, v94
	v_fmac_f32_e32 v67, v92, v84
	v_lshl_add_u32 v84, v85, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v91, v91
	v_dual_mul_f32 v94, 0x3b000000, v94 :: v_dual_fmac_f32 v67, v93, v83
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v91, 0x3b000000, v91 :: v_dual_cndmask_b32 v94, v94, v100
	v_cmp_lt_u32_e32 vcc_lo, 7, v89
	v_fmac_f32_e32 v67, v90, v82
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v87, v91, v88, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v88, 0x7fc00000, v94 :: v_dual_lshlrev_b32 v91, 24, v60
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v89
	v_lshlrev_b32_e32 v89, 16, v60
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v88, 0x80000000, v91, v88
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v86, 0x7fc00000, v87, vcc_lo
	v_bfe_u32 v87, v60, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v85
	v_bfe_u32 v91, v60, 24, 7
	v_fmac_f32_e32 v67, v88, v81
	v_and_or_b32 v86, 0x80000000, v89, v86
	v_cvt_f32_ubyte0_e32 v87, v87
	v_bfe_u32 v89, v60, 24, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v86, v66
	v_mul_f32_e32 v87, 0x3b000000, v87
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v89, v89
	v_and_b32_e32 v66, 0xffff0000, v68
	v_and_or_b32 v68, 0x80000000, v48, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v83, v87, v84, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v85
	v_lshl_add_u32 v84, v91, 20, 0x3c000000
	v_mul_f32_e32 v87, 0x3b000000, v89
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v95, v68, v66 :: v_dual_cndmask_b32 v82, 0x7fc00000, v83
	v_cmp_lt_u32_e32 vcc_lo, 7, v91
	v_lshlrev_b32_e32 v83, 8, v60
	s_delay_alu instid0(VALU_DEP_3)
	v_add_f32_e32 v79, v79, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v84, v87, v84, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v91
	v_and_or_b32 v81, 0x80000000, v83, v82
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v82, 0x7fc00000, v84 :: v_dual_fmac_f32 v67, v81, v65
	v_or_b32_e32 v65, 0x60, v80
	v_and_or_b32 v82, 0x80000000, v60, v82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v82, v66
	v_add_f32_e32 v0, v0, v67
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s14, v65
	s_cbranch_execz .LBB57_17
; %bb.27:                               ;   in Loop: Header=BB57_21 Depth=1
	v_lshl_add_u32 v65, v65, 5, 0
	s_wait_loadcnt 0x1
	v_bfe_u32 v97, v49, 8, 3
	v_and_b32_e32 v107, 0x7f, v52
	v_and_b32_e32 v96, 0x7f, v49
	v_bfe_u32 v100, v50, 8, 7
	ds_load_b128 v[92:95], v65
	ds_load_b128 v[65:68], v65 offset:16
	v_lshl_add_u32 v108, v107, 20, 0x3c000000
	v_lshl_add_u32 v81, v96, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v96
	v_bfe_u32 v101, v50, 16, 3
	v_bfe_u32 v105, v51, 8, 7
	s_wait_loadcnt 0x0
	v_bfe_u32 v110, v63, 8, 3
	s_delay_alu instid0(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v110, v110
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v86, 16, v95
	v_and_b32_e32 v85, 0xffff0000, v95
	v_bfe_u32 v95, v49, 16, 3
	v_and_b32_e32 v89, 0xffff0000, v93
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v82, 16, v66
	v_and_b32_e32 v87, 0xffff0000, v94
	v_and_b32_e32 v91, 0xffff0000, v92
	v_cvt_f32_ubyte0_e32 v95, v95
	v_lshlrev_b32_e32 v90, 16, v93
	v_cvt_f32_ubyte0_e32 v93, v97
	v_lshlrev_b32_e32 v88, 16, v94
	v_lshlrev_b32_e32 v97, 24, v49
	v_mul_f32_e32 v95, 0x3b000000, v95
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v93, 0x3b000000, v93
	v_and_b32_e32 v80, 7, v49
	v_cvt_f32_ubyte0_e32 v80, v80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v80, 0x3b000000, v80
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v98, v80, v81 :: v_dual_and_b32 v81, 0xffff0000, v66
	v_lshlrev_b32_e32 v80, 16, v67
	v_and_b32_e32 v66, 0xffff0000, v67
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v96
	v_lshlrev_b32_e32 v67, 16, v92
	v_bfe_u32 v92, v49, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v98, vcc_lo
	v_bfe_u32 v98, v49, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v96, v92, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v92
	v_and_or_b32 v94, 0x80000000, v97, v94
	v_bfe_u32 v97, v49, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v93, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v92
	v_lshl_add_u32 v96, v98, 20, 0x3c000000
	v_lshl_add_u32 v99, v97, 20, 0x3c000000
	v_fma_f32 v94, v94, v67, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, 0x7fc00000, v93, vcc_lo
	v_bfe_u32 v93, v49, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_delay_alu instid0(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v93, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, v95, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_lshlrev_b32_e32 v84, 16, v65
	v_lshlrev_b32_e32 v98, 8, v49
	v_mul_f32_e32 v93, 0x3b000000, v93
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v95, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v95, 0x80000000, v98, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v93, v99, vcc_lo
	v_bfe_u32 v99, v50, 8, 3
	v_and_b32_e32 v98, 0x7f, v50
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v99, v99
	v_lshlrev_b32_e32 v96, 16, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v93, vcc_lo
	v_lshl_add_u32 v97, v98, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	v_mul_f32_e32 v99, 0x3b000000, v99
	v_and_or_b32 v92, 0x80000000, v96, v92
	v_and_b32_e32 v96, 7, v50
	v_and_b32_e32 v83, 0xffff0000, v65
	v_and_or_b32 v93, 0x80000000, v49, v93
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v94, v92, v91
	v_cvt_f32_ubyte0_e32 v96, v96
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v94, v95, v90
	v_mul_f32_e32 v96, 0x3b000000, v96
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_cndmask_b32 v96, v96, v97 :: v_dual_lshlrev_b32 v95, 24, v52
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_lshl_add_u32 v97, v100, 20, 0x3c000000
	v_bfe_u32 v98, v50, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, 0x7fc00000, v96, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, v99, v97, vcc_lo
	v_cvt_f32_ubyte0_e32 v99, v101
	v_lshlrev_b32_e32 v101, 24, v50
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v100
	v_lshl_add_u32 v100, v98, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v99, 0x3b000000, v99
	v_and_or_b32 v96, 0x80000000, v101, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, 0x7fc00000, v97, vcc_lo
	v_bfe_u32 v101, v50, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_delay_alu instid0(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v101, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, v99, v100, vcc_lo
	v_bfe_u32 v100, v50, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_lshlrev_b32_e32 v65, 16, v68
	v_dual_mul_f32 v101, 0x3b000000, v101 :: v_dual_lshlrev_b32 v102, 16, v50
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v103, v100, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v100
	v_and_or_b32 v97, 0x80000000, v102, v97
	v_lshlrev_b32_e32 v99, 8, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, v101, v103, vcc_lo
	v_bfe_u32 v103, v51, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v100
	v_and_or_b32 v98, 0x80000000, v99, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v101, vcc_lo
	v_cvt_f32_ubyte0_e32 v101, v103
	v_and_b32_e32 v102, 7, v51
	v_bfe_u32 v103, v51, 16, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v101, 0x3b000000, v101
	v_cvt_f32_ubyte0_e32 v99, v102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v103, v103
	v_mul_f32_e32 v99, 0x3b000000, v99
	v_and_b32_e32 v104, 0x7f, v51
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v103, 0x3b000000, v103
	v_lshl_add_u32 v102, v104, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v104
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v99, v99, v102, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v104
	v_lshl_add_u32 v102, v105, 20, 0x3c000000
	v_bfe_u32 v104, v51, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v106, v104, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v101, v101, v102 :: v_dual_lshlrev_b32 v102, 24, v51
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshlrev_b32_e32 v105, 16, v51
	v_and_or_b32 v99, 0x80000000, v102, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v101, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v104
	v_bfe_u32 v102, v51, 24, 3
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v101, 0x80000000, v105, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, v103, v106, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v104
	v_and_b32_e32 v104, 7, v52
	v_lshlrev_b32_e32 v105, 8, v51
	v_bfe_u32 v106, v51, 24, 7
	v_cvt_f32_ubyte0_e32 v102, v102
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cvt_f32_ubyte0_e32 v104, v104
	v_and_or_b32 v100, 0x80000000, v50, v100
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	v_mul_f32_e32 v102, 0x3b000000, v102
	v_and_or_b32 v103, 0x80000000, v105, v103
	v_lshl_add_u32 v105, v106, 20, 0x3c000000
	v_mul_f32_e32 v104, 0x3b000000, v104
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v102, v102, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_bfe_u32 v105, v52, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v104, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_fmac_f32_e32 v94, v93, v89
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, 0x7fc00000, v102, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v94, v96, v88
	v_bfe_u32 v96, v52, 16, 7
	v_lshlrev_b32_e32 v107, 8, v62
	v_and_or_b32 v92, 0x80000000, v51, v92
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, 0x7fc00000, v104, vcc_lo
	v_bfe_u32 v104, v52, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v93, 0x80000000, v95, v102
	v_cvt_f32_ubyte0_e32 v104, v104
	v_bfe_u32 v95, v52, 16, 3
	v_lshl_add_u32 v102, v105, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v104, 0x3b000000, v104
	v_cvt_f32_ubyte0_e32 v95, v95
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v102, v104, v102, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_mul_f32_e32 v95, 0x3b000000, v95
	v_and_b32_e32 v104, 0x7f, v62
	v_bfe_u32 v105, v62, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v96
	v_fmac_f32_e32 v94, v97, v87
	v_lshl_add_u32 v97, v96, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_dual_cndmask_b32 v95, v95, v97 :: v_dual_fmac_f32 v94, v98, v86
	v_bfe_u32 v98, v52, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v96
	v_bfe_u32 v96, v52, 24, 7
	v_dual_fmac_f32 v94, v100, v85 :: v_dual_lshlrev_b32 v97, 16, v52
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v98, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v95, vcc_lo
	v_lshl_add_u32 v100, v96, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v96
	v_fmac_f32_e32 v94, v99, v84
	v_dual_mul_f32 v98, 0x3b000000, v98 :: v_dual_lshlrev_b32 v99, 8, v52
	v_and_or_b32 v97, 0x80000000, v97, v102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v95, 0x80000000, v99, v95
	v_and_b32_e32 v99, 7, v61
	v_cvt_f32_ubyte0_e32 v99, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, v98, v100, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v96
	v_and_b32_e32 v100, 0x7f, v61
	v_mul_f32_e32 v99, 0x3b000000, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, 0x7fc00000, v98, vcc_lo
	v_bfe_u32 v98, v61, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v98, v98
	v_mul_f32_e32 v98, 0x3b000000, v98
	v_fmac_f32_e32 v94, v101, v83
	v_bfe_u32 v101, v61, 8, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v94, v103, v82
	v_fmac_f32_e32 v94, v92, v81
	v_lshl_add_u32 v92, v100, 20, 0x3c000000
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v92, v99, v92, vcc_lo
	v_bfe_u32 v99, v61, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v100
	v_lshlrev_b32_e32 v100, 24, v61
	v_cvt_f32_ubyte0_e32 v99, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, 0x7fc00000, v92, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dual_mul_f32 v99, 0x3b000000, v99 :: v_dual_fmac_f32 v94, v93, v80
	v_lshl_add_u32 v93, v101, 20, 0x3c000000
	v_and_or_b32 v92, 0x80000000, v100, v92
	v_bfe_u32 v100, v61, 24, 3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_cndmask_b32_e32 v93, v98, v93, vcc_lo
	v_bfe_u32 v98, v61, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_cvt_f32_ubyte0_e32 v100, v100
	v_fma_f32 v67, v92, v67, 0
	v_lshl_add_u32 v101, v98, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, 0x7fc00000, v93, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_wait_alu 0xfffd
	v_dual_mul_f32 v100, 0x3b000000, v100 :: v_dual_cndmask_b32 v99, v99, v101
	v_bfe_u32 v101, v61, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_fmac_f32_e32 v94, v97, v66
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v103, v101, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_lshlrev_b32_e32 v99, 8, v61
	v_fmac_f32_e32 v94, v95, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v100, v103, vcc_lo
	v_bfe_u32 v103, v62, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_and_or_b32 v98, 0x80000000, v99, v98
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v101, v103
	v_bfe_u32 v103, v62, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, 0x7fc00000, v100, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v104
	v_mul_f32_e32 v101, 0x3b000000, v101
	v_cvt_f32_ubyte0_e32 v103, v103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v103, 0x3b000000, v103 :: v_dual_lshlrev_b32 v102, 16, v61
	v_and_or_b32 v93, 0x80000000, v102, v93
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v93, v91 :: v_dual_and_b32 v102, 7, v62
	v_cvt_f32_ubyte0_e32 v99, v102
	v_lshl_add_u32 v102, v104, 20, 0x3c000000
	v_lshlrev_b32_e32 v93, 8, v63
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v67, v98, v90
	v_mul_f32_e32 v99, 0x3b000000, v99
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v99, v99, v102, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v104
	v_lshl_add_u32 v102, v105, 20, 0x3c000000
	v_bfe_u32 v104, v62, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, 0x7fc00000, v99, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v106, v104, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, v101, v102, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshlrev_b32_e32 v105, 16, v62
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v101, 0x7fc00000, v101, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v104
	v_and_or_b32 v101, 0x80000000, v105, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, v103, v106, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v104
	v_lshlrev_b32_e32 v102, 24, v62
	v_and_b32_e32 v104, 7, v63
	v_bfe_u32 v105, v62, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_and_or_b32 v99, 0x80000000, v102, v99
	v_bfe_u32 v102, v62, 24, 3
	v_cvt_f32_ubyte0_e32 v104, v104
	v_lshl_add_u32 v108, v105, 20, 0x3c000000
	v_and_or_b32 v103, 0x80000000, v107, v103
	v_bfe_u32 v107, v63, 24, 3
	v_cvt_f32_ubyte0_e32 v102, v102
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_mul_f32_e32 v104, 0x3b000000, v104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v107, v107
	v_dual_mul_f32 v102, 0x3b000000, v102 :: v_dual_mul_f32 v107, 0x3b000000, v107
	v_and_b32_e32 v106, 0x7f, v63
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v102, v102, v108, vcc_lo
	v_bfe_u32 v108, v63, 8, 7
	v_lshl_add_u32 v109, v106, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v104, v104, v109, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshl_add_u32 v105, v108, 20, 0x3c000000
	v_mul_f32_e32 v109, 0x3b000000, v110
	v_bfe_u32 v110, v63, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, 0x7fc00000, v102, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v92, v110, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v109, v105, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshlrev_b32_e32 v106, 24, v63
	v_lshlrev_b32_e32 v109, 16, v63
	v_and_or_b32 v100, 0x80000000, v61, v100
	v_bfe_u32 v108, v63, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v67, v100, v89
	v_and_or_b32 v104, 0x80000000, v106, v104
	v_bfe_u32 v106, v63, 16, 3
	v_lshl_add_u32 v111, v108, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_fmac_f32_e32 v67, v99, v88
	v_bfe_u32 v88, v64, 8, 7
	v_cvt_f32_ubyte0_e32 v106, v106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v101, v87
	v_lshl_add_u32 v87, v88, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v106, 0x3b000000, v106
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v67, v103, v86 :: v_dual_cndmask_b32 v106, v106, v111
	v_cmp_lt_u32_e32 vcc_lo, 7, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v91, v107, v92, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, 0x7fc00000, v106, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v92, 0x80000000, v93, v92
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v90, 0x7fc00000, v91 :: v_dual_and_b32 v93, 7, v64
	v_and_or_b32 v102, 0x80000000, v62, v102
	v_and_or_b32 v91, 0x80000000, v109, v105
	v_cvt_f32_ubyte0_e32 v93, v93
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v89, 0x80000000, v63, v90
	v_bfe_u32 v90, v64, 8, 3
	v_fmac_f32_e32 v67, v102, v85
	v_mul_f32_e32 v93, 0x3b000000, v93
	v_and_b32_e32 v98, 0x7f, v64
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v90, v90
	v_fmac_f32_e32 v67, v104, v84
	v_bfe_u32 v84, v64, 16, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v99, v98, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_wait_alu 0xfffd
	v_dual_mul_f32 v90, 0x3b000000, v90 :: v_dual_cndmask_b32 v93, v93, v99
	v_cmp_lt_u32_e32 vcc_lo, 7, v88
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v86, v90, v87, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v87, 0x7fc00000, v93 :: v_dual_lshlrev_b32 v90, 24, v64
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v88
	v_lshlrev_b32_e32 v88, 16, v64
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v87, 0x80000000, v90, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v85, 0x7fc00000, v86, vcc_lo
	v_bfe_u32 v86, v64, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v84
	v_bfe_u32 v90, v64, 24, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v85, 0x80000000, v88, v85
	v_cvt_f32_ubyte0_e32 v86, v86
	v_bfe_u32 v88, v64, 24, 3
	v_fmac_f32_e32 v67, v91, v83
	v_lshl_add_u32 v83, v84, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v86, 0x3b000000, v86
	v_cvt_f32_ubyte0_e32 v88, v88
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v67, v92, v82 :: v_dual_cndmask_b32 v82, v86, v83
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v84
	v_lshl_add_u32 v83, v90, 20, 0x3c000000
	v_dual_mul_f32 v86, 0x3b000000, v88 :: v_dual_fmac_f32 v67, v89, v81
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v81, 0x7fc00000, v82 :: v_dual_lshlrev_b32 v82, 8, v64
	v_cmp_lt_u32_e32 vcc_lo, 7, v90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v87, v80
	v_and_or_b32 v80, 0x80000000, v82, v81
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v83, v86, v83, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v90
	v_dual_fmac_f32 v67, v85, v66 :: v_dual_and_b32 v66, 0xffff0000, v68
	v_and_or_b32 v68, 0x80000000, v52, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v81, 0x7fc00000, v83, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v67, v80, v65
	v_and_or_b32 v81, 0x80000000, v64, v81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v67, v81, v66
	v_fmac_f32_e32 v94, v68, v66
	v_dual_add_f32 v0, v0, v67 :: v_dual_add_f32 v79, v79, v94
	s_branch .LBB57_17
.LBB57_28:
	s_wait_loadcnt 0x7
	v_mbcnt_lo_u32_b32 v33, -1, 0
	s_mov_b32 s9, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v34, 16, v33
	v_xor_b32_e32 v36, 8, v33
	s_wait_loadcnt 0x6
	v_xor_b32_e32 v37, 4, v33
	v_cmp_gt_i32_e32 vcc_lo, 32, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v34, v33, v34, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v36
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v36, v33, v36, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v37
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v37, v33, v37 :: v_dual_lshlrev_b32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v37
	v_lshlrev_b32_e32 v35, 2, v34
	ds_bpermute_b32 v34, v35, v79
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v79, v34
	ds_bpermute_b32 v38, v36, v34
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v38
	v_xor_b32_e32 v38, 2, v33
	ds_bpermute_b32 v39, v37, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v38
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v38, v33, v38, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v38, 2, v38
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v39
	v_xor_b32_e32 v39, 1, v33
	ds_bpermute_b32 v40, v38, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v39
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v33, v33, v39, vcc_lo
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_add_f32 v40, v34, v40 :: v_dual_lshlrev_b32 v39, 2, v33
	v_lshlrev_b64_e32 v[33:34], 1, v[69:70]
	s_wait_loadcnt 0x5
	ds_bpermute_b32 v41, v39, v40
	s_wait_kmcnt 0x0
	v_add_co_u32 v33, s0, s10, v33
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v34, null, s11, v34, s0
	s_mov_b32 s0, exec_lo
	v_cmpx_eq_u32_e32 0, v75
	s_cbranch_execz .LBB57_34
; %bb.29:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s1, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s9, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s9, exec_lo, s9
; %bb.30:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.31:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s9, s9
; %bb.32:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.33:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s9, s2, exec_lo
	global_store_b16 v[33:34], v40, off
.LBB57_34:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	ds_bpermute_b32 v35, v35, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v36, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v37, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v38, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	ds_bpermute_b32 v35, v39, v0
	s_and_saveexec_b32 s0, s9
	s_cbranch_execz .LBB57_40
; %bb.35:
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v35, s1, v0
	v_and_b32_e32 v0, 0x7fffffff, v35
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s9, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s9, exec_lo, s9
; %bb.36:
	v_bfe_u32 v0, v35, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v35, v0, 0x7fff
                                        ; implicit-def: $vgpr35
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.37:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s9, s9
; %bb.38:
	v_lshrrev_b32_e32 v0, 16, v35
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.39:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	global_store_b16 v[33:34], v0, off offset:2
.LBB57_40:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_mov_b32 s9, 0
.LBB57_41:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s9
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB57_74
; %bb.42:
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v33, 0
	s_and_not1_b32 vcc_lo, exec_lo, s8
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB57_62
; %bb.43:
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0
	s_and_saveexec_b32 s0, s6
	s_cbranch_execz .LBB57_51
; %bb.44:
	v_lshl_add_u32 v0, v75, 5, 0
	v_perm_b32 v37, 0, v29, 0x10c000c
	v_perm_b32 v38, 0, v29, 0x30c020c
	v_perm_b32 v39, 0, v30, 0x10c000c
	v_perm_b32 v40, 0, v30, 0x30c020c
	s_wait_dscnt 0x0
	ds_load_b128 v[33:36], v0
	v_perm_b32 v41, 0, v31, 0x10c000c
	v_perm_b32 v42, 0, v31, 0x30c020c
	v_perm_b32 v43, 0, v32, 0x10c000c
	v_perm_b32 v44, 0, v32, 0x30c020c
	ds_load_b128 v[29:32], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	s_wait_loadcnt 0x3
	v_lshrrev_b32_e32 v47, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_lshrrev_b32_e32 v48, 1, v39
	v_and_b32_e32 v39, 0x80008000, v39
	v_and_or_b32 v0, 0x3f803f80, v0, v37
	v_perm_b32 v45, 0, v25, 0x10c000c
	v_and_or_b32 v38, 0x3f803f80, v47, v38
	v_lshrrev_b32_e32 v37, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_and_or_b32 v39, 0x3f803f80, v48, v39
	v_perm_b32 v25, 0, v25, 0x30c020c
	s_wait_loadcnt 0x1
	v_lshrrev_b32_e32 v49, 1, v41
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v0, v33, 0
	v_and_b32_e32 v41, 0x80008000, v41
	v_lshrrev_b32_e32 v48, 1, v44
	v_and_or_b32 v37, 0x3f803f80, v37, v40
	v_lshrrev_b32_e32 v40, 1, v45
	v_dot2_f32_f16 v0, v38, v34, v0
	v_perm_b32 v46, 0, v26, 0x10c000c
	v_lshrrev_b32_e32 v38, 1, v43
	v_and_b32_e32 v43, 0x80008000, v43
	v_and_or_b32 v41, 0x3f803f80, v49, v41
	v_dot2_f32_f16 v0, v39, v35, v0
	v_and_b32_e32 v39, 0x80008000, v44
	v_and_b32_e32 v44, 0x80008000, v45
	v_and_or_b32 v38, 0x3f803f80, v38, v43
	v_and_b32_e32 v43, 0x80008000, v46
	v_dot2_f32_f16 v0, v37, v36, v0
	v_lshrrev_b32_e32 v37, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_and_or_b32 v40, 0x3f803f80, v40, v44
	v_perm_b32 v26, 0, v26, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v41, v29, v0
	v_lshrrev_b32_e32 v41, 1, v46
	v_and_or_b32 v25, 0x3f803f80, v37, v25
	v_dot2_f32_f16 v33, v40, v33, 0
	v_perm_b32 v37, 0, v27, 0x10c000c
	v_perm_b32 v27, 0, v27, 0x30c020c
	v_and_or_b32 v40, 0x3f803f80, v41, v43
	v_lshrrev_b32_e32 v41, 1, v26
	v_and_b32_e32 v26, 0x80008000, v26
	v_dot2_f32_f16 v25, v25, v34, v33
	v_lshrrev_b32_e32 v33, 1, v37
	v_and_b32_e32 v34, 0x80008000, v37
	v_lshrrev_b32_e32 v47, 1, v42
	v_and_or_b32 v26, 0x3f803f80, v41, v26
	v_dot2_f32_f16 v25, v40, v35, v25
	v_and_b32_e32 v42, 0x80008000, v42
	v_perm_b32 v35, 0, v28, 0x10c000c
	v_and_or_b32 v33, 0x3f803f80, v33, v34
	v_lshrrev_b32_e32 v34, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_dot2_f32_f16 v25, v26, v36, v25
	v_and_or_b32 v42, 0x3f803f80, v47, v42
	v_lshrrev_b32_e32 v26, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	v_perm_b32 v28, 0, v28, 0x30c020c
	v_and_or_b32 v27, 0x3f803f80, v34, v27
	v_dot2_f32_f16 v25, v33, v29, v25
	v_dot2_f32_f16 v0, v42, v30, v0
	v_and_or_b32 v26, 0x3f803f80, v26, v35
	v_lshrrev_b32_e32 v29, 1, v28
	v_and_b32_e32 v28, 0x80008000, v28
	v_dot2_f32_f16 v25, v27, v30, v25
	v_and_or_b32 v27, 0x3f803f80, v48, v39
	v_dot2_f32_f16 v0, v38, v31, v0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v28, 0x3f803f80, v29, v28
	v_dot2_f32_f16 v25, v26, v31, v25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v34, v27, v32, v0
	v_dot2_f32_f16 v33, v28, v32, v25
	s_and_saveexec_b32 s6, s5
	s_cbranch_execz .LBB57_50
; %bb.45:
	v_lshl_add_u32 v0, v78, 5, 0
	v_perm_b32 v29, 0, v21, 0x10c000c
	v_perm_b32 v30, 0, v21, 0x30c020c
	v_perm_b32 v31, 0, v22, 0x10c000c
	v_perm_b32 v32, 0, v22, 0x30c020c
	ds_load_b128 v[25:28], v0
	v_perm_b32 v35, 0, v23, 0x10c000c
	v_perm_b32 v36, 0, v23, 0x30c020c
	v_perm_b32 v37, 0, v24, 0x10c000c
	v_perm_b32 v38, 0, v24, 0x30c020c
	ds_load_b128 v[21:24], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v29
	v_and_b32_e32 v29, 0x80008000, v29
	v_lshrrev_b32_e32 v41, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_lshrrev_b32_e32 v42, 1, v31
	v_and_b32_e32 v31, 0x80008000, v31
	v_and_or_b32 v0, 0x3f803f80, v0, v29
	v_perm_b32 v39, 0, v17, 0x10c000c
	v_and_or_b32 v30, 0x3f803f80, v41, v30
	v_lshrrev_b32_e32 v29, 1, v32
	v_and_b32_e32 v32, 0x80008000, v32
	v_and_or_b32 v31, 0x3f803f80, v42, v31
	v_perm_b32 v17, 0, v17, 0x30c020c
	v_lshrrev_b32_e32 v43, 1, v35
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v0, v25, v34
	v_and_b32_e32 v34, 0x80008000, v35
	v_lshrrev_b32_e32 v41, 1, v38
	v_and_or_b32 v29, 0x3f803f80, v29, v32
	v_lshrrev_b32_e32 v32, 1, v39
	v_dot2_f32_f16 v0, v30, v26, v0
	v_perm_b32 v40, 0, v18, 0x10c000c
	v_lshrrev_b32_e32 v35, 1, v36
	v_and_b32_e32 v36, 0x80008000, v36
	v_and_or_b32 v34, 0x3f803f80, v43, v34
	v_dot2_f32_f16 v0, v31, v27, v0
	v_and_b32_e32 v31, 0x80008000, v38
	v_and_b32_e32 v38, 0x80008000, v39
	v_and_or_b32 v35, 0x3f803f80, v35, v36
	v_and_b32_e32 v36, 0x80008000, v40
	v_dot2_f32_f16 v0, v29, v28, v0
	v_lshrrev_b32_e32 v29, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_and_or_b32 v32, 0x3f803f80, v32, v38
	v_perm_b32 v18, 0, v18, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v34, v21, v0
	v_lshrrev_b32_e32 v34, 1, v40
	v_and_or_b32 v17, 0x3f803f80, v29, v17
	v_dot2_f32_f16 v25, v32, v25, v33
	v_perm_b32 v29, 0, v19, 0x10c000c
	v_lshrrev_b32_e32 v33, 1, v18
	v_and_or_b32 v32, 0x3f803f80, v34, v36
	v_and_b32_e32 v18, 0x80008000, v18
	v_dot2_f32_f16 v17, v17, v26, v25
	v_lshrrev_b32_e32 v25, 1, v29
	v_and_b32_e32 v26, 0x80008000, v29
	v_perm_b32 v19, 0, v19, 0x30c020c
	v_and_or_b32 v18, 0x3f803f80, v33, v18
	v_dot2_f32_f16 v17, v32, v27, v17
	v_perm_b32 v27, 0, v20, 0x10c000c
	v_and_or_b32 v25, 0x3f803f80, v25, v26
	v_lshrrev_b32_e32 v26, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_dot2_f32_f16 v17, v18, v28, v17
	v_lshrrev_b32_e32 v30, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	v_lshrrev_b32_e32 v18, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_perm_b32 v20, 0, v20, 0x30c020c
	v_and_or_b32 v19, 0x3f803f80, v26, v19
	v_dot2_f32_f16 v17, v25, v21, v17
	v_and_or_b32 v30, 0x3f803f80, v30, v37
	v_dot2_f32_f16 v0, v35, v22, v0
	v_and_or_b32 v18, 0x3f803f80, v18, v27
	v_lshrrev_b32_e32 v21, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_dot2_f32_f16 v17, v19, v22, v17
	v_and_or_b32 v19, 0x3f803f80, v41, v31
	v_dot2_f32_f16 v0, v30, v23, v0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v20, 0x3f803f80, v21, v20
	v_dot2_f32_f16 v17, v18, v23, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v34, v19, v24, v0
	v_dot2_f32_f16 v33, v20, v24, v17
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB57_49
; %bb.46:
	v_lshl_add_u32 v0, v77, 5, 0
	v_perm_b32 v21, 0, v13, 0x10c000c
	v_perm_b32 v22, 0, v13, 0x30c020c
	v_perm_b32 v23, 0, v14, 0x10c000c
	v_perm_b32 v24, 0, v14, 0x30c020c
	ds_load_b128 v[17:20], v0
	v_perm_b32 v25, 0, v15, 0x10c000c
	v_perm_b32 v26, 0, v15, 0x30c020c
	v_perm_b32 v27, 0, v16, 0x10c000c
	v_perm_b32 v28, 0, v16, 0x30c020c
	ds_load_b128 v[13:16], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_lshrrev_b32_e32 v31, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_lshrrev_b32_e32 v32, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_and_or_b32 v0, 0x3f803f80, v0, v21
	v_perm_b32 v29, 0, v9, 0x10c000c
	v_and_or_b32 v22, 0x3f803f80, v31, v22
	v_lshrrev_b32_e32 v21, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v23, 0x3f803f80, v32, v23
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_lshrrev_b32_e32 v35, 1, v25
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v0, v17, v34
	v_and_b32_e32 v25, 0x80008000, v25
	v_lshrrev_b32_e32 v32, 1, v28
	v_and_or_b32 v21, 0x3f803f80, v21, v24
	v_lshrrev_b32_e32 v24, 1, v29
	v_dot2_f32_f16 v0, v22, v18, v0
	v_perm_b32 v30, 0, v10, 0x10c000c
	v_lshrrev_b32_e32 v22, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_and_or_b32 v25, 0x3f803f80, v35, v25
	v_dot2_f32_f16 v0, v23, v19, v0
	v_and_b32_e32 v23, 0x80008000, v28
	v_and_b32_e32 v28, 0x80008000, v29
	v_and_or_b32 v22, 0x3f803f80, v22, v27
	v_and_b32_e32 v27, 0x80008000, v30
	v_dot2_f32_f16 v0, v21, v20, v0
	v_lshrrev_b32_e32 v21, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_and_or_b32 v24, 0x3f803f80, v24, v28
	v_perm_b32 v10, 0, v10, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v25, v13, v0
	v_lshrrev_b32_e32 v25, 1, v30
	v_and_or_b32 v9, 0x3f803f80, v21, v9
	v_dot2_f32_f16 v17, v24, v17, v33
	v_perm_b32 v21, 0, v11, 0x10c000c
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_and_or_b32 v24, 0x3f803f80, v25, v27
	v_lshrrev_b32_e32 v25, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_dot2_f32_f16 v9, v9, v18, v17
	v_lshrrev_b32_e32 v17, 1, v21
	v_and_b32_e32 v18, 0x80008000, v21
	v_lshrrev_b32_e32 v31, 1, v26
	v_and_or_b32 v10, 0x3f803f80, v25, v10
	v_dot2_f32_f16 v9, v24, v19, v9
	v_and_b32_e32 v26, 0x80008000, v26
	v_perm_b32 v19, 0, v12, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v17, v18
	v_lshrrev_b32_e32 v18, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_dot2_f32_f16 v9, v10, v20, v9
	v_and_or_b32 v26, 0x3f803f80, v31, v26
	v_lshrrev_b32_e32 v10, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_perm_b32 v12, 0, v12, 0x30c020c
	v_and_or_b32 v11, 0x3f803f80, v18, v11
	v_dot2_f32_f16 v9, v17, v13, v9
	v_dot2_f32_f16 v0, v26, v14, v0
	v_and_or_b32 v10, 0x3f803f80, v10, v19
	v_lshrrev_b32_e32 v13, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	v_dot2_f32_f16 v9, v11, v14, v9
	v_and_or_b32 v11, 0x3f803f80, v32, v23
	v_dot2_f32_f16 v0, v22, v15, v0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v12, 0x3f803f80, v13, v12
	v_dot2_f32_f16 v9, v10, v15, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v34, v11, v16, v0
	v_dot2_f32_f16 v33, v12, v16, v9
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB57_48
; %bb.47:
	v_lshl_add_u32 v0, v76, 5, 0
	v_perm_b32 v13, 0, v5, 0x10c000c
	v_perm_b32 v14, 0, v5, 0x30c020c
	v_perm_b32 v15, 0, v6, 0x10c000c
	v_perm_b32 v16, 0, v6, 0x30c020c
	ds_load_b128 v[9:12], v0
	v_perm_b32 v17, 0, v7, 0x10c000c
	v_perm_b32 v18, 0, v7, 0x30c020c
	v_perm_b32 v19, 0, v8, 0x10c000c
	v_perm_b32 v20, 0, v8, 0x30c020c
	ds_load_b128 v[5:8], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	v_lshrrev_b32_e32 v23, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_lshrrev_b32_e32 v24, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_and_or_b32 v0, 0x3f803f80, v0, v13
	v_perm_b32 v21, 0, v1, 0x10c000c
	v_and_or_b32 v14, 0x3f803f80, v23, v14
	v_lshrrev_b32_e32 v13, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_and_or_b32 v15, 0x3f803f80, v24, v15
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_lshrrev_b32_e32 v25, 1, v17
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v0, v0, v9, v34
	v_and_b32_e32 v17, 0x80008000, v17
	v_lshrrev_b32_e32 v24, 1, v20
	v_and_or_b32 v13, 0x3f803f80, v13, v16
	v_lshrrev_b32_e32 v16, 1, v21
	v_dot2_f32_f16 v0, v14, v10, v0
	v_perm_b32 v22, 0, v2, 0x10c000c
	v_lshrrev_b32_e32 v14, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_and_or_b32 v17, 0x3f803f80, v25, v17
	v_dot2_f32_f16 v0, v15, v11, v0
	v_and_b32_e32 v15, 0x80008000, v20
	v_and_b32_e32 v20, 0x80008000, v21
	v_and_or_b32 v14, 0x3f803f80, v14, v19
	v_and_b32_e32 v19, 0x80008000, v22
	v_dot2_f32_f16 v0, v13, v12, v0
	v_lshrrev_b32_e32 v13, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_and_or_b32 v16, 0x3f803f80, v16, v20
	v_perm_b32 v2, 0, v2, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v17, v5, v0
	v_lshrrev_b32_e32 v17, 1, v22
	v_and_or_b32 v1, 0x3f803f80, v13, v1
	v_dot2_f32_f16 v9, v16, v9, v33
	v_perm_b32 v13, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v16, 0x3f803f80, v17, v19
	v_lshrrev_b32_e32 v17, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_dot2_f32_f16 v1, v1, v10, v9
	v_lshrrev_b32_e32 v9, 1, v13
	v_and_b32_e32 v10, 0x80008000, v13
	v_lshrrev_b32_e32 v23, 1, v18
	v_and_or_b32 v2, 0x3f803f80, v17, v2
	v_dot2_f32_f16 v1, v16, v11, v1
	v_and_b32_e32 v18, 0x80008000, v18
	v_perm_b32 v11, 0, v4, 0x10c000c
	v_and_or_b32 v9, 0x3f803f80, v9, v10
	v_lshrrev_b32_e32 v10, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v1, v2, v12, v1
	v_and_or_b32 v18, 0x3f803f80, v23, v18
	v_lshrrev_b32_e32 v2, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v10, v3
	v_dot2_f32_f16 v1, v9, v5, v1
	v_dot2_f32_f16 v0, v18, v6, v0
	v_and_or_b32 v2, 0x3f803f80, v2, v11
	v_lshrrev_b32_e32 v5, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_dot2_f32_f16 v1, v3, v6, v1
	v_and_or_b32 v3, 0x3f803f80, v24, v15
	v_dot2_f32_f16 v0, v14, v7, v0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v4, 0x3f803f80, v5, v4
	v_dot2_f32_f16 v1, v2, v7, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v34, v3, v8, v0
	v_dot2_f32_f16 v33, v4, v8, v1
.LBB57_48:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB57_49:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB57_50:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
.LBB57_51:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_cmp_lt_u32 s15, 0x810
	s_cbranch_scc1 .LBB57_62
; %bb.52:
	v_lshlrev_b32_e32 v1, 5, v75
	v_or_b32_e32 v0, 0x80, v75
	s_add_co_i32 s0, s7, -1
	s_delay_alu instid0(VALU_DEP_2)
	v_add3_u32 v2, v1, 0, 0x1000
	s_branch .LBB57_57
.LBB57_53:                              ;   in Loop: Header=BB57_57 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
.LBB57_54:                              ;   in Loop: Header=BB57_57 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB57_55:                              ;   in Loop: Header=BB57_57 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB57_56:                              ;   in Loop: Header=BB57_57 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_add_nc_u32_e32 v0, 0x80, v0
	v_add_nc_u32_e32 v2, 0x1000, v2
	s_add_co_i32 s0, s0, -1
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s0, 0
	s_cbranch_scc0 .LBB57_62
.LBB57_57:                              ; =>This Inner Loop Header: Depth=1
	s_mov_b32 s3, exec_lo
	v_cmpx_gt_i32_e64 s14, v0
	s_cbranch_execz .LBB57_56
; %bb.58:                               ;   in Loop: Header=BB57_57 Depth=1
	v_ashrrev_i32_e32 v1, 31, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b64_e32 v[7:8], 4, v[0:1]
	v_add_co_u32 v3, vcc_lo, v71, v7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v4, null, v72, v8, vcc_lo
	v_add_co_u32 v7, vcc_lo, v73, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, v74, v8, vcc_lo
	s_clause 0x1
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	global_load_b128 v[7:10], v[7:8], off th:TH_LOAD_NT
	ds_load_b128 v[11:14], v2
	ds_load_b128 v[15:18], v2 offset:16
	s_wait_loadcnt 0x1
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v19, 0, v4, 0x10c000c
	s_wait_loadcnt 0x0
	v_perm_b32 v22, 0, v7, 0x10c000c
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_lshrrev_b32_e32 v26, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_perm_b32 v23, 0, v8, 0x10c000c
	v_lshrrev_b32_e32 v36, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_lshrrev_b32_e32 v27, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_lshrrev_b32_e32 v37, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_and_or_b32 v1, 0x3f803f80, v26, v1
	v_and_or_b32 v22, 0x3f803f80, v36, v22
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_lshrrev_b32_e32 v28, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_lshrrev_b32_e32 v38, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_and_or_b32 v3, 0x3f803f80, v27, v3
	v_and_or_b32 v7, 0x3f803f80, v37, v7
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v11, v34
	v_dot2_f32_f16 v11, v22, v11, v33
	v_perm_b32 v20, 0, v5, 0x10c000c
	v_perm_b32 v24, 0, v9, 0x10c000c
	v_lshrrev_b32_e32 v29, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_lshrrev_b32_e32 v39, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_and_or_b32 v19, 0x3f803f80, v28, v19
	v_and_or_b32 v22, 0x3f803f80, v38, v23
	v_dot2_f32_f16 v1, v3, v12, v1
	v_dot2_f32_f16 v3, v7, v12, v11
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_lshrrev_b32_e32 v30, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_lshrrev_b32_e32 v40, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v4, 0x3f803f80, v29, v4
	v_and_or_b32 v8, 0x3f803f80, v39, v8
	v_dot2_f32_f16 v1, v19, v13, v1
	v_dot2_f32_f16 v3, v22, v13, v3
	v_perm_b32 v21, 0, v6, 0x10c000c
	v_perm_b32 v25, 0, v10, 0x10c000c
	v_lshrrev_b32_e32 v31, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_lshrrev_b32_e32 v26, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_and_or_b32 v12, 0x3f803f80, v30, v20
	v_and_or_b32 v13, 0x3f803f80, v40, v24
	v_dot2_f32_f16 v1, v4, v14, v1
	v_dot2_f32_f16 v3, v8, v14, v3
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_perm_b32 v10, 0, v10, 0x30c020c
	v_lshrrev_b32_e32 v32, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_lshrrev_b32_e32 v7, 1, v25
	v_and_b32_e32 v11, 0x80008000, v25
	v_and_or_b32 v5, 0x3f803f80, v31, v5
	v_and_or_b32 v8, 0x3f803f80, v26, v9
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v12, v15, v1
	v_dot2_f32_f16 v3, v13, v15, v3
	v_lshrrev_b32_e32 v35, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_lshrrev_b32_e32 v4, 1, v10
	v_and_b32_e32 v9, 0x80008000, v10
	v_and_or_b32 v10, 0x3f803f80, v32, v21
	v_and_or_b32 v7, 0x3f803f80, v7, v11
	v_dot2_f32_f16 v5, v5, v16, v1
	v_dot2_f32_f16 v3, v8, v16, v3
	v_add_nc_u32_e32 v1, 32, v0
	v_and_or_b32 v6, 0x3f803f80, v35, v6
	v_and_or_b32 v4, 0x3f803f80, v4, v9
	v_dot2_f32_f16 v5, v10, v17, v5
	v_dot2_f32_f16 v3, v7, v17, v3
	v_cmp_gt_i32_e32 vcc_lo, s14, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v34, v6, v18, v5
	v_dot2_f32_f16 v33, v4, v18, v3
	s_and_saveexec_b32 s4, vcc_lo
	s_cbranch_execz .LBB57_55
; %bb.59:                               ;   in Loop: Header=BB57_57 Depth=1
	v_cndmask_b32_e32 v3, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_ashrrev_i32_e32 v4, 31, v3
	v_lshlrev_b64_e32 v[7:8], 4, v[3:4]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v3, vcc_lo, v71, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, v72, v8, vcc_lo
	v_add_co_u32 v7, vcc_lo, v73, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, v74, v8, vcc_lo
	s_clause 0x1
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	global_load_b128 v[7:10], v[7:8], off th:TH_LOAD_NT
	ds_load_b128 v[11:14], v2 offset:1024
	ds_load_b128 v[15:18], v2 offset:1040
	s_wait_loadcnt 0x1
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v19, 0, v4, 0x10c000c
	s_wait_loadcnt 0x0
	v_perm_b32 v22, 0, v7, 0x10c000c
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_lshrrev_b32_e32 v26, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_perm_b32 v23, 0, v8, 0x10c000c
	v_lshrrev_b32_e32 v36, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_lshrrev_b32_e32 v27, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_lshrrev_b32_e32 v37, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_and_or_b32 v1, 0x3f803f80, v26, v1
	v_and_or_b32 v22, 0x3f803f80, v36, v22
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_lshrrev_b32_e32 v28, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_lshrrev_b32_e32 v38, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_and_or_b32 v3, 0x3f803f80, v27, v3
	v_and_or_b32 v7, 0x3f803f80, v37, v7
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v11, v34
	v_dot2_f32_f16 v11, v22, v11, v33
	v_perm_b32 v20, 0, v5, 0x10c000c
	v_perm_b32 v24, 0, v9, 0x10c000c
	v_lshrrev_b32_e32 v29, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_lshrrev_b32_e32 v39, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_and_or_b32 v19, 0x3f803f80, v28, v19
	v_and_or_b32 v22, 0x3f803f80, v38, v23
	v_dot2_f32_f16 v1, v3, v12, v1
	v_dot2_f32_f16 v3, v7, v12, v11
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_lshrrev_b32_e32 v30, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_lshrrev_b32_e32 v40, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v4, 0x3f803f80, v29, v4
	v_and_or_b32 v8, 0x3f803f80, v39, v8
	v_dot2_f32_f16 v1, v19, v13, v1
	v_dot2_f32_f16 v3, v22, v13, v3
	v_perm_b32 v21, 0, v6, 0x10c000c
	v_perm_b32 v25, 0, v10, 0x10c000c
	v_lshrrev_b32_e32 v31, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_lshrrev_b32_e32 v26, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_and_or_b32 v12, 0x3f803f80, v30, v20
	v_and_or_b32 v13, 0x3f803f80, v40, v24
	v_dot2_f32_f16 v1, v4, v14, v1
	v_dot2_f32_f16 v3, v8, v14, v3
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_perm_b32 v10, 0, v10, 0x30c020c
	v_lshrrev_b32_e32 v32, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_lshrrev_b32_e32 v7, 1, v25
	v_and_b32_e32 v11, 0x80008000, v25
	v_and_or_b32 v5, 0x3f803f80, v31, v5
	v_and_or_b32 v8, 0x3f803f80, v26, v9
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v12, v15, v1
	v_dot2_f32_f16 v3, v13, v15, v3
	v_lshrrev_b32_e32 v35, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_lshrrev_b32_e32 v4, 1, v10
	v_and_b32_e32 v9, 0x80008000, v10
	v_and_or_b32 v10, 0x3f803f80, v32, v21
	v_and_or_b32 v7, 0x3f803f80, v7, v11
	v_dot2_f32_f16 v5, v5, v16, v1
	v_dot2_f32_f16 v3, v8, v16, v3
	v_add_nc_u32_e32 v1, 64, v0
	v_and_or_b32 v6, 0x3f803f80, v35, v6
	v_and_or_b32 v4, 0x3f803f80, v4, v9
	v_dot2_f32_f16 v5, v10, v17, v5
	v_dot2_f32_f16 v3, v7, v17, v3
	v_cmp_gt_i32_e32 vcc_lo, s14, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v34, v6, v18, v5
	v_dot2_f32_f16 v33, v4, v18, v3
	s_and_saveexec_b32 s5, vcc_lo
	s_cbranch_execz .LBB57_54
; %bb.60:                               ;   in Loop: Header=BB57_57 Depth=1
	v_cndmask_b32_e32 v3, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_ashrrev_i32_e32 v4, 31, v3
	v_lshlrev_b64_e32 v[7:8], 4, v[3:4]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v3, vcc_lo, v71, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, v72, v8, vcc_lo
	v_add_co_u32 v7, vcc_lo, v73, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, v74, v8, vcc_lo
	s_clause 0x1
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	global_load_b128 v[7:10], v[7:8], off th:TH_LOAD_NT
	ds_load_b128 v[11:14], v2 offset:2048
	ds_load_b128 v[15:18], v2 offset:2064
	s_wait_loadcnt 0x1
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v19, 0, v4, 0x10c000c
	s_wait_loadcnt 0x0
	v_perm_b32 v22, 0, v7, 0x10c000c
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_lshrrev_b32_e32 v26, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_perm_b32 v23, 0, v8, 0x10c000c
	v_lshrrev_b32_e32 v36, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_lshrrev_b32_e32 v27, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_lshrrev_b32_e32 v37, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_and_or_b32 v1, 0x3f803f80, v26, v1
	v_and_or_b32 v22, 0x3f803f80, v36, v22
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_lshrrev_b32_e32 v28, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_lshrrev_b32_e32 v38, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_and_or_b32 v3, 0x3f803f80, v27, v3
	v_and_or_b32 v7, 0x3f803f80, v37, v7
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v11, v34
	v_dot2_f32_f16 v11, v22, v11, v33
	v_perm_b32 v20, 0, v5, 0x10c000c
	v_perm_b32 v24, 0, v9, 0x10c000c
	v_lshrrev_b32_e32 v29, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_lshrrev_b32_e32 v39, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_and_or_b32 v19, 0x3f803f80, v28, v19
	v_and_or_b32 v22, 0x3f803f80, v38, v23
	v_dot2_f32_f16 v1, v3, v12, v1
	v_dot2_f32_f16 v3, v7, v12, v11
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_lshrrev_b32_e32 v30, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_lshrrev_b32_e32 v40, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v4, 0x3f803f80, v29, v4
	v_and_or_b32 v8, 0x3f803f80, v39, v8
	v_dot2_f32_f16 v1, v19, v13, v1
	v_dot2_f32_f16 v3, v22, v13, v3
	v_perm_b32 v21, 0, v6, 0x10c000c
	v_perm_b32 v25, 0, v10, 0x10c000c
	v_lshrrev_b32_e32 v31, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_lshrrev_b32_e32 v26, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_and_or_b32 v12, 0x3f803f80, v30, v20
	v_and_or_b32 v13, 0x3f803f80, v40, v24
	v_dot2_f32_f16 v1, v4, v14, v1
	v_dot2_f32_f16 v3, v8, v14, v3
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_perm_b32 v10, 0, v10, 0x30c020c
	v_lshrrev_b32_e32 v32, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_lshrrev_b32_e32 v7, 1, v25
	v_and_b32_e32 v11, 0x80008000, v25
	v_and_or_b32 v5, 0x3f803f80, v31, v5
	v_and_or_b32 v8, 0x3f803f80, v26, v9
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v12, v15, v1
	v_dot2_f32_f16 v3, v13, v15, v3
	v_lshrrev_b32_e32 v35, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_lshrrev_b32_e32 v4, 1, v10
	v_and_b32_e32 v9, 0x80008000, v10
	v_and_or_b32 v10, 0x3f803f80, v32, v21
	v_and_or_b32 v7, 0x3f803f80, v7, v11
	v_dot2_f32_f16 v5, v5, v16, v1
	v_dot2_f32_f16 v3, v8, v16, v3
	v_add_nc_u32_e32 v1, 0x60, v0
	v_and_or_b32 v6, 0x3f803f80, v35, v6
	v_and_or_b32 v4, 0x3f803f80, v4, v9
	v_dot2_f32_f16 v5, v10, v17, v5
	v_dot2_f32_f16 v3, v7, v17, v3
	v_cmp_gt_i32_e32 vcc_lo, s14, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v34, v6, v18, v5
	v_dot2_f32_f16 v33, v4, v18, v3
	s_and_saveexec_b32 s6, vcc_lo
	s_cbranch_execz .LBB57_53
; %bb.61:                               ;   in Loop: Header=BB57_57 Depth=1
	v_cndmask_b32_e32 v3, 0, v1, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_ashrrev_i32_e32 v4, 31, v3
	v_lshlrev_b64_e32 v[7:8], 4, v[3:4]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v3, vcc_lo, v71, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, v72, v8, vcc_lo
	v_add_co_u32 v7, vcc_lo, v73, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, v74, v8, vcc_lo
	s_clause 0x1
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	global_load_b128 v[7:10], v[7:8], off th:TH_LOAD_NT
	ds_load_b128 v[11:14], v2 offset:3072
	ds_load_b128 v[15:18], v2 offset:3088
	s_wait_loadcnt 0x1
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v19, 0, v4, 0x10c000c
	s_wait_loadcnt 0x0
	v_perm_b32 v22, 0, v7, 0x10c000c
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_lshrrev_b32_e32 v26, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_perm_b32 v23, 0, v8, 0x10c000c
	v_lshrrev_b32_e32 v36, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_lshrrev_b32_e32 v27, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_lshrrev_b32_e32 v37, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_and_or_b32 v1, 0x3f803f80, v26, v1
	v_and_or_b32 v22, 0x3f803f80, v36, v22
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_lshrrev_b32_e32 v28, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_lshrrev_b32_e32 v38, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_and_or_b32 v3, 0x3f803f80, v27, v3
	v_and_or_b32 v7, 0x3f803f80, v37, v7
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v11, v34
	v_dot2_f32_f16 v11, v22, v11, v33
	v_perm_b32 v20, 0, v5, 0x10c000c
	v_perm_b32 v24, 0, v9, 0x10c000c
	v_lshrrev_b32_e32 v29, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_lshrrev_b32_e32 v39, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_and_or_b32 v19, 0x3f803f80, v28, v19
	v_and_or_b32 v22, 0x3f803f80, v38, v23
	v_dot2_f32_f16 v1, v3, v12, v1
	v_dot2_f32_f16 v3, v7, v12, v11
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_lshrrev_b32_e32 v30, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_lshrrev_b32_e32 v40, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v4, 0x3f803f80, v29, v4
	v_and_or_b32 v8, 0x3f803f80, v39, v8
	v_dot2_f32_f16 v1, v19, v13, v1
	v_dot2_f32_f16 v3, v22, v13, v3
	v_perm_b32 v21, 0, v6, 0x10c000c
	v_perm_b32 v25, 0, v10, 0x10c000c
	v_lshrrev_b32_e32 v31, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_lshrrev_b32_e32 v26, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_and_or_b32 v12, 0x3f803f80, v30, v20
	v_and_or_b32 v13, 0x3f803f80, v40, v24
	v_dot2_f32_f16 v1, v4, v14, v1
	v_dot2_f32_f16 v3, v8, v14, v3
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_perm_b32 v10, 0, v10, 0x30c020c
	v_lshrrev_b32_e32 v32, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_lshrrev_b32_e32 v7, 1, v25
	v_and_b32_e32 v11, 0x80008000, v25
	v_and_or_b32 v5, 0x3f803f80, v31, v5
	v_and_or_b32 v8, 0x3f803f80, v26, v9
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v12, v15, v1
	v_dot2_f32_f16 v3, v13, v15, v3
	v_lshrrev_b32_e32 v35, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_lshrrev_b32_e32 v4, 1, v10
	v_and_b32_e32 v9, 0x80008000, v10
	v_and_or_b32 v10, 0x3f803f80, v32, v21
	v_and_or_b32 v7, 0x3f803f80, v7, v11
	v_dot2_f32_f16 v1, v5, v16, v1
	v_dot2_f32_f16 v3, v8, v16, v3
	v_and_or_b32 v5, 0x3f803f80, v35, v6
	v_and_or_b32 v4, 0x3f803f80, v4, v9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v1, v10, v17, v1
	v_dot2_f32_f16 v3, v7, v17, v3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v34, v5, v18, v1
	v_dot2_f32_f16 v33, v4, v18, v3
	s_branch .LBB57_53
.LBB57_62:
	v_mbcnt_lo_u32_b32 v0, -1, 0
	s_mov_b32 s3, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v1, 16, v0
	v_xor_b32_e32 v3, 8, v0
	v_xor_b32_e32 v4, 4, v0
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v4, v0, v4 :: v_dual_lshlrev_b32 v3, 2, v3
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v2, 2, v1
	ds_bpermute_b32 v1, v2, v34
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v34, v1
	ds_bpermute_b32 v5, v3, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v5
	v_xor_b32_e32 v5, 2, v0
	ds_bpermute_b32 v6, v4, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v5, 2, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v6
	v_xor_b32_e32 v6, 1, v0
	ds_bpermute_b32 v7, v5, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_add_f32 v7, v1, v7 :: v_dual_lshlrev_b32 v6, 2, v0
	v_lshlrev_b64_e32 v[0:1], 1, v[69:70]
	ds_bpermute_b32 v8, v6, v7
	s_wait_kmcnt 0x0
	v_add_co_u32 v0, s0, s10, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v1, null, s11, v1, s0
	s_mov_b32 s0, exec_lo
	v_cmpx_eq_u32_e32 0, v75
	s_cbranch_execz .LBB57_68
; %bb.63:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s1, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s3, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
; %bb.64:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.65:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s3, s3
; %bb.66:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.67:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s3, s2, exec_lo
	global_store_b16 v[0:1], v7, off
.LBB57_68:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	ds_bpermute_b32 v2, v2, v33
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v33, v2
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v6, v2
	s_and_b32 exec_lo, exec_lo, s3
	s_cbranch_execz .LBB57_74
; %bb.69:
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, 0x47800000, v2
	v_mul_f32_e32 v3, s1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.70:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.71:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.72:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.73:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	global_store_b16 v[0:1], v2, off offset:2
.LBB57_74:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 296
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 113
		.amdhsa_next_free_sgpr 25
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 204
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,"axG",@progbits,_ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,comdat
.Lfunc_end57:
