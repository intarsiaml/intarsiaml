_ZN12_GLOBAL__N_119moe_down_g2f_kernelILi4EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iii: ; @_ZN12_GLOBAL__N_119moe_down_g2f_kernelILi4EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iii
; %bb.0:
	s_load_b64 s[2:3], s[0:1], 0x30
	s_mov_b32 s4, exec_lo
	v_cmpx_gt_u32_e32 16, v0
	s_cbranch_execz .LBB11_2
; %bb.1:
	v_and_b32_e32 v1, 7, v0
	v_lshlrev_b32_e32 v3, 28, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v2, v1, 22, 0.5
	v_cmp_ne_u32_e32 vcc_lo, 1, v1
	v_cndmask_b32_e32 v2, 0.5, v2, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v1
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v1, 0, v2 :: v_dual_lshlrev_b32 v2, 2, v0
	v_and_or_b32 v1, 0x80000000, v3, v1
	ds_store_b32 v2, v1
.LBB11_2:
	s_or_b32 exec_lo, exec_lo, s4
	s_load_b96 s[4:6], s[0:1], 0x40
	s_wait_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_wait_kmcnt 0x0
	s_ashr_i32 s9, s4, 31
	s_mov_b32 s8, s4
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_lshl_b64 s[8:9], s[8:9], 2
	s_add_nc_u64 s[8:9], s[2:3], s[8:9]
	s_load_b32 s4, s[8:9], 0x0
	s_wait_kmcnt 0x0
	s_cmp_ge_i32 ttmp9, s4
	s_cbranch_scc1 .LBB11_234
; %bb.3:
	v_lshrrev_b32_e32 v1, 3, v0
	s_lshl_b32 s4, ttmp7, 5
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)
	v_and_or_b32 v1, v1, 28, s4
	s_mov_b32 s4, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s5, v1
	s_cbranch_execz .LBB11_234
; %bb.4:
	s_mov_b32 s8, ttmp9
	s_ashr_i32 s9, ttmp9, 31
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_lshl_b64 s[8:9], s[8:9], 2
	s_add_nc_u64 s[2:3], s[2:3], s[8:9]
	s_load_b32 s20, s[2:3], 0x0
	s_load_b64 s[2:3], s[0:1], 0x28
	s_wait_kmcnt 0x0
	s_ashr_i32 s21, s20, 31
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_lshl_b64 s[8:9], s[20:21], 2
	s_add_nc_u64 s[2:3], s[2:3], s[8:9]
	s_load_b64 s[18:19], s[2:3], 0x0
	s_wait_kmcnt 0x0
	s_sub_co_i32 s26, s19, s18
	s_delay_alu instid0(SALU_CYCLE_1)
	s_cmp_lt_i32 s26, 1
	s_cbranch_scc1 .LBB11_234
; %bb.5:
	v_or_b32_e32 v15, 3, v1
	s_add_co_i32 s4, s5, -1
	v_and_b32_e32 v16, 31, v0
	v_or_b32_e32 v18, 2, v1
	s_ashr_i32 s17, s5, 31
	s_wait_alu 0xfffe
	v_min_i32_e32 v0, s4, v15
	s_mov_b32 s16, s5
	v_or_b32_e32 v20, 1, v1
	s_mul_u64 s[2:3], s[20:21], s[16:17]
	s_load_b256 s[8:15], s[0:1], 0x0
	v_ashrrev_i32_e32 v2, 31, v0
	v_add_co_u32 v14, vcc_lo, s2, v0
	v_min_i32_e32 v0, s4, v18
	v_min_i32_e32 v3, s4, v20
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v17, null, s3, v2, vcc_lo
	v_min_i32_e32 v4, s4, v1
	v_ashrrev_i32_e32 v2, 31, v0
	s_ashr_i32 s7, s6, 31
	v_add_co_u32 v12, vcc_lo, s2, v0
	s_lshr_b32 s19, s7, 28
	v_ashrrev_i32_e32 v0, 31, v3
	s_add_co_i32 s19, s6, s19
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v13, null, s3, v2, vcc_lo
	v_ashrrev_i32_e32 v2, 31, v4
	v_add_co_u32 v8, vcc_lo, s2, v3
	s_ashr_i32 s21, s19, 4
	s_lshr_b32 s19, s6, 31
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v0, null, s3, v0, vcc_lo
	v_add_co_u32 v4, vcc_lo, s2, v4
	s_add_co_i32 s19, s6, s19
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s3, v2, vcc_lo
	s_ashr_i32 s19, s19, 1
	s_ashr_i32 s22, s21, 31
	s_ashr_i32 s23, s19, 31
	v_cmp_le_i32_e64 s2, s21, v16
	v_mul_lo_u32 v9, v4, s22
	v_mul_lo_u32 v10, v5, s21
	s_wait_kmcnt 0x0
	v_mad_co_u64_u32 v[2:3], null, v4, s21, s[12:13]
	v_mul_lo_u32 v11, v4, s23
	v_mul_lo_u32 v25, v5, s19
	v_mad_co_u64_u32 v[4:5], null, v4, s19, s[10:11]
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v26, v16, 0, s2
	v_mul_lo_u32 v23, v0, s21
	v_mul_lo_u32 v24, v8, s22
	v_mad_co_u64_u32 v[6:7], null, v8, s21, s[12:13]
	v_mul_lo_u32 v27, v0, s19
	v_add3_u32 v0, v10, v3, v9
	v_add3_u32 v5, v25, v5, v11
	v_lshlrev_b32_e32 v25, 3, v26
	v_mul_lo_u32 v28, v8, s23
	v_mad_co_u64_u32 v[8:9], null, v8, s19, s[10:11]
	v_add_co_u32 v2, vcc_lo, v2, v26
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, 0, v0, vcc_lo
	v_add_co_u32 v4, vcc_lo, v4, v25
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo
	v_add3_u32 v7, v23, v7, v24
	v_add3_u32 v9, v27, v9, v28
	global_load_i8 v0, v[2:3], off
	global_load_b64 v[3:4], v[4:5], off th:TH_LOAD_NT
	v_add_co_u32 v5, vcc_lo, v6, v26
	v_mul_lo_u32 v22, v13, s21
	v_mul_lo_u32 v29, v12, s22
	v_mad_co_u64_u32 v[10:11], null, v12, s21, s[12:13]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v7, vcc_lo
	v_add_co_u32 v7, vcc_lo, v8, v25
	v_mul_lo_u32 v2, v13, s19
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo
	v_mul_lo_u32 v9, v12, s23
	v_mad_co_u64_u32 v[12:13], null, v12, s19, s[10:11]
	v_add3_u32 v11, v22, v11, v29
	v_mul_lo_u32 v19, v17, s21
	v_mul_lo_u32 v21, v14, s22
	global_load_i8 v23, v[5:6], off
	global_load_b64 v[5:6], v[7:8], off th:TH_LOAD_NT
	v_mad_co_u64_u32 v[7:8], null, v14, s21, s[12:13]
	v_add3_u32 v2, v2, v13, v9
	v_mul_lo_u32 v17, v17, s19
	v_mul_lo_u32 v24, v14, s23
	v_add_co_u32 v9, vcc_lo, v10, v26
	v_mad_co_u64_u32 v[13:14], null, v14, s19, s[10:11]
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo
	v_add_co_u32 v11, vcc_lo, v12, v25
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo
	v_add3_u32 v2, v19, v8, v21
	global_load_i8 v22, v[9:10], off
	global_load_b64 v[9:10], v[11:12], off th:TH_LOAD_NT
	v_add3_u32 v12, v17, v14, v24
	v_add_co_u32 v7, vcc_lo, v7, v26
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo
	v_add_co_u32 v11, vcc_lo, v13, v25
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v12, null, 0, v12, vcc_lo
	global_load_i8 v13, v[7:8], off
	global_load_b64 v[7:8], v[11:12], off th:TH_LOAD_NT
	s_clause 0x1
	s_load_b64 s[12:13], s[0:1], 0x38
	s_load_b64 s[10:11], s[0:1], 0x20
	s_mul_i32 s0, s20, 3
	v_cmp_gt_i32_e32 vcc_lo, s5, v15
	s_ashr_i32 s1, s0, 31
	v_cmp_gt_i32_e64 s4, s5, v20
	s_lshl_b64 s[22:23], s[0:1], 2
	v_cmp_eq_u32_e64 s0, 0, v16
	v_cmp_gt_i32_e64 s1, s21, v16
	v_cmp_gt_i32_e64 s3, s5, v18
	v_ashrrev_i32_e32 v2, 31, v1
	s_ashr_i32 s19, s18, 31
	s_and_b32 s28, s0, s4
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[14:15], s[22:23]
	s_mov_b32 s27, 0
	s_load_b32 s29, s[4:5], 0x8
	v_lshlrev_b64_e32 v[1:2], 1, v[1:2]
	s_and_b32 s3, s0, s3
	s_and_b32 s30, s0, vcc_lo
	s_mov_b32 s31, s26
	s_wait_loadcnt 0x7
	v_and_b32_e32 v12, 7, v0
	s_wait_loadcnt 0x6
	v_lshrrev_b32_e32 v15, 2, v3
	v_lshrrev_b32_e32 v16, 6, v3
	v_lshrrev_b32_e32 v17, 10, v3
	v_lshrrev_b32_e32 v18, 14, v3
	v_and_b32_e32 v21, 15, v4
	v_lshrrev_b32_e32 v27, 6, v4
	v_lshrrev_b32_e32 v28, 10, v4
	v_lshrrev_b32_e32 v29, 14, v4
	v_lshrrev_b32_e32 v30, 18, v4
	v_lshrrev_b32_e32 v31, 22, v4
	v_lshrrev_b32_e32 v19, 18, v3
	v_lshrrev_b32_e32 v20, 22, v3
	v_and_b32_e32 v15, 60, v15
	v_and_b32_e32 v16, 60, v16
	v_and_b32_e32 v17, 60, v17
	v_and_b32_e32 v18, 60, v18
	v_cvt_f32_ubyte0_e32 v12, v12
	v_and_b32_e32 v19, 60, v19
	v_and_b32_e32 v20, 60, v20
	s_wait_loadcnt 0x5
	v_and_b32_e32 v32, 7, v23
	s_wait_loadcnt 0x4
	v_and_b32_e32 v33, 15, v5
	v_lshrrev_b32_e32 v34, 2, v5
	v_lshrrev_b32_e32 v35, 6, v5
	v_lshrrev_b32_e32 v36, 10, v5
	v_lshrrev_b32_e32 v37, 14, v5
	v_lshrrev_b32_e32 v38, 18, v5
	v_lshrrev_b32_e32 v39, 22, v5
	v_and_b32_e32 v40, 15, v6
	v_lshrrev_b32_e32 v41, 2, v6
	v_lshlrev_b32_e32 v21, 2, v21
	v_and_b32_e32 v78, 60, v27
	v_and_b32_e32 v79, 60, v28
	v_and_b32_e32 v80, 60, v29
	v_and_b32_e32 v81, 60, v30
	v_and_b32_e32 v82, 60, v31
	v_cvt_f32_ubyte0_e32 v83, v32
	v_lshlrev_b32_e32 v84, 2, v33
	s_wait_loadcnt 0x3
	v_and_b32_e32 v47, 7, v22
	v_and_b32_e32 v85, 60, v34
	v_and_b32_e32 v86, 60, v35
	v_and_b32_e32 v87, 60, v36
	v_and_b32_e32 v88, 60, v37
	v_cvt_f32_ubyte0_e32 v104, v47
	v_lshlrev_b32_e32 v11, 5, v26
	v_lshrrev_b32_e32 v26, 2, v4
	v_lshrrev_b32_e32 v4, 26, v4
	v_and_b32_e32 v89, 60, v38
	v_and_b32_e32 v95, 60, v39
	v_lshlrev_b32_e32 v96, 2, v40
	s_wait_loadcnt 0x1
	v_and_b32_e32 v62, 7, v13
	v_and_b32_e32 v4, 60, v4
	v_and_b32_e32 v77, 60, v26
	v_and_b32_e32 v97, 60, v41
	v_lshrrev_b32_e32 v42, 6, v6
	v_cvt_f32_ubyte0_e32 v120, v62
	v_and_b32_e32 v14, 15, v3
	v_lshrrev_b32_e32 v3, 26, v3
	v_lshrrev_b32_e32 v43, 10, v6
	v_lshrrev_b32_e32 v44, 14, v6
	v_lshrrev_b32_e32 v45, 18, v6
	v_lshlrev_b32_e32 v14, 2, v14
	v_and_b32_e32 v3, 60, v3
	ds_load_b32 v26, v14
	ds_load_b32 v27, v15
	ds_load_b32 v28, v16
	ds_load_b32 v29, v17
	ds_load_b32 v30, v18
	ds_load_b32 v31, v19
	ds_load_b32 v32, v20
	ds_load_b32 v33, v3
	ds_load_b32 v34, v21
	ds_load_b32 v35, v77
	ds_load_b32 v36, v78
	ds_load_b32 v37, v79
	ds_load_b32 v38, v80
	ds_load_b32 v39, v81
	ds_load_b32 v40, v82
	ds_load_b32 v41, v4
	v_mul_f32_e32 v4, 0x3b000000, v104
	v_add_co_u32 v24, s8, s8, v11
	v_and_b32_e32 v11, 0x7f, v0
	v_lshrrev_b32_e32 v46, 22, v6
	v_lshrrev_b32_e32 v6, 26, v6
	v_and_b32_e32 v90, 0x7f, v23
	v_lshrrev_b32_e32 v5, 26, v5
	v_and_b32_e32 v48, 15, v9
	v_lshrrev_b32_e32 v49, 2, v9
	v_lshrrev_b32_e32 v50, 6, v9
	v_lshrrev_b32_e32 v51, 10, v9
	v_lshrrev_b32_e32 v52, 14, v9
	v_lshrrev_b32_e32 v53, 18, v9
	v_lshrrev_b32_e32 v54, 22, v9
	v_and_b32_e32 v55, 15, v10
	v_lshrrev_b32_e32 v56, 2, v10
	v_lshrrev_b32_e32 v57, 6, v10
	v_lshl_add_u32 v93, v11, 20, 0x3c000000
	v_mul_f32_e32 v12, 0x3b000000, v12
	v_cmp_lt_u32_e64 s4, 7, v11
	v_and_b32_e32 v6, 60, v6
	v_and_b32_e32 v91, 0x7f, v22
	v_lshl_add_u32 v94, v90, 20, 0x3c000000
	v_and_b32_e32 v5, 60, v5
	v_and_b32_e32 v98, 60, v42
	v_and_b32_e32 v99, 60, v43
	v_and_b32_e32 v100, 60, v44
	v_and_b32_e32 v101, 60, v45
	v_and_b32_e32 v102, 60, v46
	v_lshlrev_b32_e32 v105, 2, v48
	v_and_b32_e32 v106, 60, v49
	v_and_b32_e32 v107, 60, v50
	v_and_b32_e32 v108, 60, v51
	v_and_b32_e32 v109, 60, v52
	v_and_b32_e32 v110, 60, v53
	v_and_b32_e32 v111, 60, v54
	v_lshlrev_b32_e32 v112, 2, v55
	v_and_b32_e32 v113, 60, v56
	v_dual_mul_f32 v3, 0x3b000000, v83 :: v_dual_and_b32 v114, 60, v57
	ds_load_b32 v42, v84
	ds_load_b32 v43, v85
	ds_load_b32 v44, v86
	ds_load_b32 v45, v87
	ds_load_b32 v46, v88
	ds_load_b32 v47, v89
	ds_load_b32 v48, v95
	ds_load_b32 v49, v5
	ds_load_b32 v50, v96
	ds_load_b32 v51, v97
	ds_load_b32 v52, v98
	ds_load_b32 v53, v99
	ds_load_b32 v54, v100
	ds_load_b32 v55, v101
	ds_load_b32 v56, v102
	ds_load_b32 v57, v6
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v6, v12, v93, s4
	v_cmp_lt_u32_e64 s4, 7, v90
	s_wait_loadcnt 0x0
	v_and_b32_e32 v63, 15, v7
	v_lshrrev_b32_e32 v64, 2, v7
	v_lshrrev_b32_e32 v65, 6, v7
	v_lshrrev_b32_e32 v66, 10, v7
	v_and_b32_e32 v92, 0x7f, v13
	v_lshrrev_b32_e32 v67, 14, v7
	v_lshl_add_u32 v103, v91, 20, 0x3c000000
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v3, v3, v94, s4
	v_cmp_lt_u32_e64 s4, 7, v91
	v_lshrrev_b32_e32 v9, 26, v9
	v_lshrrev_b32_e32 v58, 10, v10
	v_lshrrev_b32_e32 v59, 14, v10
	v_lshrrev_b32_e32 v60, 18, v10
	v_lshrrev_b32_e32 v61, 22, v10
	v_lshrrev_b32_e32 v10, 26, v10
	v_lshrrev_b32_e32 v68, 18, v7
	v_lshrrev_b32_e32 v69, 22, v7
	v_lshrrev_b32_e32 v7, 26, v7
	v_and_b32_e32 v70, 15, v8
	v_lshrrev_b32_e32 v71, 2, v8
	v_lshrrev_b32_e32 v72, 6, v8
	v_lshrrev_b32_e32 v73, 10, v8
	v_lshrrev_b32_e32 v74, 14, v8
	v_lshrrev_b32_e32 v75, 18, v8
	v_lshrrev_b32_e32 v76, 22, v8
	v_lshrrev_b32_e32 v8, 26, v8
	v_lshlrev_b32_e32 v121, 2, v63
	v_and_b32_e32 v122, 60, v64
	v_and_b32_e32 v123, 60, v65
	v_and_b32_e32 v124, 60, v66
	v_lshl_add_u32 v119, v92, 20, 0x3c000000
	v_and_b32_e32 v125, 60, v67
	v_mul_f32_e32 v5, 0x3b000000, v120
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v4, v4, v103, s4
	v_cmp_lt_u32_e64 s4, 7, v92
	v_and_b32_e32 v9, 60, v9
	v_and_b32_e32 v115, 60, v58
	v_and_b32_e32 v116, 60, v59
	v_and_b32_e32 v117, 60, v60
	v_and_b32_e32 v118, 60, v61
	v_and_b32_e32 v10, 60, v10
	v_and_b32_e32 v126, 60, v68
	v_and_b32_e32 v127, 60, v69
	v_and_b32_e32 v7, 60, v7
	v_lshlrev_b32_e32 v128, 2, v70
	v_and_b32_e32 v129, 60, v71
	v_and_b32_e32 v130, 60, v72
	v_and_b32_e32 v131, 60, v73
	v_and_b32_e32 v132, 60, v74
	v_and_b32_e32 v133, 60, v75
	v_and_b32_e32 v134, 60, v76
	v_and_b32_e32 v8, 60, v8
	ds_load_b32 v58, v105
	ds_load_b32 v59, v106
	ds_load_b32 v60, v107
	ds_load_b32 v61, v108
	ds_load_b32 v62, v109
	ds_load_b32 v63, v110
	ds_load_b32 v64, v111
	ds_load_b32 v65, v9
	ds_load_b32 v66, v112
	ds_load_b32 v67, v113
	ds_load_b32 v68, v114
	ds_load_b32 v69, v115
	ds_load_b32 v70, v116
	ds_load_b32 v71, v117
	ds_load_b32 v72, v118
	ds_load_b32 v73, v10
	ds_load_b32 v74, v121
	ds_load_b32 v75, v122
	ds_load_b32 v76, v123
	ds_load_b32 v77, v124
	ds_load_b32 v78, v125
	ds_load_b32 v79, v126
	ds_load_b32 v80, v127
	ds_load_b32 v81, v7
	ds_load_b32 v82, v128
	ds_load_b32 v83, v129
	ds_load_b32 v84, v130
	ds_load_b32 v85, v131
	ds_load_b32 v86, v132
	ds_load_b32 v87, v133
	ds_load_b32 v88, v134
	ds_load_b32 v89, v8
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v5, v5, v119, s4
	v_cmp_ne_u32_e64 s4, 0x7f, v11
	v_add_co_ci_u32_e64 v25, null, s9, 0, s8
	v_mbcnt_lo_u32_b32 v96, -1, 0
	s_wait_alu 0xf1ff
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v6, 0x7fc00000, v6, s4
	v_cmp_ne_u32_e64 s4, 0x7f, v90
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v3, 0x7fc00000, v3, s4
	v_cmp_ne_u32_e64 s4, 0x7f, v91
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v93, 0x80000000, v23, v3
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v4, 0x7fc00000, v4, s4
	v_cmp_ne_u32_e64 s4, 0x7f, v92
	v_and_or_b32 v92, 0x80000000, v0, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v94, 0x80000000, v22, v4
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v5, 0x7fc00000, v5, s4
	s_wait_kmcnt 0x0
	v_add_co_u32 v90, s4, s12, v1
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v91, null, s13, v2, s4
	v_and_or_b32 v95, 0x80000000, v13, v5
	s_lshl_b64 s[4:5], s[18:19], 2
	s_wait_alu 0xfffe
	s_add_nc_u64 s[4:5], s[10:11], s[4:5]
	s_branch .LBB11_9
.LBB11_6:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_wait_kmcnt 0x0
	s_ashr_i32 s9, s8, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[8:9], s[8:9], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[8:9], s[8:9], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v1, vcc_lo, v90, s8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s9, v91, vcc_lo
	global_store_b16 v[1:2], v0, off offset:6
.LBB11_7:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
.LBB11_8:                               ;   in Loop: Header=BB11_9 Depth=1
	s_add_co_i32 s27, s27, 8
	s_add_co_i32 s31, s31, -8
	s_cmp_lt_i32 s27, s26
	s_add_nc_u64 s[4:5], s[4:5], 32
	s_cbranch_scc0 .LBB11_234
.LBB11_9:                               ; =>This Inner Loop Header: Depth=1
	s_load_b32 s24, s[4:5], 0x0
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v102, 0
	s_wait_dscnt 0x0
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v18, 0
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v106, 0
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v104, 0
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v105, 0
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v109, 0
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v111, 0
	s_wait_kmcnt 0x0
	s_ashr_i32 s25, s24, 31
	s_cmp_gt_i32 s31, 1
	s_cselect_b32 s22, -1, 0
	s_wait_alu 0xfffe
	v_cndmask_b32_e64 v97, 0, 1, s22
	s_delay_alu instid0(VALU_DEP_1)
	v_readfirstlane_b32 s8, v97
	s_lshl_b32 s8, s8, 2
	s_load_b32 s20, s[4:5], s8 offset:0x0
	s_wait_kmcnt 0x0
	s_ashr_i32 s21, s20, 31
	s_cmp_gt_i32 s31, 2
	s_cselect_b32 s37, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s8, s37, exec_lo
	s_cselect_b32 s8, 8, 0
	s_load_b32 s14, s[4:5], s8 offset:0x0
	s_wait_kmcnt 0x0
	s_ashr_i32 s15, s14, 31
	s_cmp_gt_i32 s31, 3
	s_cselect_b32 s36, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s8, s36, exec_lo
	s_cselect_b32 s8, 12, 0
	s_load_b32 s10, s[4:5], s8 offset:0x0
	s_wait_kmcnt 0x0
	s_ashr_i32 s11, s10, 31
	s_cmp_gt_i32 s31, 4
	s_cselect_b32 s9, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s8, s9, exec_lo
	s_cselect_b32 s8, 16, 0
	s_cmp_gt_i32 s31, 5
	s_cselect_b32 s35, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)
	s_and_b32 s12, s35, exec_lo
	s_cselect_b32 s12, 20, 0
	s_cmp_gt_i32 s31, 6
	s_cselect_b32 s34, -1, 0
	s_and_b32 s13, s34, exec_lo
	s_cselect_b32 s13, 24, 0
	s_cmp_gt_i32 s31, 7
	s_cselect_b32 s33, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s18, s33, exec_lo
	s_cselect_b32 s19, 28, 0
	s_and_saveexec_b32 s18, s1
	s_cbranch_execz .LBB11_18
; %bb.10:                               ;   in Loop: Header=BB11_9 Depth=1
	s_mul_u64 s[38:39], s[20:21], s[6:7]
	s_mul_u64 s[40:41], s[14:15], s[6:7]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_lshl_b64 s[40:41], s[40:41], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v0, vcc_lo, v24, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s39, v25, vcc_lo
	s_mul_u64 s[38:39], s[10:11], s[6:7]
	v_add_co_u32 v2, vcc_lo, v24, s40
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s41, v25, vcc_lo
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v24, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s39, v25, vcc_lo
	s_clause 0x5
	global_load_b128 v[16:19], v[0:1], off offset:16
	global_load_b128 v[20:23], v[0:1], off
	global_load_b128 v[8:11], v[2:3], off offset:16
	global_load_b128 v[12:15], v[2:3], off
	global_load_b128 v[0:3], v[4:5], off offset:16
	global_load_b128 v[4:7], v[4:5], off
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v111, 0
	v_mov_b32_e32 v110, 0
	v_mov_b32_e32 v106, 0
	v_mov_b32_e32 v102, 0
	s_cmp_lt_i32 s31, 1
	s_cbranch_scc1 .LBB11_12
; %bb.11:                               ;   in Loop: Header=BB11_9 Depth=1
	s_mul_u64 s[38:39], s[24:25], s[6:7]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v103, vcc_lo, v24, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v104, null, s39, v25, vcc_lo
	s_clause 0x1
	global_load_b128 v[99:102], v[103:104], off
	global_load_b128 v[103:106], v[103:104], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v110, 16, v100
	v_lshlrev_b32_e32 v107, 16, v99
	v_and_b32_e32 v99, 0xffff0000, v99
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v108, v26, v107, 0
	v_fmac_f32_e32 v108, v27, v99
	s_wait_dscnt 0x3d
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v108, v28, v110
	s_wait_dscnt 0x1f
	v_fma_f32 v112, v58, v107, 0
	v_fma_f32 v109, v42, v107, 0
	s_wait_dscnt 0xf
	v_fma_f32 v107, v74, v107, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v112, v59, v99
	v_dual_fmac_f32 v112, v60, v110 :: v_dual_fmac_f32 v109, v43, v99
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v107, v75, v99
	v_and_b32_e32 v99, 0xffff0000, v100
	v_dual_fmac_f32 v109, v44, v110 :: v_dual_lshlrev_b32 v100, 16, v101
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v107, v76, v110 :: v_dual_fmac_f32 v108, v29, v99
	v_fmac_f32_e32 v112, v61, v99
	v_fmac_f32_e32 v109, v45, v99
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v107, v77, v99
	v_dual_fmac_f32 v108, v30, v100 :: v_dual_and_b32 v99, 0xffff0000, v101
	v_fmac_f32_e32 v112, v62, v100
	v_fmac_f32_e32 v109, v46, v100
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v107, v78, v100 :: v_dual_lshlrev_b32 v100, 16, v102
	v_fmac_f32_e32 v108, v31, v99
	v_fmac_f32_e32 v112, v63, v99
	v_fmac_f32_e32 v109, v47, v99
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v107, v79, v99
	v_dual_fmac_f32 v108, v32, v100 :: v_dual_and_b32 v99, 0xffff0000, v102
	v_fmac_f32_e32 v112, v64, v100
	v_fmac_f32_e32 v109, v48, v100
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v107, v80, v100 :: v_dual_lshlrev_b32 v100, 16, v103
	v_fmac_f32_e32 v108, v33, v99
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v109, v49, v99 :: v_dual_fmac_f32 v108, v34, v100
	v_dual_fmac_f32 v112, v65, v99 :: v_dual_fmac_f32 v109, v50, v100
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v107, v81, v99 :: v_dual_fmac_f32 v112, v66, v100
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v107, v82, v100
	v_lshlrev_b32_e32 v100, 16, v104
	v_and_b32_e32 v99, 0xffff0000, v103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v108, v35, v99
	v_dual_fmac_f32 v108, v36, v100 :: v_dual_fmac_f32 v109, v51, v99
	v_fmac_f32_e32 v112, v67, v99
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v107, v83, v99
	v_and_b32_e32 v99, 0xffff0000, v104
	v_fmac_f32_e32 v109, v52, v100
	v_fmac_f32_e32 v112, v68, v100
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v107, v84, v100 :: v_dual_fmac_f32 v108, v37, v99
	v_dual_fmac_f32 v109, v53, v99 :: v_dual_lshlrev_b32 v100, 16, v105
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v112, v69, v99
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v107, v85, v99
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v108, v38, v100 :: v_dual_and_b32 v99, 0xffff0000, v105
	v_fmac_f32_e32 v109, v54, v100
	v_fmac_f32_e32 v112, v70, v100
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v107, v86, v100 :: v_dual_lshlrev_b32 v100, 16, v106
	v_fmac_f32_e32 v108, v39, v99
	v_fmac_f32_e32 v109, v55, v99
	v_fmac_f32_e32 v112, v71, v99
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v107, v87, v99
	v_dual_fmac_f32 v108, v40, v100 :: v_dual_and_b32 v99, 0xffff0000, v106
	v_fmac_f32_e32 v109, v56, v100
	v_fmac_f32_e32 v112, v72, v100
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v107, v88, v100 :: v_dual_fmac_f32 v108, v41, v99
	v_fmac_f32_e32 v109, v57, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v112, v73, v99
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v107, v89, v99
	v_fma_f32 v111, v108, v92, 0
	v_fma_f32 v110, v109, v93, 0
	v_fma_f32 v106, v112, v94, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v102, v107, v95, 0
.LBB11_12:                              ;   in Loop: Header=BB11_9 Depth=1
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v103, 0
	v_mov_b32_e32 v99, 0
	s_and_not1_b32 vcc_lo, exec_lo, s22
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_14
; %bb.13:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_loadcnt 0x4
	v_lshlrev_b32_e32 v98, 16, v20
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_1)
	v_fma_f32 v99, v26, v98, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v100, v42, v98, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v101, v58, v98, 0
	s_wait_dscnt 0xf
	v_fma_f32 v104, v74, v98, 0
	v_lshlrev_b32_e32 v98, 16, v21
	v_and_b32_e32 v20, 0xffff0000, v20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v99, v27, v20
	v_fmac_f32_e32 v99, v28, v98
	v_fmac_f32_e32 v101, v59, v20
	v_fmac_f32_e32 v100, v43, v20
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v104, v75, v20
	v_and_b32_e32 v20, 0xffff0000, v21
	v_lshlrev_b32_e32 v21, 16, v22
	v_fmac_f32_e32 v101, v60, v98
	v_fmac_f32_e32 v100, v44, v98
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v104, v76, v98 :: v_dual_fmac_f32 v99, v29, v20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v101, v61, v20
	v_fmac_f32_e32 v100, v45, v20
	s_wait_dscnt 0xc
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v104, v77, v20 :: v_dual_fmac_f32 v99, v30, v21
	v_fmac_f32_e32 v101, v62, v21
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v100, v46, v21
	s_wait_dscnt 0xb
	v_dual_fmac_f32 v104, v78, v21 :: v_dual_lshlrev_b32 v21, 16, v23
	v_and_b32_e32 v20, 0xffff0000, v22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v99, v31, v20
	v_fmac_f32_e32 v99, v32, v21
	v_fmac_f32_e32 v101, v63, v20
	v_fmac_f32_e32 v100, v47, v20
	s_wait_dscnt 0xa
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v104, v79, v20 :: v_dual_fmac_f32 v101, v64, v21
	v_fmac_f32_e32 v100, v48, v21
	s_wait_dscnt 0x9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v104, v80, v21 :: v_dual_lshlrev_b32 v21, 16, v16
	v_and_b32_e32 v20, 0xffff0000, v23
	v_and_b32_e32 v16, 0xffff0000, v16
	v_fmac_f32_e32 v101, v65, v20
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v101, v66, v21
	v_fmac_f32_e32 v99, v33, v20
	v_fmac_f32_e32 v100, v49, v20
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v104, v81, v20
	v_dual_fmac_f32 v101, v67, v16 :: v_dual_lshlrev_b32 v20, 16, v17
	v_fmac_f32_e32 v99, v34, v21
	v_fmac_f32_e32 v100, v50, v21
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v104, v82, v21 :: v_dual_fmac_f32 v101, v68, v20
	v_fmac_f32_e32 v99, v35, v16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v100, v51, v16
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v104, v83, v16
	v_and_b32_e32 v16, 0xffff0000, v17
	v_lshlrev_b32_e32 v17, 16, v18
	v_fmac_f32_e32 v99, v36, v20
	v_fmac_f32_e32 v100, v52, v20
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v104, v84, v20
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v100, v53, v16
	v_fmac_f32_e32 v99, v37, v16
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v104, v85, v16
	v_dual_fmac_f32 v101, v69, v16 :: v_dual_and_b32 v16, 0xffff0000, v18
	v_fmac_f32_e32 v100, v54, v17
	v_fmac_f32_e32 v99, v38, v17
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v104, v86, v17
	v_fmac_f32_e32 v101, v70, v17
	v_dual_fmac_f32 v100, v55, v16 :: v_dual_lshlrev_b32 v17, 16, v19
	v_fmac_f32_e32 v99, v39, v16
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v104, v87, v16
	v_dual_fmac_f32 v101, v71, v16 :: v_dual_and_b32 v16, 0xffff0000, v19
	v_fmac_f32_e32 v100, v56, v17
	v_fmac_f32_e32 v99, v40, v17
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v104, v88, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v101, v72, v17 :: v_dual_fmac_f32 v100, v57, v16
	v_fmac_f32_e32 v99, v41, v16
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v104, v89, v16
	v_fmac_f32_e32 v101, v73, v16
	v_fma_f32 v108, v100, v93, 0
	v_fma_f32 v98, v99, v92, 0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v99, v104, v95, 0
	v_fma_f32 v103, v101, v94, 0
.LBB11_14:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_loadcnt 0x5
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v109, 0
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v17, 0
	v_mov_b32_e32 v18, 0
	s_and_not1_b32 vcc_lo, exec_lo, s37
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_16
; %bb.15:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_loadcnt 0x2
	v_lshlrev_b32_e32 v21, 16, v13
	v_lshlrev_b32_e32 v17, 16, v12
	v_and_b32_e32 v12, 0xffff0000, v12
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v18, v26, v17, 0
	v_fmac_f32_e32 v18, v27, v12
	s_wait_dscnt 0x3d
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v18, v28, v21
	s_wait_dscnt 0x2f
	v_fma_f32 v19, v42, v17, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v20, v58, v17, 0
	s_wait_dscnt 0xf
	v_fma_f32 v17, v74, v17, 0
	v_fmac_f32_e32 v19, v43, v12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v19, v44, v21
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v17, v75, v12
	v_fmac_f32_e32 v20, v59, v12
	v_and_b32_e32 v12, 0xffff0000, v13
	v_lshlrev_b32_e32 v13, 16, v14
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v17, v76, v21
	v_fmac_f32_e32 v20, v60, v21
	v_fmac_f32_e32 v18, v29, v12
	v_fmac_f32_e32 v19, v45, v12
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v17, v77, v12
	v_fmac_f32_e32 v20, v61, v12
	v_and_b32_e32 v12, 0xffff0000, v14
	v_fmac_f32_e32 v18, v30, v13
	v_fmac_f32_e32 v19, v46, v13
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v17, v78, v13
	v_dual_fmac_f32 v20, v62, v13 :: v_dual_lshlrev_b32 v13, 16, v15
	v_fmac_f32_e32 v18, v31, v12
	v_fmac_f32_e32 v19, v47, v12
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v17, v79, v12
	v_fmac_f32_e32 v20, v63, v12
	v_and_b32_e32 v12, 0xffff0000, v15
	v_fmac_f32_e32 v18, v32, v13
	v_fmac_f32_e32 v19, v48, v13
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v17, v80, v13
	v_dual_fmac_f32 v20, v64, v13 :: v_dual_lshlrev_b32 v13, 16, v8
	v_fmac_f32_e32 v18, v33, v12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v19, v49, v12 :: v_dual_fmac_f32 v18, v34, v13
	v_dual_fmac_f32 v20, v65, v12 :: v_dual_fmac_f32 v19, v50, v13
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v17, v81, v12 :: v_dual_fmac_f32 v20, v66, v13
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v17, v82, v13 :: v_dual_and_b32 v8, 0xffff0000, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v19, v51, v8 :: v_dual_lshlrev_b32 v12, 16, v9
	v_fmac_f32_e32 v18, v35, v8
	v_fmac_f32_e32 v20, v67, v8
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v17, v83, v8 :: v_dual_and_b32 v8, 0xffff0000, v9
	v_fmac_f32_e32 v19, v52, v12
	v_lshlrev_b32_e32 v9, 16, v10
	s_wait_dscnt 0x5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v17, v84, v12
	v_fmac_f32_e32 v19, v53, v8
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v17, v85, v8
	v_dual_fmac_f32 v18, v36, v12 :: v_dual_fmac_f32 v19, v54, v9
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v20, v68, v12 :: v_dual_fmac_f32 v17, v86, v9
	v_fmac_f32_e32 v18, v37, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v20, v69, v8
	v_and_b32_e32 v8, 0xffff0000, v10
	v_fmac_f32_e32 v18, v38, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v20, v70, v9 :: v_dual_lshlrev_b32 v9, 16, v11
	v_fmac_f32_e32 v18, v39, v8
	v_fmac_f32_e32 v19, v55, v8
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v20, v71, v8
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v17, v87, v8 :: v_dual_and_b32 v8, 0xffff0000, v11
	v_fmac_f32_e32 v18, v40, v9
	v_fmac_f32_e32 v19, v56, v9
	v_fmac_f32_e32 v20, v72, v9
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v17, v88, v9 :: v_dual_fmac_f32 v18, v41, v8
	v_fmac_f32_e32 v19, v57, v8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v20, v73, v8
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v17, v89, v8
	v_fma_f32 v109, v18, v92, 0
	v_fma_f32 v104, v19, v93, 0
	v_fma_f32 v18, v20, v94, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v17, v17, v95, 0
.LBB11_16:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_loadcnt 0x3
	v_mov_b32_e32 v11, 0
	s_wait_loadcnt 0x2
	v_mov_b32_e32 v15, 0
	v_mov_b32_e32 v105, 0
	s_and_not1_b32 vcc_lo, exec_lo, s36
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_18
; %bb.17:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v8, 16, v4
	v_and_b32_e32 v4, 0xffff0000, v4
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2)
	v_fma_f32 v9, v26, v8, 0
	s_wait_dscnt 0x2f
	v_fma_f32 v10, v42, v8, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v11, v58, v8, 0
	s_wait_dscnt 0xf
	v_fma_f32 v8, v74, v8, 0
	v_dual_fmac_f32 v9, v27, v4 :: v_dual_lshlrev_b32 v12, 16, v5
	v_fmac_f32_e32 v10, v43, v4
	v_fmac_f32_e32 v11, v59, v4
	s_wait_dscnt 0xe
	v_fmac_f32_e32 v8, v75, v4
	v_and_b32_e32 v4, 0xffff0000, v5
	v_dual_fmac_f32 v10, v44, v12 :: v_dual_lshlrev_b32 v5, 16, v6
	v_fmac_f32_e32 v9, v28, v12
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v8, v76, v12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v10, v45, v4
	v_fmac_f32_e32 v11, v60, v12
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v8, v77, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v9, v29, v4 :: v_dual_fmac_f32 v10, v46, v5
	v_dual_fmac_f32 v11, v61, v4 :: v_dual_and_b32 v4, 0xffff0000, v6
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v8, v78, v5
	v_fmac_f32_e32 v9, v30, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v11, v62, v5
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v8, v79, v4 :: v_dual_lshlrev_b32 v5, 16, v7
	v_fmac_f32_e32 v10, v47, v4
	v_fmac_f32_e32 v9, v31, v4
	v_dual_fmac_f32 v11, v63, v4 :: v_dual_and_b32 v4, 0xffff0000, v7
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v8, v80, v5
	v_fmac_f32_e32 v10, v48, v5
	v_fmac_f32_e32 v9, v32, v5
	v_fmac_f32_e32 v11, v64, v5
	v_lshlrev_b32_e32 v5, 16, v0
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v8, v81, v4
	v_fmac_f32_e32 v10, v49, v4
	v_fmac_f32_e32 v9, v33, v4
	v_fmac_f32_e32 v11, v65, v4
	v_and_b32_e32 v0, 0xffff0000, v0
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v8, v82, v5
	v_fmac_f32_e32 v10, v50, v5
	v_fmac_f32_e32 v9, v34, v5
	v_fmac_f32_e32 v11, v66, v5
	v_lshlrev_b32_e32 v4, 16, v1
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v8, v83, v0
	v_fmac_f32_e32 v10, v51, v0
	v_fmac_f32_e32 v9, v35, v0
	v_dual_fmac_f32 v11, v67, v0 :: v_dual_and_b32 v0, 0xffff0000, v1
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v8, v84, v4
	v_fmac_f32_e32 v10, v52, v4
	v_fmac_f32_e32 v9, v36, v4
	s_wait_dscnt 0x4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v8, v85, v0 :: v_dual_lshlrev_b32 v1, 16, v2
	v_fmac_f32_e32 v11, v68, v4
	v_fmac_f32_e32 v9, v37, v0
	v_fmac_f32_e32 v10, v53, v0
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v8, v86, v1 :: v_dual_fmac_f32 v11, v69, v0
	v_dual_fmac_f32 v9, v38, v1 :: v_dual_and_b32 v0, 0xffff0000, v2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v10, v54, v1
	v_fmac_f32_e32 v11, v70, v1
	s_wait_dscnt 0x2
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v8, v87, v0 :: v_dual_lshlrev_b32 v1, 16, v3
	v_fmac_f32_e32 v9, v39, v0
	v_fmac_f32_e32 v10, v55, v0
	v_dual_fmac_f32 v11, v71, v0 :: v_dual_and_b32 v0, 0xffff0000, v3
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v8, v88, v1
	v_fmac_f32_e32 v9, v40, v1
	v_fmac_f32_e32 v10, v56, v1
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v11, v72, v1 :: v_dual_fmac_f32 v8, v89, v0
	v_fmac_f32_e32 v9, v41, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v10, v57, v0
	v_fmac_f32_e32 v11, v73, v0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v16, v8, v95, 0
	v_fma_f32 v105, v9, v92, 0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v15, v10, v93, 0
	v_fma_f32 v11, v11, v94, 0
.LBB11_18:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s18
	s_clause 0x3
	s_load_b32 s22, s[4:5], s8 offset:0x0
	s_load_b32 s18, s[4:5], s12 offset:0x0
	s_load_b32 s12, s[4:5], s13 offset:0x0
	s_load_b32 s8, s[4:5], s19 offset:0x0
	s_wait_loadcnt 0x0
	v_cndmask_b32_e64 v7, 0, 1, s9
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, 0
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v13, 0
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v19, 0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v3, 0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v107, 0
	v_mov_b32_e32 v100, 0
	v_mov_b32_e32 v12, 0
	s_and_not1_b32 vcc_lo, exec_lo, s9
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_28
; %bb.19:                               ;   in Loop: Header=BB11_9 Depth=1
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v100, 0
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v8, 0
	v_mov_b32_e32 v13, 0
	s_and_saveexec_b32 s9, s1
	s_cbranch_execz .LBB11_21
; %bb.20:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_kmcnt 0x0
	s_ashr_i32 s23, s22, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[38:39], s[22:23], s[6:7]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v0, vcc_lo, v24, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, s39, v25, vcc_lo
	s_clause 0x1
	global_load_b128 v[19:22], v[0:1], off
	global_load_b128 v[112:115], v[0:1], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v6, 16, v20
	v_and_b32_e32 v1, 0xffff0000, v19
	v_lshlrev_b32_e32 v0, 16, v19
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v5, v58, v0, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v5, v59, v1
	v_fma_f32 v2, v26, v0, 0
	v_fma_f32 v4, v42, v0, 0
	s_wait_dscnt 0xf
	v_fma_f32 v0, v74, v0, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v5, v60, v6 :: v_dual_fmac_f32 v2, v27, v1
	v_fmac_f32_e32 v2, v28, v6
	v_fmac_f32_e32 v4, v43, v1
	s_wait_dscnt 0xe
	v_dual_fmac_f32 v0, v75, v1 :: v_dual_and_b32 v1, 0xffff0000, v20
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v5, v61, v1 :: v_dual_fmac_f32 v4, v44, v6
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v0, v76, v6
	v_lshlrev_b32_e32 v6, 16, v21
	v_fmac_f32_e32 v2, v29, v1
	v_fmac_f32_e32 v4, v45, v1
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v0, v77, v1
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v2, v30, v6 :: v_dual_and_b32 v1, 0xffff0000, v21
	v_fmac_f32_e32 v5, v62, v6
	v_fmac_f32_e32 v4, v46, v6
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v0, v78, v6
	v_lshlrev_b32_e32 v6, 16, v22
	v_fmac_f32_e32 v2, v31, v1
	v_fmac_f32_e32 v5, v63, v1
	v_fmac_f32_e32 v4, v47, v1
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v0, v79, v1 :: v_dual_and_b32 v1, 0xffff0000, v22
	v_fmac_f32_e32 v2, v32, v6
	v_fmac_f32_e32 v5, v64, v6
	v_fmac_f32_e32 v4, v48, v6
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v0, v80, v6
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v6, 16, v112
	v_fmac_f32_e32 v2, v33, v1
	v_fmac_f32_e32 v5, v65, v1
	v_fmac_f32_e32 v4, v49, v1
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v0, v81, v1 :: v_dual_and_b32 v1, 0xffff0000, v112
	v_fmac_f32_e32 v2, v34, v6
	v_fmac_f32_e32 v5, v66, v6
	v_fmac_f32_e32 v4, v50, v6
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v0, v82, v6
	v_lshlrev_b32_e32 v6, 16, v113
	v_fmac_f32_e32 v2, v35, v1
	v_fmac_f32_e32 v5, v67, v1
	v_fmac_f32_e32 v4, v51, v1
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v0, v83, v1
	v_dual_fmac_f32 v2, v36, v6 :: v_dual_and_b32 v1, 0xffff0000, v113
	v_fmac_f32_e32 v5, v68, v6
	v_fmac_f32_e32 v4, v52, v6
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v0, v84, v6
	v_lshlrev_b32_e32 v6, 16, v114
	v_fmac_f32_e32 v2, v37, v1
	v_fmac_f32_e32 v5, v69, v1
	v_fmac_f32_e32 v4, v53, v1
	s_wait_dscnt 0x4
	v_dual_fmac_f32 v0, v85, v1 :: v_dual_and_b32 v1, 0xffff0000, v114
	v_fmac_f32_e32 v2, v38, v6
	v_fmac_f32_e32 v5, v70, v6
	v_fmac_f32_e32 v4, v54, v6
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v0, v86, v6
	v_lshlrev_b32_e32 v6, 16, v115
	v_fmac_f32_e32 v2, v39, v1
	v_fmac_f32_e32 v5, v71, v1
	v_fmac_f32_e32 v4, v55, v1
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v0, v87, v1 :: v_dual_and_b32 v1, 0xffff0000, v115
	v_fmac_f32_e32 v2, v40, v6
	v_fmac_f32_e32 v5, v72, v6
	v_fmac_f32_e32 v4, v56, v6
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v0, v88, v6
	v_fmac_f32_e32 v2, v41, v1
	v_fmac_f32_e32 v5, v73, v1
	v_fmac_f32_e32 v4, v57, v1
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v0, v89, v1
	v_fma_f32 v107, v2, v92, 0
	v_fma_f32 v13, v5, v94, 0
	v_fma_f32 v100, v4, v93, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v8, v0, v95, 0
.LBB11_21:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_cmp_lg_u32 s31, 5
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v9, 0
	v_mov_b32_e32 v4, 0
	s_cselect_b32 s13, -1, 0
	s_xor_b32 s9, s2, -1
	s_wait_alu 0xfffe
	s_and_b32 s19, s9, s13
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s13, s19
	s_cbranch_execz .LBB11_23
; %bb.22:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_kmcnt 0x0
	s_ashr_i32 s19, s18, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[38:39], s[18:19], s[6:7]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v4, vcc_lo, v24, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, s39, v25, vcc_lo
	s_clause 0x1
	global_load_b128 v[0:3], v[4:5], off
	global_load_b128 v[19:22], v[4:5], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v10, 16, v1
	v_lshlrev_b32_e32 v4, 16, v0
	v_and_b32_e32 v0, 0xffff0000, v0
	s_wait_dscnt 0x3e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v5, v26, v4, 0
	v_fmac_f32_e32 v5, v27, v0
	s_wait_dscnt 0x3d
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v5, v28, v10
	s_wait_dscnt 0x1f
	v_fma_f32 v9, v58, v4, 0
	v_fma_f32 v6, v42, v4, 0
	s_wait_dscnt 0xf
	v_fma_f32 v4, v74, v4, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v9, v59, v0
	v_dual_fmac_f32 v9, v60, v10 :: v_dual_fmac_f32 v6, v43, v0
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v4, v75, v0
	v_and_b32_e32 v0, 0xffff0000, v1
	v_lshlrev_b32_e32 v1, 16, v2
	v_dual_fmac_f32 v6, v44, v10 :: v_dual_fmac_f32 v5, v29, v0
	v_fmac_f32_e32 v9, v61, v0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v6, v45, v0 :: v_dual_fmac_f32 v5, v30, v1
	s_wait_dscnt 0xd
	v_dual_fmac_f32 v4, v76, v10 :: v_dual_fmac_f32 v9, v62, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v6, v46, v1
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v4, v77, v0
	s_wait_dscnt 0xb
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v4, v78, v1 :: v_dual_lshlrev_b32 v1, 16, v3
	v_and_b32_e32 v0, 0xffff0000, v2
	v_fmac_f32_e32 v5, v31, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v5, v32, v1
	v_fmac_f32_e32 v9, v63, v0
	v_fmac_f32_e32 v6, v47, v0
	s_wait_dscnt 0xa
	v_dual_fmac_f32 v4, v79, v0 :: v_dual_fmac_f32 v9, v64, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v6, v48, v1
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v4, v80, v1 :: v_dual_lshlrev_b32 v1, 16, v19
	v_and_b32_e32 v0, 0xffff0000, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v5, v33, v0
	v_fmac_f32_e32 v5, v34, v1
	v_fmac_f32_e32 v9, v65, v0
	v_fmac_f32_e32 v6, v49, v0
	s_wait_dscnt 0x8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v4, v81, v0 :: v_dual_fmac_f32 v9, v66, v1
	v_fmac_f32_e32 v6, v50, v1
	s_wait_dscnt 0x7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v4, v82, v1 :: v_dual_lshlrev_b32 v1, 16, v20
	v_and_b32_e32 v0, 0xffff0000, v19
	v_fmac_f32_e32 v9, v67, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v9, v68, v1
	v_fmac_f32_e32 v5, v35, v0
	v_fmac_f32_e32 v6, v51, v0
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v4, v83, v0 :: v_dual_fmac_f32 v5, v36, v1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v6, v52, v1
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v4, v84, v1
	v_lshlrev_b32_e32 v1, 16, v21
	v_and_b32_e32 v0, 0xffff0000, v20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v9, v69, v0
	v_fmac_f32_e32 v9, v70, v1
	v_fmac_f32_e32 v5, v37, v0
	v_fmac_f32_e32 v6, v53, v0
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v4, v85, v0
	v_and_b32_e32 v0, 0xffff0000, v21
	v_fmac_f32_e32 v5, v38, v1
	v_fmac_f32_e32 v6, v54, v1
	s_wait_dscnt 0x3
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v4, v86, v1 :: v_dual_fmac_f32 v9, v71, v0
	v_lshlrev_b32_e32 v1, 16, v22
	v_fmac_f32_e32 v5, v39, v0
	v_fmac_f32_e32 v6, v55, v0
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v4, v87, v0
	v_dual_fmac_f32 v9, v72, v1 :: v_dual_and_b32 v0, 0xffff0000, v22
	v_fmac_f32_e32 v5, v40, v1
	v_fmac_f32_e32 v6, v56, v1
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v4, v88, v1 :: v_dual_fmac_f32 v9, v73, v0
	v_fmac_f32_e32 v5, v41, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v6, v57, v0
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v4, v89, v0
	v_fma_f32 v9, v9, v94, 0
	v_fma_f32 v3, v5, v92, 0
	v_fma_f32 v14, v6, v93, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v4, v4, v95, 0
.LBB11_23:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_cmp_gt_u32 s31, 6
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v19, 0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v5, 0
	v_mov_b32_e32 v1, 0
	s_cselect_b32 s13, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s13, s9, s13
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s19, s13
	s_cbranch_execz .LBB11_25
; %bb.24:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_kmcnt 0x0
	s_ashr_i32 s13, s12, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[38:39], s[12:13], s[6:7]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v1, vcc_lo, v24, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s39, v25, vcc_lo
	s_clause 0x1
	global_load_b128 v[19:22], v[1:2], off
	global_load_b128 v[112:115], v[1:2], off offset:16
	s_wait_loadcnt 0x1
	v_lshlrev_b32_e32 v10, 16, v20
	v_and_b32_e32 v2, 0xffff0000, v19
	v_lshlrev_b32_e32 v1, 16, v19
	s_wait_dscnt 0x2f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v6, v42, v1, 0
	s_wait_dscnt 0x2e
	v_fmac_f32_e32 v6, v43, v2
	v_fma_f32 v5, v26, v1, 0
	s_wait_dscnt 0x1f
	v_fma_f32 v12, v58, v1, 0
	s_wait_dscnt 0xf
	v_fma_f32 v1, v74, v1, 0
	v_fmac_f32_e32 v5, v27, v2
	v_fmac_f32_e32 v6, v44, v10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v5, v28, v10
	v_fmac_f32_e32 v12, v59, v2
	s_wait_dscnt 0xe
	v_dual_fmac_f32 v1, v75, v2 :: v_dual_and_b32 v2, 0xffff0000, v20
	v_fmac_f32_e32 v12, v60, v10
	s_wait_dscnt 0xd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v1, v76, v10 :: v_dual_lshlrev_b32 v10, 16, v21
	v_fmac_f32_e32 v5, v29, v2
	v_fmac_f32_e32 v6, v45, v2
	v_fmac_f32_e32 v12, v61, v2
	s_wait_dscnt 0xc
	v_dual_fmac_f32 v1, v77, v2 :: v_dual_and_b32 v2, 0xffff0000, v21
	v_fmac_f32_e32 v5, v30, v10
	v_fmac_f32_e32 v6, v46, v10
	v_fmac_f32_e32 v12, v62, v10
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v1, v78, v10
	v_lshlrev_b32_e32 v10, 16, v22
	v_fmac_f32_e32 v5, v31, v2
	v_fmac_f32_e32 v6, v47, v2
	v_fmac_f32_e32 v12, v63, v2
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v1, v79, v2
	v_and_b32_e32 v2, 0xffff0000, v22
	v_fmac_f32_e32 v5, v32, v10
	v_fmac_f32_e32 v6, v48, v10
	v_fmac_f32_e32 v12, v64, v10
	s_wait_loadcnt_dscnt 0x9
	v_dual_fmac_f32 v1, v80, v10 :: v_dual_lshlrev_b32 v10, 16, v112
	v_fmac_f32_e32 v5, v33, v2
	v_fmac_f32_e32 v6, v49, v2
	v_fmac_f32_e32 v12, v65, v2
	s_wait_dscnt 0x8
	v_dual_fmac_f32 v1, v81, v2 :: v_dual_and_b32 v2, 0xffff0000, v112
	v_fmac_f32_e32 v5, v34, v10
	v_fmac_f32_e32 v6, v50, v10
	v_fmac_f32_e32 v12, v66, v10
	s_wait_dscnt 0x7
	v_dual_fmac_f32 v1, v82, v10 :: v_dual_lshlrev_b32 v10, 16, v113
	v_fmac_f32_e32 v5, v35, v2
	v_fmac_f32_e32 v6, v51, v2
	v_fmac_f32_e32 v12, v67, v2
	s_wait_dscnt 0x6
	v_dual_fmac_f32 v1, v83, v2 :: v_dual_and_b32 v2, 0xffff0000, v113
	v_fmac_f32_e32 v5, v36, v10
	v_fmac_f32_e32 v6, v52, v10
	v_fmac_f32_e32 v12, v68, v10
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v1, v84, v10
	v_lshlrev_b32_e32 v10, 16, v114
	v_fmac_f32_e32 v5, v37, v2
	v_fmac_f32_e32 v6, v53, v2
	v_fmac_f32_e32 v12, v69, v2
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v1, v85, v2
	v_and_b32_e32 v2, 0xffff0000, v114
	v_fmac_f32_e32 v5, v38, v10
	v_fmac_f32_e32 v6, v54, v10
	v_fmac_f32_e32 v12, v70, v10
	s_wait_dscnt 0x3
	v_dual_fmac_f32 v1, v86, v10 :: v_dual_lshlrev_b32 v10, 16, v115
	v_fmac_f32_e32 v5, v39, v2
	v_fmac_f32_e32 v6, v55, v2
	v_fmac_f32_e32 v12, v71, v2
	s_wait_dscnt 0x2
	v_dual_fmac_f32 v1, v87, v2 :: v_dual_and_b32 v2, 0xffff0000, v115
	v_fmac_f32_e32 v5, v40, v10
	v_fmac_f32_e32 v6, v56, v10
	v_fmac_f32_e32 v12, v72, v10
	s_wait_dscnt 0x1
	v_fmac_f32_e32 v1, v88, v10
	v_fmac_f32_e32 v5, v41, v2
	v_fmac_f32_e32 v6, v57, v2
	v_fmac_f32_e32 v12, v73, v2
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v1, v89, v2
	v_fma_f32 v19, v5, v92, 0
	v_fma_f32 v10, v6, v93, 0
	v_fma_f32 v5, v12, v94, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v1, v1, v95, 0
.LBB11_25:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s19
	s_cmp_gt_u32 s31, 7
	v_mov_b32_e32 v2, 0
	v_mov_b32_e32 v6, 0
	v_mov_b32_e32 v12, 0
	s_cselect_b32 s13, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s9, s9, s13
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s13, s9
	s_cbranch_execz .LBB11_27
; %bb.26:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_kmcnt 0x0
	s_ashr_i32 s9, s8, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[38:39], s[8:9], s[6:7]
	s_wait_alu 0xfffe
	s_lshl_b64 s[38:39], s[38:39], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v112, vcc_lo, v24, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v113, null, s39, v25, vcc_lo
	s_clause 0x1
	global_load_b128 v[20:23], v[112:113], off
	global_load_b128 v[112:115], v[112:113], off offset:16
	s_wait_loadcnt 0x1
	v_and_b32_e32 v2, 0xffff0000, v20
	v_lshlrev_b32_e32 v0, 16, v20
	s_wait_dscnt 0x1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fma_f32 v101, v58, v0, 0
	s_wait_dscnt 0x1e
	v_fmac_f32_e32 v101, v59, v2
	v_fma_f32 v6, v26, v0, 0
	v_fma_f32 v20, v42, v0, 0
	s_wait_dscnt 0xf
	v_fma_f32 v0, v74, v0, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v6, v27, v2
	v_fmac_f32_e32 v20, v43, v2
	s_wait_dscnt 0xe
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v0, v75, v2
	v_and_b32_e32 v2, 0xffff0000, v21
	v_lshlrev_b32_e32 v12, 16, v21
	v_fmac_f32_e32 v101, v60, v12
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v101, v61, v2 :: v_dual_fmac_f32 v6, v28, v12
	v_fmac_f32_e32 v20, v44, v12
	s_wait_dscnt 0xd
	v_fmac_f32_e32 v0, v76, v12
	v_lshlrev_b32_e32 v12, 16, v22
	v_fmac_f32_e32 v6, v29, v2
	v_fmac_f32_e32 v20, v45, v2
	s_wait_dscnt 0xc
	v_fmac_f32_e32 v0, v77, v2
	v_dual_fmac_f32 v101, v62, v12 :: v_dual_and_b32 v2, 0xffff0000, v22
	v_fmac_f32_e32 v6, v30, v12
	v_fmac_f32_e32 v20, v46, v12
	s_wait_dscnt 0xb
	v_fmac_f32_e32 v0, v78, v12
	v_dual_fmac_f32 v101, v63, v2 :: v_dual_lshlrev_b32 v12, 16, v23
	v_fmac_f32_e32 v6, v31, v2
	v_fmac_f32_e32 v20, v47, v2
	s_wait_dscnt 0xa
	v_fmac_f32_e32 v0, v79, v2
	v_dual_fmac_f32 v101, v64, v12 :: v_dual_and_b32 v2, 0xffff0000, v23
	v_fmac_f32_e32 v6, v32, v12
	v_fmac_f32_e32 v20, v48, v12
	s_wait_dscnt 0x9
	v_fmac_f32_e32 v0, v80, v12
	s_wait_loadcnt 0x0
	v_dual_fmac_f32 v101, v65, v2 :: v_dual_lshlrev_b32 v12, 16, v112
	v_fmac_f32_e32 v6, v33, v2
	v_fmac_f32_e32 v20, v49, v2
	s_wait_dscnt 0x8
	v_fmac_f32_e32 v0, v81, v2
	v_and_b32_e32 v2, 0xffff0000, v112
	v_fmac_f32_e32 v101, v66, v12
	v_fmac_f32_e32 v6, v34, v12
	v_fmac_f32_e32 v20, v50, v12
	s_wait_dscnt 0x7
	v_fmac_f32_e32 v0, v82, v12
	v_dual_fmac_f32 v101, v67, v2 :: v_dual_lshlrev_b32 v12, 16, v113
	v_fmac_f32_e32 v6, v35, v2
	v_fmac_f32_e32 v20, v51, v2
	s_wait_dscnt 0x6
	v_fmac_f32_e32 v0, v83, v2
	v_dual_fmac_f32 v101, v68, v12 :: v_dual_and_b32 v2, 0xffff0000, v113
	v_fmac_f32_e32 v6, v36, v12
	v_fmac_f32_e32 v20, v52, v12
	s_wait_dscnt 0x5
	v_fmac_f32_e32 v0, v84, v12
	v_lshlrev_b32_e32 v12, 16, v114
	v_fmac_f32_e32 v101, v69, v2
	v_fmac_f32_e32 v6, v37, v2
	v_fmac_f32_e32 v20, v53, v2
	s_wait_dscnt 0x4
	v_fmac_f32_e32 v0, v85, v2
	v_dual_fmac_f32 v101, v70, v12 :: v_dual_and_b32 v2, 0xffff0000, v114
	v_fmac_f32_e32 v6, v38, v12
	v_fmac_f32_e32 v20, v54, v12
	s_wait_dscnt 0x3
	v_fmac_f32_e32 v0, v86, v12
	v_dual_fmac_f32 v101, v71, v2 :: v_dual_lshlrev_b32 v12, 16, v115
	v_fmac_f32_e32 v6, v39, v2
	v_fmac_f32_e32 v20, v55, v2
	s_wait_dscnt 0x2
	v_fmac_f32_e32 v0, v87, v2
	v_dual_fmac_f32 v101, v72, v12 :: v_dual_and_b32 v2, 0xffff0000, v115
	v_fmac_f32_e32 v6, v40, v12
	v_fmac_f32_e32 v20, v56, v12
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v0, v88, v12 :: v_dual_fmac_f32 v101, v73, v2
	v_fmac_f32_e32 v6, v41, v2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v20, v57, v2
	s_wait_dscnt 0x0
	v_fmac_f32_e32 v0, v89, v2
	v_fma_f32 v2, v101, v94, 0
	v_fma_f32 v12, v6, v92, 0
	v_fma_f32 v6, v20, v93, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_fma_f32 v0, v0, v95, 0
.LBB11_27:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
.LBB11_28:                              ;   in Loop: Header=BB11_9 Depth=1
	v_xor_b32_e32 v101, 16, v96
	v_xor_b32_e32 v23, 8, v96
	v_xor_b32_e32 v22, 4, v96
	v_xor_b32_e32 v21, 2, v96
	v_xor_b32_e32 v20, 1, v96
	s_cmp_lt_i32 s31, 1
	s_cbranch_scc1 .LBB11_54
; %bb.29:                               ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_mul_u64 s[24:25], s[24:25], s[16:17]
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v113, v96, v23 :: v_dual_lshlrev_b32 v112, 2, v112
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	ds_bpermute_b32 v114, v112, v111
	s_wait_dscnt 0x0
	v_dual_add_f32 v114, v111, v114 :: v_dual_lshlrev_b32 v113, 2, v113
	ds_bpermute_b32 v115, v113, v114
	s_wait_dscnt 0x0
	v_add_f32_e32 v115, v114, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v96, v22, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v114, v96, v21 :: v_dual_lshlrev_b32 v111, 2, v111
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	ds_bpermute_b32 v116, v111, v115
	v_lshlrev_b32_e32 v114, 2, v114
	s_wait_dscnt 0x0
	v_add_f32_e32 v116, v115, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v96, v20, vcc_lo
	ds_bpermute_b32 v117, v114, v116
	s_wait_dscnt 0x0
	v_dual_add_f32 v116, v116, v117 :: v_dual_lshlrev_b32 v115, 2, v115
	ds_bpermute_b32 v117, v115, v116
	s_and_saveexec_b32 s9, s0
	s_cbranch_execz .LBB11_35
; %bb.30:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v116, v116, v117
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v117, s29, v116
	v_and_b32_e32 v116, 0x7fffffff, v117
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v116
                                        ; implicit-def: $vgpr116
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.31:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v116, v117, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v116, v117, v116, 0x7fff
                                        ; implicit-def: $vgpr117
	v_lshrrev_b32_e32 v116, 16, v116
; %bb.32:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.33:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v116, 16, v117
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v116, 64, v116
; %bb.34:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_lshl_b64 s[38:39], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v117, vcc_lo, v90, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v118, null, s39, v91, vcc_lo
	global_store_b16 v[117:118], v116, off
.LBB11_35:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v116, v112, v110
	s_wait_dscnt 0x0
	v_add_f32_e32 v110, v110, v116
	ds_bpermute_b32 v116, v113, v110
	s_wait_dscnt 0x0
	v_add_f32_e32 v110, v110, v116
	ds_bpermute_b32 v116, v111, v110
	s_wait_dscnt 0x0
	v_add_f32_e32 v110, v110, v116
	ds_bpermute_b32 v116, v114, v110
	s_wait_dscnt 0x0
	v_add_f32_e32 v110, v110, v116
	ds_bpermute_b32 v116, v115, v110
	s_and_saveexec_b32 s9, s28
	s_cbranch_execz .LBB11_41
; %bb.36:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v110, v110, v116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v116, s29, v110
	v_and_b32_e32 v110, 0x7fffffff, v116
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v110
                                        ; implicit-def: $vgpr110
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.37:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v110, v116, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v110, v116, v110, 0x7fff
                                        ; implicit-def: $vgpr116
	v_lshrrev_b32_e32 v110, 16, v110
; %bb.38:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.39:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v110, 16, v116
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v110, 64, v110
; %bb.40:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_lshl_b64 s[38:39], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v116, vcc_lo, v90, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v117, null, s39, v91, vcc_lo
	global_store_b16 v[116:117], v110, off offset:2
.LBB11_41:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v110, v112, v106
	s_wait_dscnt 0x0
	v_add_f32_e32 v106, v106, v110
	ds_bpermute_b32 v110, v113, v106
	s_wait_dscnt 0x0
	v_add_f32_e32 v106, v106, v110
	ds_bpermute_b32 v110, v111, v106
	s_wait_dscnt 0x0
	v_add_f32_e32 v106, v106, v110
	ds_bpermute_b32 v110, v114, v106
	s_wait_dscnt 0x0
	v_add_f32_e32 v106, v106, v110
	ds_bpermute_b32 v110, v115, v106
	s_and_saveexec_b32 s9, s3
	s_cbranch_execz .LBB11_47
; %bb.42:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v106, v106, v110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v110, s29, v106
	v_and_b32_e32 v106, 0x7fffffff, v110
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v106
                                        ; implicit-def: $vgpr106
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.43:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v106, v110, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v106, v110, v106, 0x7fff
                                        ; implicit-def: $vgpr110
	v_lshrrev_b32_e32 v106, 16, v106
; %bb.44:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.45:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v106, 16, v110
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v106, 64, v106
; %bb.46:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_lshl_b64 s[38:39], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v116, vcc_lo, v90, s38
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v117, null, s39, v91, vcc_lo
	global_store_b16 v[116:117], v106, off offset:4
.LBB11_47:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v106, v112, v102
	s_wait_dscnt 0x0
	v_add_f32_e32 v102, v102, v106
	ds_bpermute_b32 v106, v113, v102
	s_wait_dscnt 0x0
	v_add_f32_e32 v102, v102, v106
	ds_bpermute_b32 v106, v111, v102
	s_wait_dscnt 0x0
	v_add_f32_e32 v102, v102, v106
	ds_bpermute_b32 v106, v114, v102
	s_wait_dscnt 0x0
	v_add_f32_e32 v102, v102, v106
	ds_bpermute_b32 v106, v115, v102
	s_and_saveexec_b32 s9, s30
	s_cbranch_execz .LBB11_53
; %bb.48:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v102, v102, v106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v106, s29, v102
	v_and_b32_e32 v102, 0x7fffffff, v106
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v102
                                        ; implicit-def: $vgpr102
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.49:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v102, v106, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v102, v106, v102, 0x7fff
                                        ; implicit-def: $vgpr106
	v_lshrrev_b32_e32 v102, 16, v102
; %bb.50:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.51:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v102, 16, v106
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v102, 64, v102
; %bb.52:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_lshl_b64 s[24:25], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v110, vcc_lo, v90, s24
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v111, null, s25, v91, vcc_lo
	global_store_b16 v[110:111], v102, off offset:6
.LBB11_53:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
.LBB11_54:                              ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_ne_u32_e32 vcc_lo, 1, v97
	s_cbranch_vccz .LBB11_61
; %bb.55:                               ;   in Loop: Header=BB11_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s37
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB11_86
.LBB11_56:                              ;   in Loop: Header=BB11_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s36
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB11_111
.LBB11_57:                              ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_ne_u32_e32 vcc_lo, 1, v7
	s_cbranch_vccz .LBB11_136
.LBB11_58:                              ;   in Loop: Header=BB11_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB11_161
.LBB11_59:                              ;   in Loop: Header=BB11_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s34
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB11_186
.LBB11_60:                              ;   in Loop: Header=BB11_9 Depth=1
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_8
	s_branch .LBB11_211
.LBB11_61:                              ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, v96, v23, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v102, 2, v102
	v_lshlrev_b32_e32 v97, 2, v97
	s_wait_dscnt 0x0
	ds_bpermute_b32 v106, v97, v98
	s_wait_dscnt 0x0
	v_add_f32_e32 v106, v98, v106
	ds_bpermute_b32 v110, v102, v106
	s_wait_dscnt 0x0
	v_add_f32_e32 v110, v106, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, v96, v22, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v98, 2, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v96, v21, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	ds_bpermute_b32 v111, v98, v110
	s_wait_dscnt 0x0
	v_dual_add_f32 v111, v110, v111 :: v_dual_lshlrev_b32 v106, 2, v106
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v96, v20, vcc_lo
	ds_bpermute_b32 v112, v106, v111
	s_wait_dscnt 0x0
	v_dual_add_f32 v111, v111, v112 :: v_dual_lshlrev_b32 v110, 2, v110
	ds_bpermute_b32 v112, v110, v111
	s_and_saveexec_b32 s9, s0
	s_cbranch_execz .LBB11_67
; %bb.62:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v111, v111, v112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v112, s29, v111
	v_and_b32_e32 v111, 0x7fffffff, v112
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v111
                                        ; implicit-def: $vgpr111
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.63:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v111, v112, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v111, v112, v111, 0x7fff
                                        ; implicit-def: $vgpr112
	v_lshrrev_b32_e32 v111, 16, v111
; %bb.64:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.65:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v111, 16, v112
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v111, 64, v111
; %bb.66:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[24:25], s[20:21], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v112, vcc_lo, v90, s24
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v113, null, s25, v91, vcc_lo
	global_store_b16 v[112:113], v111, off
.LBB11_67:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v111, v97, v108
	s_wait_dscnt 0x0
	v_add_f32_e32 v108, v108, v111
	ds_bpermute_b32 v111, v102, v108
	s_wait_dscnt 0x0
	v_add_f32_e32 v108, v108, v111
	ds_bpermute_b32 v111, v98, v108
	s_wait_dscnt 0x0
	v_add_f32_e32 v108, v108, v111
	ds_bpermute_b32 v111, v106, v108
	s_wait_dscnt 0x0
	v_add_f32_e32 v108, v108, v111
	ds_bpermute_b32 v111, v110, v108
	s_and_saveexec_b32 s9, s28
	s_cbranch_execz .LBB11_73
; %bb.68:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v108, v108, v111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v111, s29, v108
	v_and_b32_e32 v108, 0x7fffffff, v111
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v108
                                        ; implicit-def: $vgpr108
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.69:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v108, v111, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v108, v111, v108, 0x7fff
                                        ; implicit-def: $vgpr111
	v_lshrrev_b32_e32 v108, 16, v108
; %bb.70:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.71:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v108, 16, v111
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v108, 64, v108
; %bb.72:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[24:25], s[20:21], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v111, vcc_lo, v90, s24
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v112, null, s25, v91, vcc_lo
	global_store_b16 v[111:112], v108, off offset:2
.LBB11_73:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v108, v97, v103
	s_wait_dscnt 0x0
	v_add_f32_e32 v103, v103, v108
	ds_bpermute_b32 v108, v102, v103
	s_wait_dscnt 0x0
	v_add_f32_e32 v103, v103, v108
	ds_bpermute_b32 v108, v98, v103
	s_wait_dscnt 0x0
	v_add_f32_e32 v103, v103, v108
	ds_bpermute_b32 v108, v106, v103
	s_wait_dscnt 0x0
	v_add_f32_e32 v103, v103, v108
	ds_bpermute_b32 v108, v110, v103
	s_and_saveexec_b32 s9, s3
	s_cbranch_execz .LBB11_79
; %bb.74:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v103, v103, v108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v108, s29, v103
	v_and_b32_e32 v103, 0x7fffffff, v108
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v103
                                        ; implicit-def: $vgpr103
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.75:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v103, v108, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v103, v108, v103, 0x7fff
                                        ; implicit-def: $vgpr108
	v_lshrrev_b32_e32 v103, 16, v103
; %bb.76:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.77:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v103, 16, v108
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v103, 64, v103
; %bb.78:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[24:25], s[20:21], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[24:25], s[24:25], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v111, vcc_lo, v90, s24
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v112, null, s25, v91, vcc_lo
	global_store_b16 v[111:112], v103, off offset:4
.LBB11_79:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v97, v97, v99
	s_wait_dscnt 0x0
	v_add_f32_e32 v97, v99, v97
	ds_bpermute_b32 v99, v102, v97
	s_wait_dscnt 0x0
	v_add_f32_e32 v97, v97, v99
	ds_bpermute_b32 v98, v98, v97
	s_wait_dscnt 0x0
	v_add_f32_e32 v97, v97, v98
	ds_bpermute_b32 v98, v106, v97
	s_wait_dscnt 0x0
	v_add_f32_e32 v97, v97, v98
	ds_bpermute_b32 v98, v110, v97
	s_and_saveexec_b32 s9, s30
	s_cbranch_execz .LBB11_85
; %bb.80:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v97, v97, v98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v98, s29, v97
	v_and_b32_e32 v97, 0x7fffffff, v98
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v97
                                        ; implicit-def: $vgpr97
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.81:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v97, v98, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v97, v98, v97, 0x7fff
                                        ; implicit-def: $vgpr98
	v_lshrrev_b32_e32 v97, 16, v97
; %bb.82:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.83:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v97, 16, v98
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v97, 64, v97
; %bb.84:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[20:21], s[20:21], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[20:21], s[20:21], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v98, vcc_lo, v90, s20
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v99, null, s21, v91, vcc_lo
	global_store_b16 v[98:99], v97, off offset:6
.LBB11_85:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s37
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_56
.LBB11_86:                              ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v97, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v98, v96, v23, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v98, 2, v98
	v_lshlrev_b32_e32 v97, 2, v97
	ds_bpermute_b32 v99, v97, v109
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v102, v109, v99 :: v_dual_cndmask_b32 v99, v96, v22
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	ds_bpermute_b32 v103, v98, v102
	v_lshlrev_b32_e32 v99, 2, v99
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v103, v102, v103 :: v_dual_cndmask_b32 v102, v96, v21
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v102, 2, v102
	ds_bpermute_b32 v106, v99, v103
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v106, v103, v106 :: v_dual_cndmask_b32 v103, v96, v20
	ds_bpermute_b32 v108, v102, v106
	s_wait_dscnt 0x0
	v_dual_add_f32 v106, v106, v108 :: v_dual_lshlrev_b32 v103, 2, v103
	ds_bpermute_b32 v108, v103, v106
	s_and_saveexec_b32 s9, s0
	s_cbranch_execz .LBB11_92
; %bb.87:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v106, v106, v108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v108, s29, v106
	v_and_b32_e32 v106, 0x7fffffff, v108
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v106
                                        ; implicit-def: $vgpr106
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.88:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v106, v108, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v106, v108, v106, 0x7fff
                                        ; implicit-def: $vgpr108
	v_lshrrev_b32_e32 v106, 16, v106
; %bb.89:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.90:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v106, 16, v108
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v106, 64, v106
; %bb.91:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[20:21], s[14:15], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[20:21], s[20:21], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v108, vcc_lo, v90, s20
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v109, null, s21, v91, vcc_lo
	global_store_b16 v[108:109], v106, off
.LBB11_92:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v106, v97, v104
	s_wait_dscnt 0x0
	v_add_f32_e32 v104, v104, v106
	ds_bpermute_b32 v106, v98, v104
	s_wait_dscnt 0x0
	v_add_f32_e32 v104, v104, v106
	ds_bpermute_b32 v106, v99, v104
	s_wait_dscnt 0x0
	v_add_f32_e32 v104, v104, v106
	ds_bpermute_b32 v106, v102, v104
	s_wait_dscnt 0x0
	v_add_f32_e32 v104, v104, v106
	ds_bpermute_b32 v106, v103, v104
	s_and_saveexec_b32 s9, s28
	s_cbranch_execz .LBB11_98
; %bb.93:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v104, v104, v106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v106, s29, v104
	v_and_b32_e32 v104, 0x7fffffff, v106
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v104
                                        ; implicit-def: $vgpr104
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.94:                               ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v104, v106, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v104, v106, v104, 0x7fff
                                        ; implicit-def: $vgpr106
	v_lshrrev_b32_e32 v104, 16, v104
; %bb.95:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.96:                               ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v104, 16, v106
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v104, 64, v104
; %bb.97:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[20:21], s[14:15], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[20:21], s[20:21], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v108, vcc_lo, v90, s20
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v109, null, s21, v91, vcc_lo
	global_store_b16 v[108:109], v104, off offset:2
.LBB11_98:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v104, v97, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v104
	ds_bpermute_b32 v104, v98, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v104
	ds_bpermute_b32 v104, v99, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v104
	ds_bpermute_b32 v104, v102, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v104
	ds_bpermute_b32 v104, v103, v18
	s_and_saveexec_b32 s9, s3
	s_cbranch_execz .LBB11_104
; %bb.99:                               ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v104, s29, v18
	v_and_b32_e32 v18, 0x7fffffff, v104
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v18
                                        ; implicit-def: $vgpr18
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.100:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v18, v104, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v18, v104, v18, 0x7fff
                                        ; implicit-def: $vgpr104
	v_lshrrev_b32_e32 v18, 16, v18
; %bb.101:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.102:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v18, 16, v104
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v18, 64, v18
; %bb.103:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[20:21], s[14:15], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[20:21], s[20:21], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v108, vcc_lo, v90, s20
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v109, null, s21, v91, vcc_lo
	global_store_b16 v[108:109], v18, off offset:4
.LBB11_104:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v18, v97, v17
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	ds_bpermute_b32 v18, v98, v17
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	ds_bpermute_b32 v18, v99, v17
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	ds_bpermute_b32 v18, v102, v17
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	ds_bpermute_b32 v18, v103, v17
	s_and_saveexec_b32 s9, s30
	s_cbranch_execz .LBB11_110
; %bb.105:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v18, s29, v17
	v_and_b32_e32 v17, 0x7fffffff, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v17
                                        ; implicit-def: $vgpr17
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.106:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v17, v18, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v17, v18, v17, 0x7fff
                                        ; implicit-def: $vgpr18
	v_lshrrev_b32_e32 v17, 16, v17
; %bb.107:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.108:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v17, 16, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v17, 64, v17
; %bb.109:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[14:15], s[14:15], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[14:15], s[14:15], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v97, vcc_lo, v90, s14
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v98, null, s15, v91, vcc_lo
	global_store_b16 v[97:98], v17, off offset:6
.LBB11_110:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s36
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_57
.LBB11_111:                             ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v18, v96, v23, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v18, 2, v18
	v_lshlrev_b32_e32 v17, 2, v17
	ds_bpermute_b32 v97, v17, v105
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v98, v105, v97 :: v_dual_cndmask_b32 v97, v96, v22
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	ds_bpermute_b32 v99, v18, v98
	v_lshlrev_b32_e32 v97, 2, v97
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v99, v98, v99 :: v_dual_cndmask_b32 v98, v96, v21
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	ds_bpermute_b32 v102, v97, v99
	v_lshlrev_b32_e32 v98, 2, v98
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v102, v99, v102 :: v_dual_cndmask_b32 v99, v96, v20
	ds_bpermute_b32 v103, v98, v102
	v_lshlrev_b32_e32 v99, 2, v99
	s_wait_dscnt 0x0
	v_add_f32_e32 v102, v102, v103
	ds_bpermute_b32 v103, v99, v102
	s_and_saveexec_b32 s9, s0
	s_cbranch_execz .LBB11_117
; %bb.112:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v102, v102, v103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v103, s29, v102
	v_and_b32_e32 v102, 0x7fffffff, v103
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v102
                                        ; implicit-def: $vgpr102
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.113:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v102, v103, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v102, v103, v102, 0x7fff
                                        ; implicit-def: $vgpr103
	v_lshrrev_b32_e32 v102, 16, v102
; %bb.114:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.115:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v102, 16, v103
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v102, 64, v102
; %bb.116:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[14:15], s[10:11], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[14:15], s[14:15], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v103, vcc_lo, v90, s14
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v104, null, s15, v91, vcc_lo
	global_store_b16 v[103:104], v102, off
.LBB11_117:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v102, v17, v15
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v15, v102
	ds_bpermute_b32 v102, v18, v15
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v15, v102
	ds_bpermute_b32 v102, v97, v15
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v15, v102
	ds_bpermute_b32 v102, v98, v15
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v15, v102
	ds_bpermute_b32 v102, v99, v15
	s_and_saveexec_b32 s9, s28
	s_cbranch_execz .LBB11_123
; %bb.118:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v15, v102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v102, s29, v15
	v_and_b32_e32 v15, 0x7fffffff, v102
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v15
                                        ; implicit-def: $vgpr15
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.119:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v15, v102, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v15, v102, v15, 0x7fff
                                        ; implicit-def: $vgpr102
	v_lshrrev_b32_e32 v15, 16, v15
; %bb.120:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.121:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v15, 16, v102
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v15, 64, v15
; %bb.122:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[14:15], s[10:11], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[14:15], s[14:15], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v102, vcc_lo, v90, s14
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v103, null, s15, v91, vcc_lo
	global_store_b16 v[102:103], v15, off offset:2
.LBB11_123:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v15, v17, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	ds_bpermute_b32 v15, v18, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	ds_bpermute_b32 v15, v97, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	ds_bpermute_b32 v15, v98, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	ds_bpermute_b32 v15, v99, v11
	s_and_saveexec_b32 s9, s3
	s_cbranch_execz .LBB11_129
; %bb.124:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v15, s29, v11
	v_and_b32_e32 v11, 0x7fffffff, v15
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v11
                                        ; implicit-def: $vgpr11
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.125:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v11, v15, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v11, v15, v11, 0x7fff
                                        ; implicit-def: $vgpr15
	v_lshrrev_b32_e32 v11, 16, v11
; %bb.126:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.127:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v11, 16, v15
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v11, 64, v11
; %bb.128:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[14:15], s[10:11], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[14:15], s[14:15], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v102, vcc_lo, v90, s14
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v103, null, s15, v91, vcc_lo
	global_store_b16 v[102:103], v11, off offset:4
.LBB11_129:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v11, v17, v16
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v16, v11
	ds_bpermute_b32 v15, v18, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	ds_bpermute_b32 v15, v97, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	ds_bpermute_b32 v15, v98, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	ds_bpermute_b32 v15, v99, v11
	s_and_saveexec_b32 s9, s30
	s_cbranch_execz .LBB11_135
; %bb.130:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v15, s29, v11
	v_and_b32_e32 v11, 0x7fffffff, v15
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v11
                                        ; implicit-def: $vgpr11
	s_and_saveexec_b32 s13, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s13, exec_lo, s13
; %bb.131:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v11, v15, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v11, v15, v11, 0x7fff
                                        ; implicit-def: $vgpr15
	v_lshrrev_b32_e32 v11, 16, v11
; %bb.132:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s13, s13
; %bb.133:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v11, 16, v15
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v11, 64, v11
; %bb.134:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_mul_u64 s[10:11], s[10:11], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v15, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v16, null, s11, v91, vcc_lo
	global_store_b16 v[15:16], v11, off offset:6
.LBB11_135:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	v_cmp_ne_u32_e32 vcc_lo, 1, v7
	s_cbranch_vccnz .LBB11_58
.LBB11_136:                             ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v7, 2, v7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v96, v23, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	s_wait_dscnt 0x0
	ds_bpermute_b32 v15, v7, v107
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v16, v107, v15 :: v_dual_cndmask_b32 v15, v96, v22
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	ds_bpermute_b32 v17, v11, v16
	v_lshlrev_b32_e32 v15, 2, v15
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v16, v17
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v16, v96, v21, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	ds_bpermute_b32 v18, v15, v17
	v_lshlrev_b32_e32 v16, 2, v16
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v18, v17, v18 :: v_dual_cndmask_b32 v17, v96, v20
	ds_bpermute_b32 v97, v16, v18
	v_lshlrev_b32_e32 v17, 2, v17
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v97
	ds_bpermute_b32 v97, v17, v18
	s_and_saveexec_b32 s9, s0
	s_cbranch_execz .LBB11_142
; %bb.137:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v97, s29, v18
	v_and_b32_e32 v18, 0x7fffffff, v97
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v18
                                        ; implicit-def: $vgpr18
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.138:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v18, v97, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v18, v97, v18, 0x7fff
                                        ; implicit-def: $vgpr97
	v_lshrrev_b32_e32 v18, 16, v18
; %bb.139:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.140:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v18, 16, v97
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v18, 64, v18
; %bb.141:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s23, s22, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[22:23], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v97, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v98, null, s11, v91, vcc_lo
	global_store_b16 v[97:98], v18, off
.LBB11_142:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v18, v7, v100
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v100, v18
	ds_bpermute_b32 v97, v11, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v97
	ds_bpermute_b32 v97, v15, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v97
	ds_bpermute_b32 v97, v16, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v97
	ds_bpermute_b32 v97, v17, v18
	s_and_saveexec_b32 s9, s28
	s_cbranch_execz .LBB11_148
; %bb.143:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v97, s29, v18
	v_and_b32_e32 v18, 0x7fffffff, v97
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v18
                                        ; implicit-def: $vgpr18
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.144:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v18, v97, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v18, v97, v18, 0x7fff
                                        ; implicit-def: $vgpr97
	v_lshrrev_b32_e32 v18, 16, v18
; %bb.145:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.146:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v18, 16, v97
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v18, 64, v18
; %bb.147:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s23, s22, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[22:23], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v97, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v98, null, s11, v91, vcc_lo
	global_store_b16 v[97:98], v18, off offset:2
.LBB11_148:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v18, v7, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v13, v13, v18
	ds_bpermute_b32 v18, v11, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v13, v13, v18
	ds_bpermute_b32 v18, v15, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v13, v13, v18
	ds_bpermute_b32 v18, v16, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v13, v13, v18
	ds_bpermute_b32 v18, v17, v13
	s_and_saveexec_b32 s9, s3
	s_cbranch_execz .LBB11_154
; %bb.149:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v13, v13, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v18, s29, v13
	v_and_b32_e32 v13, 0x7fffffff, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v13
                                        ; implicit-def: $vgpr13
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.150:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v13, v18, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v13, v18, v13, 0x7fff
                                        ; implicit-def: $vgpr18
	v_lshrrev_b32_e32 v13, 16, v13
; %bb.151:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.152:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v13, 16, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v13, 64, v13
; %bb.153:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s23, s22, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[22:23], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v97, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v98, null, s11, v91, vcc_lo
	global_store_b16 v[97:98], v13, off offset:4
.LBB11_154:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v7, v7, v8
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v8, v7
	ds_bpermute_b32 v8, v11, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v15, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v16, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	ds_bpermute_b32 v8, v17, v7
	s_and_saveexec_b32 s9, s30
	s_cbranch_execz .LBB11_160
; %bb.155:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v8, s29, v7
	v_and_b32_e32 v7, 0x7fffffff, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.156:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.157:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.158:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.159:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s23, s22, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[22:23], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v15, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v16, null, s11, v91, vcc_lo
	global_store_b16 v[15:16], v7, off offset:6
.LBB11_160:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s35
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_59
.LBB11_161:                             ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v8, v96, v23, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v8, 2, v8
	v_lshlrev_b32_e32 v7, 2, v7
	ds_bpermute_b32 v11, v7, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v3, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v96, v22, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	ds_bpermute_b32 v13, v8, v11
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v13, v11, v13
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v11, v96, v21, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	ds_bpermute_b32 v15, v3, v13
	v_lshlrev_b32_e32 v11, 2, v11
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v13, v15
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v13, v96, v20, vcc_lo
	ds_bpermute_b32 v16, v11, v15
	v_lshlrev_b32_e32 v13, 2, v13
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v15, v16
	ds_bpermute_b32 v16, v13, v15
	s_and_saveexec_b32 s9, s0
	s_cbranch_execz .LBB11_167
; %bb.162:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v15, v15, v16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v16, s29, v15
	v_and_b32_e32 v15, 0x7fffffff, v16
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v15
                                        ; implicit-def: $vgpr15
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.163:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v15, v16, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v15, v16, v15, 0x7fff
                                        ; implicit-def: $vgpr16
	v_lshrrev_b32_e32 v15, 16, v15
; %bb.164:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.165:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v15, 16, v16
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v15, 64, v15
; %bb.166:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s19, s18, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[18:19], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v16, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v17, null, s11, v91, vcc_lo
	global_store_b16 v[16:17], v15, off
.LBB11_167:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v15, v7, v14
	s_wait_dscnt 0x0
	v_add_f32_e32 v14, v14, v15
	ds_bpermute_b32 v15, v8, v14
	s_wait_dscnt 0x0
	v_add_f32_e32 v14, v14, v15
	ds_bpermute_b32 v15, v3, v14
	s_wait_dscnt 0x0
	v_add_f32_e32 v14, v14, v15
	ds_bpermute_b32 v15, v11, v14
	s_wait_dscnt 0x0
	v_add_f32_e32 v14, v14, v15
	ds_bpermute_b32 v15, v13, v14
	s_and_saveexec_b32 s9, s28
	s_cbranch_execz .LBB11_173
; %bb.168:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v14, v14, v15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v15, s29, v14
	v_and_b32_e32 v14, 0x7fffffff, v15
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v14
                                        ; implicit-def: $vgpr14
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.169:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v14, v15, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v14, v15, v14, 0x7fff
                                        ; implicit-def: $vgpr15
	v_lshrrev_b32_e32 v14, 16, v14
; %bb.170:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.171:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v14, 16, v15
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v14, 64, v14
; %bb.172:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s19, s18, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[18:19], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v15, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v16, null, s11, v91, vcc_lo
	global_store_b16 v[15:16], v14, off offset:2
.LBB11_173:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v14, v7, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v9, v9, v14
	ds_bpermute_b32 v14, v8, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v9, v9, v14
	ds_bpermute_b32 v14, v3, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v9, v9, v14
	ds_bpermute_b32 v14, v11, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v9, v9, v14
	ds_bpermute_b32 v14, v13, v9
	s_and_saveexec_b32 s9, s3
	s_cbranch_execz .LBB11_179
; %bb.174:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v9, v9, v14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v14, s29, v9
	v_and_b32_e32 v9, 0x7fffffff, v14
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v9
                                        ; implicit-def: $vgpr9
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.175:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v9, v14, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v9, v14, v9, 0x7fff
                                        ; implicit-def: $vgpr14
	v_lshrrev_b32_e32 v9, 16, v9
; %bb.176:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.177:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v9, 16, v14
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v9, 64, v9
; %bb.178:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s19, s18, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[18:19], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v14, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v15, null, s11, v91, vcc_lo
	global_store_b16 v[14:15], v9, off offset:4
.LBB11_179:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v7, v7, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v7
	ds_bpermute_b32 v7, v8, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v4, v4, v7
	ds_bpermute_b32 v3, v3, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v4, v3
	ds_bpermute_b32 v4, v11, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v4
	ds_bpermute_b32 v4, v13, v3
	s_and_saveexec_b32 s9, s30
	s_cbranch_execz .LBB11_185
; %bb.180:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v3, v3, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v4, s29, v3
	v_and_b32_e32 v3, 0x7fffffff, v4
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v3
                                        ; implicit-def: $vgpr3
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.181:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v3, v4, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v3, v4, v3, 0x7fff
                                        ; implicit-def: $vgpr4
	v_lshrrev_b32_e32 v3, 16, v3
; %bb.182:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.183:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v3, 16, v4
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v3, 64, v3
; %bb.184:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s19, s18, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[18:19], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v7, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v8, null, s11, v91, vcc_lo
	global_store_b16 v[7:8], v3, off offset:6
.LBB11_185:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s34
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_60
.LBB11_186:                             ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v96, v23, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v3, 2, v3
	ds_bpermute_b32 v7, v3, v19
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_add_f32 v8, v19, v7 :: v_dual_cndmask_b32 v7, v96, v22
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	ds_bpermute_b32 v9, v4, v8
	v_lshlrev_b32_e32 v7, 2, v7
	s_wait_dscnt 0x0
	v_add_f32_e32 v9, v8, v9
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v8, v96, v21, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v8, 2, v8
	ds_bpermute_b32 v11, v7, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v9, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v9, v96, v20, vcc_lo
	ds_bpermute_b32 v13, v8, v11
	v_lshlrev_b32_e32 v9, 2, v9
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v13
	ds_bpermute_b32 v13, v9, v11
	s_and_saveexec_b32 s9, s0
	s_cbranch_execz .LBB11_192
; %bb.187:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v11, v11, v13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v13, s29, v11
	v_and_b32_e32 v11, 0x7fffffff, v13
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v11
                                        ; implicit-def: $vgpr11
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.188:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v11, v13, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v11, v13, v11, 0x7fff
                                        ; implicit-def: $vgpr13
	v_lshrrev_b32_e32 v11, 16, v11
; %bb.189:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.190:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v11, 16, v13
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v11, 64, v11
; %bb.191:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s13, s12, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[12:13], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v13, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v14, null, s11, v91, vcc_lo
	global_store_b16 v[13:14], v11, off
.LBB11_192:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v11, v3, v10
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v4, v10
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v7, v10
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v8, v10
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v10, v11
	ds_bpermute_b32 v11, v9, v10
	s_and_saveexec_b32 s9, s28
	s_cbranch_execz .LBB11_198
; %bb.193:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v10, v10, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v11, s29, v10
	v_and_b32_e32 v10, 0x7fffffff, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v10
                                        ; implicit-def: $vgpr10
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.194:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v10, v11, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v10, v11, v10, 0x7fff
                                        ; implicit-def: $vgpr11
	v_lshrrev_b32_e32 v10, 16, v10
; %bb.195:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.196:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v10, 16, v11
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v10, 64, v10
; %bb.197:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s13, s12, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[12:13], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v13, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v14, null, s11, v91, vcc_lo
	global_store_b16 v[13:14], v10, off offset:2
.LBB11_198:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v10, v3, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v10
	ds_bpermute_b32 v10, v4, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v10
	ds_bpermute_b32 v10, v7, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v10
	ds_bpermute_b32 v10, v8, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v10
	ds_bpermute_b32 v10, v9, v5
	s_and_saveexec_b32 s9, s3
	s_cbranch_execz .LBB11_204
; %bb.199:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v5, v10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v10, s29, v5
	v_and_b32_e32 v5, 0x7fffffff, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v5
                                        ; implicit-def: $vgpr5
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.200:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v5, v10, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v5, v10, v5, 0x7fff
                                        ; implicit-def: $vgpr10
	v_lshrrev_b32_e32 v5, 16, v5
; %bb.201:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.202:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v5, 16, v10
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v5, 64, v5
; %bb.203:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s13, s12, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[12:13], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v10, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v11, null, s11, v91, vcc_lo
	global_store_b16 v[10:11], v5, off offset:4
.LBB11_204:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	ds_bpermute_b32 v3, v3, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v3
	ds_bpermute_b32 v3, v4, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v3
	ds_bpermute_b32 v3, v7, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v3
	ds_bpermute_b32 v3, v8, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v3
	ds_bpermute_b32 v3, v9, v1
	s_and_saveexec_b32 s9, s30
	s_cbranch_execz .LBB11_210
; %bb.205:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v3, s29, v1
	v_and_b32_e32 v1, 0x7fffffff, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s10, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s10, exec_lo, s10
; %bb.206:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v1, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v3, v1, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.207:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s10, s10
; %bb.208:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v1, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.209:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_wait_kmcnt 0x0
	s_ashr_i32 s13, s12, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[10:11], s[12:13], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[10:11], s[10:11], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v3, vcc_lo, v90, s10
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, s11, v91, vcc_lo
	global_store_b16 v[3:4], v1, off offset:6
.LBB11_210:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s33
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB11_8
.LBB11_211:                             ;   in Loop: Header=BB11_9 Depth=1
	v_cmp_gt_i32_e32 vcc_lo, 32, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v96, v101, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v23
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v96, v23, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v22
	v_lshlrev_b32_e32 v1, 2, v1
	s_delay_alu instid0(VALU_DEP_3)
	v_lshlrev_b32_e32 v3, 2, v3
	ds_bpermute_b32 v4, v1, v12
	s_wait_dscnt 0x0
	v_add_f32_e32 v5, v12, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v96, v22, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v21
	ds_bpermute_b32 v7, v3, v5
	s_wait_dscnt 0x0
	v_dual_add_f32 v7, v5, v7 :: v_dual_lshlrev_b32 v4, 2, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v96, v21, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	ds_bpermute_b32 v8, v4, v7
	s_wait_dscnt 0x0
	v_dual_add_f32 v8, v7, v8 :: v_dual_lshlrev_b32 v5, 2, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v7, v96, v20, vcc_lo
	ds_bpermute_b32 v9, v5, v8
	s_wait_dscnt 0x0
	v_dual_add_f32 v8, v8, v9 :: v_dual_lshlrev_b32 v7, 2, v7
	ds_bpermute_b32 v9, v7, v8
	s_and_saveexec_b32 s10, s0
	s_cbranch_execz .LBB11_217
; %bb.212:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v8, v8, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v9, s29, v8
	v_and_b32_e32 v8, 0x7fffffff, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v8
                                        ; implicit-def: $vgpr8
	s_and_saveexec_b32 s9, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s9, exec_lo, s9
; %bb.213:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v8, v9, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v8, v9, v8, 0x7fff
                                        ; implicit-def: $vgpr9
	v_lshrrev_b32_e32 v8, 16, v8
; %bb.214:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s9, s9
; %bb.215:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v8, 16, v9
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v8, 64, v8
; %bb.216:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_wait_kmcnt 0x0
	s_ashr_i32 s9, s8, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[12:13], s[8:9], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[12:13], s[12:13], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v9, vcc_lo, v90, s12
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, s13, v91, vcc_lo
	global_store_b16 v[9:10], v8, off
.LBB11_217:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	ds_bpermute_b32 v8, v1, v6
	s_wait_dscnt 0x0
	v_add_f32_e32 v6, v6, v8
	ds_bpermute_b32 v8, v3, v6
	s_wait_dscnt 0x0
	v_add_f32_e32 v6, v6, v8
	ds_bpermute_b32 v8, v4, v6
	s_wait_dscnt 0x0
	v_add_f32_e32 v6, v6, v8
	ds_bpermute_b32 v8, v5, v6
	s_wait_dscnt 0x0
	v_add_f32_e32 v6, v6, v8
	ds_bpermute_b32 v8, v7, v6
	s_and_saveexec_b32 s10, s28
	s_cbranch_execz .LBB11_223
; %bb.218:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v6, v6, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v8, s29, v6
	v_and_b32_e32 v6, 0x7fffffff, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v6
                                        ; implicit-def: $vgpr6
	s_and_saveexec_b32 s9, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s9, exec_lo, s9
; %bb.219:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v6, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v6, v8, v6, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v6, 16, v6
; %bb.220:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s9, s9
; %bb.221:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v6, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v6, 64, v6
; %bb.222:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_wait_kmcnt 0x0
	s_ashr_i32 s9, s8, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[12:13], s[8:9], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[12:13], s[12:13], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v8, vcc_lo, v90, s12
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v9, null, s13, v91, vcc_lo
	global_store_b16 v[8:9], v6, off offset:2
.LBB11_223:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	ds_bpermute_b32 v6, v1, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v6
	ds_bpermute_b32 v6, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v6
	ds_bpermute_b32 v6, v4, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v6
	ds_bpermute_b32 v6, v5, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v6
	ds_bpermute_b32 v6, v7, v2
	s_and_saveexec_b32 s10, s3
	s_cbranch_execz .LBB11_229
; %bb.224:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v6, s29, v2
	v_and_b32_e32 v2, 0x7fffffff, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s9, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s9, exec_lo, s9
; %bb.225:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v2, v6, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v6, v2, 0x7fff
                                        ; implicit-def: $vgpr6
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.226:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s9, s9
; %bb.227:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v2, 16, v6
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.228:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_wait_kmcnt 0x0
	s_ashr_i32 s9, s8, 31
	s_wait_alu 0xfffe
	s_mul_u64 s[12:13], s[8:9], s[16:17]
	s_wait_alu 0xfffe
	s_lshl_b64 s[12:13], s[12:13], 1
	s_wait_alu 0xfffe
	v_add_co_u32 v8, vcc_lo, v90, s12
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v9, null, s13, v91, vcc_lo
	global_store_b16 v[8:9], v2, off offset:4
.LBB11_229:                             ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	ds_bpermute_b32 v1, v1, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v1
	ds_bpermute_b32 v1, v3, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v1
	ds_bpermute_b32 v1, v4, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v1
	ds_bpermute_b32 v1, v5, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v1
	ds_bpermute_b32 v1, v7, v0
	s_and_saveexec_b32 s10, s30
	s_cbranch_execz .LBB11_7
; %bb.230:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v1, s29, v0
	v_and_b32_e32 v0, 0x7fffffff, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s9, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s9, exec_lo, s9
; %bb.231:                              ;   in Loop: Header=BB11_9 Depth=1
	v_bfe_u32 v0, v1, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v1, v0, 0x7fff
                                        ; implicit-def: $vgpr1
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.232:                              ;   in Loop: Header=BB11_9 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s9, s9
	s_cbranch_execz .LBB11_6
; %bb.233:                              ;   in Loop: Header=BB11_9 Depth=1
	v_lshrrev_b32_e32 v0, 16, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
	s_branch .LBB11_6
.LBB11_234:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_119moe_down_g2f_kernelILi4EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iii
		.amdhsa_group_segment_fixed_size 64
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 76
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 135
		.amdhsa_next_free_sgpr 42
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 133
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_119moe_down_g2f_kernelILi4EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iii,"axG",@progbits,_ZN12_GLOBAL__N_119moe_down_g2f_kernelILi4EEEvPK7ik_bf16PKhS5_PKfPKiS9_S9_PS1_iii,comdat
.Lfunc_end11:
