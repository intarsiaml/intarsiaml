_ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii: ; @_ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
; %bb.0:
	s_clause 0x1
	s_load_b64 s[6:7], s[0:1], 0x20
	s_load_b64 s[2:3], s[0:1], 0x8
	s_mov_b32 s4, ttmp9
	s_mov_b32 s5, 0
	v_lshrrev_b32_e32 v1, 4, v0
	s_lshl_b64 s[4:5], s[4:5], 4
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, s5
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v75, 0
	v_and_or_b32 v71, v1, 14, s4
	v_mov_b32_e32 v76, 0
	s_mov_b32 s4, exec_lo
	s_wait_kmcnt 0x0
	s_ashr_i32 s11, s6, 31
	s_mov_b32 s10, s6
	s_ashr_i32 s18, s7, 31
	v_cmpx_gt_i64_e64 s[10:11], v[71:72]
; %bb.1:
	v_mad_co_u64_u32 v[75:76], null, v71, s7, s[2:3]
	v_mul_lo_u32 v1, v71, s18
	v_mul_lo_u32 v2, v72, s7
	s_delay_alu instid0(VALU_DEP_1)
	v_add3_u32 v76, v2, v76, v1
; %bb.2:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v69, 1, v71
	v_mov_b32_e32 v70, v72
	s_mov_b32 s4, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i64_e64 s[10:11], v[69:70]
; %bb.3:
	v_mad_co_u64_u32 v[73:74], null, v69, s7, s[2:3]
	v_mul_lo_u32 v1, v69, s18
	v_mul_lo_u32 v2, v70, s7
	s_delay_alu instid0(VALU_DEP_1)
	v_add3_u32 v74, v2, v74, v1
; %bb.4:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_lshr_b32 s2, s18, 28
	v_dual_mov_b32 v30, 0 :: v_dual_and_b32 v81, 31, v0
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s7, s2
	v_cmp_ne_u64_e32 vcc_lo, 0, v[75:76]
	s_wait_alu 0xfffe
	s_ashr_i32 s16, s2, 4
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v82, 4, v81
	v_cmp_gt_i32_e64 s6, s16, v81
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v32, 0
	v_mov_b32_e32 v31, 0
	s_and_b32 s2, s6, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s3, s2
	s_wait_alu 0xfffe
	s_xor_b32 s3, exec_lo, s3
	s_cbranch_execz .LBB57_6
; %bb.5:
	v_add_co_u32 v1, s2, v75, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v76, s2
	global_load_b128 v[29:32], v[1:2], off th:TH_LOAD_NT
.LBB57_6:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_cmp_ne_u64_e64 s2, 0, v[73:74]
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0
	v_mov_b32_e32 v24, 0
	s_and_b32 s3, s6, s2
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB57_8
; %bb.7:
	v_add_co_u32 v1, s3, v73, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v74, s3
	global_load_b128 v[21:24], v[1:2], off th:TH_LOAD_NT
.LBB57_8:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v86, 32, v81
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v26, 0
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v28, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s5, s16, v86
	v_mov_b32_e32 v27, 0
	s_and_b32 s3, vcc_lo, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB57_10
; %bb.9:
	v_add_co_u32 v1, s3, v75, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v76, s3
	global_load_b128 v[25:28], v[1:2], off offset:512 th:TH_LOAD_NT
.LBB57_10:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0
	v_mov_b32_e32 v16, 0
	s_and_b32 s3, s2, s5
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB57_12
; %bb.11:
	v_add_co_u32 v1, s3, v73, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v74, s3
	global_load_b128 v[13:16], v[1:2], off offset:512 th:TH_LOAD_NT
.LBB57_12:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v85, 64, v81
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v18, 0
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s4, s16, v85
	v_mov_b32_e32 v19, 0
	s_and_b32 s3, vcc_lo, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s3
	s_cbranch_execz .LBB57_14
; %bb.13:
	v_add_co_u32 v1, s3, v75, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v76, s3
	global_load_b128 v[17:20], v[1:2], off offset:1024 th:TH_LOAD_NT
.LBB57_14:
	s_or_b32 exec_lo, exec_lo, s8
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0
	v_mov_b32_e32 v8, 0
	s_and_b32 s3, s2, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s3
	s_cbranch_execz .LBB57_16
; %bb.15:
	v_add_co_u32 v1, s3, v73, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v74, s3
	global_load_b128 v[5:8], v[1:2], off offset:1024 th:TH_LOAD_NT
.LBB57_16:
	s_or_b32 exec_lo, exec_lo, s8
	s_load_b64 s[8:9], s[0:1], 0x10
	v_or_b32_e32 v84, 0x60, v81
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v10, 0
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v12, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	v_cmp_gt_i32_e64 s3, s16, v84
	v_mov_b32_e32 v11, 0
	s_and_b32 s13, vcc_lo, s3
	s_and_saveexec_b32 s12, s13
	s_cbranch_execz .LBB57_18
; %bb.17:
	v_add_co_u32 v2, vcc_lo, v75, v82
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v3, null, 0, v76, vcc_lo
	global_load_b128 v[9:12], v[2:3], off offset:1536 th:TH_LOAD_NT
.LBB57_18:
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0
	v_mov_b32_e32 v4, 0
	s_and_b32 s13, s2, s3
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_saveexec_b32 s12, s13
	s_cbranch_execz .LBB57_20
; %bb.19:
	v_add_co_u32 v1, vcc_lo, v73, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v74, vcc_lo
	global_load_b128 v[1:4], v[1:2], off offset:1536 th:TH_LOAD_NT
.LBB57_20:
	s_or_b32 exec_lo, exec_lo, s12
	s_wait_kmcnt 0x0
	s_load_b64 s[14:15], s[8:9], 0x0
	s_load_b64 s[12:13], s[0:1], 0x18
	s_mov_b32 s20, 0
	s_mov_b32 s19, exec_lo
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s15, 0
	s_cselect_b32 s9, -1, 0
	s_cmp_ngt_f32 s15, 0
	s_cselect_b32 s17, -1, 0
	s_lshr_b32 s8, s18, 29
	s_delay_alu instid0(SALU_CYCLE_1)
	s_add_co_i32 s7, s7, s8
	s_wait_alu 0xfffe
	s_ashr_i32 s18, s7, 3
	s_wait_alu 0xfffe
	v_cmpx_gt_i32_e64 s18, v0
	s_cbranch_execz .LBB57_25
; %bb.21:
	s_clause 0x1
	s_load_b64 s[22:23], s[0:1], 0x0
	s_load_b32 s0, s[0:1], 0x34
	v_lshlrev_b32_e32 v33, 4, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v39, 0, v33
	s_wait_kmcnt 0x0
	v_add_co_u32 v33, s1, s22, v33
	v_add_co_ci_u32_e64 v34, null, s23, 0, s1
	s_and_b32 s21, s0, 0xffff
	v_add_co_u32 v37, vcc_lo, v33, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, 0, v34, vcc_lo
	s_lshl_b32 s22, s21, 4
	s_mov_b32 s23, 0xc3e00000
	s_branch .LBB57_23
.LBB57_22:                              ;   in Loop: Header=BB57_23 Depth=1
	v_add_nc_u32_e32 v0, s21, v0
	v_add_co_u32 v37, s0, v37, s22
	s_wait_loadcnt 0x0
	ds_store_b128 v39, v[33:36]
	v_add_nc_u32_e32 v39, s22, v39
	v_cmp_le_i32_e32 vcc_lo, s18, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v38, null, 0, v38, s0
	s_or_b32 s20, vcc_lo, s20
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s20
	s_cbranch_execz .LBB57_25
.LBB57_23:                              ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[33:36], v[37:38], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s9
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB57_22
; %bb.24:                               ;   in Loop: Header=BB57_23 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v43, 16, v34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_div_scale_f32 v54, s1, v43, s15, v43
	v_lshlrev_b32_e32 v40, 16, v33
	v_and_b32_e32 v33, 0xffff0000, v33
	v_div_scale_f32 v47, null, s15, s15, v43
	v_div_scale_f32 v41, null, s15, s15, v40
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_scale_f32 v42, null, s15, s15, v33
	v_rcp_f32_e32 v50, v47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v45, v41
	v_div_scale_f32 v49, vcc_lo, v40, s15, v40
	v_rcp_f32_e32 v46, v42
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v51, -v41, v45, 1.0
	v_and_b32_e32 v34, 0xffff0000, v34
	v_fma_f32 v52, -v42, v46, 1.0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v45, v51, v45 :: v_dual_lshlrev_b32 v44, 16, v35
	v_div_scale_f32 v51, null, s15, s15, v34
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v46, v52, v46
	v_div_scale_f32 v53, s0, v33, s15, v33
	v_fma_f32 v52, -v47, v50, 1.0
	v_mul_f32_e32 v55, v49, v45
	v_dual_mul_f32 v56, v53, v46 :: v_dual_and_b32 v35, 0xffff0000, v35
	v_div_scale_f32 v57, null, s15, s15, v44
	s_delay_alu instid0(VALU_DEP_3)
	v_fma_f32 v59, -v41, v55, v49
	v_fmac_f32_e32 v50, v52, v50
	v_lshlrev_b32_e32 v48, 16, v36
	v_fma_f32 v52, -v42, v56, v53
	v_rcp_f32_e32 v58, v51
	v_fmac_f32_e32 v55, v59, v45
	v_mul_f32_e32 v59, v54, v50
	v_div_scale_f32 v60, s7, v34, s15, v34
	v_fmac_f32_e32 v56, v52, v46
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v41, -v41, v55, v49
	v_fma_f32 v49, -v47, v59, v54
	v_and_b32_e32 v36, 0xffff0000, v36
	v_rcp_f32_e32 v52, v57
	v_fma_f32 v42, -v42, v56, v53
	s_wait_alu 0xfffd
	v_div_fmas_f32 v41, v41, v45, v55
	v_div_scale_f32 v45, null, s15, s15, v35
	v_fmac_f32_e32 v59, v49, v50
	s_mov_b32 vcc_lo, s0
	s_delay_alu instid0(VALU_DEP_3)
	v_div_fixup_f32 v40, v41, s15, v40
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v46, v56
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v46, -v47, v59, v54
	v_rcp_f32_e32 v47, v45
	v_fma_f32 v41, -v57, v52, 1.0
	v_fma_f32 v61, -v51, v58, 1.0
	v_div_fixup_f32 v33, v42, s15, v33
	v_div_scale_f32 v55, null, s15, s15, v36
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v52, v41, v52
	v_div_scale_f32 v41, s0, v44, s15, v44
	v_med3_num_f32 v40, v40, s23, 0x43e00000
	v_fma_f32 v53, -v45, v47, 1.0
	v_med3_num_f32 v33, v33, s23, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v47, v53, v47
	s_wait_alu 0xfffe
	v_div_fmas_f32 v46, v46, v50, v59
	s_mov_b32 vcc_lo, s7
	v_div_scale_f32 v50, null, s15, s15, v48
	v_div_scale_f32 v53, s1, v35, s15, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v43, v46, s15, v43
	v_mul_f32_e32 v46, v41, v52
	v_rcp_f32_e32 v54, v50
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v43, v43, s23, 0x43e00000
	v_fma_f32 v59, -v57, v46, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v46, v59, v52
	v_div_scale_f32 v59, s7, v36, s15, v36
	v_fmac_f32_e32 v58, v61, v58
	v_fma_f32 v56, -v50, v54, 1.0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v41, -v57, v46, v41
	v_mul_f32_e32 v42, v60, v58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v54, v56, v54
	v_div_scale_f32 v56, s8, v48, s15, v48
	v_fma_f32 v49, -v51, v42, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v42, v49, v58
	v_rcp_f32_e32 v49, v55
	v_fma_f32 v51, -v51, v42, v60
	v_mul_f32_e32 v60, v53, v47
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fmas_f32 v42, v51, v58, v42
	v_fma_f32 v51, -v45, v60, v53
	v_mul_f32_e32 v58, v56, v54
	s_delay_alu instid0(TRANS32_DEP_1)
	v_fma_f32 v61, -v55, v49, 1.0
	s_mov_b32 vcc_lo, s0
	v_div_fixup_f32 v34, v42, s15, v34
	v_fmac_f32_e32 v60, v51, v47
	v_fma_f32 v42, -v50, v58, v56
	v_fmac_f32_e32 v49, v61, v49
	s_wait_alu 0xfffe
	v_div_fmas_f32 v41, v41, v52, v46
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v45, -v45, v60, v53
	v_dual_fmac_f32 v58, v42, v54 :: v_dual_mul_f32 v51, v59, v49
	v_med3_num_f32 v34, v34, s23, 0x43e00000
	v_div_fixup_f32 v41, v41, s15, v44
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v45, v47, v60
	v_mov_b32_e32 v45, 0
	v_fma_f32 v46, -v55, v51, v59
	v_fma_f32 v44, -v50, v58, v56
	v_med3_num_f32 v41, v41, s23, 0x43e00000
	v_div_fixup_f32 v35, v42, s15, v35
	v_cvt_pk_fp8_f32 v45, v40, v33
	v_mov_b32_e32 v33, 0
	v_fmac_f32_e32 v51, v46, v49
	s_mov_b32 vcc_lo, s8
	v_med3_num_f32 v35, v35, s23, 0x43e00000
	v_cvt_pk_fp8_f32 v45, v43, v34 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v42, -v55, v51, v59
	v_cvt_pk_fp8_f32 v33, v41, v35
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_perm_b32 v35, 0, v45, 0x30c020c
	v_perm_b32 v34, 0, v45, 0x10c000c
	v_lshrrev_b32_e32 v41, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	s_wait_alu 0xfffe
	v_div_fmas_f32 v44, v44, v54, v58
	s_mov_b32 vcc_lo, s7
	s_wait_alu 0xfffe
	v_div_fmas_f32 v42, v42, v49, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fixup_f32 v44, v44, s15, v48
	v_div_fixup_f32 v36, v42, s15, v36
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v40, v44, s23, 0x43e00000
	v_med3_num_f32 v36, v36, s23, 0x43e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v33, v40, v36 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v36, 1, v34
	v_and_b32_e32 v34, 0x80008000, v34
	v_perm_b32 v40, 0, v33, 0x10c000c
	v_perm_b32 v33, 0, v33, 0x30c020c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v42, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_lshrrev_b32_e32 v43, 1, v33
	v_and_b32_e32 v44, 0x80008000, v33
	v_and_or_b32 v33, 0x3f803f80, v36, v34
	v_and_or_b32 v34, 0x3f803f80, v41, v35
	v_and_or_b32 v35, 0x3f803f80, v42, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v36, 0x3f803f80, v43, v44
	s_branch .LBB57_22
.LBB57_25:
	s_or_b32 exec_lo, exec_lo, s19
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_mov_b32 s0, exec_lo
	v_cmpx_ne_u64_e32 0, v[75:76]
	s_cbranch_execz .LBB57_121
; %bb.26:
	v_xad_u32 v0, v81, 31, s16
	s_and_b32 s0, s9, exec_lo
	s_cselect_b32 s1, s15, 1.0
	s_and_not1_b32 vcc_lo, exec_lo, s17
	s_wait_alu 0xfffe
	s_mul_f32 s9, s14, s1
	v_ashrrev_i32_e32 v33, 31, v0
	v_cmp_lt_i32_e64 s0, 31, v0
	s_mov_b32 s1, -1
	v_lshrrev_b32_e32 v33, 27, v33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v33, v0, v33
	v_ashrrev_i32_e32 v83, 5, v33
	s_cbranch_vccnz .LBB57_70
; %bb.27:
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v87, 0
	s_and_saveexec_b32 s7, s0
	s_cbranch_execz .LBB57_57
; %bb.28:
	v_dual_mov_b32 v78, v76 :: v_dual_lshlrev_b32 v33, 5, v81
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v80, v74
	v_dual_mov_b32 v77, v75 :: v_dual_mov_b32 v60, v12
	v_dual_mov_b32 v79, v73 :: v_dual_mov_b32 v58, v10
	s_delay_alu instid0(VALU_DEP_4)
	v_add3_u32 v89, v33, 0, 0x400
	v_dual_mov_b32 v59, v11 :: v_dual_mov_b32 v52, v20
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v50, v18
	v_dual_mov_b32 v51, v19 :: v_dual_mov_b32 v44, v28
	v_dual_mov_b32 v49, v17 :: v_dual_mov_b32 v42, v26
	v_dual_mov_b32 v43, v27 :: v_dual_mov_b32 v36, v32
	v_dual_mov_b32 v41, v25 :: v_dual_mov_b32 v34, v30
	v_dual_mov_b32 v35, v31 :: v_dual_mov_b32 v38, v22
	v_dual_mov_b32 v33, v29 :: v_dual_mov_b32 v40, v24
	v_dual_mov_b32 v37, v21 :: v_dual_mov_b32 v46, v14
	v_dual_mov_b32 v39, v23 :: v_dual_mov_b32 v48, v16
	v_dual_mov_b32 v45, v13 :: v_dual_mov_b32 v54, v6
	v_dual_mov_b32 v47, v15 :: v_dual_mov_b32 v56, v8
	v_dual_mov_b32 v53, v5 :: v_dual_mov_b32 v62, v2
	v_dual_mov_b32 v55, v7 :: v_dual_mov_b32 v64, v4
	v_dual_mov_b32 v61, v1 :: v_dual_mov_b32 v88, 0
	v_mov_b32_e32 v63, v3
	s_mov_b32 s8, 0
	s_mov_b32 s14, 0
	s_mov_b32 s15, 0
	s_branch .LBB57_33
.LBB57_29:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s19
.LBB57_30:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s18
.LBB57_31:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
.LBB57_32:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_add_co_i32 s15, s15, 4
	v_add_co_u32 v79, vcc_lo, 0x800, v79
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v80, null, 0, v80, vcc_lo
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s15, v83
	v_add_co_u32 v77, s1, 0x800, v77
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v78, null, 0, v78, s1
	v_add_nc_u32_e32 v89, 0x1000, v89
	s_addk_co_i32 s14, 0x80
	s_or_b32 s8, vcc_lo, s8
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 exec_lo, exec_lo, s8
	s_cbranch_execz .LBB57_56
.LBB57_33:                              ; =>This Inner Loop Header: Depth=1
	s_wait_alu 0xfffe
	v_dual_mov_b32 v65, v81 :: v_dual_add_nc_u32 v90, s14, v81
	s_cmp_eq_u32 s14, 0
	s_cbranch_scc1 .LBB57_51
; %bb.34:                               ;   in Loop: Header=BB57_33 Depth=1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, s16, v90
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v34, 0
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v36, 0
	v_mov_b32_e32 v35, 0
	s_and_saveexec_b32 s17, vcc_lo
	s_cbranch_execz .LBB57_36
; %bb.35:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v33, s1, v77, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v34, null, 0, v78, s1
	global_load_b128 v[33:36], v[33:34], off th:TH_LOAD_NT
.LBB57_36:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0
	v_mov_b32_e32 v40, 0
	s_and_b32 s17, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s17
	s_cbranch_execz .LBB57_38
; %bb.37:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v37, vcc_lo, v79, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v38, null, 0, v80, vcc_lo
	global_load_b128 v[37:40], v[37:38], off th:TH_LOAD_NT
.LBB57_38:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v45, 0 :: v_dual_add_nc_u32 v44, 32, v90
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0
	v_mov_b32_e32 v43, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s16, v44
	v_mov_b32_e32 v44, 0
	s_and_saveexec_b32 s17, vcc_lo
	s_cbranch_execz .LBB57_40
; %bb.39:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v41, s1, v77, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v42, null, 0, v78, s1
	global_load_b128 v[41:44], v[41:42], off offset:512 th:TH_LOAD_NT
.LBB57_40:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0
	v_mov_b32_e32 v48, 0
	s_and_b32 s17, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s17
	s_cbranch_execz .LBB57_42
; %bb.41:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v45, vcc_lo, v79, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v46, null, 0, v80, vcc_lo
	global_load_b128 v[45:48], v[45:46], off offset:512 th:TH_LOAD_NT
.LBB57_42:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v53, 0 :: v_dual_add_nc_u32 v52, 64, v90
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0
	v_mov_b32_e32 v51, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s16, v52
	v_mov_b32_e32 v52, 0
	s_and_saveexec_b32 s17, vcc_lo
	s_cbranch_execz .LBB57_44
; %bb.43:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v49, s1, v77, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v50, null, 0, v78, s1
	global_load_b128 v[49:52], v[49:50], off offset:1024 th:TH_LOAD_NT
.LBB57_44:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v55, 0
	v_mov_b32_e32 v56, 0
	s_and_b32 s17, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s17
	s_cbranch_execz .LBB57_46
; %bb.45:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v53, vcc_lo, v79, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v54, null, 0, v80, vcc_lo
	global_load_b128 v[53:56], v[53:54], off offset:1024 th:TH_LOAD_NT
.LBB57_46:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_dual_mov_b32 v61, 0 :: v_dual_add_nc_u32 v60, 0x60, v90
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v58, 0
	v_mov_b32_e32 v59, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s16, v60
	v_mov_b32_e32 v60, 0
	s_and_saveexec_b32 s17, vcc_lo
	s_cbranch_execz .LBB57_48
; %bb.47:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v57, s1, v77, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v58, null, 0, v78, s1
	global_load_b128 v[57:60], v[57:58], off offset:1536 th:TH_LOAD_NT
.LBB57_48:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v63, 0
	v_mov_b32_e32 v64, 0
	s_and_b32 s17, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s17
	s_cbranch_execz .LBB57_50
; %bb.49:                               ;   in Loop: Header=BB57_33 Depth=1
	v_add_co_u32 v61, vcc_lo, v79, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v62, null, 0, v80, vcc_lo
	global_load_b128 v[61:64], v[61:62], off offset:1536 th:TH_LOAD_NT
.LBB57_50:                              ;   in Loop: Header=BB57_33 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	v_mov_b32_e32 v65, v90
.LBB57_51:                              ;   in Loop: Header=BB57_33 Depth=1
	s_mov_b32 s1, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s16, v65
	s_cbranch_execz .LBB57_32
; %bb.52:                               ;   in Loop: Header=BB57_33 Depth=1
	v_lshl_add_u32 v65, v65, 5, 0
	s_wait_loadcnt 0x0
	v_bfe_u32 v105, v33, 8, 3
	v_and_b32_e32 v118, 0x7f, v36
	v_and_b32_e32 v95, 7, v33
	v_bfe_u32 v109, v33, 16, 7
	ds_load_b128 v[91:94], v65
	ds_load_b128 v[65:68], v65 offset:16
	v_cvt_f32_ubyte0_e32 v105, v105
	v_lshl_add_u32 v119, v118, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v95, v95
	v_lshlrev_b32_e32 v108, 24, v33
	v_bfe_u32 v111, v34, 8, 7
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_bfe_u32 v112, v34, 16, 3
	v_mul_f32_e32 v95, 0x3b000000, v95
	v_bfe_u32 v116, v35, 8, 7
	v_bfe_u32 v121, v39, 8, 3
	s_mov_b32 s17, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v121, v121
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v103, 16, v91
	v_and_b32_e32 v102, 0xffff0000, v91
	v_lshlrev_b32_e32 v101, 16, v92
	v_and_b32_e32 v100, 0xffff0000, v92
	v_lshlrev_b32_e32 v99, 16, v93
	v_and_b32_e32 v98, 0xffff0000, v93
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v93, 16, v66
	v_and_b32_e32 v92, 0xffff0000, v66
	v_lshlrev_b32_e32 v91, 16, v67
	v_and_b32_e32 v66, 0xffff0000, v67
	v_bfe_u32 v67, v33, 8, 7
	v_lshlrev_b32_e32 v97, 16, v94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshl_add_u32 v107, v67, 20, 0x3c000000
	v_and_b32_e32 v104, 0x7f, v33
	v_lshl_add_u32 v96, v104, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v104
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v106, v95, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v106, vcc_lo
	v_bfe_u32 v106, v33, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v104, 0x80000000, v108, v104
	v_cvt_f32_ubyte0_e32 v106, v106
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshl_add_u32 v107, v109, 20, 0x3c000000
	v_bfe_u32 v108, v33, 24, 7
	v_mul_f32_e32 v106, 0x3b000000, v106
	v_fma_f32 v104, v104, v103, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v105, vcc_lo
	v_bfe_u32 v105, v33, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_lshl_add_u32 v110, v108, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v105, v105
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v106, v106, v107 :: v_dual_lshlrev_b32 v107, 16, v33
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_lshlrev_b32_e32 v109, 8, v33
	v_mul_f32_e32 v105, 0x3b000000, v105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v67, 0x80000000, v107, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	v_and_b32_e32 v107, 7, v34
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_and_or_b32 v106, 0x80000000, v109, v106
	v_and_b32_e32 v109, 0x7f, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v110, vcc_lo
	v_cvt_f32_ubyte0_e32 v107, v107
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_bfe_u32 v110, v34, 8, 3
	v_lshl_add_u32 v108, v109, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_fmac_f32 v104, v67, v102 :: v_dual_mul_f32 v107, 0x3b000000, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_cvt_f32_ubyte0_e32 v110, v110
	v_lshlrev_b32_e32 v95, 16, v65
	v_fmac_f32_e32 v104, v106, v101
	v_lshlrev_b32_e32 v106, 24, v36
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_lshl_add_u32 v108, v111, 20, 0x3c000000
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_bfe_u32 v109, v34, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v110, v108, vcc_lo
	v_cvt_f32_ubyte0_e32 v110, v112
	v_lshlrev_b32_e32 v112, 24, v34
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v111, v109, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_and_or_b32 v107, 0x80000000, v112, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_bfe_u32 v112, v34, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	s_delay_alu instid0(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v112, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v111, vcc_lo
	v_bfe_u32 v111, v34, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v114, v111, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_lshlrev_b32_e32 v110, 8, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v114, vcc_lo
	v_bfe_u32 v114, v35, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_and_or_b32 v109, 0x80000000, v110, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v112, vcc_lo
	v_cvt_f32_ubyte0_e32 v112, v114
	v_lshlrev_b32_e32 v113, 16, v34
	v_bfe_u32 v114, v35, 16, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v111, 0x80000000, v34, v111
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_and_or_b32 v108, 0x80000000, v113, v108
	v_and_b32_e32 v113, 7, v35
	v_cvt_f32_ubyte0_e32 v114, v114
	v_cvt_f32_ubyte0_e32 v110, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v114, 0x3b000000, v114
	v_and_b32_e32 v115, 0x7f, v35
	v_mul_f32_e32 v110, 0x3b000000, v110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v113, v115, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_bfe_u32 v115, v35, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v113, 24, v35
	v_lshlrev_b32_e32 v116, 16, v35
	v_and_or_b32 v105, 0x80000000, v33, v105
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_and_or_b32 v110, 0x80000000, v113, v110
	v_bfe_u32 v113, v35, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v116, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v114, v117, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_and_b32_e32 v115, 7, v36
	v_lshlrev_b32_e32 v116, 8, v35
	v_bfe_u32 v117, v35, 24, 7
	v_cvt_f32_ubyte0_e32 v113, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cvt_f32_ubyte0_e32 v115, v115
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_mul_f32_e32 v113, 0x3b000000, v113
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v114, 0x80000000, v116, v114
	v_lshl_add_u32 v116, v117, 20, 0x3c000000
	v_and_b32_e32 v96, 0xffff0000, v94
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v113, v116, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_bfe_u32 v116, v36, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v104, v105, v100 :: v_dual_cndmask_b32 v67, 0x7fc00000, v113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v104, v107, v99
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_bfe_u32 v107, v36, 16, 7
	v_and_or_b32 v67, 0x80000000, v35, v67
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v104, v108, v98 :: v_dual_cndmask_b32 v113, 0x7fc00000, v115
	v_bfe_u32 v115, v36, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v108, v107, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_fmac_f32_e32 v104, v109, v97
	v_and_or_b32 v105, 0x80000000, v106, v113
	v_cvt_f32_ubyte0_e32 v115, v115
	v_bfe_u32 v106, v36, 16, 3
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_bfe_u32 v109, v36, 24, 3
	v_fmac_f32_e32 v104, v111, v96
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v106, v106
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_cvt_f32_ubyte0_e32 v109, v109
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v106, 0x3b000000, v106 :: v_dual_cndmask_b32 v113, v115, v113
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_bfe_u32 v116, v38, 8, 7
	v_and_b32_e32 v115, 0x7f, v38
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_bfe_u32 v107, v36, 24, 7
	v_lshlrev_b32_e32 v108, 16, v36
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v111, v107, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_and_b32_e32 v94, 0xffff0000, v65
	v_and_or_b32 v108, 0x80000000, v108, v113
	v_lshlrev_b32_e32 v113, 16, v37
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_and_b32_e32 v111, 0x7f, v37
	v_dual_fmac_f32 v104, v110, v95 :: v_dual_lshlrev_b32 v65, 16, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v107, 0x7fc00000, v109 :: v_dual_lshlrev_b32 v110, 8, v36
	v_bfe_u32 v109, v37, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v106, 0x80000000, v110, v106
	v_and_b32_e32 v110, 7, v37
	v_cvt_f32_ubyte0_e32 v109, v109
	v_fmac_f32_e32 v104, v112, v94
	v_bfe_u32 v112, v37, 8, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v110, v110
	v_mul_f32_e32 v109, 0x3b000000, v109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v104, v114, v93
	v_mul_f32_e32 v110, 0x3b000000, v110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v104, v67, v92
	v_lshl_add_u32 v67, v111, 20, 0x3c000000
	v_fmac_f32_e32 v104, v105, v91
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v110, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v105, v112, 20, 0x3c000000
	v_bfe_u32 v110, v37, 16, 3
	v_lshlrev_b32_e32 v111, 24, v37
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v67, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_cvt_f32_ubyte0_e32 v110, v110
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v67, 0x80000000, v111, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v109, v105, vcc_lo
	v_bfe_u32 v109, v37, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_bfe_u32 v111, v37, 24, 3
	v_fma_f32 v67, v67, v103, 0
	v_lshl_add_u32 v112, v109, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_cvt_f32_ubyte0_e32 v111, v111
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v105, 0x80000000, v113, v105
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v112, vcc_lo
	v_bfe_u32 v112, v37, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_and_b32_e32 v113, 7, v38
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_fmac_f32_e32 v67, v105, v102
	v_lshl_add_u32 v114, v112, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_lshlrev_b32_e32 v110, 8, v37
	v_dual_fmac_f32 v104, v108, v66 :: v_dual_lshlrev_b32 v105, 8, v39
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v114, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_cvt_f32_ubyte0_e32 v110, v113
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_lshl_add_u32 v113, v115, 20, 0x3c000000
	v_bfe_u32 v114, v38, 8, 3
	v_dual_fmac_f32 v67, v109, v101 :: v_dual_mul_f32 v110, 0x3b000000, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_cvt_f32_ubyte0_e32 v112, v114
	v_bfe_u32 v114, v38, 16, 3
	v_dual_fmac_f32 v104, v106, v65 :: v_dual_and_b32 v109, 0x7f, v40
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_bfe_u32 v115, v38, 16, 7
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v112, v112, v113 :: v_dual_lshlrev_b32 v113, 24, v38
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v116, 16, v38
	v_and_or_b32 v111, 0x80000000, v37, v111
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v110, 0x80000000, v113, v110
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_bfe_u32 v113, v38, 24, 3
	v_fmac_f32_e32 v67, v111, v100
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v116, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v114, v117, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_and_b32_e32 v115, 7, v39
	v_bfe_u32 v116, v38, 24, 7
	v_cvt_f32_ubyte0_e32 v113, v113
	v_and_b32_e32 v117, 0x7f, v39
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cvt_f32_ubyte0_e32 v115, v115
	v_lshl_add_u32 v119, v116, 20, 0x3c000000
	v_mul_f32_e32 v113, 0x3b000000, v113
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v120, v117, 20, 0x3c000000
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_fmac_f32_e32 v67, v110, v99
	v_bfe_u32 v99, v40, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v113, v119, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_bfe_u32 v119, v39, 8, 7
	v_lshl_add_u32 v110, v109, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v118, 8, v38
	v_lshl_add_u32 v116, v119, 20, 0x3c000000
	v_mul_f32_e32 v120, 0x3b000000, v121
	v_bfe_u32 v121, v39, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v117, 24, v39
	v_and_or_b32 v114, 0x80000000, v118, v114
	v_bfe_u32 v118, v39, 24, 3
	v_lshl_add_u32 v103, v121, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	v_and_or_b32 v113, 0x80000000, v38, v113
	v_cvt_f32_ubyte0_e32 v118, v118
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v115, 0x80000000, v117, v115
	v_bfe_u32 v117, v39, 16, 3
	v_mul_f32_e32 v118, 0x3b000000, v118
	s_delay_alu instid0(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v117, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v120, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_bfe_u32 v119, v39, 16, 7
	v_mul_f32_e32 v117, 0x3b000000, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, 0x7fc00000, v116, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v122, v119, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, v117, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, v118, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v103, 0x7fc00000, v117 :: v_dual_lshlrev_b32 v120, 16, v39
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v121
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v103, 0x80000000, v105, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, 0x7fc00000, v102, vcc_lo
	v_and_b32_e32 v105, 7, v40
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_and_or_b32 v102, 0x80000000, v120, v116
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_and_or_b32 v100, 0x80000000, v39, v101
	v_bfe_u32 v101, v40, 8, 3
	v_cvt_f32_ubyte0_e32 v105, v105
	v_cvt_f32_ubyte0_e32 v101, v101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v105, 0x3b000000, v105
	v_mul_f32_e32 v101, 0x3b000000, v101
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v105, v105, v110, vcc_lo
	v_fmac_f32_e32 v67, v112, v98
	v_lshl_add_u32 v98, v99, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	v_fmac_f32_e32 v67, v114, v97
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v97, v101, v98, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v67, v113, v96 :: v_dual_cndmask_b32 v98, 0x7fc00000, v105
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	v_lshlrev_b32_e32 v101, 24, v40
	v_lshlrev_b32_e32 v99, 16, v40
	s_delay_alu instid0(VALU_DEP_4)
	v_fmac_f32_e32 v67, v115, v95
	v_bfe_u32 v95, v40, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, 0x7fc00000, v97, vcc_lo
	v_bfe_u32 v97, v40, 16, 3
	v_and_or_b32 v98, 0x80000000, v101, v98
	v_fmac_f32_e32 v67, v102, v94
	v_lshl_add_u32 v94, v95, 20, 0x3c000000
	v_and_or_b32 v96, 0x80000000, v99, v96
	v_cvt_f32_ubyte0_e32 v97, v97
	v_bfe_u32 v99, v40, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v95
	v_bfe_u32 v101, v40, 24, 7
	v_fmac_f32_e32 v67, v103, v93
	v_mul_f32_e32 v97, 0x3b000000, v97
	v_cvt_f32_ubyte0_e32 v99, v99
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v67, v100, v92
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v97, v94, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v95
	v_lshl_add_u32 v94, v101, 20, 0x3c000000
	v_mul_f32_e32 v97, 0x3b000000, v99
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v67, v98, v91 :: v_dual_cndmask_b32 v92, 0x7fc00000, v93
	v_cmp_lt_u32_e32 vcc_lo, 7, v101
	v_lshlrev_b32_e32 v93, 8, v40
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_fmac_f32 v67, v96, v66 :: v_dual_and_b32 v66, 0xffff0000, v68
	v_and_or_b32 v68, 0x80000000, v36, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, v97, v94, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v101
	v_and_or_b32 v91, 0x80000000, v93, v92
	v_fmac_f32_e32 v104, v68, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v92, 0x7fc00000, v94 :: v_dual_fmac_f32 v67, v91, v65
	v_dual_add_f32 v88, v88, v104 :: v_dual_add_nc_u32 v65, 32, v90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v92, 0x80000000, v40, v92
	v_fmac_f32_e32 v67, v92, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_add_f32_e32 v87, v87, v67
	v_cmpx_gt_i32_e64 s16, v65
	s_cbranch_execz .LBB57_31
; %bb.53:                               ;   in Loop: Header=BB57_33 Depth=1
	v_bfe_u32 v106, v41, 8, 3
	ds_load_b128 v[91:94], v89
	ds_load_b128 v[65:68], v89 offset:16
	v_bfe_u32 v109, v41, 16, 7
	v_lshlrev_b32_e32 v108, 24, v41
	v_bfe_u32 v111, v42, 8, 7
	v_cvt_f32_ubyte0_e32 v106, v106
	v_bfe_u32 v112, v42, 16, 3
	v_and_b32_e32 v115, 0x7f, v43
	v_bfe_u32 v116, v43, 8, 7
	v_bfe_u32 v121, v47, 8, 3
	v_mul_f32_e32 v106, 0x3b000000, v106
	v_and_b32_e32 v103, 0x7f, v41
	s_mov_b32 s18, exec_lo
	v_lshlrev_b32_e32 v113, 16, v42
	v_cvt_f32_ubyte0_e32 v121, v121
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v104, v103, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v103
	v_and_b32_e32 v95, 7, v41
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v100, 16, v92
	v_cvt_f32_ubyte0_e32 v95, v95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v105, 0x3b000000, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v105, v104, vcc_lo
	v_bfe_u32 v105, v41, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v103
	v_lshlrev_b32_e32 v102, 16, v91
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v104, vcc_lo
	v_bfe_u32 v104, v41, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_and_or_b32 v103, 0x80000000, v108, v103
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v104, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshlrev_b32_e32 v98, 16, v93
	v_lshl_add_u32 v107, v109, 20, 0x3c000000
	v_mul_f32_e32 v104, 0x3b000000, v104
	v_bfe_u32 v108, v41, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v106, vcc_lo
	v_bfe_u32 v106, v41, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_and_b32_e32 v99, 0xffff0000, v92
	v_lshl_add_u32 v110, v108, 20, 0x3c000000
	v_fma_f32 v103, v103, v102, 0
	v_cvt_f32_ubyte0_e32 v106, v106
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v104, v104, v107 :: v_dual_lshlrev_b32 v107, 16, v41
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v106, 0x3b000000, v106 :: v_dual_lshlrev_b32 v109, 8, v41
	v_and_or_b32 v105, 0x80000000, v107, v105
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v104, 0x7fc00000, v104 :: v_dual_and_b32 v107, 7, v42
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_and_b32_e32 v101, 0xffff0000, v91
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v104, 0x80000000, v109, v104
	v_and_b32_e32 v109, 0x7f, v42
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v110, vcc_lo
	v_cvt_f32_ubyte0_e32 v107, v107
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshlrev_b32_e32 v96, 16, v94
	v_bfe_u32 v110, v42, 8, 3
	v_lshl_add_u32 v108, v109, 20, 0x3c000000
	v_mul_f32_e32 v107, 0x3b000000, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v92, 16, v66
	v_cvt_f32_ubyte0_e32 v110, v110
	v_fmac_f32_e32 v103, v105, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_lshl_add_u32 v108, v111, 20, 0x3c000000
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_bfe_u32 v109, v42, 16, 7
	v_fmac_f32_e32 v103, v104, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_and_b32_e32 v97, 0xffff0000, v93
	v_lshlrev_b32_e32 v104, 24, v44
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v110, v108, vcc_lo
	v_cvt_f32_ubyte0_e32 v110, v112
	v_lshlrev_b32_e32 v112, 24, v42
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v111, v109, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_and_or_b32 v107, 0x80000000, v112, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_bfe_u32 v112, v42, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_and_b32_e32 v95, 0xffff0000, v94
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v108, 0x80000000, v113, v108
	v_cvt_f32_ubyte0_e32 v112, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v111, vcc_lo
	v_bfe_u32 v111, v42, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_and_b32_e32 v118, 0x7f, v44
	v_lshlrev_b32_e32 v94, 16, v65
	v_and_b32_e32 v113, 7, v43
	v_lshl_add_u32 v114, v111, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_lshl_add_u32 v119, v118, 20, 0x3c000000
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_cndmask_b32 v112, v112, v114 :: v_dual_and_b32 v93, 0xffff0000, v65
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshlrev_b32_e32 v110, 8, v42
	v_bfe_u32 v114, v43, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v112, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_cvt_f32_ubyte0_e32 v110, v113
	v_lshl_add_u32 v113, v115, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_cvt_f32_ubyte0_e32 v112, v114
	v_bfe_u32 v114, v43, 16, 3
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_and_b32_e32 v91, 0xffff0000, v66
	v_and_or_b32 v111, 0x80000000, v42, v111
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_bfe_u32 v115, v43, 16, 7
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_and_b32_e32 v65, 0xffff0000, v67
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v112, v112, v113 :: v_dual_lshlrev_b32 v113, 24, v43
	v_and_or_b32 v106, 0x80000000, v41, v106
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v116, 16, v43
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v110, 0x80000000, v113, v110
	v_bfe_u32 v113, v43, 24, 3
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v103, v106, v99 :: v_dual_cndmask_b32 v112, 0x7fc00000, v112
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_bfe_u32 v106, v44, 16, 3
	v_cvt_f32_ubyte0_e32 v113, v113
	v_lshlrev_b32_e32 v66, 16, v67
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v114, v114, v117 :: v_dual_lshlrev_b32 v67, 16, v68
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_fmac_f32_e32 v103, v107, v98
	v_and_or_b32 v112, 0x80000000, v116, v112
	v_and_b32_e32 v115, 7, v44
	v_lshlrev_b32_e32 v116, 8, v43
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v114, 0x7fc00000, v114 :: v_dual_fmac_f32 v103, v108, v97
	v_bfe_u32 v117, v43, 24, 7
	v_cvt_f32_ubyte0_e32 v115, v115
	v_mul_f32_e32 v113, 0x3b000000, v113
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v114, 0x80000000, v116, v114
	v_fmac_f32_e32 v103, v109, v96
	v_lshl_add_u32 v116, v117, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_cvt_f32_ubyte0_e32 v106, v106
	v_fmac_f32_e32 v103, v111, v95
	v_bfe_u32 v107, v44, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v113, v116, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_bfe_u32 v116, v44, 8, 7
	v_mul_f32_e32 v106, 0x3b000000, v106
	v_lshl_add_u32 v108, v107, 20, 0x3c000000
	v_bfe_u32 v109, v44, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_dual_fmac_f32 v103, v110, v94 :: v_dual_lshlrev_b32 v110, 8, v44
	v_cvt_f32_ubyte0_e32 v109, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_fmac_f32_e32 v103, v112, v93
	v_bfe_u32 v112, v45, 8, 7
	v_lshlrev_b32_e32 v118, 8, v46
	v_and_or_b32 v105, 0x80000000, v43, v105
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v115, vcc_lo
	v_bfe_u32 v115, v44, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_fmac_f32_e32 v103, v114, v92
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v104, 0x80000000, v104, v113
	v_cvt_f32_ubyte0_e32 v115, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v115, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_bfe_u32 v116, v46, 8, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_bfe_u32 v107, v44, 24, 7
	v_lshlrev_b32_e32 v108, 16, v44
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v111, v107, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_and_or_b32 v108, 0x80000000, v108, v113
	v_and_or_b32 v106, 0x80000000, v110, v106
	v_and_b32_e32 v110, 7, v45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v110, v110
	v_dual_mul_f32 v109, 0x3b000000, v109 :: v_dual_mul_f32 v110, 0x3b000000, v110
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v109, v109, v111, vcc_lo
	v_and_b32_e32 v111, 0x7f, v45
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v109, vcc_lo
	v_bfe_u32 v109, v45, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_fmac_f32_e32 v103, v105, v91
	v_lshl_add_u32 v105, v111, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v109, v109
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v103, v104, v66 :: v_dual_cndmask_b32 v104, v110, v105
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v105, v112, 20, 0x3c000000
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_bfe_u32 v110, v45, 16, 3
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v104, 0x7fc00000, v104 :: v_dual_lshlrev_b32 v111, 24, v45
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v110, v110
	v_and_or_b32 v104, 0x80000000, v111, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v109, v105, vcc_lo
	v_bfe_u32 v109, v45, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_bfe_u32 v111, v45, 24, 3
	v_fma_f32 v102, v104, v102, 0
	v_lshl_add_u32 v112, v109, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_cvt_f32_ubyte0_e32 v111, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v112, vcc_lo
	v_bfe_u32 v112, v45, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_mul_f32_e32 v111, 0x3b000000, v111
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v114, v112, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_lshlrev_b32_e32 v110, 8, v45
	v_fmac_f32_e32 v103, v108, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v114, vcc_lo
	v_bfe_u32 v114, v46, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_fmac_f32_e32 v103, v106, v67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v112, v114
	v_bfe_u32 v114, v46, 16, 3
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v114, v114
	v_lshlrev_b32_e32 v113, 16, v45
	v_and_b32_e32 v115, 0x7f, v46
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v105, 0x80000000, v113, v105
	v_and_b32_e32 v113, 7, v46
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_fmac_f32_e32 v102, v105, v101
	v_cvt_f32_ubyte0_e32 v110, v113
	v_lshl_add_u32 v113, v115, 20, 0x3c000000
	v_and_or_b32 v111, 0x80000000, v45, v111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v102, v109, v100 :: v_dual_lshlrev_b32 v105, 8, v47
	v_mul_f32_e32 v110, 0x3b000000, v110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v102, v111, v99 :: v_dual_and_b32 v109, 0x7f, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_bfe_u32 v115, v46, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v113, 24, v46
	v_lshlrev_b32_e32 v116, 16, v46
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_and_or_b32 v110, 0x80000000, v113, v110
	v_bfe_u32 v113, v46, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v116, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v114, v117, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_and_b32_e32 v115, 7, v47
	v_bfe_u32 v116, v46, 24, 7
	v_cvt_f32_ubyte0_e32 v113, v113
	v_and_b32_e32 v117, 0x7f, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cvt_f32_ubyte0_e32 v115, v115
	v_lshl_add_u32 v119, v116, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v120, v117, 20, 0x3c000000
	v_and_or_b32 v114, 0x80000000, v118, v114
	v_bfe_u32 v118, v47, 24, 3
	v_dual_mul_f32 v115, 0x3b000000, v115 :: v_dual_fmac_f32 v102, v110, v98
	v_bfe_u32 v98, v48, 8, 7
	v_lshl_add_u32 v110, v109, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v118, v118
	v_mul_f32_e32 v113, 0x3b000000, v113
	v_fmac_f32_e32 v102, v112, v97
	v_lshl_add_u32 v97, v98, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v118, 0x3b000000, v118 :: v_dual_cndmask_b32 v113, v113, v119
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_bfe_u32 v119, v47, 8, 7
	v_fmac_f32_e32 v102, v114, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshl_add_u32 v116, v119, 20, 0x3c000000
	v_mul_f32_e32 v120, 0x3b000000, v121
	v_bfe_u32 v121, v47, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v104, v121, 20, 0x3c000000
	v_and_or_b32 v113, 0x80000000, v46, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v102, v113, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v120, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_lshlrev_b32_e32 v117, 24, v47
	v_bfe_u32 v119, v47, 16, 7
	v_lshlrev_b32_e32 v120, 16, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, 0x7fc00000, v116, vcc_lo
	v_and_or_b32 v115, 0x80000000, v117, v115
	v_bfe_u32 v117, v47, 16, 3
	v_lshl_add_u32 v122, v119, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v102, v115, v94
	v_cvt_f32_ubyte0_e32 v117, v117
	v_bfe_u32 v94, v48, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v117, 0x3b000000, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, v117, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, v118, v104, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v117, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v104, 0x80000000, v105, v104
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v100, 0x7fc00000, v101 :: v_dual_and_b32 v105, 7, v48
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_and_or_b32 v101, 0x80000000, v120, v116
	v_and_or_b32 v99, 0x80000000, v47, v100
	v_bfe_u32 v100, v48, 8, 3
	v_cvt_f32_ubyte0_e32 v105, v105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v102, v101, v93
	v_lshl_add_u32 v93, v94, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v100, v100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v105, 0x3b000000, v105 :: v_dual_fmac_f32 v102, v104, v92
	s_wait_alu 0xfffd
	v_dual_mul_f32 v100, 0x3b000000, v100 :: v_dual_cndmask_b32 v105, v105, v110
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v96, v100, v97, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v97, 0x7fc00000, v105 :: v_dual_lshlrev_b32 v100, 24, v48
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_lshlrev_b32_e32 v98, 16, v48
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v97, 0x80000000, v100, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v96, vcc_lo
	v_bfe_u32 v96, v48, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v94
	v_bfe_u32 v100, v48, 24, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v95, 0x80000000, v98, v95
	v_cvt_f32_ubyte0_e32 v96, v96
	v_bfe_u32 v98, v48, 24, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v96, 0x3b000000, v96
	v_cvt_f32_ubyte0_e32 v98, v98
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v92, v96, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v94
	v_fmac_f32_e32 v102, v99, v91
	v_mul_f32_e32 v96, 0x3b000000, v98
	v_lshl_add_u32 v93, v100, 20, 0x3c000000
	v_fmac_f32_e32 v102, v97, v66
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v102, v95, v65 :: v_dual_and_b32 v65, 0xffff0000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v91, 0x7fc00000, v92, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v100
	v_lshlrev_b32_e32 v92, 8, v48
	v_and_or_b32 v68, 0x80000000, v44, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v96, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v100
	v_and_or_b32 v66, 0x80000000, v92, v91
	v_fmac_f32_e32 v103, v68, v65
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v91, 0x7fc00000, v93 :: v_dual_fmac_f32 v102, v66, v67
	v_and_or_b32 v91, 0x80000000, v48, v91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v102, v91, v65 :: v_dual_add_nc_u32 v65, 64, v90
	v_dual_add_f32 v88, v88, v103 :: v_dual_add_f32 v87, v87, v102
	s_delay_alu instid0(VALU_DEP_2)
	v_cmpx_gt_i32_e64 s16, v65
	s_cbranch_execz .LBB57_30
; %bb.54:                               ;   in Loop: Header=BB57_33 Depth=1
	v_bfe_u32 v106, v49, 8, 3
	ds_load_b128 v[91:94], v89 offset:1024
	ds_load_b128 v[65:68], v89 offset:1040
	v_bfe_u32 v109, v49, 16, 7
	v_lshlrev_b32_e32 v108, 24, v49
	v_bfe_u32 v111, v50, 8, 7
	v_cvt_f32_ubyte0_e32 v106, v106
	v_bfe_u32 v112, v50, 16, 3
	v_and_b32_e32 v115, 0x7f, v51
	v_bfe_u32 v116, v51, 8, 7
	v_bfe_u32 v121, v55, 8, 3
	v_mul_f32_e32 v106, 0x3b000000, v106
	v_and_b32_e32 v103, 0x7f, v49
	s_mov_b32 s19, exec_lo
	v_lshlrev_b32_e32 v113, 16, v50
	v_cvt_f32_ubyte0_e32 v121, v121
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v104, v103, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v103
	v_and_b32_e32 v95, 7, v49
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v100, 16, v92
	v_cvt_f32_ubyte0_e32 v95, v95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v105, 0x3b000000, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v105, v104, vcc_lo
	v_bfe_u32 v105, v49, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v103
	v_lshlrev_b32_e32 v102, 16, v91
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v107, v105, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v104, vcc_lo
	v_bfe_u32 v104, v49, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v105
	v_and_or_b32 v103, 0x80000000, v108, v103
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v104, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v105
	v_lshlrev_b32_e32 v98, 16, v93
	v_lshl_add_u32 v107, v109, 20, 0x3c000000
	v_mul_f32_e32 v104, 0x3b000000, v104
	v_bfe_u32 v108, v49, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v106, vcc_lo
	v_bfe_u32 v106, v49, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_and_b32_e32 v99, 0xffff0000, v92
	v_lshl_add_u32 v110, v108, 20, 0x3c000000
	v_fma_f32 v103, v103, v102, 0
	v_cvt_f32_ubyte0_e32 v106, v106
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v104, v104, v107 :: v_dual_lshlrev_b32 v107, 16, v49
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v106, 0x3b000000, v106 :: v_dual_lshlrev_b32 v109, 8, v49
	v_and_or_b32 v105, 0x80000000, v107, v105
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v104, 0x7fc00000, v104 :: v_dual_and_b32 v107, 7, v50
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_and_b32_e32 v101, 0xffff0000, v91
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v104, 0x80000000, v109, v104
	v_and_b32_e32 v109, 0x7f, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v110, vcc_lo
	v_cvt_f32_ubyte0_e32 v107, v107
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshlrev_b32_e32 v96, 16, v94
	v_bfe_u32 v110, v50, 8, 3
	v_lshl_add_u32 v108, v109, 20, 0x3c000000
	v_mul_f32_e32 v107, 0x3b000000, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v92, 16, v66
	v_cvt_f32_ubyte0_e32 v110, v110
	v_fmac_f32_e32 v103, v105, v101
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, v107, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_lshl_add_u32 v108, v111, 20, 0x3c000000
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_bfe_u32 v109, v50, 16, 7
	v_fmac_f32_e32 v103, v104, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_and_b32_e32 v97, 0xffff0000, v93
	v_lshlrev_b32_e32 v104, 24, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, v110, v108, vcc_lo
	v_cvt_f32_ubyte0_e32 v110, v112
	v_lshlrev_b32_e32 v112, 24, v50
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v111, v109, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_and_or_b32 v107, 0x80000000, v112, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v108, vcc_lo
	v_bfe_u32 v112, v50, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_and_b32_e32 v95, 0xffff0000, v94
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v108, 0x80000000, v113, v108
	v_cvt_f32_ubyte0_e32 v112, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v111, vcc_lo
	v_bfe_u32 v111, v50, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_and_b32_e32 v118, 0x7f, v52
	v_lshlrev_b32_e32 v94, 16, v65
	v_and_b32_e32 v113, 7, v51
	v_lshl_add_u32 v114, v111, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_lshl_add_u32 v119, v118, 20, 0x3c000000
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_cndmask_b32 v112, v112, v114 :: v_dual_and_b32 v93, 0xffff0000, v65
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshlrev_b32_e32 v110, 8, v50
	v_bfe_u32 v114, v51, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v112, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_cvt_f32_ubyte0_e32 v110, v113
	v_lshl_add_u32 v113, v115, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_cvt_f32_ubyte0_e32 v112, v114
	v_bfe_u32 v114, v51, 16, 3
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_and_b32_e32 v91, 0xffff0000, v66
	v_and_or_b32 v111, 0x80000000, v50, v111
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_cvt_f32_ubyte0_e32 v114, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_bfe_u32 v115, v51, 16, 7
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_and_b32_e32 v65, 0xffff0000, v67
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v112, v112, v113 :: v_dual_lshlrev_b32 v113, 24, v51
	v_and_or_b32 v106, 0x80000000, v49, v106
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v116, 16, v51
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v110, 0x80000000, v113, v110
	v_bfe_u32 v113, v51, 24, 3
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v103, v106, v99 :: v_dual_cndmask_b32 v112, 0x7fc00000, v112
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_bfe_u32 v106, v52, 16, 3
	v_cvt_f32_ubyte0_e32 v113, v113
	v_lshlrev_b32_e32 v66, 16, v67
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v114, v114, v117 :: v_dual_lshlrev_b32 v67, 16, v68
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_fmac_f32_e32 v103, v107, v98
	v_and_or_b32 v112, 0x80000000, v116, v112
	v_and_b32_e32 v115, 7, v52
	v_lshlrev_b32_e32 v116, 8, v51
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v114, 0x7fc00000, v114 :: v_dual_fmac_f32 v103, v108, v97
	v_bfe_u32 v117, v51, 24, 7
	v_cvt_f32_ubyte0_e32 v115, v115
	v_mul_f32_e32 v113, 0x3b000000, v113
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v114, 0x80000000, v116, v114
	v_fmac_f32_e32 v103, v109, v96
	v_lshl_add_u32 v116, v117, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_mul_f32_e32 v115, 0x3b000000, v115
	v_cvt_f32_ubyte0_e32 v106, v106
	v_fmac_f32_e32 v103, v111, v95
	v_bfe_u32 v107, v52, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v113, v116, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_bfe_u32 v116, v52, 8, 7
	v_mul_f32_e32 v106, 0x3b000000, v106
	v_lshl_add_u32 v108, v107, 20, 0x3c000000
	v_bfe_u32 v109, v52, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v119, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_dual_fmac_f32 v103, v110, v94 :: v_dual_lshlrev_b32 v110, 8, v52
	v_cvt_f32_ubyte0_e32 v109, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_fmac_f32_e32 v103, v112, v93
	v_bfe_u32 v112, v53, 8, 7
	v_lshlrev_b32_e32 v118, 8, v54
	v_and_or_b32 v105, 0x80000000, v51, v105
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v115, vcc_lo
	v_bfe_u32 v115, v52, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_fmac_f32_e32 v103, v114, v92
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v104, 0x80000000, v104, v113
	v_cvt_f32_ubyte0_e32 v115, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v115, 0x3b000000, v115
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v115, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_bfe_u32 v116, v54, 8, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v108, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_bfe_u32 v107, v52, 24, 7
	v_lshlrev_b32_e32 v108, 16, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v111, v107, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_and_or_b32 v108, 0x80000000, v108, v113
	v_and_or_b32 v106, 0x80000000, v110, v106
	v_and_b32_e32 v110, 7, v53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v110, v110
	v_dual_mul_f32 v109, 0x3b000000, v109 :: v_dual_mul_f32 v110, 0x3b000000, v110
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v109, v109, v111, vcc_lo
	v_and_b32_e32 v111, 0x7f, v53
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v109, vcc_lo
	v_bfe_u32 v109, v53, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_fmac_f32_e32 v103, v105, v91
	v_lshl_add_u32 v105, v111, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v109, v109
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v103, v104, v66 :: v_dual_cndmask_b32 v104, v110, v105
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_lshl_add_u32 v105, v112, 20, 0x3c000000
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_bfe_u32 v110, v53, 16, 3
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v104, 0x7fc00000, v104 :: v_dual_lshlrev_b32 v111, 24, v53
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v110, v110
	v_and_or_b32 v104, 0x80000000, v111, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v109, v105, vcc_lo
	v_bfe_u32 v109, v53, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_mul_f32_e32 v110, 0x3b000000, v110
	v_bfe_u32 v111, v53, 24, 3
	v_fma_f32 v102, v104, v102, 0
	v_lshl_add_u32 v112, v109, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_cvt_f32_ubyte0_e32 v111, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v112, vcc_lo
	v_bfe_u32 v112, v53, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	v_mul_f32_e32 v111, 0x3b000000, v111
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v114, v112, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v112
	v_lshlrev_b32_e32 v110, 8, v53
	v_fmac_f32_e32 v103, v108, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v114, vcc_lo
	v_bfe_u32 v114, v54, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v112
	v_and_or_b32 v109, 0x80000000, v110, v109
	v_fmac_f32_e32 v103, v106, v67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v112, v114
	v_bfe_u32 v114, v54, 16, 3
	v_mul_f32_e32 v112, 0x3b000000, v112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v114, v114
	v_lshlrev_b32_e32 v113, 16, v53
	v_and_b32_e32 v115, 0x7f, v54
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v105, 0x80000000, v113, v105
	v_and_b32_e32 v113, 7, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_fmac_f32_e32 v102, v105, v101
	v_cvt_f32_ubyte0_e32 v110, v113
	v_lshl_add_u32 v113, v115, 20, 0x3c000000
	v_and_or_b32 v111, 0x80000000, v53, v111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v102, v109, v100 :: v_dual_lshlrev_b32 v105, 8, v55
	v_mul_f32_e32 v110, 0x3b000000, v110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v102, v111, v99 :: v_dual_and_b32 v109, 0x7f, v56
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, v110, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v113, v116, 20, 0x3c000000
	v_bfe_u32 v115, v54, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v117, v115, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v113, 24, v54
	v_lshlrev_b32_e32 v116, 16, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_and_or_b32 v110, 0x80000000, v113, v110
	v_bfe_u32 v113, v54, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v116, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v114, v117, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_and_b32_e32 v115, 7, v55
	v_bfe_u32 v116, v54, 24, 7
	v_cvt_f32_ubyte0_e32 v113, v113
	v_and_b32_e32 v117, 0x7f, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cvt_f32_ubyte0_e32 v115, v115
	v_lshl_add_u32 v119, v116, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_lshl_add_u32 v120, v117, 20, 0x3c000000
	v_and_or_b32 v114, 0x80000000, v118, v114
	v_bfe_u32 v118, v55, 24, 3
	v_dual_mul_f32 v115, 0x3b000000, v115 :: v_dual_fmac_f32 v102, v110, v98
	v_bfe_u32 v98, v56, 8, 7
	v_lshl_add_u32 v110, v109, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v118, v118
	v_mul_f32_e32 v113, 0x3b000000, v113
	v_fmac_f32_e32 v102, v112, v97
	v_lshl_add_u32 v97, v98, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_mul_f32 v118, 0x3b000000, v118 :: v_dual_cndmask_b32 v113, v113, v119
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_bfe_u32 v119, v55, 8, 7
	v_fmac_f32_e32 v102, v114, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v115, v120, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshl_add_u32 v116, v119, 20, 0x3c000000
	v_mul_f32_e32 v120, 0x3b000000, v121
	v_bfe_u32 v121, v55, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v104, v121, 20, 0x3c000000
	v_and_or_b32 v113, 0x80000000, v54, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v102, v113, v95
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v120, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	v_lshlrev_b32_e32 v117, 24, v55
	v_bfe_u32 v119, v55, 16, 7
	v_lshlrev_b32_e32 v120, 16, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, 0x7fc00000, v116, vcc_lo
	v_and_or_b32 v115, 0x80000000, v117, v115
	v_bfe_u32 v117, v55, 16, 3
	v_lshl_add_u32 v122, v119, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v119
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v102, v115, v94
	v_cvt_f32_ubyte0_e32 v117, v117
	v_bfe_u32 v94, v56, 16, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v117, 0x3b000000, v117
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v117, v117, v122, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v121
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v101, v118, v104, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v119
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v117, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v104, 0x80000000, v105, v104
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v100, 0x7fc00000, v101 :: v_dual_and_b32 v105, 7, v56
	v_cmp_lt_u32_e32 vcc_lo, 7, v109
	v_and_or_b32 v101, 0x80000000, v120, v116
	v_and_or_b32 v99, 0x80000000, v55, v100
	v_bfe_u32 v100, v56, 8, 3
	v_cvt_f32_ubyte0_e32 v105, v105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v102, v101, v93
	v_lshl_add_u32 v93, v94, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v100, v100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v105, 0x3b000000, v105 :: v_dual_fmac_f32 v102, v104, v92
	s_wait_alu 0xfffd
	v_dual_mul_f32 v100, 0x3b000000, v100 :: v_dual_cndmask_b32 v105, v105, v110
	v_cmp_lt_u32_e32 vcc_lo, 7, v98
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v96, v100, v97, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v109
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v97, 0x7fc00000, v105 :: v_dual_lshlrev_b32 v100, 24, v56
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v98
	v_lshlrev_b32_e32 v98, 16, v56
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v97, 0x80000000, v100, v97
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v95, 0x7fc00000, v96, vcc_lo
	v_bfe_u32 v96, v56, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v94
	v_bfe_u32 v100, v56, 24, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v95, 0x80000000, v98, v95
	v_cvt_f32_ubyte0_e32 v96, v96
	v_bfe_u32 v98, v56, 24, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v96, 0x3b000000, v96
	v_cvt_f32_ubyte0_e32 v98, v98
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v92, v96, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v94
	v_fmac_f32_e32 v102, v99, v91
	v_mul_f32_e32 v96, 0x3b000000, v98
	v_lshl_add_u32 v93, v100, 20, 0x3c000000
	v_fmac_f32_e32 v102, v97, v66
	s_delay_alu instid0(VALU_DEP_1)
	v_dual_fmac_f32 v102, v95, v65 :: v_dual_and_b32 v65, 0xffff0000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v91, 0x7fc00000, v92, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v100
	v_lshlrev_b32_e32 v92, 8, v56
	v_and_or_b32 v68, 0x80000000, v52, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v93, v96, v93, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v100
	v_and_or_b32 v66, 0x80000000, v92, v91
	v_fmac_f32_e32 v103, v68, v65
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v91, 0x7fc00000, v93 :: v_dual_fmac_f32 v102, v66, v67
	v_and_or_b32 v91, 0x80000000, v56, v91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v102, v91, v65 :: v_dual_add_nc_u32 v65, 0x60, v90
	v_dual_add_f32 v88, v88, v103 :: v_dual_add_f32 v87, v87, v102
	s_delay_alu instid0(VALU_DEP_2)
	v_cmpx_gt_i32_e64 s16, v65
	s_cbranch_execz .LBB57_29
; %bb.55:                               ;   in Loop: Header=BB57_33 Depth=1
	v_bfe_u32 v105, v57, 8, 3
	ds_load_b128 v[90:93], v89 offset:2048
	ds_load_b128 v[65:68], v89 offset:2064
	v_bfe_u32 v108, v57, 16, 7
	v_lshlrev_b32_e32 v107, 24, v57
	v_bfe_u32 v110, v58, 8, 7
	v_cvt_f32_ubyte0_e32 v105, v105
	v_bfe_u32 v111, v58, 16, 3
	v_bfe_u32 v115, v59, 8, 7
	v_bfe_u32 v120, v63, 8, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v105, 0x3b000000, v105 :: v_dual_lshlrev_b32 v112, 16, v58
	v_and_b32_e32 v102, 0x7f, v57
	v_cvt_f32_ubyte0_e32 v120, v120
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v103, v102, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v102
	v_and_b32_e32 v94, 7, v57
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v99, 16, v91
	v_cvt_f32_ubyte0_e32 v94, v94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v104, 0x3b000000, v94
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, v104, v103, vcc_lo
	v_bfe_u32 v104, v57, 8, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v102
	v_lshlrev_b32_e32 v101, 16, v90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v106, v104, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v102, 0x7fc00000, v103, vcc_lo
	v_bfe_u32 v103, v57, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v104
	v_and_or_b32 v102, 0x80000000, v107, v102
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v103, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v106, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v104
	v_lshlrev_b32_e32 v97, 16, v92
	v_lshl_add_u32 v106, v108, 20, 0x3c000000
	v_mul_f32_e32 v103, 0x3b000000, v103
	v_bfe_u32 v107, v57, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v105, vcc_lo
	v_bfe_u32 v105, v57, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_and_b32_e32 v98, 0xffff0000, v91
	v_lshl_add_u32 v109, v107, 20, 0x3c000000
	v_fma_f32 v102, v102, v101, 0
	v_cvt_f32_ubyte0_e32 v105, v105
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v103, v103, v106 :: v_dual_lshlrev_b32 v106, 16, v57
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshlrev_b32_e32 v108, 8, v57
	v_mul_f32_e32 v105, 0x3b000000, v105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v104, 0x80000000, v106, v104
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v103, 0x7fc00000, v103 :: v_dual_and_b32 v106, 7, v58
	v_cmp_lt_u32_e32 vcc_lo, 7, v107
	v_and_b32_e32 v100, 0xffff0000, v90
	v_and_or_b32 v103, 0x80000000, v108, v103
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v105, v105, v109 :: v_dual_and_b32 v108, 0x7f, v58
	v_cvt_f32_ubyte0_e32 v106, v106
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v107
	v_lshlrev_b32_e32 v95, 16, v93
	v_bfe_u32 v109, v58, 8, 3
	v_lshl_add_u32 v107, v108, 20, 0x3c000000
	v_mul_f32_e32 v106, 0x3b000000, v106
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v91, 16, v66
	v_cvt_f32_ubyte0_e32 v109, v109
	v_fmac_f32_e32 v102, v104, v100
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, v106, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshl_add_u32 v107, v110, 20, 0x3c000000
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_bfe_u32 v108, v58, 16, 7
	v_fmac_f32_e32 v102, v103, v99
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v106, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v110
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v107, v109, v107 :: v_dual_and_b32 v96, 0xffff0000, v92
	v_cvt_f32_ubyte0_e32 v109, v111
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v110
	v_lshl_add_u32 v110, v108, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v109, 0x3b000000, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v107, 0x7fc00000, v107, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_and_b32_e32 v94, 0xffff0000, v93
	v_and_or_b32 v107, 0x80000000, v112, v107
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v110, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshlrev_b32_e32 v111, 24, v58
	v_bfe_u32 v110, v58, 24, 7
	v_and_b32_e32 v112, 7, v59
	v_and_or_b32 v105, 0x80000000, v57, v105
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v109, vcc_lo
	v_and_or_b32 v106, 0x80000000, v111, v106
	v_bfe_u32 v111, v58, 24, 3
	v_lshl_add_u32 v113, v110, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v110
	v_lshlrev_b32_e32 v109, 8, v58
	v_fmac_f32_e32 v102, v105, v98
	v_cvt_f32_ubyte0_e32 v111, v111
	v_bfe_u32 v105, v60, 16, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v108, 0x80000000, v109, v108
	v_cvt_f32_ubyte0_e32 v109, v112
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_and_b32_e32 v90, 0xffff0000, v66
	v_lshlrev_b32_e32 v66, 16, v67
	v_fmac_f32_e32 v102, v106, v97
	v_mul_f32_e32 v109, 0x3b000000, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v113, vcc_lo
	v_bfe_u32 v113, v59, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v110
	v_lshlrev_b32_e32 v93, 16, v65
	v_bfe_u32 v106, v60, 16, 7
	v_cvt_f32_ubyte0_e32 v105, v105
	v_fmac_f32_e32 v102, v107, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v111, vcc_lo
	v_cvt_f32_ubyte0_e32 v111, v113
	v_bfe_u32 v113, v59, 16, 3
	v_dual_fmac_f32 v102, v108, v95 :: v_dual_and_b32 v117, 0x7f, v60
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v110, 0x80000000, v58, v110
	v_mul_f32_e32 v111, 0x3b000000, v111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v113, v113
	v_lshl_add_u32 v118, v117, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v102, v110, v94 :: v_dual_lshlrev_b32 v103, 24, v60
	v_lshl_add_u32 v107, v106, 20, 0x3c000000
	v_mul_f32_e32 v113, 0x3b000000, v113
	v_and_b32_e32 v114, 0x7f, v59
	v_bfe_u32 v108, v60, 24, 3
	v_mul_f32_e32 v105, 0x3b000000, v105
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v112, v114, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	v_and_b32_e32 v92, 0xffff0000, v65
	v_cvt_f32_ubyte0_e32 v108, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v112, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_lshl_add_u32 v112, v115, 20, 0x3c000000
	v_bfe_u32 v114, v59, 16, 7
	v_mul_f32_e32 v108, 0x3b000000, v108
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_lshl_add_u32 v116, v114, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v112, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshlrev_b32_e32 v112, 24, v59
	v_lshlrev_b32_e32 v115, 16, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	v_and_or_b32 v109, 0x80000000, v112, v109
	v_bfe_u32 v112, v59, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v111, 0x80000000, v115, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v113, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_and_b32_e32 v114, 7, v60
	v_lshlrev_b32_e32 v115, 8, v59
	v_bfe_u32 v116, v59, 24, 7
	v_cvt_f32_ubyte0_e32 v112, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cvt_f32_ubyte0_e32 v114, v114
	v_fmac_f32_e32 v102, v109, v93
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_and_or_b32 v113, 0x80000000, v115, v113
	v_lshl_add_u32 v115, v116, 20, 0x3c000000
	v_mul_f32_e32 v114, 0x3b000000, v114
	v_fmac_f32_e32 v102, v111, v92
	v_bfe_u32 v111, v61, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v115, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v117
	v_and_b32_e32 v65, 0xffff0000, v67
	v_bfe_u32 v115, v60, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, v114, v118, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v112, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v117
	v_lshlrev_b32_e32 v67, 16, v68
	v_lshlrev_b32_e32 v117, 8, v62
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_and_or_b32 v104, 0x80000000, v59, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v114, vcc_lo
	v_bfe_u32 v114, v60, 8, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_and_or_b32 v103, 0x80000000, v103, v112
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v114, v114
	v_lshl_add_u32 v112, v115, 20, 0x3c000000
	v_mul_f32_e32 v114, 0x3b000000, v114
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e32 v112, v114, v112, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_and_b32_e32 v114, 0x7f, v62
	v_bfe_u32 v115, v62, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, v105, v107, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_bfe_u32 v106, v60, 24, 7
	v_lshlrev_b32_e32 v107, 16, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v105, 0x7fc00000, v105, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v110, v106, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v106
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v108, v108, v110 :: v_dual_lshlrev_b32 v109, 8, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_and_or_b32 v105, 0x80000000, v109, v105
	v_and_b32_e32 v109, 7, v61
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v106
	v_and_or_b32 v107, 0x80000000, v107, v112
	v_lshlrev_b32_e32 v112, 16, v61
	v_cvt_f32_ubyte0_e32 v109, v109
	v_fmac_f32_e32 v102, v113, v91
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v106, 0x7fc00000, v108, vcc_lo
	v_bfe_u32 v108, v61, 8, 3
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_and_b32_e32 v110, 0x7f, v61
	v_fmac_f32_e32 v102, v104, v90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v108, v108
	v_lshl_add_u32 v104, v110, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v110
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v102, v103, v66 :: v_dual_cndmask_b32 v103, v109, v104
	v_bfe_u32 v109, v61, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v110
	v_lshl_add_u32 v104, v111, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v109, v109
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v103, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v109, 0x3b000000, v109 :: v_dual_mul_f32 v108, 0x3b000000, v108
	v_fmac_f32_e32 v102, v107, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, v108, v104, vcc_lo
	v_bfe_u32 v108, v61, 16, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_fmac_f32_e32 v102, v105, v67
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v111, v108, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v104, 0x7fc00000, v104, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_and_or_b32 v104, 0x80000000, v112, v104
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v111, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_and_b32_e32 v112, 7, v62
	v_bfe_u32 v111, v61, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v108, 0x7fc00000, v109, vcc_lo
	v_lshlrev_b32_e32 v109, 8, v61
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v113, v111, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v111
	v_and_or_b32 v108, 0x80000000, v109, v108
	v_cvt_f32_ubyte0_e32 v109, v112
	v_lshl_add_u32 v112, v114, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v109, 0x3b000000, v109
	v_lshlrev_b32_e32 v110, 24, v61
	v_and_or_b32 v103, 0x80000000, v110, v103
	v_bfe_u32 v110, v61, 24, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fma_f32 v101, v103, v101, 0
	v_cvt_f32_ubyte0_e32 v110, v110
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v101, v104, v100 :: v_dual_mul_f32 v110, 0x3b000000, v110
	v_lshlrev_b32_e32 v104, 8, v63
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v101, v108, v99 :: v_dual_cndmask_b32 v110, v110, v113
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v111
	v_bfe_u32 v113, v62, 8, 3
	v_and_b32_e32 v108, 0x7f, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v110, 0x7fc00000, v110, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	v_cvt_f32_ubyte0_e32 v111, v113
	v_bfe_u32 v113, v62, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v109, v112, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_lshl_add_u32 v112, v115, 20, 0x3c000000
	v_mul_f32_e32 v111, 0x3b000000, v111
	v_bfe_u32 v114, v62, 16, 7
	v_cvt_f32_ubyte0_e32 v113, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, 0x7fc00000, v109, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_lshl_add_u32 v116, v114, 20, 0x3c000000
	v_mul_f32_e32 v113, 0x3b000000, v113
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, v111, v112, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshlrev_b32_e32 v112, 24, v62
	v_lshlrev_b32_e32 v115, 16, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v111, 0x7fc00000, v111, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v114
	v_and_or_b32 v109, 0x80000000, v112, v109
	v_bfe_u32 v112, v62, 24, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v111, 0x80000000, v115, v111
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, v113, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v114
	v_and_b32_e32 v114, 7, v63
	v_bfe_u32 v115, v62, 24, 7
	v_cvt_f32_ubyte0_e32 v112, v112
	v_and_b32_e32 v116, 0x7f, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v113, 0x7fc00000, v113, vcc_lo
	v_cvt_f32_ubyte0_e32 v114, v114
	v_lshl_add_u32 v118, v115, 20, 0x3c000000
	v_mul_f32_e32 v112, 0x3b000000, v112
	v_cmp_lt_u32_e32 vcc_lo, 7, v115
	v_and_or_b32 v113, 0x80000000, v117, v113
	v_bfe_u32 v117, v63, 24, 3
	v_lshl_add_u32 v119, v116, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, v112, v118, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v116
	v_cvt_f32_ubyte0_e32 v117, v117
	v_mul_f32_e32 v114, 0x3b000000, v114
	v_bfe_u32 v118, v63, 8, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v117, 0x3b000000, v117 :: v_dual_cndmask_b32 v114, v114, v119
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v115
	v_lshl_add_u32 v115, v118, 20, 0x3c000000
	v_mul_f32_e32 v119, 0x3b000000, v120
	v_bfe_u32 v120, v63, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v112, 0x7fc00000, v112, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v116
	v_lshlrev_b32_e32 v116, 24, v63
	v_lshl_add_u32 v103, v120, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v112, 0x80000000, v62, v112
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v114, 0x7fc00000, v114, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, v119, v115, vcc_lo
	v_lshlrev_b32_e32 v119, 16, v63
	v_and_or_b32 v110, 0x80000000, v61, v110
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	v_bfe_u32 v118, v63, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v101, v110, v98
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v115, 0x7fc00000, v115, vcc_lo
	v_lshl_add_u32 v121, v118, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v118
	v_fmac_f32_e32 v101, v109, v97
	v_bfe_u32 v97, v64, 8, 7
	v_lshl_add_u32 v109, v108, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v101, v111, v96
	v_lshl_add_u32 v96, v97, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v101, v113, v95
	v_and_or_b32 v114, 0x80000000, v116, v114
	v_bfe_u32 v116, v63, 16, 3
	v_fmac_f32_e32 v101, v112, v94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v116, v116
	v_fmac_f32_e32 v101, v114, v93
	v_bfe_u32 v93, v64, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v116, 0x3b000000, v116
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v116, v116, v121, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v120
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v100, v117, v103, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v118
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v103, 0x7fc00000, v116, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v120
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v103, 0x80000000, v104, v103
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v99, 0x7fc00000, v100, vcc_lo
	v_and_b32_e32 v104, 7, v64
	v_cmp_lt_u32_e32 vcc_lo, 7, v108
	v_and_or_b32 v100, 0x80000000, v119, v115
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v98, 0x80000000, v63, v99
	v_bfe_u32 v99, v64, 8, 3
	v_cvt_f32_ubyte0_e32 v104, v104
	v_fmac_f32_e32 v101, v100, v92
	v_lshl_add_u32 v92, v93, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v99, v99
	v_dual_mul_f32 v104, 0x3b000000, v104 :: v_dual_fmac_f32 v101, v103, v91
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v99, 0x3b000000, v99 :: v_dual_cndmask_b32 v104, v104, v109
	v_cmp_lt_u32_e32 vcc_lo, 7, v97
	v_fmac_f32_e32 v101, v98, v90
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v95, v99, v96, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v108
	v_lshlrev_b32_e32 v99, 24, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v96, 0x7fc00000, v104, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v97
	v_lshlrev_b32_e32 v97, 16, v64
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v96, 0x80000000, v99, v96
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v94, 0x7fc00000, v95, vcc_lo
	v_bfe_u32 v95, v64, 16, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v93
	v_bfe_u32 v99, v64, 24, 7
	v_fmac_f32_e32 v101, v96, v66
	v_and_or_b32 v94, 0x80000000, v97, v94
	v_cvt_f32_ubyte0_e32 v95, v95
	v_bfe_u32 v97, v64, 24, 3
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v101, v94, v65
	v_and_b32_e32 v65, 0xffff0000, v68
	v_and_or_b32 v68, 0x80000000, v60, v106
	v_mul_f32_e32 v95, 0x3b000000, v95
	v_cvt_f32_ubyte0_e32 v97, v97
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v102, v68, v65 :: v_dual_cndmask_b32 v91, v95, v92
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v93
	v_lshl_add_u32 v92, v99, 20, 0x3c000000
	v_dual_mul_f32 v95, 0x3b000000, v97 :: v_dual_add_f32 v88, v88, v102
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v90, 0x7fc00000, v91 :: v_dual_lshlrev_b32 v91, 8, v64
	v_cmp_lt_u32_e32 vcc_lo, 7, v99
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_and_or_b32 v66, 0x80000000, v91, v90
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v92, v95, v92, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v99
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v101, v66, v67 :: v_dual_cndmask_b32 v90, 0x7fc00000, v92
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v90, 0x80000000, v64, v90
	v_fmac_f32_e32 v101, v90, v65
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v87, v87, v101
	s_branch .LBB57_29
.LBB57_56:
	s_or_b32 exec_lo, exec_lo, s8
.LBB57_57:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v33, -1, 0
	v_cmp_gt_i64_e64 s7, s[10:11], v[71:72]
	v_cmp_eq_u32_e64 s1, 0, v81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v34, 16, v33
	v_xor_b32_e32 v36, 8, v33
	v_xor_b32_e32 v37, 4, v33
	s_and_b32 s1, s1, s7
	v_cmp_gt_i32_e32 vcc_lo, 32, v34
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v34, v33, v34, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v36
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v36, v33, v36, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v37
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v37, v33, v37 :: v_dual_lshlrev_b32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v37
	v_lshlrev_b32_e32 v35, 2, v34
	ds_bpermute_b32 v34, v35, v88
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v88, v34
	ds_bpermute_b32 v38, v36, v34
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v38
	v_xor_b32_e32 v38, 2, v33
	ds_bpermute_b32 v39, v37, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v38
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v38, v33, v38, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v38, 2, v38
	s_wait_dscnt 0x0
	v_add_f32_e32 v34, v34, v39
	v_xor_b32_e32 v39, 1, v33
	ds_bpermute_b32 v40, v38, v34
	v_cmp_gt_i32_e32 vcc_lo, 32, v39
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v33, v33, v39, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v81
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_dual_add_f32 v40, v34, v40 :: v_dual_lshlrev_b32 v39, 2, v33
	v_lshlrev_b64_e32 v[33:34], 1, v[71:72]
	ds_bpermute_b32 v41, v39, v40
	v_add_co_u32 v33, s8, s12, v33
	v_add_co_ci_u32_e64 v34, null, s13, v34, s8
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s7, s1
	s_cbranch_execz .LBB57_63
; %bb.58:
	s_wait_dscnt 0x0
	v_add_f32_e32 v40, v40, v41
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v41, s9, v40
	v_and_b32_e32 v40, 0x7fffffff, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e64 s1, 0x7f800001, v40
                                        ; implicit-def: $vgpr40
	s_and_saveexec_b32 s8, s1
	s_wait_alu 0xfffe
	s_xor_b32 s1, exec_lo, s8
; %bb.59:
	v_bfe_u32 v40, v41, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v40, v41, v40, 0x7fff
                                        ; implicit-def: $vgpr41
	v_lshrrev_b32_e32 v40, 16, v40
; %bb.60:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s1, s1
; %bb.61:
	v_lshrrev_b32_e32 v40, 16, v41
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v40, 64, v40
; %bb.62:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	global_store_b16 v[33:34], v40, off
.LBB57_63:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	ds_bpermute_b32 v35, v35, v87
	v_cmp_gt_i64_e64 s1, s[10:11], v[69:70]
	s_xor_b32 s7, vcc_lo, -1
	s_wait_alu 0xfffe
	s_and_b32 s7, s7, s1
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v87, v35
	ds_bpermute_b32 v36, v36, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	ds_bpermute_b32 v36, v37, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	ds_bpermute_b32 v36, v38, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	ds_bpermute_b32 v36, v39, v35
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s7
	s_cbranch_execz .LBB57_69
; %bb.64:
	s_wait_dscnt 0x0
	v_add_f32_e32 v35, v35, v36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v36, s9, v35
	v_and_b32_e32 v35, 0x7fffffff, v36
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v35
                                        ; implicit-def: $vgpr35
	s_and_saveexec_b32 s7, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s7, exec_lo, s7
; %bb.65:
	v_bfe_u32 v35, v36, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v35, v36, v35, 0x7fff
                                        ; implicit-def: $vgpr36
	v_lshrrev_b32_e32 v35, 16, v35
; %bb.66:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s7, s7
; %bb.67:
	v_lshrrev_b32_e32 v35, 16, v36
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v35, 64, v35
; %bb.68:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	global_store_b16 v[33:34], v35, off offset:2
.LBB57_69:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	s_mov_b32 s1, 0
.LBB57_70:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s1
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB57_121
; %bb.71:
	v_mov_b32_e32 v35, 0
	v_mov_b32_e32 v33, 0
	s_and_saveexec_b32 s7, s0
	s_cbranch_execz .LBB57_109
; %bb.72:
	v_mov_b32_e32 v33, 0
	v_mov_b32_e32 v35, 0
	s_and_saveexec_b32 s0, s6
	s_cbranch_execz .LBB57_80
; %bb.73:
	v_lshl_add_u32 v37, v81, 5, 0
	v_perm_b32 v38, 0, v29, 0x10c000c
	v_perm_b32 v39, 0, v29, 0x30c020c
	v_perm_b32 v40, 0, v30, 0x10c000c
	v_perm_b32 v41, 0, v30, 0x30c020c
	s_wait_dscnt 0x0
	ds_load_b128 v[33:36], v37
	v_perm_b32 v42, 0, v31, 0x10c000c
	v_perm_b32 v43, 0, v31, 0x30c020c
	v_perm_b32 v44, 0, v32, 0x10c000c
	v_perm_b32 v45, 0, v32, 0x30c020c
	ds_load_b128 v[29:32], v37 offset:16
	v_lshrrev_b32_e32 v37, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_lshrrev_b32_e32 v48, 1, v39
	v_and_b32_e32 v39, 0x80008000, v39
	v_lshrrev_b32_e32 v49, 1, v40
	v_and_b32_e32 v40, 0x80008000, v40
	v_and_or_b32 v37, 0x3f803f80, v37, v38
	v_perm_b32 v46, 0, v21, 0x10c000c
	v_and_or_b32 v39, 0x3f803f80, v48, v39
	v_lshrrev_b32_e32 v38, 1, v41
	v_and_b32_e32 v41, 0x80008000, v41
	v_and_or_b32 v40, 0x3f803f80, v49, v40
	v_perm_b32 v21, 0, v21, 0x30c020c
	v_lshrrev_b32_e32 v50, 1, v42
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v37, v37, v33, 0
	v_and_b32_e32 v42, 0x80008000, v42
	v_lshrrev_b32_e32 v49, 1, v45
	v_and_or_b32 v38, 0x3f803f80, v38, v41
	v_lshrrev_b32_e32 v41, 1, v46
	v_dot2_f32_f16 v37, v39, v34, v37
	v_perm_b32 v47, 0, v22, 0x10c000c
	v_lshrrev_b32_e32 v39, 1, v44
	v_and_b32_e32 v44, 0x80008000, v44
	v_and_or_b32 v42, 0x3f803f80, v50, v42
	v_dot2_f32_f16 v37, v40, v35, v37
	v_and_b32_e32 v40, 0x80008000, v45
	v_and_b32_e32 v45, 0x80008000, v46
	v_and_or_b32 v39, 0x3f803f80, v39, v44
	v_and_b32_e32 v44, 0x80008000, v47
	v_dot2_f32_f16 v37, v38, v36, v37
	v_lshrrev_b32_e32 v38, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_and_or_b32 v41, 0x3f803f80, v41, v45
	v_perm_b32 v22, 0, v22, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v37, v42, v29, v37
	v_lshrrev_b32_e32 v42, 1, v47
	v_and_or_b32 v21, 0x3f803f80, v38, v21
	v_dot2_f32_f16 v33, v41, v33, 0
	v_perm_b32 v38, 0, v23, 0x10c000c
	v_perm_b32 v23, 0, v23, 0x30c020c
	v_and_or_b32 v41, 0x3f803f80, v42, v44
	v_lshrrev_b32_e32 v42, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_dot2_f32_f16 v21, v21, v34, v33
	v_lshrrev_b32_e32 v33, 1, v38
	v_and_b32_e32 v34, 0x80008000, v38
	v_lshrrev_b32_e32 v48, 1, v43
	v_and_or_b32 v22, 0x3f803f80, v42, v22
	v_dot2_f32_f16 v21, v41, v35, v21
	v_and_b32_e32 v43, 0x80008000, v43
	v_perm_b32 v35, 0, v24, 0x10c000c
	v_and_or_b32 v33, 0x3f803f80, v33, v34
	v_lshrrev_b32_e32 v34, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_dot2_f32_f16 v21, v22, v36, v21
	v_and_or_b32 v43, 0x3f803f80, v48, v43
	v_lshrrev_b32_e32 v22, 1, v35
	v_and_b32_e32 v35, 0x80008000, v35
	v_perm_b32 v24, 0, v24, 0x30c020c
	v_and_or_b32 v23, 0x3f803f80, v34, v23
	v_dot2_f32_f16 v21, v33, v29, v21
	v_dot2_f32_f16 v29, v43, v30, v37
	v_and_or_b32 v22, 0x3f803f80, v22, v35
	v_lshrrev_b32_e32 v33, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_dot2_f32_f16 v21, v23, v30, v21
	v_and_or_b32 v23, 0x3f803f80, v49, v40
	v_dot2_f32_f16 v29, v39, v31, v29
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v24, 0x3f803f80, v33, v24
	v_dot2_f32_f16 v21, v22, v31, v21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v23, v32, v29
	v_dot2_f32_f16 v33, v24, v32, v21
	s_and_saveexec_b32 s1, s5
	s_cbranch_execz .LBB57_79
; %bb.74:
	v_lshl_add_u32 v29, v86, 5, 0
	v_perm_b32 v30, 0, v25, 0x10c000c
	v_perm_b32 v31, 0, v25, 0x30c020c
	v_perm_b32 v32, 0, v26, 0x10c000c
	v_perm_b32 v34, 0, v26, 0x30c020c
	ds_load_b128 v[21:24], v29
	v_perm_b32 v36, 0, v27, 0x10c000c
	v_perm_b32 v37, 0, v27, 0x30c020c
	v_perm_b32 v38, 0, v28, 0x10c000c
	v_perm_b32 v39, 0, v28, 0x30c020c
	ds_load_b128 v[25:28], v29 offset:16
	v_lshrrev_b32_e32 v29, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_lshrrev_b32_e32 v42, 1, v31
	v_and_b32_e32 v31, 0x80008000, v31
	v_lshrrev_b32_e32 v43, 1, v32
	v_and_b32_e32 v32, 0x80008000, v32
	v_and_or_b32 v29, 0x3f803f80, v29, v30
	v_perm_b32 v40, 0, v13, 0x10c000c
	v_and_or_b32 v31, 0x3f803f80, v42, v31
	v_lshrrev_b32_e32 v30, 1, v34
	v_and_b32_e32 v34, 0x80008000, v34
	v_and_or_b32 v32, 0x3f803f80, v43, v32
	v_perm_b32 v13, 0, v13, 0x30c020c
	v_lshrrev_b32_e32 v44, 1, v36
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v29, v29, v21, v35
	v_and_b32_e32 v35, 0x80008000, v36
	v_lshrrev_b32_e32 v42, 1, v39
	v_and_or_b32 v30, 0x3f803f80, v30, v34
	v_lshrrev_b32_e32 v34, 1, v40
	v_dot2_f32_f16 v29, v31, v22, v29
	v_perm_b32 v41, 0, v14, 0x10c000c
	v_lshrrev_b32_e32 v36, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	v_and_or_b32 v35, 0x3f803f80, v44, v35
	v_dot2_f32_f16 v29, v32, v23, v29
	v_and_b32_e32 v32, 0x80008000, v39
	v_and_b32_e32 v39, 0x80008000, v40
	v_and_or_b32 v36, 0x3f803f80, v36, v37
	v_and_b32_e32 v37, 0x80008000, v41
	v_dot2_f32_f16 v29, v30, v24, v29
	v_lshrrev_b32_e32 v30, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	v_and_or_b32 v34, 0x3f803f80, v34, v39
	v_perm_b32 v14, 0, v14, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v29, v35, v25, v29
	v_lshrrev_b32_e32 v35, 1, v41
	v_and_or_b32 v13, 0x3f803f80, v30, v13
	v_dot2_f32_f16 v21, v34, v21, v33
	v_perm_b32 v30, 0, v15, 0x10c000c
	v_lshrrev_b32_e32 v34, 1, v14
	v_and_or_b32 v33, 0x3f803f80, v35, v37
	v_and_b32_e32 v14, 0x80008000, v14
	v_dot2_f32_f16 v13, v13, v22, v21
	v_lshrrev_b32_e32 v21, 1, v30
	v_and_b32_e32 v22, 0x80008000, v30
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v34, v14
	v_dot2_f32_f16 v13, v33, v23, v13
	v_perm_b32 v23, 0, v16, 0x10c000c
	v_and_or_b32 v21, 0x3f803f80, v21, v22
	v_lshrrev_b32_e32 v22, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v13, v14, v24, v13
	v_lshrrev_b32_e32 v31, 1, v38
	v_and_b32_e32 v38, 0x80008000, v38
	v_lshrrev_b32_e32 v14, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_and_or_b32 v15, 0x3f803f80, v22, v15
	v_dot2_f32_f16 v13, v21, v25, v13
	v_and_or_b32 v31, 0x3f803f80, v31, v38
	v_dot2_f32_f16 v21, v36, v26, v29
	v_and_or_b32 v14, 0x3f803f80, v14, v23
	v_lshrrev_b32_e32 v22, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_dot2_f32_f16 v13, v15, v26, v13
	v_and_or_b32 v15, 0x3f803f80, v42, v32
	v_dot2_f32_f16 v21, v31, v27, v21
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v16, 0x3f803f80, v22, v16
	v_dot2_f32_f16 v13, v14, v27, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v15, v28, v21
	v_dot2_f32_f16 v33, v16, v28, v13
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB57_78
; %bb.75:
	v_lshl_add_u32 v21, v85, 5, 0
	v_perm_b32 v22, 0, v17, 0x10c000c
	v_perm_b32 v23, 0, v17, 0x30c020c
	v_perm_b32 v24, 0, v18, 0x10c000c
	v_perm_b32 v25, 0, v18, 0x30c020c
	ds_load_b128 v[13:16], v21
	v_perm_b32 v26, 0, v19, 0x10c000c
	v_perm_b32 v27, 0, v19, 0x30c020c
	v_perm_b32 v28, 0, v20, 0x10c000c
	v_perm_b32 v29, 0, v20, 0x30c020c
	ds_load_b128 v[17:20], v21 offset:16
	v_lshrrev_b32_e32 v21, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_lshrrev_b32_e32 v32, 1, v23
	v_and_b32_e32 v23, 0x80008000, v23
	v_lshrrev_b32_e32 v34, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v21, 0x3f803f80, v21, v22
	v_perm_b32 v30, 0, v5, 0x10c000c
	v_and_or_b32 v23, 0x3f803f80, v32, v23
	v_lshrrev_b32_e32 v22, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_and_or_b32 v24, 0x3f803f80, v34, v24
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_lshrrev_b32_e32 v36, 1, v26
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v21, v21, v13, v35
	v_and_b32_e32 v26, 0x80008000, v26
	v_lshrrev_b32_e32 v34, 1, v29
	v_and_or_b32 v22, 0x3f803f80, v22, v25
	v_lshrrev_b32_e32 v25, 1, v30
	v_dot2_f32_f16 v21, v23, v14, v21
	v_perm_b32 v31, 0, v6, 0x10c000c
	v_lshrrev_b32_e32 v23, 1, v28
	v_and_b32_e32 v28, 0x80008000, v28
	v_and_or_b32 v26, 0x3f803f80, v36, v26
	v_dot2_f32_f16 v21, v24, v15, v21
	v_and_b32_e32 v24, 0x80008000, v29
	v_and_b32_e32 v29, 0x80008000, v30
	v_and_or_b32 v23, 0x3f803f80, v23, v28
	v_and_b32_e32 v28, 0x80008000, v31
	v_dot2_f32_f16 v21, v22, v16, v21
	v_lshrrev_b32_e32 v22, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_and_or_b32 v25, 0x3f803f80, v25, v29
	v_perm_b32 v6, 0, v6, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v21, v26, v17, v21
	v_lshrrev_b32_e32 v26, 1, v31
	v_and_or_b32 v5, 0x3f803f80, v22, v5
	v_dot2_f32_f16 v13, v25, v13, v33
	v_perm_b32 v22, 0, v7, 0x10c000c
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v25, 0x3f803f80, v26, v28
	v_lshrrev_b32_e32 v26, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v5, v5, v14, v13
	v_lshrrev_b32_e32 v13, 1, v22
	v_and_b32_e32 v14, 0x80008000, v22
	v_lshrrev_b32_e32 v32, 1, v27
	v_and_or_b32 v6, 0x3f803f80, v26, v6
	v_dot2_f32_f16 v5, v25, v15, v5
	v_and_b32_e32 v27, 0x80008000, v27
	v_perm_b32 v15, 0, v8, 0x10c000c
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v5, v6, v16, v5
	v_and_or_b32 v27, 0x3f803f80, v32, v27
	v_lshrrev_b32_e32 v6, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_and_or_b32 v7, 0x3f803f80, v14, v7
	v_dot2_f32_f16 v5, v13, v17, v5
	v_dot2_f32_f16 v13, v27, v18, v21
	v_and_or_b32 v6, 0x3f803f80, v6, v15
	v_lshrrev_b32_e32 v14, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_dot2_f32_f16 v5, v7, v18, v5
	v_and_or_b32 v7, 0x3f803f80, v34, v24
	v_dot2_f32_f16 v13, v23, v19, v13
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v8, 0x3f803f80, v14, v8
	v_dot2_f32_f16 v5, v6, v19, v5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v7, v20, v13
	v_dot2_f32_f16 v33, v8, v20, v5
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB57_77
; %bb.76:
	v_lshl_add_u32 v13, v84, 5, 0
	v_perm_b32 v14, 0, v9, 0x10c000c
	v_perm_b32 v15, 0, v9, 0x30c020c
	v_perm_b32 v16, 0, v10, 0x10c000c
	v_perm_b32 v17, 0, v10, 0x30c020c
	ds_load_b128 v[5:8], v13
	v_perm_b32 v18, 0, v11, 0x10c000c
	v_perm_b32 v19, 0, v11, 0x30c020c
	v_perm_b32 v20, 0, v12, 0x10c000c
	v_perm_b32 v21, 0, v12, 0x30c020c
	ds_load_b128 v[9:12], v13 offset:16
	v_lshrrev_b32_e32 v13, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_lshrrev_b32_e32 v24, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_lshrrev_b32_e32 v25, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_perm_b32 v22, 0, v1, 0x10c000c
	v_and_or_b32 v15, 0x3f803f80, v24, v15
	v_lshrrev_b32_e32 v14, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_and_or_b32 v16, 0x3f803f80, v25, v16
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_lshrrev_b32_e32 v26, 1, v18
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v13, v13, v5, v35
	v_and_b32_e32 v18, 0x80008000, v18
	v_lshrrev_b32_e32 v25, 1, v21
	v_and_or_b32 v14, 0x3f803f80, v14, v17
	v_lshrrev_b32_e32 v17, 1, v22
	v_dot2_f32_f16 v13, v15, v6, v13
	v_perm_b32 v23, 0, v2, 0x10c000c
	v_lshrrev_b32_e32 v15, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_and_or_b32 v18, 0x3f803f80, v26, v18
	v_dot2_f32_f16 v13, v16, v7, v13
	v_and_b32_e32 v16, 0x80008000, v21
	v_and_b32_e32 v21, 0x80008000, v22
	v_and_or_b32 v15, 0x3f803f80, v15, v20
	v_and_b32_e32 v20, 0x80008000, v23
	v_dot2_f32_f16 v13, v14, v8, v13
	v_lshrrev_b32_e32 v14, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_and_or_b32 v17, 0x3f803f80, v17, v21
	v_perm_b32 v2, 0, v2, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v13, v18, v9, v13
	v_lshrrev_b32_e32 v18, 1, v23
	v_and_or_b32 v1, 0x3f803f80, v14, v1
	v_dot2_f32_f16 v5, v17, v5, v33
	v_perm_b32 v14, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v17, 0x3f803f80, v18, v20
	v_lshrrev_b32_e32 v18, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_dot2_f32_f16 v1, v1, v6, v5
	v_lshrrev_b32_e32 v5, 1, v14
	v_and_b32_e32 v6, 0x80008000, v14
	v_lshrrev_b32_e32 v24, 1, v19
	v_and_or_b32 v2, 0x3f803f80, v18, v2
	v_dot2_f32_f16 v1, v17, v7, v1
	v_and_b32_e32 v19, 0x80008000, v19
	v_perm_b32 v7, 0, v4, 0x10c000c
	v_and_or_b32 v5, 0x3f803f80, v5, v6
	v_lshrrev_b32_e32 v6, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v1, v2, v8, v1
	v_and_or_b32 v19, 0x3f803f80, v24, v19
	v_lshrrev_b32_e32 v2, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v6, v3
	v_dot2_f32_f16 v1, v5, v9, v1
	v_dot2_f32_f16 v5, v19, v10, v13
	v_and_or_b32 v2, 0x3f803f80, v2, v7
	v_lshrrev_b32_e32 v6, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_dot2_f32_f16 v1, v3, v10, v1
	v_and_or_b32 v3, 0x3f803f80, v25, v16
	v_dot2_f32_f16 v5, v15, v11, v5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v4, 0x3f803f80, v6, v4
	v_dot2_f32_f16 v1, v2, v11, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v3, v12, v5
	v_dot2_f32_f16 v33, v4, v12, v1
.LBB57_77:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB57_78:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB57_79:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
.LBB57_80:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_mov_b32 s5, exec_lo
	v_cmpx_lt_u32_e32 0x9f, v0
	s_cbranch_execz .LBB57_108
; %bb.81:
	v_lshlrev_b32_e32 v0, 5, v81
	v_or_b32_e32 v34, 0xe0, v81
	s_mov_b32 s6, 0
	s_mov_b32 s8, 4
	s_delay_alu instid0(VALU_DEP_2)
	v_add3_u32 v32, v0, 0, 0x1000
	s_branch .LBB57_86
.LBB57_82:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
.LBB57_83:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
.LBB57_84:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB57_85:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	s_add_co_i32 s8, s8, 4
	v_add_co_u32 v73, vcc_lo, 0x800, v73
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v74, null, 0, v74, vcc_lo
	s_wait_alu 0xfffe
	v_cmp_ge_i32_e32 vcc_lo, s8, v83
	v_add_co_u32 v75, s0, 0x800, v75
	v_add_nc_u32_e32 v32, 0x1000, v32
	v_add_nc_u32_e32 v34, 0x80, v34
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v76, null, 0, v76, s0
	s_or_b32 s6, vcc_lo, s6
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s6
	s_cbranch_execz .LBB57_107
.LBB57_86:                              ; =>This Inner Loop Header: Depth=1
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v0, 0xffffffa0, v34
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v31, 0
	v_mov_b32_e32 v28, 0
	v_mov_b32_e32 v30, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_cmp_gt_i32_e64 s3, s16, v0
	s_and_saveexec_b32 s0, s3
	s_cbranch_execz .LBB57_88
; %bb.87:                               ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v0, vcc_lo, v75, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v76, vcc_lo
	global_load_b128 v[28:31], v[0:1], off offset:2048 th:TH_LOAD_NT
.LBB57_88:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0
	s_and_b32 s1, s2, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s1
	s_cbranch_execz .LBB57_90
; %bb.89:                               ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v0, vcc_lo, v73, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v74, vcc_lo
	global_load_b128 v[24:27], v[0:1], off offset:2048 th:TH_LOAD_NT
.LBB57_90:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_subrev_nc_u32_e32 v0, 64, v34
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v17, 0
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s1, s16, v0
	s_and_saveexec_b32 s0, s1
	s_cbranch_execz .LBB57_92
; %bb.91:                               ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v0, vcc_lo, v75, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v76, vcc_lo
	global_load_b128 v[16:19], v[0:1], off offset:2560 th:TH_LOAD_NT
.LBB57_92:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0
	s_and_b32 s4, s2, s1
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s0, s4
	s_cbranch_execz .LBB57_94
; %bb.93:                               ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v0, vcc_lo, v73, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v74, vcc_lo
	global_load_b128 v[20:23], v[0:1], off offset:2560 th:TH_LOAD_NT
.LBB57_94:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_subrev_nc_u32_e32 v0, 32, v34
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v9, 0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s0, s16, v0
	s_and_saveexec_b32 s4, s0
	s_cbranch_execz .LBB57_96
; %bb.95:                               ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v0, vcc_lo, v75, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v76, vcc_lo
	global_load_b128 v[8:11], v[0:1], off offset:3072 th:TH_LOAD_NT
.LBB57_96:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0
	s_and_b32 s14, s2, s0
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s14
	s_cbranch_execz .LBB57_98
; %bb.97:                               ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v0, vcc_lo, v73, v82
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v1, null, 0, v74, vcc_lo
	global_load_b128 v[12:15], v[0:1], off offset:3072 th:TH_LOAD_NT
.LBB57_98:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_cmp_gt_i32_e32 vcc_lo, s16, v34
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v5, 0
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0
	s_and_saveexec_b32 s14, vcc_lo
	s_cbranch_execz .LBB57_100
; %bb.99:                               ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v1, s4, v75, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v76, s4
	global_load_b128 v[4:7], v[1:2], off offset:3584 th:TH_LOAD_NT
.LBB57_100:                             ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0
	v_mov_b32_e32 v3, 0
	s_and_b32 s4, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s14, s4
	s_cbranch_execz .LBB57_102
; %bb.101:                              ;   in Loop: Header=BB57_86 Depth=1
	v_add_co_u32 v0, s4, v73, v82
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v1, null, 0, v74, s4
	global_load_b128 v[0:3], v[0:1], off offset:3584 th:TH_LOAD_NT
.LBB57_102:                             ;   in Loop: Header=BB57_86 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB57_85
; %bb.103:                              ;   in Loop: Header=BB57_86 Depth=1
	s_wait_dscnt 0x0
	ds_load_b128 v[36:39], v32
	ds_load_b128 v[40:43], v32 offset:16
	s_wait_loadcnt 0x0
	v_perm_b32 v44, 0, v28, 0x10c000c
	v_perm_b32 v28, 0, v28, 0x30c020c
	v_perm_b32 v45, 0, v29, 0x10c000c
	v_perm_b32 v29, 0, v29, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v46, 1, v44
	v_and_b32_e32 v44, 0x80008000, v44
	v_lshrrev_b32_e32 v47, 1, v28
	v_and_b32_e32 v28, 0x80008000, v28
	v_lshrrev_b32_e32 v48, 1, v45
	v_and_b32_e32 v45, 0x80008000, v45
	v_and_or_b32 v44, 0x3f803f80, v46, v44
	v_lshrrev_b32_e32 v49, 1, v29
	v_and_or_b32 v28, 0x3f803f80, v47, v28
	v_and_b32_e32 v29, 0x80008000, v29
	v_perm_b32 v46, 0, v30, 0x10c000c
	v_and_or_b32 v45, 0x3f803f80, v48, v45
	v_perm_b32 v30, 0, v30, 0x30c020c
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v35, v44, v36, v35
	v_and_or_b32 v29, 0x3f803f80, v49, v29
	v_lshrrev_b32_e32 v47, 1, v46
	v_and_b32_e32 v44, 0x80008000, v46
	v_perm_b32 v48, 0, v31, 0x10c000c
	v_dot2_f32_f16 v28, v28, v37, v35
	v_lshrrev_b32_e32 v46, 1, v30
	v_and_b32_e32 v30, 0x80008000, v30
	v_and_or_b32 v44, 0x3f803f80, v47, v44
	v_perm_b32 v47, 0, v25, 0x10c000c
	v_dot2_f32_f16 v28, v45, v38, v28
	v_perm_b32 v45, 0, v24, 0x10c000c
	v_perm_b32 v24, 0, v24, 0x30c020c
	v_perm_b32 v25, 0, v25, 0x30c020c
	v_lshrrev_b32_e32 v49, 1, v48
	v_dot2_f32_f16 v28, v29, v39, v28
	v_lshrrev_b32_e32 v29, 1, v45
	v_and_b32_e32 v45, 0x80008000, v45
	v_and_b32_e32 v35, 0x80008000, v48
	v_perm_b32 v31, 0, v31, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v28, v44, v40, v28
	v_lshrrev_b32_e32 v44, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v29, 0x3f803f80, v29, v45
	v_lshrrev_b32_e32 v45, 1, v47
	v_and_b32_e32 v47, 0x80008000, v47
	v_and_or_b32 v30, 0x3f803f80, v46, v30
	v_and_or_b32 v24, 0x3f803f80, v44, v24
	v_dot2_f32_f16 v29, v29, v36, v33
	v_perm_b32 v33, 0, v26, 0x10c000c
	v_and_or_b32 v36, 0x3f803f80, v45, v47
	v_lshrrev_b32_e32 v44, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_dot2_f32_f16 v24, v24, v37, v29
	v_lshrrev_b32_e32 v29, 1, v33
	v_and_b32_e32 v33, 0x80008000, v33
	v_perm_b32 v26, 0, v26, 0x30c020c
	v_and_or_b32 v25, 0x3f803f80, v44, v25
	v_dot2_f32_f16 v24, v36, v38, v24
	v_perm_b32 v36, 0, v27, 0x10c000c
	v_and_or_b32 v29, 0x3f803f80, v29, v33
	v_lshrrev_b32_e32 v33, 1, v26
	v_and_b32_e32 v26, 0x80008000, v26
	v_dot2_f32_f16 v24, v25, v39, v24
	v_lshrrev_b32_e32 v25, 1, v36
	v_and_b32_e32 v36, 0x80008000, v36
	v_perm_b32 v27, 0, v27, 0x30c020c
	v_and_or_b32 v26, 0x3f803f80, v33, v26
	v_dot2_f32_f16 v24, v29, v40, v24
	v_and_or_b32 v35, 0x3f803f80, v49, v35
	v_lshrrev_b32_e32 v46, 1, v31
	v_and_b32_e32 v31, 0x80008000, v31
	v_dot2_f32_f16 v28, v30, v41, v28
	v_and_or_b32 v25, 0x3f803f80, v25, v36
	v_lshrrev_b32_e32 v29, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_dot2_f32_f16 v24, v26, v41, v24
	v_and_or_b32 v26, 0x3f803f80, v46, v31
	v_dot2_f32_f16 v28, v35, v42, v28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v27, 0x3f803f80, v29, v27
	v_dot2_f32_f16 v24, v25, v42, v24
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v26, v43, v28
	v_dot2_f32_f16 v33, v27, v43, v24
	s_and_saveexec_b32 s3, s1
	s_cbranch_execz .LBB57_84
; %bb.104:                              ;   in Loop: Header=BB57_86 Depth=1
	ds_load_b128 v[24:27], v32 offset:1024
	ds_load_b128 v[28:31], v32 offset:1040
	v_perm_b32 v36, 0, v16, 0x10c000c
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_perm_b32 v37, 0, v17, 0x10c000c
	v_perm_b32 v17, 0, v17, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v38, 1, v36
	v_and_b32_e32 v36, 0x80008000, v36
	v_lshrrev_b32_e32 v39, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_lshrrev_b32_e32 v40, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	v_and_or_b32 v36, 0x3f803f80, v38, v36
	v_lshrrev_b32_e32 v41, 1, v17
	v_and_or_b32 v16, 0x3f803f80, v39, v16
	v_and_b32_e32 v17, 0x80008000, v17
	v_perm_b32 v38, 0, v18, 0x10c000c
	v_and_or_b32 v37, 0x3f803f80, v40, v37
	v_perm_b32 v18, 0, v18, 0x30c020c
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v35, v36, v24, v35
	v_and_or_b32 v17, 0x3f803f80, v41, v17
	v_lshrrev_b32_e32 v39, 1, v38
	v_and_b32_e32 v36, 0x80008000, v38
	v_perm_b32 v40, 0, v19, 0x10c000c
	v_dot2_f32_f16 v16, v16, v25, v35
	v_lshrrev_b32_e32 v38, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_and_or_b32 v36, 0x3f803f80, v39, v36
	v_perm_b32 v39, 0, v21, 0x10c000c
	v_dot2_f32_f16 v16, v37, v26, v16
	v_perm_b32 v37, 0, v20, 0x10c000c
	v_perm_b32 v21, 0, v21, 0x30c020c
	v_lshrrev_b32_e32 v41, 1, v40
	v_and_b32_e32 v35, 0x80008000, v40
	v_dot2_f32_f16 v16, v17, v27, v16
	v_perm_b32 v17, 0, v20, 0x30c020c
	v_lshrrev_b32_e32 v20, 1, v37
	v_and_b32_e32 v37, 0x80008000, v37
	v_perm_b32 v19, 0, v19, 0x30c020c
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v16, v36, v28, v16
	v_lshrrev_b32_e32 v36, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_and_or_b32 v20, 0x3f803f80, v20, v37
	v_lshrrev_b32_e32 v37, 1, v39
	v_and_b32_e32 v39, 0x80008000, v39
	v_and_or_b32 v18, 0x3f803f80, v38, v18
	v_and_or_b32 v17, 0x3f803f80, v36, v17
	v_dot2_f32_f16 v20, v20, v24, v33
	v_perm_b32 v24, 0, v22, 0x10c000c
	v_and_or_b32 v33, 0x3f803f80, v37, v39
	v_lshrrev_b32_e32 v36, 1, v21
	v_and_b32_e32 v21, 0x80008000, v21
	v_dot2_f32_f16 v17, v17, v25, v20
	v_lshrrev_b32_e32 v20, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_perm_b32 v22, 0, v22, 0x30c020c
	v_and_or_b32 v21, 0x3f803f80, v36, v21
	v_dot2_f32_f16 v17, v33, v26, v17
	v_perm_b32 v25, 0, v23, 0x10c000c
	v_and_or_b32 v20, 0x3f803f80, v20, v24
	v_lshrrev_b32_e32 v24, 1, v22
	v_and_b32_e32 v22, 0x80008000, v22
	v_dot2_f32_f16 v17, v21, v27, v17
	v_lshrrev_b32_e32 v21, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_perm_b32 v23, 0, v23, 0x30c020c
	v_and_or_b32 v22, 0x3f803f80, v24, v22
	v_dot2_f32_f16 v17, v20, v28, v17
	v_and_or_b32 v35, 0x3f803f80, v41, v35
	v_lshrrev_b32_e32 v38, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_dot2_f32_f16 v16, v18, v29, v16
	v_and_or_b32 v18, 0x3f803f80, v21, v25
	v_lshrrev_b32_e32 v20, 1, v23
	v_and_b32_e32 v21, 0x80008000, v23
	v_dot2_f32_f16 v17, v22, v29, v17
	v_and_or_b32 v19, 0x3f803f80, v38, v19
	v_dot2_f32_f16 v16, v35, v30, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v20, 0x3f803f80, v20, v21
	v_dot2_f32_f16 v17, v18, v30, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v19, v31, v16
	v_dot2_f32_f16 v33, v20, v31, v17
	s_and_saveexec_b32 s1, s0
	s_cbranch_execz .LBB57_83
; %bb.105:                              ;   in Loop: Header=BB57_86 Depth=1
	ds_load_b128 v[16:19], v32 offset:2048
	ds_load_b128 v[20:23], v32 offset:2064
	v_perm_b32 v24, 0, v8, 0x10c000c
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_perm_b32 v25, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v26, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_lshrrev_b32_e32 v27, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_lshrrev_b32_e32 v28, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_and_or_b32 v24, 0x3f803f80, v26, v24
	v_lshrrev_b32_e32 v29, 1, v9
	v_and_or_b32 v8, 0x3f803f80, v27, v8
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v26, 0, v10, 0x10c000c
	v_and_or_b32 v25, 0x3f803f80, v28, v25
	v_perm_b32 v28, 0, v11, 0x10c000c
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v24, v24, v16, v35
	v_and_or_b32 v9, 0x3f803f80, v29, v9
	v_lshrrev_b32_e32 v27, 1, v26
	v_and_b32_e32 v26, 0x80008000, v26
	v_lshrrev_b32_e32 v30, 1, v28
	v_dot2_f32_f16 v8, v8, v17, v24
	v_and_b32_e32 v24, 0x80008000, v28
	v_perm_b32 v28, 0, v13, 0x10c000c
	v_and_or_b32 v26, 0x3f803f80, v27, v26
	v_perm_b32 v13, 0, v13, 0x30c020c
	v_dot2_f32_f16 v8, v25, v18, v8
	v_perm_b32 v25, 0, v12, 0x10c000c
	v_perm_b32 v10, 0, v10, 0x30c020c
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_and_or_b32 v24, 0x3f803f80, v30, v24
	v_dot2_f32_f16 v8, v9, v19, v8
	v_perm_b32 v9, 0, v12, 0x30c020c
	v_lshrrev_b32_e32 v12, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_lshrrev_b32_e32 v29, 1, v10
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v8, v26, v20, v8
	v_lshrrev_b32_e32 v26, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_and_or_b32 v12, 0x3f803f80, v12, v25
	v_lshrrev_b32_e32 v25, 1, v28
	v_and_b32_e32 v28, 0x80008000, v28
	v_and_b32_e32 v10, 0x80008000, v10
	v_and_or_b32 v9, 0x3f803f80, v26, v9
	v_dot2_f32_f16 v12, v12, v16, v33
	v_perm_b32 v16, 0, v14, 0x10c000c
	v_and_or_b32 v25, 0x3f803f80, v25, v28
	v_lshrrev_b32_e32 v26, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	v_dot2_f32_f16 v9, v9, v17, v12
	v_lshrrev_b32_e32 v12, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_perm_b32 v14, 0, v14, 0x30c020c
	v_and_or_b32 v13, 0x3f803f80, v26, v13
	v_dot2_f32_f16 v9, v25, v18, v9
	v_perm_b32 v17, 0, v15, 0x10c000c
	v_and_or_b32 v12, 0x3f803f80, v12, v16
	v_lshrrev_b32_e32 v16, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_dot2_f32_f16 v9, v13, v19, v9
	v_and_or_b32 v10, 0x3f803f80, v29, v10
	v_lshrrev_b32_e32 v13, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v16, v14
	v_dot2_f32_f16 v9, v12, v20, v9
	v_lshrrev_b32_e32 v27, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_dot2_f32_f16 v8, v10, v21, v8
	v_and_or_b32 v10, 0x3f803f80, v13, v17
	v_lshrrev_b32_e32 v12, 1, v15
	v_and_b32_e32 v13, 0x80008000, v15
	v_dot2_f32_f16 v9, v14, v21, v9
	v_and_or_b32 v11, 0x3f803f80, v27, v11
	v_dot2_f32_f16 v8, v24, v22, v8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v12, 0x3f803f80, v12, v13
	v_dot2_f32_f16 v9, v10, v22, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v11, v23, v8
	v_dot2_f32_f16 v33, v12, v23, v9
	s_and_saveexec_b32 s0, vcc_lo
	s_cbranch_execz .LBB57_82
; %bb.106:                              ;   in Loop: Header=BB57_86 Depth=1
	ds_load_b128 v[8:11], v32 offset:3072
	ds_load_b128 v[12:15], v32 offset:3088
	v_perm_b32 v16, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v17, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4)
	v_lshrrev_b32_e32 v18, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	v_lshrrev_b32_e32 v19, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_lshrrev_b32_e32 v20, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_and_or_b32 v16, 0x3f803f80, v18, v16
	v_lshrrev_b32_e32 v21, 1, v5
	v_and_or_b32 v4, 0x3f803f80, v19, v4
	v_and_b32_e32 v5, 0x80008000, v5
	v_perm_b32 v18, 0, v6, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v20, v17
	v_perm_b32 v20, 0, v7, 0x10c000c
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v16, v16, v8, v35
	v_and_or_b32 v5, 0x3f803f80, v21, v5
	v_lshrrev_b32_e32 v19, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_lshrrev_b32_e32 v22, 1, v20
	v_dot2_f32_f16 v4, v4, v9, v16
	v_and_b32_e32 v16, 0x80008000, v20
	v_perm_b32 v20, 0, v1, 0x10c000c
	v_and_or_b32 v18, 0x3f803f80, v19, v18
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_dot2_f32_f16 v4, v17, v10, v4
	v_perm_b32 v17, 0, v0, 0x10c000c
	v_perm_b32 v0, 0, v0, 0x30c020c
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_dot2_f32_f16 v4, v5, v11, v4
	v_lshrrev_b32_e32 v5, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_lshrrev_b32_e32 v21, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v4, v18, v12, v4
	v_lshrrev_b32_e32 v18, 1, v0
	v_and_b32_e32 v0, 0x80008000, v0
	v_and_or_b32 v5, 0x3f803f80, v5, v17
	v_lshrrev_b32_e32 v17, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_and_or_b32 v6, 0x3f803f80, v21, v6
	v_and_or_b32 v0, 0x3f803f80, v18, v0
	v_dot2_f32_f16 v5, v5, v8, v33
	v_perm_b32 v8, 0, v2, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v17, v20
	v_lshrrev_b32_e32 v18, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_dot2_f32_f16 v0, v0, v9, v5
	v_lshrrev_b32_e32 v5, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v2, 0, v2, 0x30c020c
	v_and_or_b32 v1, 0x3f803f80, v18, v1
	v_dot2_f32_f16 v0, v17, v10, v0
	v_perm_b32 v9, 0, v3, 0x10c000c
	v_and_or_b32 v5, 0x3f803f80, v5, v8
	v_lshrrev_b32_e32 v8, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_dot2_f32_f16 v0, v1, v11, v0
	v_lshrrev_b32_e32 v1, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v2, 0x3f803f80, v8, v2
	v_dot2_f32_f16 v0, v5, v12, v0
	v_and_or_b32 v16, 0x3f803f80, v22, v16
	v_lshrrev_b32_e32 v19, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v4, v6, v13, v4
	v_and_or_b32 v1, 0x3f803f80, v1, v9
	v_lshrrev_b32_e32 v5, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v0, v2, v13, v0
	v_and_or_b32 v2, 0x3f803f80, v19, v7
	v_dot2_f32_f16 v4, v16, v14, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v3, 0x3f803f80, v5, v3
	v_dot2_f32_f16 v0, v1, v14, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v35, v2, v15, v4
	v_dot2_f32_f16 v33, v3, v15, v0
	s_branch .LBB57_82
.LBB57_107:
	s_or_b32 exec_lo, exec_lo, s6
.LBB57_108:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB57_109:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_wait_loadcnt 0x0
	v_mbcnt_lo_u32_b32 v0, -1, 0
	v_cmp_gt_i64_e64 s1, s[10:11], v[71:72]
	v_cmp_eq_u32_e64 s0, 0, v81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v1, 16, v0
	v_xor_b32_e32 v3, 8, v0
	v_xor_b32_e32 v4, 4, v0
	s_and_b32 s0, s0, s1
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v4, v0, v4 :: v_dual_lshlrev_b32 v3, 2, v3
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v2, 2, v1
	ds_bpermute_b32 v1, v2, v35
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v35, v1
	ds_bpermute_b32 v5, v3, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v5
	v_xor_b32_e32 v5, 2, v0
	ds_bpermute_b32 v6, v4, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v5
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v5, 2, v5
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v6
	v_xor_b32_e32 v6, 1, v0
	ds_bpermute_b32 v7, v5, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0, v81
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_add_f32 v7, v1, v7 :: v_dual_lshlrev_b32 v6, 2, v0
	v_lshlrev_b64_e32 v[0:1], 1, v[71:72]
	ds_bpermute_b32 v8, v6, v7
	v_add_co_u32 v0, s2, s12, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v1, null, s13, v1, s2
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s1, s0
	s_cbranch_execz .LBB57_115
; %bb.110:
	s_wait_dscnt 0x0
	v_add_f32_e32 v7, v7, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v7, 0x47800000, v7
	v_mul_f32_e32 v8, s9, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v7, 0x7fffffff, v8
	v_cmp_gt_u32_e64 s0, 0x7f800001, v7
                                        ; implicit-def: $vgpr7
	s_and_saveexec_b32 s2, s0
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s2
; %bb.111:
	v_bfe_u32 v7, v8, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v7, v8, v7, 0x7fff
                                        ; implicit-def: $vgpr8
	v_lshrrev_b32_e32 v7, 16, v7
; %bb.112:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.113:
	v_lshrrev_b32_e32 v7, 16, v8
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v7, 64, v7
; %bb.114:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	global_store_b16 v[0:1], v7, off
.LBB57_115:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s1
	ds_bpermute_b32 v2, v2, v33
	v_cmp_gt_i64_e64 s0, s[10:11], v[69:70]
	s_xor_b32 s1, vcc_lo, -1
	s_wait_alu 0xfffe
	s_and_b32 s0, s1, s0
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v33, v2
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v5, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v6, v2
	s_wait_alu 0xfffe
	s_and_b32 exec_lo, exec_lo, s0
	s_cbranch_execz .LBB57_121
; %bb.116:
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v2, 0x47800000, v2
	v_mul_f32_e32 v3, s9, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v2, 0x7fffffff, v3
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v2
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.117:
	v_bfe_u32 v2, v3, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v2, v3, v2, 0x7fff
                                        ; implicit-def: $vgpr3
	v_lshrrev_b32_e32 v2, 16, v2
; %bb.118:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.119:
	v_lshrrev_b32_e32 v2, 16, v3
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v2, 64, v2
; %bb.120:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	global_store_b16 v[0:1], v2, off offset:2
.LBB57_121:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 296
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 123
		.amdhsa_next_free_sgpr 24
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 190
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,"axG",@progbits,_ZN12_GLOBAL__N_115fp8_gemv_kernelILi1ELi2E7ik_bf16Li2EEEvPKS1_PKhPKfPT1_ii,comdat
.Lfunc_end57:
