_ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii: ; @_ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii
; %bb.0:
	s_clause 0x2
	s_load_b32 s16, s[0:1], 0x20
	s_load_b64 s[14:15], s[0:1], 0x0
	s_load_b64 s[12:13], s[0:1], 0x40
	v_lshrrev_b32_e32 v38, 5, v0
	v_and_b32_e32 v37, 31, v0
	s_mov_b32 s18, ttmp9
	s_mov_b32 s19, 0
	s_wait_kmcnt 0x0
	s_add_co_i32 s2, s16, 7
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_ashr_i32 s3, s2, 31
	s_lshr_b32 s3, s3, 29
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	s_add_co_i32 s2, s2, s3
	s_mov_b32 s3, -1
	s_ashr_i32 s2, s2, 3
	s_cmp_ge_i32 ttmp9, s2
	s_cbranch_scc0 .LBB317_56
; %bb.1:
	s_ashr_i32 s3, s2, 31
	s_clause 0x1
	s_load_b128 s[8:11], s[0:1], 0x28
	s_load_b64 s[20:21], s[0:1], 0x38
	s_sub_nc_u64 s[2:3], s[18:19], s[2:3]
	s_ashr_i32 s5, s12, 31
	s_lshl_b64 s[2:3], s[2:3], 3
	s_mov_b32 s4, s12
	v_or_b32_e32 v33, s2, v38
	v_mov_b32_e32 v34, s3
	s_ashr_i32 s7, s13, 31
	v_or_b32_e32 v41, 32, v37
	s_lshr_b32 s2, s7, 28
	v_or_b32_e32 v40, 64, v37
	v_cmp_gt_i64_e64 s6, s[4:5], v[33:34]
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s13, s2
	v_or_b32_e32 v39, 0x60, v37
	s_wait_alu 0xfffe
	s_ashr_i32 s12, s2, 4
	s_mov_b32 s25, exec_lo
	v_cmp_gt_i32_e64 s5, s12, v37
	v_cndmask_b32_e64 v1, 0, v33, s6
	v_cndmask_b32_e64 v2, 0, s3, s6
	v_cmp_gt_i32_e64 s4, s12, v41
	v_cmp_gt_i32_e64 s3, s12, v40
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v3, 0, v37, s5
	v_mul_lo_u32 v4, v1, s7
	s_wait_kmcnt 0x0
	v_mad_co_u64_u32 v[35:36], null, v1, s13, s[8:9]
	v_mul_lo_u32 v1, v2, s13
	v_cmp_gt_i32_e64 s2, s12, v39
	v_cndmask_b32_e64 v2, 0, v41, s4
	v_cndmask_b32_e64 v5, 0, v40, s3
	v_lshlrev_b32_e32 v3, 4, v3
	s_lshr_b32 s7, s7, 29
	v_cndmask_b32_e64 v6, 0, v39, s2
	s_wait_alu 0xfffe
	s_add_co_i32 s7, s13, s7
	v_add3_u32 v36, v1, v36, v4
	v_lshlrev_b32_e32 v4, 4, v2
	v_lshlrev_b32_e32 v5, 4, v5
	v_add_co_u32 v1, vcc_lo, v35, v3
	v_lshlrev_b32_e32 v7, 4, v6
	v_add_co_ci_u32_e64 v2, null, 0, v36, vcc_lo
	v_add_co_u32 v3, vcc_lo, v35, v4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v36, vcc_lo
	v_add_co_u32 v5, vcc_lo, v35, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v36, vcc_lo
	v_add_co_u32 v17, vcc_lo, v35, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, 0, v36, vcc_lo
	s_clause 0x3
	global_load_b128 v[13:16], v[1:2], off th:TH_LOAD_NT
	global_load_b128 v[9:12], v[3:4], off th:TH_LOAD_NT
	global_load_b128 v[5:8], v[5:6], off th:TH_LOAD_NT
	global_load_b128 v[1:4], v[17:18], off th:TH_LOAD_NT
	s_load_b64 s[22:23], s[10:11], 0x0
	s_ashr_i32 s24, s7, 3
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s23, 0
	s_cselect_b32 s17, -1, 0
	s_cmp_ngt_f32 s23, 0
	s_cselect_b32 s11, -1, 0
	v_cmpx_gt_i32_e64 s24, v0
	s_cbranch_execz .LBB317_6
; %bb.2:
	s_load_b32 s7, s[0:1], 0x54
	v_lshlrev_b32_e32 v17, 4, v0
	v_mov_b32_e32 v23, v0
	s_mov_b32 s27, 0
	s_mov_b32 s29, 0xc3e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_add_co_u32 v18, s8, s14, v17
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v19, null, s15, 0, s8
	v_add_nc_u32_e32 v24, 0, v17
	v_add_co_u32 v21, vcc_lo, v18, 8
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	v_add_co_ci_u32_e64 v22, null, 0, v19, vcc_lo
	s_wait_kmcnt 0x0
	s_and_b32 s26, s7, 0xffff
	s_lshl_b32 s28, s26, 4
	s_branch .LBB317_4
.LBB317_3:                              ;   in Loop: Header=BB317_4 Depth=1
	v_add_nc_u32_e32 v23, s26, v23
	v_add_co_u32 v21, s7, v21, s28
	s_wait_loadcnt 0x0
	ds_store_b128 v24, v[17:20]
	v_add_nc_u32_e32 v24, s28, v24
	v_cmp_le_i32_e32 vcc_lo, s24, v23
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v22, null, 0, v22, s7
	s_or_b32 s27, vcc_lo, s27
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s27
	s_cbranch_execz .LBB317_6
.LBB317_4:                              ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[17:20], v[21:22], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s17
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_3
; %bb.5:                                ;   in Loop: Header=BB317_4 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v25, 16, v17
	v_and_b32_e32 v17, 0xffff0000, v17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_scale_f32 v26, null, s23, s23, v25
	v_div_scale_f32 v27, null, s23, s23, v17
	v_div_scale_f32 v47, s7, v17, s23, v17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v30, v26
	v_rcp_f32_e32 v31, v27
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_fma_f32 v45, -v26, v30, 1.0
	v_fma_f32 v46, -v27, v31, 1.0
	v_lshlrev_b32_e32 v28, 16, v18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v30, v45, v30 :: v_dual_fmac_f32 v31, v46, v31
	v_div_scale_f32 v32, null, s23, s23, v28
	v_div_scale_f32 v43, vcc_lo, v25, s23, v25
	v_lshlrev_b32_e32 v42, 16, v20
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_rcp_f32_e32 v44, v32
	v_div_scale_f32 v48, s8, v28, s23, v28
	v_mul_f32_e32 v49, v43, v30
	v_mul_f32_e32 v50, v47, v31
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v53, -v26, v49, v43
	v_and_b32_e32 v20, 0xffff0000, v20
	v_fma_f32 v46, -v32, v44, 1.0
	v_lshlrev_b32_e32 v29, 16, v19
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v49, v53, v30 :: v_dual_fmac_f32 v44, v46, v44
	v_and_b32_e32 v18, 0xffff0000, v18
	v_fma_f32 v46, -v27, v50, v47
	v_fma_f32 v26, -v26, v49, v43
	v_div_scale_f32 v51, null, s23, s23, v29
	v_mul_f32_e32 v53, v48, v44
	v_div_scale_f32 v45, null, s23, s23, v18
	s_wait_alu 0xfffd
	v_div_fmas_f32 v26, v26, v30, v49
	s_mov_b32 vcc_lo, s7
	v_fma_f32 v43, -v32, v53, v48
	v_rcp_f32_e32 v52, v45
	v_fmac_f32_e32 v50, v46, v31
	v_div_scale_f32 v54, s9, v18, s23, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v53, v43, v44
	v_rcp_f32_e32 v46, v51
	v_fma_f32 v27, -v27, v50, v47
	v_div_fixup_f32 v25, v26, s23, v25
	v_div_scale_f32 v49, null, s23, s23, v20
	s_delay_alu instid0(TRANS32_DEP_2)
	v_fma_f32 v55, -v45, v52, 1.0
	v_and_b32_e32 v19, 0xffff0000, v19
	s_wait_alu 0xfffe
	v_div_fmas_f32 v27, v27, v31, v50
	v_fma_f32 v31, -v32, v53, v48
	s_mov_b32 vcc_lo, s8
	v_fmac_f32_e32 v52, v55, v52
	v_div_scale_f32 v30, null, s23, s23, v19
	v_div_fixup_f32 v17, v27, s23, v17
	v_fma_f32 v26, -v51, v46, 1.0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v27, v54, v52
	v_rcp_f32_e32 v32, v30
	s_wait_alu 0xfffe
	v_div_fmas_f32 v31, v31, v44, v53
	v_div_scale_f32 v44, null, s23, s23, v42
	v_fma_f32 v43, -v45, v27, v54
	v_fmac_f32_e32 v46, v26, v46
	v_div_scale_f32 v26, s7, v29, s23, v29
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_rcp_f32_e32 v48, v44
	v_fmac_f32_e32 v27, v43, v52
	s_delay_alu instid0(TRANS32_DEP_2)
	v_fma_f32 v47, -v30, v32, 1.0
	v_rcp_f32_e32 v43, v49
	v_div_fixup_f32 v28, v31, s23, v28
	v_mul_f32_e32 v31, v26, v46
	v_fma_f32 v45, -v45, v27, v54
	v_fmac_f32_e32 v32, v47, v32
	v_div_scale_f32 v47, s8, v19, s23, v19
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fma_f32 v50, -v44, v48, 1.0
	v_fma_f32 v53, -v51, v31, v26
	s_mov_b32 vcc_lo, s9
	v_mul_f32_e32 v54, v47, v32
	v_fma_f32 v55, -v49, v43, 1.0
	v_fmac_f32_e32 v48, v50, v48
	v_div_scale_f32 v50, s10, v42, s23, v42
	s_wait_alu 0xfffe
	v_div_fmas_f32 v27, v45, v52, v27
	v_fmac_f32_e32 v31, v53, v46
	v_fma_f32 v45, -v30, v54, v47
	v_fmac_f32_e32 v43, v55, v43
	v_div_scale_f32 v53, s9, v20, s23, v20
	v_mul_f32_e32 v52, v50, v48
	v_fma_f32 v26, -v51, v31, v26
	v_fmac_f32_e32 v54, v45, v32
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v45, v53, v43
	s_mov_b32 vcc_lo, s7
	v_div_fixup_f32 v18, v27, s23, v18
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v26, v46, v31
	v_fma_f32 v27, -v44, v52, v50
	v_fma_f32 v31, -v49, v45, v53
	s_mov_b32 vcc_lo, s8
	v_med3_num_f32 v25, v25, s29, 0x43e00000
	v_med3_num_f32 v17, v17, s29, 0x43e00000
	v_fmac_f32_e32 v52, v27, v48
	v_fmac_f32_e32 v45, v31, v43
	v_fma_f32 v30, -v30, v54, v47
	v_div_fixup_f32 v26, v26, s23, v29
	v_med3_num_f32 v28, v28, s29, 0x43e00000
	v_med3_num_f32 v18, v18, s29, 0x43e00000
	s_wait_alu 0xfffe
	v_div_fmas_f32 v27, v30, v32, v54
	v_mov_b32_e32 v30, 0
	s_mov_b32 vcc_lo, s10
	v_med3_num_f32 v26, v26, s29, 0x43e00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fixup_f32 v19, v27, s23, v19
	v_cvt_pk_fp8_f32 v30, v25, v17
	v_mov_b32_e32 v17, 0
	v_fma_f32 v29, -v44, v52, v50
	v_fma_f32 v27, -v49, v45, v53
	v_med3_num_f32 v19, v19, s29, 0x43e00000
	v_cvt_pk_fp8_f32 v30, v28, v18 op_sel:[0,0,1]
	s_wait_alu 0xfffe
	v_div_fmas_f32 v29, v29, v48, v52
	s_mov_b32 vcc_lo, s9
	v_cvt_pk_fp8_f32 v17, v26, v19
	s_wait_alu 0xfffe
	v_div_fmas_f32 v27, v27, v43, v45
	v_perm_b32 v18, 0, v30, 0x10c000c
	v_div_fixup_f32 v29, v29, s23, v42
	v_perm_b32 v19, 0, v30, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fixup_f32 v20, v27, s23, v20
	v_med3_num_f32 v25, v29, s29, 0x43e00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshrrev_b32_e32 v26, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_med3_num_f32 v20, v20, s29, 0x43e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v17, v25, v20 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v20, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_perm_b32 v25, 0, v17, 0x10c000c
	v_perm_b32 v17, 0, v17, 0x30c020c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v27, 1, v25
	v_and_b32_e32 v25, 0x80008000, v25
	v_lshrrev_b32_e32 v28, 1, v17
	v_and_b32_e32 v29, 0x80008000, v17
	v_and_or_b32 v17, 0x3f803f80, v20, v18
	v_and_or_b32 v18, 0x3f803f80, v26, v19
	v_and_or_b32 v19, 0x3f803f80, v27, v25
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v20, 0x3f803f80, v28, v29
	s_branch .LBB317_3
.LBB317_6:
	s_or_b32 exec_lo, exec_lo, s25
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s7, s6
	s_cbranch_execz .LBB317_55
; %bb.7:
	s_and_b32 s6, s17, exec_lo
	s_cselect_b32 s6, s23, 1.0
	s_add_co_i32 s8, s12, 31
	s_wait_alu 0xfffe
	s_ashr_i32 s9, s8, 31
	s_wait_alu 0xfffe
	s_lshr_b32 s9, s9, 27
	s_wait_alu 0xfffe
	s_add_co_i32 s8, s8, s9
	s_wait_alu 0xfffe
	s_ashr_i32 s8, s8, 5
	s_wait_alu 0xfffe
	s_add_co_i32 s8, s8, 3
	s_wait_alu 0xfffe
	s_lshr_b32 s9, s8, 30
	s_wait_alu 0xfffe
	s_add_co_i32 s8, s8, s9
	s_wait_alu 0xfffe
	s_ashr_i32 s9, s8, 2
	s_cmp_gt_i32 s13, 15
	s_mul_f32 s8, s22, s6
	s_cselect_b32 s10, -1, 0
	s_and_b32 vcc_lo, exec_lo, s11
	v_cndmask_b32_e64 v17, 0, 1, s10
	s_mov_b32 s11, -1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_ne_u32_e64 s6, 1, v17
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB317_28
; %bb.8:
	v_mov_b32_e32 v42, 0
	s_and_b32 vcc_lo, exec_lo, s6
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_21
; %bb.9:
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v17, v13
	v_dual_mov_b32 v18, v14 :: v_dual_mov_b32 v19, v15
	v_dual_mov_b32 v20, v16 :: v_dual_mov_b32 v21, v9
	v_dual_mov_b32 v22, v10 :: v_dual_mov_b32 v23, v11
	v_dual_mov_b32 v24, v12 :: v_dual_mov_b32 v25, v5
	v_dual_mov_b32 v26, v6 :: v_dual_mov_b32 v27, v7
	v_dual_mov_b32 v28, v8 :: v_dual_mov_b32 v29, v1
	v_dual_mov_b32 v30, v2 :: v_dual_mov_b32 v31, v3
	v_mov_b32_e32 v32, v4
	s_max_i32 s6, s9, 1
	s_mov_b32 s11, 0
	s_wait_alu 0xfffe
	s_lshl_b32 s6, s6, 7
	s_branch .LBB317_14
.LBB317_10:                             ;   in Loop: Header=BB317_14 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s24
.LBB317_11:                             ;   in Loop: Header=BB317_14 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s23
.LBB317_12:                             ;   in Loop: Header=BB317_14 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s22
.LBB317_13:                             ;   in Loop: Header=BB317_14 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
	s_addk_co_i32 s11, 0x80
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s6, s11
	s_cbranch_scc0 .LBB317_21
.LBB317_14:                             ; =>This Inner Loop Header: Depth=1
	s_cmp_eq_u32 s11, 0
	s_mov_b32 s17, 0
	s_cbranch_scc1 .LBB317_16
; %bb.15:                               ;   in Loop: Header=BB317_14 Depth=1
	s_wait_loadcnt 0x3
	v_add_nc_u32_e32 v18, s11, v37
	s_mov_b32 s17, s11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_add_nc_u32_e32 v19, 32, v18
	v_cmp_gt_i32_e32 vcc_lo, s12, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, 0, v18, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s12, v19
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v19, 0, v19 :: v_dual_add_nc_u32 v20, 64, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, s12, v20
	s_wait_loadcnt 0x2
	v_add_nc_u32_e32 v22, 0x60, v18
	v_ashrrev_i32_e32 v18, 31, v17
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v21, 0, v20, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s12, v22
	v_ashrrev_i32_e32 v20, 31, v19
	v_lshlrev_b64_e32 v[17:18], 4, v[17:18]
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v23, 0, v22, vcc_lo
	v_lshlrev_b64_e32 v[19:20], 4, v[19:20]
	v_ashrrev_i32_e32 v22, 31, v21
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_add_co_u32 v17, vcc_lo, v35, v17
	v_ashrrev_i32_e32 v24, 31, v23
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, v36, v18, vcc_lo
	v_lshlrev_b64_e32 v[21:22], 4, v[21:22]
	s_wait_loadcnt 0x1
	v_add_co_u32 v25, vcc_lo, v35, v19
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, v36, v20, vcc_lo
	v_lshlrev_b64_e32 v[19:20], 4, v[23:24]
	v_add_co_u32 v27, vcc_lo, v35, v21
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v28, null, v36, v22, vcc_lo
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_u32 v29, vcc_lo, v35, v19
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v30, null, v36, v20, vcc_lo
	s_clause 0x3
	global_load_b128 v[17:20], v[17:18], off th:TH_LOAD_NT
	global_load_b128 v[21:24], v[25:26], off th:TH_LOAD_NT
	global_load_b128 v[25:28], v[27:28], off th:TH_LOAD_NT
	global_load_b128 v[29:32], v[29:30], off th:TH_LOAD_NT
.LBB317_16:                             ;   in Loop: Header=BB317_14 Depth=1
	s_wait_alu 0xfffe
	v_or_b32_e32 v43, s17, v37
	s_mov_b32 s17, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s12, v43
	s_cbranch_execz .LBB317_13
; %bb.17:                               ;   in Loop: Header=BB317_14 Depth=1
	v_lshl_add_u32 v48, v43, 5, 0
	s_wait_loadcnt 0x3
	v_bfe_u32 v54, v17, 8, 3
	v_bfe_u32 v55, v17, 8, 7
	v_bfe_u32 v64, v17, 16, 3
	v_bfe_u32 v68, v18, 8, 7
	ds_load_b128 v[44:47], v48
	ds_load_b128 v[48:51], v48 offset:16
	v_cvt_f32_ubyte0_e32 v54, v54
	v_bfe_u32 v73, v19, 8, 3
	s_mov_b32 s22, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v54, 0x3b000000, v54 :: v_dual_lshlrev_b32 v65, 16, v17
	v_and_b32_e32 v52, 7, v17
	v_cvt_f32_ubyte0_e32 v73, v73
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v52, v52
	s_wait_dscnt 0x1
	v_dual_mul_f32 v52, 0x3b000000, v52 :: v_dual_lshlrev_b32 v59, 16, v46
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v61, 16, v48
	v_and_b32_e32 v53, 0x7f, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v56, v53, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v52, v56, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v63, 16, v50
	v_lshl_add_u32 v56, v55, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v52, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, v54, v56, vcc_lo
	v_bfe_u32 v54, v17, 16, 7
	v_cvt_f32_ubyte0_e32 v56, v64
	v_lshlrev_b32_e32 v64, 24, v17
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_lshlrev_b32_e32 v60, 16, v47
	v_lshl_add_u32 v55, v54, 20, 0x3c000000
	v_mul_f32_e32 v56, 0x3b000000, v56
	v_and_or_b32 v52, 0x80000000, v64, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v53, vcc_lo
	v_bfe_u32 v64, v17, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_lshlrev_b32_e32 v58, 16, v45
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v53, 0x80000000, v65, v53
	v_cvt_f32_ubyte0_e32 v64, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v56, v55, vcc_lo
	v_bfe_u32 v56, v17, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_dual_mul_f32 v64, 0x3b000000, v64 :: v_dual_and_b32 v65, 7, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v66, v56, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v54, 0x7fc00000, v55 :: v_dual_lshlrev_b32 v55, 8, v17
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	v_and_b32_e32 v57, 0xffff0000, v44
	v_and_or_b32 v54, 0x80000000, v55, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v66, vcc_lo
	v_bfe_u32 v66, v18, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	v_cvt_f32_ubyte0_e32 v55, v65
	v_lshlrev_b32_e32 v62, 16, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, 0x7fc00000, v64, vcc_lo
	v_cvt_f32_ubyte0_e32 v64, v66
	v_bfe_u32 v66, v18, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v55, 0x3b000000, v55 :: v_dual_mul_f32 v64, 0x3b000000, v64
	v_cvt_f32_ubyte0_e32 v66, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v66, 0x3b000000, v66
	v_and_b32_e32 v67, 0x7f, v18
	v_lshl_add_u32 v65, v67, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v55, v55, v65 :: v_dual_and_b32 v46, 0xffff0000, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v44, 16, v44
	v_lshl_add_u32 v65, v68, 20, 0x3c000000
	v_bfe_u32 v67, v18, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, 0x7fc00000, v55, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v47, 0xffff0000, v47
	v_lshl_add_u32 v69, v67, 20, 0x3c000000
	v_fma_f32 v52, v52, v44, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v64, v64, v65 :: v_dual_lshlrev_b32 v65, 24, v18
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	v_lshlrev_b32_e32 v68, 16, v18
	v_fmac_f32_e32 v52, v53, v57
	v_and_or_b32 v56, 0x80000000, v17, v56
	v_and_or_b32 v55, 0x80000000, v65, v55
	v_bfe_u32 v65, v18, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_dual_fmac_f32 v52, v54, v58 :: v_dual_lshlrev_b32 v57, 8, v19
	v_cvt_f32_ubyte0_e32 v65, v65
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v64, 0x80000000, v68, v64
	v_bfe_u32 v68, v18, 24, 7
	v_mul_f32_e32 v65, 0x3b000000, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, v66, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_and_b32_e32 v67, 7, v19
	v_and_b32_e32 v69, 0x7f, v19
	v_lshl_add_u32 v71, v68, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v66, vcc_lo
	v_cvt_f32_ubyte0_e32 v67, v67
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v48, 0xffff0000, v48
	v_lshl_add_u32 v72, v69, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v67, 0x3b000000, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	v_and_b32_e32 v50, 0xffff0000, v50
	v_bfe_u32 v71, v19, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v67, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v68, v71, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	v_lshlrev_b32_e32 v70, 8, v18
	v_lshlrev_b32_e32 v69, 24, v19
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v65, 0x80000000, v18, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v67, vcc_lo
	v_and_or_b32 v66, 0x80000000, v70, v66
	v_bfe_u32 v70, v19, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v67, 0x80000000, v69, v67
	v_bfe_u32 v69, v19, 16, 3
	v_cvt_f32_ubyte0_e32 v70, v70
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v69, v69
	v_dual_mul_f32 v70, 0x3b000000, v70 :: v_dual_mul_f32 v69, 0x3b000000, v69
	v_mul_f32_e32 v72, 0x3b000000, v73
	v_and_b32_e32 v45, 0xffff0000, v45
	v_bfe_u32 v73, v19, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v68, v72, v68, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_bfe_u32 v71, v19, 16, 7
	v_lshl_add_u32 v44, v73, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, 0x7fc00000, v68, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v74, v71, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v69, v74, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v73
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v44, v70, v44 :: v_dual_and_b32 v49, 0xffff0000, v49
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v53, 0x7fc00000, v69 :: v_dual_lshlrev_b32 v72, 16, v19
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v73
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v54, 0x80000000, v72, v68
	v_and_or_b32 v53, 0x80000000, v57, v53
	v_and_b32_e32 v57, 7, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v44, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v57, v57
	v_and_or_b32 v44, 0x80000000, v19, v44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v57, 0x3b000000, v57
	v_fmac_f32_e32 v52, v56, v45
	v_bfe_u32 v45, v20, 8, 3
	v_cvt_f32_ubyte0_e32 v45, v45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v45, 0x3b000000, v45
	v_and_b32_e32 v56, 0x7f, v20
	v_lshl_add_u32 v58, v56, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v57, v57, v58 :: v_dual_fmac_f32 v52, v55, v59
	v_bfe_u32 v55, v20, 8, 7
	v_fmac_f32_e32 v52, v64, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v46, v55, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v52, v66, v60 :: v_dual_cndmask_b32 v45, v45, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v52, v65, v47
	v_bfe_u32 v47, v20, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v46, 0x7fc00000, v57, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_lshlrev_b32_e32 v55, 16, v20
	v_cvt_f32_ubyte0_e32 v47, v47
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v45, 0x7fc00000, v45 :: v_dual_lshlrev_b32 v56, 24, v20
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v47, 0x3b000000, v47
	v_and_or_b32 v46, 0x80000000, v56, v46
	v_bfe_u32 v56, v20, 16, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v45, 0x80000000, v55, v45
	v_bfe_u32 v55, v20, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v55, v55
	v_fmac_f32_e32 v52, v67, v61
	v_fmac_f32_e32 v52, v54, v48
	v_lshl_add_u32 v48, v56, 20, 0x3c000000
	v_bfe_u32 v54, v20, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v52, v53, v62 :: v_dual_cndmask_b32 v47, v47, v48
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	v_lshl_add_u32 v48, v54, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_mul_f32 v53, 0x3b000000, v55 :: v_dual_fmac_f32 v52, v44, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v47, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_lshlrev_b32_e32 v47, 8, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v53, v48, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v44, 0x80000000, v47, v44
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v47, 0x7fc00000, v48 :: v_dual_fmac_f32 v52, v46, v63
	v_lshlrev_b32_e32 v46, 16, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v47, 0x80000000, v20, v47
	v_dual_fmac_f32 v52, v45, v50 :: v_dual_and_b32 v45, 0xffff0000, v51
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v44, v46
	v_or_b32_e32 v44, 32, v43
	v_fmac_f32_e32 v52, v47, v45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add_f32_e32 v42, v42, v52
	v_cmpx_gt_i32_e64 s12, v44
	s_cbranch_execz .LBB317_12
; %bb.18:                               ;   in Loop: Header=BB317_14 Depth=1
	v_lshl_add_u32 v48, v44, 5, 0
	s_wait_loadcnt 0x2
	v_bfe_u32 v54, v21, 8, 3
	v_bfe_u32 v55, v21, 8, 7
	v_bfe_u32 v64, v21, 16, 3
	v_bfe_u32 v68, v22, 8, 7
	ds_load_b128 v[44:47], v48
	ds_load_b128 v[48:51], v48 offset:16
	v_cvt_f32_ubyte0_e32 v54, v54
	v_bfe_u32 v73, v23, 8, 3
	s_mov_b32 s23, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v54, 0x3b000000, v54 :: v_dual_lshlrev_b32 v65, 16, v21
	v_and_b32_e32 v52, 7, v21
	v_cvt_f32_ubyte0_e32 v73, v73
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v52, v52
	s_wait_dscnt 0x1
	v_dual_mul_f32 v52, 0x3b000000, v52 :: v_dual_lshlrev_b32 v59, 16, v46
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v61, 16, v48
	v_and_b32_e32 v53, 0x7f, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v56, v53, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v52, v56, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v63, 16, v50
	v_lshl_add_u32 v56, v55, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v52, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, v54, v56, vcc_lo
	v_bfe_u32 v54, v21, 16, 7
	v_cvt_f32_ubyte0_e32 v56, v64
	v_lshlrev_b32_e32 v64, 24, v21
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_lshlrev_b32_e32 v60, 16, v47
	v_lshl_add_u32 v55, v54, 20, 0x3c000000
	v_mul_f32_e32 v56, 0x3b000000, v56
	v_and_or_b32 v52, 0x80000000, v64, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v53, vcc_lo
	v_bfe_u32 v64, v21, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_lshlrev_b32_e32 v58, 16, v45
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v53, 0x80000000, v65, v53
	v_cvt_f32_ubyte0_e32 v64, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v56, v55, vcc_lo
	v_bfe_u32 v56, v21, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_dual_mul_f32 v64, 0x3b000000, v64 :: v_dual_and_b32 v65, 7, v22
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v66, v56, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v54, 0x7fc00000, v55 :: v_dual_lshlrev_b32 v55, 8, v21
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	v_and_b32_e32 v57, 0xffff0000, v44
	v_and_or_b32 v54, 0x80000000, v55, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v66, vcc_lo
	v_bfe_u32 v66, v22, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	v_cvt_f32_ubyte0_e32 v55, v65
	v_lshlrev_b32_e32 v62, 16, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, 0x7fc00000, v64, vcc_lo
	v_cvt_f32_ubyte0_e32 v64, v66
	v_bfe_u32 v66, v22, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v55, 0x3b000000, v55 :: v_dual_mul_f32 v64, 0x3b000000, v64
	v_cvt_f32_ubyte0_e32 v66, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v66, 0x3b000000, v66
	v_and_b32_e32 v67, 0x7f, v22
	v_lshl_add_u32 v65, v67, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v55, v55, v65 :: v_dual_and_b32 v46, 0xffff0000, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v44, 16, v44
	v_lshl_add_u32 v65, v68, 20, 0x3c000000
	v_bfe_u32 v67, v22, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, 0x7fc00000, v55, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v47, 0xffff0000, v47
	v_lshl_add_u32 v69, v67, 20, 0x3c000000
	v_fma_f32 v52, v52, v44, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v64, v64, v65 :: v_dual_lshlrev_b32 v65, 24, v22
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	v_lshlrev_b32_e32 v68, 16, v22
	v_fmac_f32_e32 v52, v53, v57
	v_and_or_b32 v56, 0x80000000, v21, v56
	v_and_or_b32 v55, 0x80000000, v65, v55
	v_bfe_u32 v65, v22, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_dual_fmac_f32 v52, v54, v58 :: v_dual_lshlrev_b32 v57, 8, v23
	v_cvt_f32_ubyte0_e32 v65, v65
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v64, 0x80000000, v68, v64
	v_bfe_u32 v68, v22, 24, 7
	v_mul_f32_e32 v65, 0x3b000000, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, v66, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_and_b32_e32 v67, 7, v23
	v_and_b32_e32 v69, 0x7f, v23
	v_lshl_add_u32 v71, v68, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v66, vcc_lo
	v_cvt_f32_ubyte0_e32 v67, v67
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v48, 0xffff0000, v48
	v_lshl_add_u32 v72, v69, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v67, 0x3b000000, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	v_and_b32_e32 v50, 0xffff0000, v50
	v_bfe_u32 v71, v23, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v67, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v68, v71, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	v_lshlrev_b32_e32 v70, 8, v22
	v_lshlrev_b32_e32 v69, 24, v23
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v65, 0x80000000, v22, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v67, vcc_lo
	v_and_or_b32 v66, 0x80000000, v70, v66
	v_bfe_u32 v70, v23, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v67, 0x80000000, v69, v67
	v_bfe_u32 v69, v23, 16, 3
	v_cvt_f32_ubyte0_e32 v70, v70
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v69, v69
	v_dual_mul_f32 v70, 0x3b000000, v70 :: v_dual_mul_f32 v69, 0x3b000000, v69
	v_mul_f32_e32 v72, 0x3b000000, v73
	v_and_b32_e32 v45, 0xffff0000, v45
	v_bfe_u32 v73, v23, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v68, v72, v68, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_bfe_u32 v71, v23, 16, 7
	v_lshl_add_u32 v44, v73, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, 0x7fc00000, v68, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v74, v71, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v69, v74, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v73
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v44, v70, v44 :: v_dual_and_b32 v49, 0xffff0000, v49
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v53, 0x7fc00000, v69 :: v_dual_lshlrev_b32 v72, 16, v23
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v73
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v54, 0x80000000, v72, v68
	v_and_or_b32 v53, 0x80000000, v57, v53
	v_and_b32_e32 v57, 7, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v44, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v57, v57
	v_and_or_b32 v44, 0x80000000, v23, v44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v57, 0x3b000000, v57
	v_fmac_f32_e32 v52, v56, v45
	v_bfe_u32 v45, v24, 8, 3
	v_cvt_f32_ubyte0_e32 v45, v45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v45, 0x3b000000, v45
	v_and_b32_e32 v56, 0x7f, v24
	v_lshl_add_u32 v58, v56, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v57, v57, v58 :: v_dual_fmac_f32 v52, v55, v59
	v_bfe_u32 v55, v24, 8, 7
	v_fmac_f32_e32 v52, v64, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v46, v55, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v52, v66, v60 :: v_dual_cndmask_b32 v45, v45, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v52, v65, v47
	v_bfe_u32 v47, v24, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v46, 0x7fc00000, v57, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_lshlrev_b32_e32 v55, 16, v24
	v_cvt_f32_ubyte0_e32 v47, v47
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v45, 0x7fc00000, v45 :: v_dual_lshlrev_b32 v56, 24, v24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v47, 0x3b000000, v47
	v_and_or_b32 v46, 0x80000000, v56, v46
	v_bfe_u32 v56, v24, 16, 7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v45, 0x80000000, v55, v45
	v_bfe_u32 v55, v24, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v55, v55
	v_fmac_f32_e32 v52, v67, v61
	v_fmac_f32_e32 v52, v54, v48
	v_lshl_add_u32 v48, v56, 20, 0x3c000000
	v_bfe_u32 v54, v24, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v52, v53, v62 :: v_dual_cndmask_b32 v47, v47, v48
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	v_lshl_add_u32 v48, v54, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3)
	v_dual_mul_f32 v53, 0x3b000000, v55 :: v_dual_fmac_f32 v52, v44, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v47, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_lshlrev_b32_e32 v47, 8, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v53, v48, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v44, 0x80000000, v47, v44
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v47, 0x7fc00000, v48 :: v_dual_fmac_f32 v52, v46, v63
	v_lshlrev_b32_e32 v46, 16, v51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v47, 0x80000000, v24, v47
	v_dual_fmac_f32 v52, v45, v50 :: v_dual_and_b32 v45, 0xffff0000, v51
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v52, v44, v46
	v_or_b32_e32 v44, 64, v43
	v_fmac_f32_e32 v52, v47, v45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_add_f32_e32 v42, v42, v52
	v_cmpx_gt_i32_e64 s12, v44
	s_cbranch_execz .LBB317_11
; %bb.19:                               ;   in Loop: Header=BB317_14 Depth=1
	v_lshl_add_u32 v48, v44, 5, 0
	s_wait_loadcnt 0x1
	v_bfe_u32 v54, v25, 8, 3
	v_bfe_u32 v55, v25, 8, 7
	v_bfe_u32 v64, v25, 16, 3
	v_bfe_u32 v68, v26, 8, 7
	ds_load_b128 v[44:47], v48
	ds_load_b128 v[48:51], v48 offset:16
	v_cvt_f32_ubyte0_e32 v54, v54
	v_bfe_u32 v73, v27, 8, 3
	v_or_b32_e32 v43, 0x60, v43
	s_mov_b32 s24, exec_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v54, 0x3b000000, v54 :: v_dual_lshlrev_b32 v65, 16, v25
	v_and_b32_e32 v52, 7, v25
	v_cvt_f32_ubyte0_e32 v73, v73
	v_cvt_f32_ubyte0_e32 v52, v52
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v52, 0x3b000000, v52 :: v_dual_lshlrev_b32 v59, 16, v46
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v61, 16, v48
	v_and_b32_e32 v53, 0x7f, v25
	v_lshl_add_u32 v56, v53, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v52, v52, v56, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v63, 16, v50
	v_lshl_add_u32 v56, v55, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v52, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, v54, v56, vcc_lo
	v_bfe_u32 v54, v25, 16, 7
	v_cvt_f32_ubyte0_e32 v56, v64
	v_lshlrev_b32_e32 v64, 24, v25
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_lshlrev_b32_e32 v60, 16, v47
	v_lshl_add_u32 v55, v54, 20, 0x3c000000
	v_mul_f32_e32 v56, 0x3b000000, v56
	v_and_or_b32 v52, 0x80000000, v64, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v53, vcc_lo
	v_bfe_u32 v64, v25, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_lshlrev_b32_e32 v58, 16, v45
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v53, 0x80000000, v65, v53
	v_cvt_f32_ubyte0_e32 v64, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, v56, v55, vcc_lo
	v_bfe_u32 v56, v25, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_dual_mul_f32 v64, 0x3b000000, v64 :: v_dual_and_b32 v65, 7, v26
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v66, v56, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v54, 0x7fc00000, v55 :: v_dual_lshlrev_b32 v55, 8, v25
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	v_and_b32_e32 v57, 0xffff0000, v44
	v_and_or_b32 v54, 0x80000000, v55, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v66, vcc_lo
	v_bfe_u32 v66, v26, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	v_cvt_f32_ubyte0_e32 v55, v65
	v_lshlrev_b32_e32 v62, 16, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v56, 0x7fc00000, v64, vcc_lo
	v_cvt_f32_ubyte0_e32 v64, v66
	v_bfe_u32 v66, v26, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v55, 0x3b000000, v55 :: v_dual_mul_f32 v64, 0x3b000000, v64
	v_cvt_f32_ubyte0_e32 v66, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v66, 0x3b000000, v66
	v_and_b32_e32 v67, 0x7f, v26
	v_lshl_add_u32 v65, v67, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v55, v55, v65 :: v_dual_and_b32 v46, 0xffff0000, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v44, 16, v44
	v_lshl_add_u32 v65, v68, 20, 0x3c000000
	v_bfe_u32 v67, v26, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, 0x7fc00000, v55, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v47, 0xffff0000, v47
	v_lshl_add_u32 v69, v67, 20, 0x3c000000
	v_fma_f32 v44, v52, v44, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v64, v64, v65 :: v_dual_lshlrev_b32 v65, 24, v26
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	v_lshlrev_b32_e32 v68, 16, v26
	v_fmac_f32_e32 v44, v53, v57
	v_and_or_b32 v56, 0x80000000, v25, v56
	v_and_or_b32 v55, 0x80000000, v65, v55
	v_bfe_u32 v65, v26, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_dual_fmac_f32 v44, v54, v58 :: v_dual_lshlrev_b32 v57, 8, v27
	v_cvt_f32_ubyte0_e32 v65, v65
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v64, 0x80000000, v68, v64
	v_bfe_u32 v68, v26, 24, 7
	v_mul_f32_e32 v65, 0x3b000000, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, v66, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_and_b32_e32 v67, 7, v27
	v_and_b32_e32 v69, 0x7f, v27
	v_lshl_add_u32 v71, v68, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v66, vcc_lo
	v_cvt_f32_ubyte0_e32 v67, v67
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v48, 0xffff0000, v48
	v_lshl_add_u32 v72, v69, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_f32_e32 v67, 0x3b000000, v67
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v71, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	v_and_b32_e32 v50, 0xffff0000, v50
	v_bfe_u32 v71, v27, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v67, v72, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v68, v71, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	v_lshlrev_b32_e32 v70, 8, v26
	v_lshlrev_b32_e32 v69, 24, v27
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v65, 0x80000000, v26, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v67, vcc_lo
	v_and_or_b32 v66, 0x80000000, v70, v66
	v_bfe_u32 v70, v27, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v67, 0x80000000, v69, v67
	v_bfe_u32 v69, v27, 16, 3
	v_cvt_f32_ubyte0_e32 v70, v70
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v69, v69
	v_dual_mul_f32 v70, 0x3b000000, v70 :: v_dual_mul_f32 v69, 0x3b000000, v69
	v_mul_f32_e32 v72, 0x3b000000, v73
	v_and_b32_e32 v45, 0xffff0000, v45
	v_bfe_u32 v73, v27, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v68, v72, v68, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_bfe_u32 v71, v27, 16, 7
	v_lshl_add_u32 v52, v73, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, 0x7fc00000, v68, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v74, v71, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v69, v69, v74, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v73
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v52, v70, v52 :: v_dual_and_b32 v49, 0xffff0000, v49
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v53, 0x7fc00000, v69 :: v_dual_lshlrev_b32 v72, 16, v27
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v73
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_and_or_b32 v54, 0x80000000, v72, v68
	v_and_or_b32 v53, 0x80000000, v57, v53
	v_and_b32_e32 v57, 7, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v52, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v57, v57
	v_mul_f32_e32 v57, 0x3b000000, v57
	v_fmac_f32_e32 v44, v56, v45
	v_and_b32_e32 v56, 0x7f, v28
	v_and_or_b32 v45, 0x80000000, v27, v52
	v_bfe_u32 v52, v28, 8, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v58, v56, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	v_cvt_f32_ubyte0_e32 v52, v52
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v57, v57, v58 :: v_dual_fmac_f32 v44, v55, v59
	v_bfe_u32 v55, v28, 8, 7
	v_fmac_f32_e32 v44, v64, v46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v46, v55, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	v_fmac_f32_e32 v44, v66, v60
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v44, v65, v47
	v_bfe_u32 v47, v28, 16, 3
	v_fmac_f32_e32 v44, v67, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v47, v47
	v_mul_f32_e32 v52, 0x3b000000, v52
	v_dual_fmac_f32 v44, v54, v48 :: v_dual_mul_f32 v47, 0x3b000000, v47
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v46, v52, v46, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	v_lshlrev_b32_e32 v56, 24, v28
	v_bfe_u32 v54, v28, 24, 7
	v_fmac_f32_e32 v44, v53, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v57, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v44, v45, v49 :: v_dual_lshlrev_b32 v55, 16, v28
	v_lshlrev_b32_e32 v49, 16, v51
	v_and_or_b32 v52, 0x80000000, v56, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v46, 0x7fc00000, v46, vcc_lo
	v_bfe_u32 v56, v28, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v44, v52, v63
	v_and_or_b32 v46, 0x80000000, v55, v46
	v_bfe_u32 v55, v28, 24, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v48, v56, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v56
	v_fmac_f32_e32 v44, v46, v50
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v55, v55
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v47, v47, v48 :: v_dual_and_b32 v46, 0xffff0000, v51
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v56
	v_lshl_add_u32 v48, v54, 20, 0x3c000000
	v_mul_f32_e32 v53, 0x3b000000, v55
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v45, 0x7fc00000, v47, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_lshlrev_b32_e32 v47, 8, v28
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v48, v53, v48, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v45, 0x80000000, v47, v45
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v47, 0x7fc00000, v48 :: v_dual_fmac_f32 v44, v45, v49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v47, 0x80000000, v28, v47
	v_fmac_f32_e32 v44, v47, v46
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v42, v42, v44
	v_cmpx_gt_i32_e64 s12, v43
	s_cbranch_execz .LBB317_10
; %bb.20:                               ;   in Loop: Header=BB317_14 Depth=1
	v_lshl_add_u32 v47, v43, 5, 0
	s_wait_loadcnt 0x0
	v_bfe_u32 v53, v29, 8, 3
	v_bfe_u32 v54, v29, 8, 7
	v_bfe_u32 v63, v29, 16, 3
	v_bfe_u32 v67, v30, 8, 7
	ds_load_b128 v[43:46], v47
	ds_load_b128 v[47:50], v47 offset:16
	v_cvt_f32_ubyte0_e32 v53, v53
	v_bfe_u32 v72, v31, 8, 3
	v_lshlrev_b32_e32 v64, 16, v29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v53, 0x3b000000, v53
	v_and_b32_e32 v51, 7, v29
	v_cvt_f32_ubyte0_e32 v72, v72
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v51, v51
	s_wait_dscnt 0x1
	v_dual_mul_f32 v51, 0x3b000000, v51 :: v_dual_lshlrev_b32 v58, 16, v45
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v60, 16, v47
	v_and_b32_e32 v52, 0x7f, v29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v55, v52, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v51, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_lshlrev_b32_e32 v62, 16, v49
	v_lshl_add_u32 v55, v54, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v51, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, v53, v55, vcc_lo
	v_bfe_u32 v53, v29, 16, 7
	v_cvt_f32_ubyte0_e32 v55, v63
	v_lshlrev_b32_e32 v63, 24, v29
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_lshlrev_b32_e32 v59, 16, v46
	v_lshl_add_u32 v54, v53, 20, 0x3c000000
	v_mul_f32_e32 v55, 0x3b000000, v55
	v_and_or_b32 v51, 0x80000000, v63, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v52, vcc_lo
	v_bfe_u32 v63, v29, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	v_lshlrev_b32_e32 v57, 16, v44
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v52, 0x80000000, v64, v52
	v_cvt_f32_ubyte0_e32 v63, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v54, v55, v54, vcc_lo
	v_bfe_u32 v55, v29, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_dual_mul_f32 v63, 0x3b000000, v63 :: v_dual_and_b32 v64, 7, v30
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v65, v55, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v53, 0x7fc00000, v54 :: v_dual_lshlrev_b32 v54, 8, v29
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	v_and_b32_e32 v56, 0xffff0000, v43
	v_and_or_b32 v53, 0x80000000, v54, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, v63, v65, vcc_lo
	v_bfe_u32 v65, v30, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_cvt_f32_ubyte0_e32 v54, v64
	v_lshlrev_b32_e32 v61, 16, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v55, 0x7fc00000, v63, vcc_lo
	v_cvt_f32_ubyte0_e32 v63, v65
	v_bfe_u32 v65, v30, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v54, 0x3b000000, v54 :: v_dual_mul_f32 v63, 0x3b000000, v63
	v_cvt_f32_ubyte0_e32 v65, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v65, 0x3b000000, v65
	v_and_b32_e32 v66, 0x7f, v30
	v_lshl_add_u32 v64, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v54, v54, v64 :: v_dual_and_b32 v45, 0xffff0000, v45
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_lshlrev_b32_e32 v43, 16, v43
	v_lshl_add_u32 v64, v67, 20, 0x3c000000
	v_bfe_u32 v66, v30, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v54, 0x7fc00000, v54, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v46, 0xffff0000, v46
	v_lshl_add_u32 v68, v66, 20, 0x3c000000
	v_fma_f32 v43, v51, v43, 0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v63, v63, v64 :: v_dual_lshlrev_b32 v64, 24, v30
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v67, 16, v30
	v_fmac_f32_e32 v43, v52, v56
	v_and_or_b32 v55, 0x80000000, v29, v55
	v_and_or_b32 v54, 0x80000000, v64, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, 0x7fc00000, v63, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_bfe_u32 v64, v30, 24, 3
	v_dual_fmac_f32 v43, v53, v57 :: v_dual_lshlrev_b32 v56, 8, v31
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v63, 0x80000000, v67, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v68, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_and_b32_e32 v66, 7, v31
	v_bfe_u32 v67, v30, 24, 7
	v_cvt_f32_ubyte0_e32 v64, v64
	v_and_b32_e32 v68, 0x7f, v31
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_cvt_f32_ubyte0_e32 v66, v66
	v_lshl_add_u32 v70, v67, 20, 0x3c000000
	v_mul_f32_e32 v64, 0x3b000000, v64
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v47, 0xffff0000, v47
	v_lshl_add_u32 v71, v68, 20, 0x3c000000
	v_mul_f32_e32 v66, 0x3b000000, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v70, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v49, 0xffff0000, v49
	v_bfe_u32 v70, v31, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, v66, v71, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v67, v70, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	v_lshlrev_b32_e32 v68, 24, v31
	v_and_or_b32 v64, 0x80000000, v30, v64
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v66, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v66, 0x80000000, v68, v66
	v_bfe_u32 v68, v31, 16, 3
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_lshlrev_b32 v69, 8, v30
	v_mul_f32_e32 v71, 0x3b000000, v72
	v_and_b32_e32 v44, 0xffff0000, v44
	v_and_or_b32 v65, 0x80000000, v69, v65
	v_bfe_u32 v69, v31, 24, 3
	v_bfe_u32 v72, v31, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v71, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	v_bfe_u32 v70, v31, 16, 7
	v_cvt_f32_ubyte0_e32 v69, v69
	v_lshl_add_u32 v51, v72, 20, 0x3c000000
	v_lshlrev_b32_e32 v71, 16, v31
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, 0x7fc00000, v67, vcc_lo
	v_lshl_add_u32 v73, v70, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	v_mul_f32_e32 v69, 0x3b000000, v69
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v68, v68, v73, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v72
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, v69, v51 :: v_dual_and_b32 v48, 0xffff0000, v48
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v68, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v72
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_and_or_b32 v52, 0x80000000, v56, v52
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v51, 0x7fc00000, v51 :: v_dual_and_b32 v56, 7, v32
	v_cvt_f32_ubyte0_e32 v56, v56
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_mul_f32_e32 v56, 0x3b000000, v56
	v_fmac_f32_e32 v43, v55, v44
	v_and_b32_e32 v55, 0x7f, v32
	v_and_or_b32 v44, 0x80000000, v31, v51
	v_bfe_u32 v51, v32, 8, 3
	v_lshl_add_u32 v57, v55, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v51, v51
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v56, v56, v57 :: v_dual_fmac_f32 v43, v54, v58
	v_bfe_u32 v54, v32, 8, 7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v43, v63, v45
	v_lshl_add_u32 v45, v54, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v65, v59
	v_fmac_f32_e32 v43, v64, v46
	v_bfe_u32 v46, v32, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v43, v66, v60
	v_cvt_f32_ubyte0_e32 v46, v46
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v51, 0x3b000000, v51 :: v_dual_mul_f32 v46, 0x3b000000, v46
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v45, v51, v45, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_lshlrev_b32_e32 v55, 24, v32
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v56, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_lshlrev_b32_e32 v54, 16, v32
	v_and_or_b32 v53, 0x80000000, v71, v67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v51, 0x80000000, v55, v51
	v_bfe_u32 v55, v32, 16, 7
	v_fmac_f32_e32 v43, v53, v47
	v_bfe_u32 v53, v32, 24, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v47, v55, 20, 0x3c000000
	v_fmac_f32_e32 v43, v52, v61
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v43, v44, v48 :: v_dual_lshlrev_b32 v48, 16, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v45, 0x7fc00000, v45, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v55
	v_fmac_f32_e32 v43, v51, v62
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v45, 0x80000000, v54, v45
	v_bfe_u32 v54, v32, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v46, v46, v47, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v55
	v_lshl_add_u32 v47, v53, 20, 0x3c000000
	v_fmac_f32_e32 v43, v45, v49
	v_cvt_f32_ubyte0_e32 v54, v54
	v_and_b32_e32 v45, 0xffff0000, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v46, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	v_lshlrev_b32_e32 v46, 8, v32
	v_mul_f32_e32 v52, 0x3b000000, v54
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v44, 0x80000000, v46, v44
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v47, v52, v47, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v43, v44, v48 :: v_dual_cndmask_b32 v46, 0x7fc00000, v47
	v_and_or_b32 v46, 0x80000000, v32, v46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v43, v46, v45
	v_add_f32_e32 v42, v42, v43
	s_branch .LBB317_10
.LBB317_21:
	s_wait_loadcnt 0x3
	v_mbcnt_lo_u32_b32 v17, -1, 0
	s_mov_b32 s11, 0
	s_mov_b32 s6, exec_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v18, 16, v17
	v_xor_b32_e32 v19, 8, v17
	v_xor_b32_e32 v20, 4, v17
	v_cmp_gt_i32_e32 vcc_lo, 32, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v18, v17, v18, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v19, v17, v19, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v19, 2, v19
	v_lshlrev_b32_e32 v18, 2, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v20, v17, v20, vcc_lo
	ds_bpermute_b32 v18, v18, v42
	v_lshlrev_b32_e32 v20, 2, v20
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v42, v18
	ds_bpermute_b32 v19, v19, v18
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v19
	ds_bpermute_b32 v19, v20, v18
	v_xor_b32_e32 v20, 2, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v20, v17, v20, vcc_lo
	v_lshlrev_b32_e32 v20, 2, v20
	s_wait_dscnt 0x0
	v_add_f32_e32 v18, v18, v19
	ds_bpermute_b32 v19, v20, v18
	v_xor_b32_e32 v20, 1, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, v17, v20, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v17, v18, v19 :: v_dual_lshlrev_b32 v20, 2, v17
	ds_bpermute_b32 v18, v20, v17
	v_cmpx_eq_u32_e32 0, v37
	s_cbranch_execz .LBB317_27
; %bb.22:
	s_wait_dscnt 0x0
	v_add_f32_e32 v17, v17, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v18, s8, v17
	v_and_b32_e32 v17, 0x7fffffff, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v17
                                        ; implicit-def: $vgpr17
	s_and_saveexec_b32 s17, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s17, exec_lo, s17
; %bb.23:
	v_bfe_u32 v17, v18, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v17, v18, v17, 0x7fff
                                        ; implicit-def: $vgpr18
	v_lshrrev_b32_e32 v17, 16, v17
; %bb.24:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s17, s17
; %bb.25:
	v_lshrrev_b32_e32 v17, 16, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v17, 64, v17
; %bb.26:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s17
	v_lshlrev_b64_e32 v[18:19], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v18, vcc_lo, s20, v18
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v19, null, s21, v19, vcc_lo
	global_store_b16 v[18:19], v17, off
.LBB317_27:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
.LBB317_28:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 vcc_lo, exec_lo, s11
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB317_55
; %bb.29:
	v_mov_b32_e32 v17, 0
	s_and_not1_b32 vcc_lo, exec_lo, s10
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_49
; %bb.30:
	v_mov_b32_e32 v17, 0
	s_and_saveexec_b32 s6, s5
	s_cbranch_execz .LBB317_38
; %bb.31:
	s_wait_loadcnt 0x2
	v_lshl_add_u32 v21, v37, 5, 0
	v_perm_b32 v22, 0, v13, 0x10c000c
	v_perm_b32 v13, 0, v13, 0x30c020c
	s_wait_loadcnt 0x1
	v_perm_b32 v27, 0, v14, 0x10c000c
	v_perm_b32 v14, 0, v14, 0x30c020c
	s_wait_dscnt 0x0
	ds_load_b128 v[17:20], v21
	v_lshrrev_b32_e32 v25, 1, v22
	v_and_b32_e32 v26, 0x80008000, v22
	v_lshrrev_b32_e32 v28, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	ds_load_b128 v[21:24], v21 offset:16
	v_and_or_b32 v25, 0x3f803f80, v25, v26
	v_lshrrev_b32_e32 v26, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	v_and_or_b32 v13, 0x3f803f80, v28, v13
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v26, 0x3f803f80, v26, v27
	v_lshrrev_b32_e32 v27, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v17, v25, v17, 0
	v_perm_b32 v25, 0, v15, 0x10c000c
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v27, v14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v13, v13, v18, v17
	v_lshrrev_b32_e32 v17, 1, v25
	v_and_b32_e32 v18, 0x80008000, v25
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v13, v26, v19, v13
	v_perm_b32 v19, 0, v16, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v17, v18
	v_lshrrev_b32_e32 v18, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v13, v14, v20, v13
	v_lshrrev_b32_e32 v14, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_and_or_b32 v15, 0x3f803f80, v18, v15
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v13, v17, v21, v13
	v_and_or_b32 v14, 0x3f803f80, v14, v19
	v_lshrrev_b32_e32 v17, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v13, v15, v22, v13
	v_and_or_b32 v15, 0x3f803f80, v17, v16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v13, v14, v23, v13
	v_dot2_f32_f16 v17, v15, v24, v13
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB317_37
; %bb.32:
	v_lshl_add_u32 v18, v41, 5, 0
	v_perm_b32 v19, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_perm_b32 v24, 0, v10, 0x10c000c
	v_perm_b32 v10, 0, v10, 0x30c020c
	ds_load_b128 v[13:16], v18
	v_lshrrev_b32_e32 v22, 1, v19
	v_and_b32_e32 v23, 0x80008000, v19
	v_lshrrev_b32_e32 v25, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	ds_load_b128 v[18:21], v18 offset:16
	v_and_or_b32 v22, 0x3f803f80, v22, v23
	v_lshrrev_b32_e32 v23, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_and_or_b32 v9, 0x3f803f80, v25, v9
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v13, v22, v13, v17
	v_perm_b32 v17, 0, v11, 0x10c000c
	v_and_or_b32 v22, 0x3f803f80, v23, v24
	v_lshrrev_b32_e32 v23, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_dot2_f32_f16 v9, v9, v14, v13
	v_lshrrev_b32_e32 v13, 1, v17
	v_and_b32_e32 v14, 0x80008000, v17
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_and_or_b32 v10, 0x3f803f80, v23, v10
	v_dot2_f32_f16 v9, v22, v15, v9
	v_perm_b32 v15, 0, v12, 0x10c000c
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_dot2_f32_f16 v9, v10, v16, v9
	v_lshrrev_b32_e32 v10, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_perm_b32 v12, 0, v12, 0x30c020c
	v_and_or_b32 v11, 0x3f803f80, v14, v11
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v9, v13, v18, v9
	v_and_or_b32 v10, 0x3f803f80, v10, v15
	v_lshrrev_b32_e32 v13, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v9, v11, v19, v9
	v_and_or_b32 v11, 0x3f803f80, v13, v12
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v9, v10, v20, v9
	v_dot2_f32_f16 v17, v11, v21, v9
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB317_36
; %bb.33:
	v_lshl_add_u32 v13, v40, 5, 0
	v_perm_b32 v14, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v20, 0, v6, 0x10c000c
	v_perm_b32 v6, 0, v6, 0x30c020c
	ds_load_b128 v[9:12], v13
	v_lshrrev_b32_e32 v18, 1, v14
	v_and_b32_e32 v19, 0x80008000, v14
	v_lshrrev_b32_e32 v21, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	ds_load_b128 v[13:16], v13 offset:16
	v_and_or_b32 v18, 0x3f803f80, v18, v19
	v_lshrrev_b32_e32 v19, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	v_and_or_b32 v5, 0x3f803f80, v21, v5
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v9, v18, v9, v17
	v_perm_b32 v17, 0, v7, 0x10c000c
	v_and_or_b32 v18, 0x3f803f80, v19, v20
	v_lshrrev_b32_e32 v19, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v5, v5, v10, v9
	v_lshrrev_b32_e32 v9, 1, v17
	v_and_b32_e32 v10, 0x80008000, v17
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v19, v6
	v_dot2_f32_f16 v5, v18, v11, v5
	v_perm_b32 v11, 0, v8, 0x10c000c
	v_and_or_b32 v9, 0x3f803f80, v9, v10
	v_lshrrev_b32_e32 v10, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v5, v6, v12, v5
	v_lshrrev_b32_e32 v6, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_and_or_b32 v7, 0x3f803f80, v10, v7
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v5, v9, v13, v5
	v_and_or_b32 v6, 0x3f803f80, v6, v11
	v_lshrrev_b32_e32 v9, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v5, v7, v14, v5
	v_and_or_b32 v7, 0x3f803f80, v9, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v5, v6, v15, v5
	v_dot2_f32_f16 v17, v7, v16, v5
	s_and_saveexec_b32 s3, s2
	s_cbranch_execz .LBB317_35
; %bb.34:
	v_lshl_add_u32 v9, v39, 5, 0
	v_perm_b32 v10, 0, v1, 0x10c000c
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_perm_b32 v15, 0, v2, 0x10c000c
	v_perm_b32 v2, 0, v2, 0x30c020c
	ds_load_b128 v[5:8], v9
	v_lshrrev_b32_e32 v13, 1, v10
	v_and_b32_e32 v14, 0x80008000, v10
	v_lshrrev_b32_e32 v16, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	ds_load_b128 v[9:12], v9 offset:16
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_and_or_b32 v1, 0x3f803f80, v16, v1
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v14, 0x3f803f80, v14, v15
	v_lshrrev_b32_e32 v15, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v5, v13, v5, v17
	v_perm_b32 v13, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v2, 0x3f803f80, v15, v2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dot2_f32_f16 v1, v1, v6, v5
	v_lshrrev_b32_e32 v5, 1, v13
	v_and_b32_e32 v6, 0x80008000, v13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v1, v14, v7, v1
	v_perm_b32 v7, 0, v4, 0x10c000c
	v_and_or_b32 v5, 0x3f803f80, v5, v6
	v_lshrrev_b32_e32 v6, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v1, v2, v8, v1
	v_lshrrev_b32_e32 v2, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v6, v3
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v5, v9, v1
	v_and_or_b32 v2, 0x3f803f80, v2, v7
	v_lshrrev_b32_e32 v5, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v1, v3, v10, v1
	v_and_or_b32 v3, 0x3f803f80, v5, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v1, v2, v11, v1
	v_dot2_f32_f16 v17, v3, v12, v1
.LBB317_35:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB317_36:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_37:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB317_38:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
	s_cmp_lt_u32 s13, 0x810
	s_cbranch_scc1 .LBB317_49
; %bb.39:
	v_lshlrev_b32_e32 v2, 5, v37
	v_or_b32_e32 v1, 0x80, v37
	s_add_co_i32 s2, s9, -1
	s_delay_alu instid0(VALU_DEP_2)
	v_add3_u32 v3, v2, 0, 0x1000
	s_branch .LBB317_44
.LBB317_40:                             ;   in Loop: Header=BB317_44 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s6
.LBB317_41:                             ;   in Loop: Header=BB317_44 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB317_42:                             ;   in Loop: Header=BB317_44 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_43:                             ;   in Loop: Header=BB317_44 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
	v_add_nc_u32_e32 v1, 0x80, v1
	v_add_nc_u32_e32 v3, 0x1000, v3
	s_add_co_i32 s2, s2, -1
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s2, 0
	s_cbranch_scc0 .LBB317_49
.LBB317_44:                             ; =>This Inner Loop Header: Depth=1
	s_mov_b32 s3, exec_lo
	v_cmpx_gt_i32_e64 s12, v1
	s_cbranch_execz .LBB317_43
; %bb.45:                               ;   in Loop: Header=BB317_44 Depth=1
	v_ashrrev_i32_e32 v2, 31, v1
	ds_load_b128 v[8:11], v3
	ds_load_b128 v[12:15], v3 offset:16
	v_lshlrev_b64_e32 v[4:5], 4, v[1:2]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v4, vcc_lo, v35, v4
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v5, null, v36, v5, vcc_lo
	global_load_b128 v[4:7], v[4:5], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v2, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	s_wait_dscnt 0x2
	v_perm_b32 v18, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_lshrrev_b32_e32 v16, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_lshrrev_b32_e32 v19, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_and_or_b32 v2, 0x3f803f80, v16, v2
	v_lshrrev_b32_e32 v16, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_and_or_b32 v4, 0x3f803f80, v19, v4
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v2, v2, v8, v17
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v16, 0x3f803f80, v16, v18
	v_lshrrev_b32_e32 v17, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v2, v4, v9, v2
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v17, v5
	v_dot2_f32_f16 v2, v16, v10, v2
	v_perm_b32 v9, 0, v7, 0x10c000c
	v_and_or_b32 v4, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v8, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v2, v5, v11, v2
	v_lshrrev_b32_e32 v5, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v8, v6
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v2, v4, v12, v2
	v_and_or_b32 v4, 0x3f803f80, v5, v9
	v_lshrrev_b32_e32 v5, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v6, v6, v13, v2
	v_add_nc_u32_e32 v2, 32, v1
	v_and_or_b32 v5, 0x3f803f80, v5, v7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v4, v4, v14, v6
	v_cmp_gt_i32_e32 vcc_lo, s12, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_dot2_f32_f16 v17, v5, v15, v4
	s_and_saveexec_b32 s4, vcc_lo
	s_cbranch_execz .LBB317_42
; %bb.46:                               ;   in Loop: Header=BB317_44 Depth=1
	v_cndmask_b32_e32 v4, 0, v2, vcc_lo
	ds_load_b128 v[8:11], v3 offset:1024
	ds_load_b128 v[12:15], v3 offset:1040
	v_ashrrev_i32_e32 v5, 31, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b64_e32 v[4:5], 4, v[4:5]
	v_add_co_u32 v4, vcc_lo, v35, v4
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v5, null, v36, v5, vcc_lo
	global_load_b128 v[4:7], v[4:5], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v2, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v18, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v16, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_lshrrev_b32_e32 v19, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_and_or_b32 v2, 0x3f803f80, v16, v2
	v_lshrrev_b32_e32 v16, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v4, 0x3f803f80, v19, v4
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v2, v2, v8, v17
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v16, 0x3f803f80, v16, v18
	v_lshrrev_b32_e32 v17, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v2, v4, v9, v2
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v17, v5
	v_dot2_f32_f16 v2, v16, v10, v2
	v_perm_b32 v9, 0, v7, 0x10c000c
	v_and_or_b32 v4, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v8, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v2, v5, v11, v2
	v_lshrrev_b32_e32 v5, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v8, v6
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v2, v4, v12, v2
	v_and_or_b32 v4, 0x3f803f80, v5, v9
	v_lshrrev_b32_e32 v5, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v6, v6, v13, v2
	v_add_nc_u32_e32 v2, 64, v1
	v_and_or_b32 v5, 0x3f803f80, v5, v7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v4, v4, v14, v6
	v_cmp_gt_i32_e32 vcc_lo, s12, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_dot2_f32_f16 v17, v5, v15, v4
	s_and_saveexec_b32 s5, vcc_lo
	s_cbranch_execz .LBB317_41
; %bb.47:                               ;   in Loop: Header=BB317_44 Depth=1
	v_cndmask_b32_e32 v4, 0, v2, vcc_lo
	ds_load_b128 v[8:11], v3 offset:2048
	ds_load_b128 v[12:15], v3 offset:2064
	v_ashrrev_i32_e32 v5, 31, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b64_e32 v[4:5], 4, v[4:5]
	v_add_co_u32 v4, vcc_lo, v35, v4
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v5, null, v36, v5, vcc_lo
	global_load_b128 v[4:7], v[4:5], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v2, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v18, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v16, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_lshrrev_b32_e32 v19, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_and_or_b32 v2, 0x3f803f80, v16, v2
	v_lshrrev_b32_e32 v16, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v4, 0x3f803f80, v19, v4
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v2, v2, v8, v17
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v16, 0x3f803f80, v16, v18
	v_lshrrev_b32_e32 v17, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v2, v4, v9, v2
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v17, v5
	v_dot2_f32_f16 v2, v16, v10, v2
	v_perm_b32 v9, 0, v7, 0x10c000c
	v_and_or_b32 v4, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v8, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v2, v5, v11, v2
	v_lshrrev_b32_e32 v5, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v8, v6
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v2, v4, v12, v2
	v_and_or_b32 v4, 0x3f803f80, v5, v9
	v_lshrrev_b32_e32 v5, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v6, v6, v13, v2
	v_add_nc_u32_e32 v2, 0x60, v1
	v_and_or_b32 v5, 0x3f803f80, v5, v7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v4, v4, v14, v6
	v_cmp_gt_i32_e32 vcc_lo, s12, v2
	s_delay_alu instid0(VALU_DEP_2)
	v_dot2_f32_f16 v17, v5, v15, v4
	s_and_saveexec_b32 s6, vcc_lo
	s_cbranch_execz .LBB317_40
; %bb.48:                               ;   in Loop: Header=BB317_44 Depth=1
	v_cndmask_b32_e32 v4, 0, v2, vcc_lo
	ds_load_b128 v[8:11], v3 offset:3072
	ds_load_b128 v[12:15], v3 offset:3088
	v_ashrrev_i32_e32 v5, 31, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b64_e32 v[4:5], 4, v[4:5]
	v_add_co_u32 v4, vcc_lo, v35, v4
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v5, null, v36, v5, vcc_lo
	global_load_b128 v[4:7], v[4:5], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v2, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_perm_b32 v18, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v16, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_lshrrev_b32_e32 v19, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_and_or_b32 v2, 0x3f803f80, v16, v2
	v_lshrrev_b32_e32 v16, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v4, 0x3f803f80, v19, v4
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v2, v2, v8, v17
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v16, 0x3f803f80, v16, v18
	v_lshrrev_b32_e32 v17, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v2, v4, v9, v2
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v17, v5
	v_dot2_f32_f16 v2, v16, v10, v2
	v_perm_b32 v9, 0, v7, 0x10c000c
	v_and_or_b32 v4, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v8, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v2, v5, v11, v2
	v_lshrrev_b32_e32 v5, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v8, v6
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v2, v4, v12, v2
	v_and_or_b32 v4, 0x3f803f80, v5, v9
	v_lshrrev_b32_e32 v5, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v2, v6, v13, v2
	v_and_or_b32 v5, 0x3f803f80, v5, v7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v2, v4, v14, v2
	v_dot2_f32_f16 v17, v5, v15, v2
	s_branch .LBB317_40
.LBB317_49:
	v_mbcnt_lo_u32_b32 v1, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v2, 16, v1
	v_xor_b32_e32 v3, 8, v1
	v_xor_b32_e32 v4, 4, v1
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_lshlrev_b32_e32 v4, 2, v4
	v_lshlrev_b32_e32 v3, 2, v3
	v_lshlrev_b32_e32 v2, 2, v2
	ds_bpermute_b32 v2, v2, v17
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v17, v2
	ds_bpermute_b32 v3, v3, v2
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	v_xor_b32_e32 v4, 2, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo
	v_lshlrev_b32_e32 v4, 2, v4
	s_wait_dscnt 0x0
	v_add_f32_e32 v2, v2, v3
	ds_bpermute_b32 v3, v4, v2
	v_xor_b32_e32 v4, 1, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo
	v_cmp_eq_u32_e32 vcc_lo, 0, v37
	s_wait_dscnt 0x0
	v_dual_add_f32 v1, v2, v3 :: v_dual_lshlrev_b32 v4, 2, v1
	ds_bpermute_b32 v2, v4, v1
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB317_55
; %bb.50:
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v1, 0x47800000, v1
	v_mul_f32_e32 v2, s8, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 0x7fffffff, v2
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v1
                                        ; implicit-def: $vgpr1
	s_and_saveexec_b32 s2, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s2, exec_lo, s2
; %bb.51:
	v_bfe_u32 v1, v2, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v1, v2, v1, 0x7fff
                                        ; implicit-def: $vgpr2
	v_lshrrev_b32_e32 v1, 16, v1
; %bb.52:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s2, s2
; %bb.53:
	v_lshrrev_b32_e32 v1, 16, v2
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v1, 64, v1
; %bb.54:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_lshlrev_b64_e32 v[2:3], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v2, vcc_lo, s20, v2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo
	global_store_b16 v[2:3], v1, off
.LBB317_55:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s7
	s_mov_b32 s3, 0
.LBB317_56:
	s_wait_alu 0xfffe
	s_and_b32 vcc_lo, exec_lo, s3
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB317_111
; %bb.57:
	s_lshl_b64 s[2:3], s[18:19], 3
	s_ashr_i32 s7, s13, 31
	s_wait_alu 0xfffe
	v_or_b32_e32 v33, s2, v38
	s_lshr_b32 s2, s7, 28
	s_load_b128 s[8:11], s[0:1], 0x8
	s_add_co_i32 s2, s13, s2
	s_ashr_i32 s17, s16, 31
	s_wait_alu 0xfffe
	s_ashr_i32 s12, s2, 4
	v_or_b32_e32 v40, 32, v37
	s_wait_alu 0xfffe
	v_cmp_gt_i32_e64 s5, s12, v37
	v_or_b32_e32 v39, 64, v37
	v_or_b32_e32 v38, 0x60, v37
	s_mov_b32 s20, 0
	v_cmp_gt_i32_e64 s4, s12, v40
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v3, 0, v37, s5
	v_mov_b32_e32 v34, s3
	v_cmp_gt_i32_e64 s2, s12, v38
	s_mov_b32 s21, exec_lo
	v_lshlrev_b32_e32 v3, 4, v3
	v_cmp_gt_i64_e64 s6, s[16:17], v[33:34]
	s_load_b64 s[16:17], s[0:1], 0x18
	v_cndmask_b32_e64 v7, 0, v38, s2
	v_cndmask_b32_e64 v1, 0, v33, s6
	s_wait_dscnt 0x0
	v_cndmask_b32_e64 v2, 0, s3, s6
	v_cmp_gt_i32_e64 s3, s12, v39
	v_lshlrev_b32_e32 v7, 4, v7
	v_mul_lo_u32 v4, v1, s7
	s_delay_alu instid0(VALU_DEP_4)
	v_mul_lo_u32 v2, v2, s13
	s_wait_kmcnt 0x0
	v_mad_co_u64_u32 v[35:36], null, v1, s13, s[8:9]
	v_cndmask_b32_e64 v1, 0, v40, s4
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v5, 0, v39, s3
	s_lshr_b32 s7, s7, 29
	s_wait_alu 0xfffe
	s_add_co_i32 s7, s13, s7
	v_lshlrev_b32_e32 v6, 4, v1
	v_add3_u32 v36, v2, v36, v4
	v_lshlrev_b32_e32 v5, 4, v5
	v_add_co_u32 v1, vcc_lo, v35, v3
	s_wait_alu 0xfffe
	s_ashr_i32 s19, s7, 3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, 0, v36, vcc_lo
	v_add_co_u32 v3, vcc_lo, v35, v6
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, 0, v36, vcc_lo
	v_add_co_u32 v5, vcc_lo, v35, v5
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v6, null, 0, v36, vcc_lo
	v_add_co_u32 v17, vcc_lo, v35, v7
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, 0, v36, vcc_lo
	s_clause 0x3
	global_load_b128 v[13:16], v[1:2], off th:TH_LOAD_NT
	global_load_b128 v[9:12], v[3:4], off th:TH_LOAD_NT
	global_load_b128 v[5:8], v[5:6], off th:TH_LOAD_NT
	global_load_b128 v[1:4], v[17:18], off th:TH_LOAD_NT
	s_load_b64 s[10:11], s[10:11], 0x0
	s_wait_kmcnt 0x0
	s_cmp_gt_f32 s11, 0
	s_cselect_b32 s18, -1, 0
	s_cmp_ngt_f32 s11, 0
	s_cselect_b32 s9, -1, 0
	v_cmpx_gt_i32_e64 s19, v0
	s_cbranch_execz .LBB317_62
; %bb.58:
	s_load_b32 s0, s[0:1], 0x54
	v_lshlrev_b32_e32 v17, 4, v0
	s_mov_b32 s22, 0xc3e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_co_u32 v18, s1, s14, v17
	v_add_co_ci_u32_e64 v19, null, s15, 0, s1
	s_wait_loadcnt 0x6
	v_add_nc_u32_e32 v23, 0, v17
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_u32 v21, vcc_lo, v18, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v22, null, 0, v19, vcc_lo
	s_wait_kmcnt 0x0
	s_and_b32 s14, s0, 0xffff
	s_wait_alu 0xfffe
	s_lshl_b32 s15, s14, 4
	s_branch .LBB317_60
.LBB317_59:                             ;   in Loop: Header=BB317_60 Depth=1
	v_add_nc_u32_e32 v0, s14, v0
	v_add_co_u32 v21, s0, v21, s15
	s_wait_loadcnt 0x0
	ds_store_b128 v23, v[17:20]
	v_add_nc_u32_e32 v23, s15, v23
	v_cmp_le_i32_e32 vcc_lo, s19, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v22, null, 0, v22, s0
	s_or_b32 s20, vcc_lo, s20
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s20
	s_cbranch_execz .LBB317_62
.LBB317_60:                             ; =>This Inner Loop Header: Depth=1
	global_load_b128 v[17:20], v[21:22], off offset:-8
	s_and_not1_b32 vcc_lo, exec_lo, s18
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_59
; %bb.61:                               ;   in Loop: Header=BB317_60 Depth=1
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v27, 16, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_div_scale_f32 v46, s1, v27, s11, v27
	v_lshlrev_b32_e32 v24, 16, v17
	v_and_b32_e32 v17, 0xffff0000, v17
	v_div_scale_f32 v31, null, s11, s11, v27
	v_div_scale_f32 v25, null, s11, s11, v24
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_scale_f32 v26, null, s11, s11, v17
	v_rcp_f32_e32 v42, v31
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_rcp_f32_e32 v29, v25
	v_div_scale_f32 v41, vcc_lo, v24, s11, v24
	v_rcp_f32_e32 v30, v26
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)
	v_fma_f32 v43, -v25, v29, 1.0
	v_and_b32_e32 v18, 0xffff0000, v18
	v_fma_f32 v44, -v26, v30, 1.0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v29, v43, v29 :: v_dual_lshlrev_b32 v28, 16, v19
	v_div_scale_f32 v43, null, s11, s11, v18
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v30, v44, v30
	v_div_scale_f32 v45, s0, v17, s11, v17
	v_fma_f32 v44, -v31, v42, 1.0
	v_mul_f32_e32 v47, v41, v29
	v_dual_mul_f32 v48, v45, v30 :: v_dual_and_b32 v19, 0xffff0000, v19
	v_div_scale_f32 v49, null, s11, s11, v28
	s_delay_alu instid0(VALU_DEP_3)
	v_fma_f32 v51, -v25, v47, v41
	v_fmac_f32_e32 v42, v44, v42
	v_lshlrev_b32_e32 v32, 16, v20
	v_fma_f32 v44, -v26, v48, v45
	v_rcp_f32_e32 v50, v43
	v_fmac_f32_e32 v47, v51, v29
	v_mul_f32_e32 v51, v46, v42
	v_div_scale_f32 v52, s7, v18, s11, v18
	v_fmac_f32_e32 v48, v44, v30
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fma_f32 v25, -v25, v47, v41
	v_fma_f32 v41, -v31, v51, v46
	v_and_b32_e32 v20, 0xffff0000, v20
	v_rcp_f32_e32 v44, v49
	v_fma_f32 v26, -v26, v48, v45
	s_wait_alu 0xfffd
	v_div_fmas_f32 v25, v25, v29, v47
	v_div_scale_f32 v29, null, s11, s11, v19
	v_fmac_f32_e32 v51, v41, v42
	s_mov_b32 vcc_lo, s0
	s_delay_alu instid0(VALU_DEP_3)
	v_div_fixup_f32 v24, v25, s11, v24
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v26, v30, v48
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v30, -v31, v51, v46
	v_rcp_f32_e32 v31, v29
	v_fma_f32 v25, -v49, v44, 1.0
	v_fma_f32 v53, -v43, v50, 1.0
	v_div_fixup_f32 v17, v26, s11, v17
	v_div_scale_f32 v47, null, s11, s11, v20
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v44, v25, v44
	v_div_scale_f32 v25, s0, v28, s11, v28
	v_med3_num_f32 v24, v24, s22, 0x43e00000
	v_fma_f32 v45, -v29, v31, 1.0
	v_med3_num_f32 v17, v17, s22, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v31, v45, v31
	s_wait_alu 0xfffe
	v_div_fmas_f32 v30, v30, v42, v51
	s_mov_b32 vcc_lo, s7
	v_div_scale_f32 v42, null, s11, s11, v32
	v_div_scale_f32 v45, s1, v19, s11, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v27, v30, s11, v27
	v_mul_f32_e32 v30, v25, v44
	v_rcp_f32_e32 v46, v42
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v27, v27, s22, 0x43e00000
	v_fma_f32 v51, -v49, v30, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v30, v51, v44
	v_div_scale_f32 v51, s7, v20, s11, v20
	v_fmac_f32_e32 v50, v53, v50
	v_fma_f32 v48, -v42, v46, 1.0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v25, -v49, v30, v25
	v_mul_f32_e32 v26, v52, v50
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v46, v48, v46
	v_div_scale_f32 v48, s8, v32, s11, v32
	v_fma_f32 v41, -v43, v26, v52
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v26, v41, v50
	v_rcp_f32_e32 v41, v47
	v_fma_f32 v43, -v43, v26, v52
	v_mul_f32_e32 v52, v45, v31
	s_wait_alu 0xfffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fmas_f32 v26, v43, v50, v26
	v_fma_f32 v43, -v29, v52, v45
	v_mul_f32_e32 v50, v48, v46
	s_delay_alu instid0(TRANS32_DEP_1)
	v_fma_f32 v53, -v47, v41, 1.0
	s_mov_b32 vcc_lo, s0
	v_div_fixup_f32 v18, v26, s11, v18
	v_fmac_f32_e32 v52, v43, v31
	v_fma_f32 v26, -v42, v50, v48
	v_fmac_f32_e32 v41, v53, v41
	s_wait_alu 0xfffe
	v_div_fmas_f32 v25, v25, v44, v30
	s_mov_b32 vcc_lo, s1
	v_fma_f32 v29, -v29, v52, v45
	v_dual_fmac_f32 v50, v26, v46 :: v_dual_mul_f32 v43, v51, v41
	v_med3_num_f32 v18, v18, s22, 0x43e00000
	v_div_fixup_f32 v25, v25, s11, v28
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v29, v31, v52
	v_mov_b32_e32 v29, 0
	v_fma_f32 v30, -v47, v43, v51
	v_fma_f32 v28, -v42, v50, v48
	v_med3_num_f32 v25, v25, s22, 0x43e00000
	v_div_fixup_f32 v19, v26, s11, v19
	v_cvt_pk_fp8_f32 v29, v24, v17
	v_mov_b32_e32 v17, 0
	v_fmac_f32_e32 v43, v30, v41
	s_mov_b32 vcc_lo, s8
	v_med3_num_f32 v19, v19, s22, 0x43e00000
	v_cvt_pk_fp8_f32 v29, v27, v18 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v26, -v47, v43, v51
	v_cvt_pk_fp8_f32 v17, v25, v19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_perm_b32 v19, 0, v29, 0x30c020c
	v_perm_b32 v18, 0, v29, 0x10c000c
	v_lshrrev_b32_e32 v25, 1, v19
	v_and_b32_e32 v19, 0x80008000, v19
	s_wait_alu 0xfffe
	v_div_fmas_f32 v28, v28, v46, v50
	s_mov_b32 vcc_lo, s7
	s_wait_alu 0xfffe
	v_div_fmas_f32 v26, v26, v41, v43
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_div_fixup_f32 v28, v28, s11, v32
	v_div_fixup_f32 v20, v26, s11, v20
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_med3_num_f32 v24, v28, s22, 0x43e00000
	v_med3_num_f32 v20, v20, s22, 0x43e00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v17, v24, v20 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v20, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_perm_b32 v24, 0, v17, 0x10c000c
	v_perm_b32 v17, 0, v17, 0x30c020c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v26, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	v_lshrrev_b32_e32 v27, 1, v17
	v_and_b32_e32 v28, 0x80008000, v17
	v_and_or_b32 v17, 0x3f803f80, v20, v18
	v_and_or_b32 v18, 0x3f803f80, v25, v19
	v_and_or_b32 v19, 0x3f803f80, v26, v24
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v20, 0x3f803f80, v27, v28
	s_branch .LBB317_59
.LBB317_62:
	s_or_b32 exec_lo, exec_lo, s21
	s_wait_storecnt 0x0
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_saveexec_b32 s0, s6
	s_cbranch_execz .LBB317_111
; %bb.63:
	s_and_b32 s0, s18, exec_lo
	s_cselect_b32 s0, s11, 1.0
	s_add_co_i32 s1, s12, 31
	s_mov_b32 s8, -1
	s_wait_alu 0xfffe
	s_ashr_i32 s6, s1, 31
	s_wait_alu 0xfffe
	s_lshr_b32 s6, s6, 27
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, s6
	s_wait_alu 0xfffe
	s_ashr_i32 s1, s1, 5
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, 3
	s_wait_alu 0xfffe
	s_lshr_b32 s6, s1, 30
	s_wait_alu 0xfffe
	s_add_co_i32 s1, s1, s6
	s_wait_alu 0xfffe
	s_ashr_i32 s6, s1, 2
	s_cmp_gt_i32 s13, 15
	s_mul_f32 s1, s10, s0
	s_cselect_b32 s7, -1, 0
	s_and_b32 vcc_lo, exec_lo, s9
	s_wait_alu 0xfffe
	v_cndmask_b32_e64 v0, 0, 1, s7
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_ne_u32_e64 s0, 1, v0
	s_cbranch_vccz .LBB317_84
; %bb.64:
	v_mov_b32_e32 v0, 0
	s_and_b32 vcc_lo, exec_lo, s0
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_77
; %bb.65:
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v17, v13
	v_dual_mov_b32 v18, v14 :: v_dual_mov_b32 v19, v15
	v_dual_mov_b32 v20, v16 :: v_dual_mov_b32 v21, v9
	v_dual_mov_b32 v22, v10 :: v_dual_mov_b32 v23, v11
	v_dual_mov_b32 v24, v12 :: v_dual_mov_b32 v25, v5
	v_dual_mov_b32 v26, v6 :: v_dual_mov_b32 v27, v7
	v_dual_mov_b32 v28, v8 :: v_dual_mov_b32 v29, v1
	v_dual_mov_b32 v30, v2 :: v_dual_mov_b32 v31, v3
	v_mov_b32_e32 v32, v4
	s_max_i32 s0, s6, 1
	s_mov_b32 s8, 0
	s_wait_alu 0xfffe
	s_lshl_b32 s0, s0, 7
	s_branch .LBB317_70
.LBB317_66:                             ;   in Loop: Header=BB317_70 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s14
.LBB317_67:                             ;   in Loop: Header=BB317_70 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
.LBB317_68:                             ;   in Loop: Header=BB317_70 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
.LBB317_69:                             ;   in Loop: Header=BB317_70 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	s_addk_co_i32 s8, 0x80
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s0, s8
	s_cbranch_scc0 .LBB317_77
.LBB317_70:                             ; =>This Inner Loop Header: Depth=1
	s_cmp_eq_u32 s8, 0
	s_mov_b32 s9, 0
	s_cbranch_scc1 .LBB317_72
; %bb.71:                               ;   in Loop: Header=BB317_70 Depth=1
	s_wait_loadcnt 0x3
	v_add_nc_u32_e32 v18, s8, v37
	s_mov_b32 s9, s8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_add_nc_u32_e32 v19, 32, v18
	v_cmp_gt_i32_e32 vcc_lo, s12, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, 0, v18, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, s12, v19
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v19, 0, v19 :: v_dual_add_nc_u32 v20, 64, v18
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, s12, v20
	s_wait_loadcnt 0x2
	v_add_nc_u32_e32 v22, 0x60, v18
	v_ashrrev_i32_e32 v18, 31, v17
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v21, 0, v20, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s12, v22
	v_ashrrev_i32_e32 v20, 31, v19
	v_lshlrev_b64_e32 v[17:18], 4, v[17:18]
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v23, 0, v22, vcc_lo
	v_lshlrev_b64_e32 v[19:20], 4, v[19:20]
	v_ashrrev_i32_e32 v22, 31, v21
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_add_co_u32 v17, vcc_lo, v35, v17
	v_ashrrev_i32_e32 v24, 31, v23
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, v36, v18, vcc_lo
	v_lshlrev_b64_e32 v[21:22], 4, v[21:22]
	s_wait_loadcnt 0x1
	v_add_co_u32 v25, vcc_lo, v35, v19
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, v36, v20, vcc_lo
	v_lshlrev_b64_e32 v[19:20], 4, v[23:24]
	v_add_co_u32 v27, vcc_lo, v35, v21
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v28, null, v36, v22, vcc_lo
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_3)
	v_add_co_u32 v29, vcc_lo, v35, v19
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v30, null, v36, v20, vcc_lo
	s_clause 0x3
	global_load_b128 v[17:20], v[17:18], off th:TH_LOAD_NT
	global_load_b128 v[21:24], v[25:26], off th:TH_LOAD_NT
	global_load_b128 v[25:28], v[27:28], off th:TH_LOAD_NT
	global_load_b128 v[29:32], v[29:30], off th:TH_LOAD_NT
.LBB317_72:                             ;   in Loop: Header=BB317_70 Depth=1
	s_wait_alu 0xfffe
	v_or_b32_e32 v41, s9, v37
	s_mov_b32 s9, exec_lo
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s12, v41
	s_cbranch_execz .LBB317_69
; %bb.73:                               ;   in Loop: Header=BB317_70 Depth=1
	v_lshl_add_u32 v46, v41, 5, 0
	s_wait_loadcnt 0x3
	v_bfe_u32 v52, v17, 8, 3
	v_bfe_u32 v53, v17, 8, 7
	v_bfe_u32 v62, v17, 16, 3
	v_bfe_u32 v66, v18, 8, 7
	ds_load_b128 v[42:45], v46
	ds_load_b128 v[46:49], v46 offset:16
	v_cvt_f32_ubyte0_e32 v52, v52
	v_bfe_u32 v71, v19, 8, 3
	s_mov_b32 s10, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v52, 0x3b000000, v52 :: v_dual_lshlrev_b32 v63, 16, v17
	v_and_b32_e32 v50, 7, v17
	v_cvt_f32_ubyte0_e32 v71, v71
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v50, v50
	s_wait_dscnt 0x1
	v_dual_mul_f32 v50, 0x3b000000, v50 :: v_dual_lshlrev_b32 v57, 16, v44
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v59, 16, v46
	v_and_b32_e32 v51, 0x7f, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v54, v51, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, v50, v54, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v51
	v_lshlrev_b32_e32 v61, 16, v48
	v_lshl_add_u32 v54, v53, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v50, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v52, v54, vcc_lo
	v_bfe_u32 v52, v17, 16, 7
	v_cvt_f32_ubyte0_e32 v54, v62
	v_lshlrev_b32_e32 v62, 24, v17
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v58, 16, v45
	v_lshl_add_u32 v53, v52, 20, 0x3c000000
	v_mul_f32_e32 v54, 0x3b000000, v54
	v_and_or_b32 v50, 0x80000000, v62, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v51, vcc_lo
	v_bfe_u32 v62, v17, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	v_lshlrev_b32_e32 v56, 16, v43
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v51, 0x80000000, v63, v51
	v_cvt_f32_ubyte0_e32 v62, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, v54, v53, vcc_lo
	v_bfe_u32 v54, v17, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_and_b32_e32 v63, 7, v18
	v_mul_f32_e32 v62, 0x3b000000, v62
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v64, v54, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v53, vcc_lo
	v_lshlrev_b32_e32 v53, 8, v17
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_and_b32_e32 v55, 0xffff0000, v42
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v52, 0x80000000, v53, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v64, vcc_lo
	v_bfe_u32 v64, v18, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_cvt_f32_ubyte0_e32 v53, v63
	v_lshlrev_b32_e32 v60, 16, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v54, 0x7fc00000, v62, vcc_lo
	v_cvt_f32_ubyte0_e32 v62, v64
	v_bfe_u32 v64, v18, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v53, 0x3b000000, v53 :: v_dual_mul_f32 v62, 0x3b000000, v62
	v_cvt_f32_ubyte0_e32 v64, v64
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v64, 0x3b000000, v64
	v_and_b32_e32 v65, 0x7f, v18
	v_lshl_add_u32 v63, v65, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v53, v53, v63 :: v_dual_and_b32 v44, 0xffff0000, v44
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshl_add_u32 v63, v66, 20, 0x3c000000
	v_bfe_u32 v65, v18, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v53, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_and_b32_e32 v45, 0xffff0000, v45
	v_lshl_add_u32 v67, v65, 20, 0x3c000000
	v_fma_f32 v50, v50, v42, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_lshlrev_b32_e32 v66, 16, v18
	v_fmac_f32_e32 v50, v51, v55
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v62, 0x7fc00000, v62 :: v_dual_lshlrev_b32 v55, 8, v19
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v50, v52, v56
	v_and_or_b32 v62, 0x80000000, v66, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshlrev_b32_e32 v63, 24, v18
	v_and_b32_e32 v65, 7, v19
	v_bfe_u32 v66, v18, 24, 7
	v_and_b32_e32 v67, 0x7f, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_and_or_b32 v53, 0x80000000, v63, v53
	v_bfe_u32 v63, v18, 24, 3
	v_cvt_f32_ubyte0_e32 v65, v65
	v_lshl_add_u32 v69, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_lshl_add_u32 v70, v67, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v63, v63
	v_mul_f32_e32 v65, 0x3b000000, v65
	v_and_or_b32 v54, 0x80000000, v17, v54
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v63, 0x3b000000, v63
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v63, v63, v69 :: v_dual_and_b32 v46, 0xffff0000, v46
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v48, 0xffff0000, v48
	v_bfe_u32 v69, v19, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v70, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v66, v69, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, 0x7fc00000, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v68, 8, v18
	v_lshlrev_b32_e32 v67, 24, v19
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v63, 0x80000000, v18, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_and_or_b32 v64, 0x80000000, v68, v64
	v_bfe_u32 v68, v19, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v65, 0x80000000, v67, v65
	v_bfe_u32 v67, v19, 16, 3
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v67, v67
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_mul_f32 v67, 0x3b000000, v67
	v_mul_f32_e32 v70, 0x3b000000, v71
	v_and_b32_e32 v43, 0xffff0000, v43
	v_bfe_u32 v71, v19, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v66, v70, v66, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	v_bfe_u32 v69, v19, 16, 7
	v_lshl_add_u32 v42, v71, 20, 0x3c000000
	v_fmac_f32_e32 v50, v54, v43
	v_bfe_u32 v43, v20, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v66, vcc_lo
	v_lshl_add_u32 v72, v69, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	v_fmac_f32_e32 v50, v53, v57
	v_cvt_f32_ubyte0_e32 v43, v43
	v_bfe_u32 v53, v20, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v67, v72, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	v_dual_fmac_f32 v50, v62, v44 :: v_dual_and_b32 v47, 0xffff0000, v47
	v_mul_f32_e32 v43, 0x3b000000, v43
	v_lshl_add_u32 v44, v53, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v42, v68, v42, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v50, v64, v58 :: v_dual_cndmask_b32 v51, 0x7fc00000, v67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v50, v63, v45
	v_bfe_u32 v45, v20, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_and_or_b32 v51, 0x80000000, v55, v51
	v_and_b32_e32 v55, 7, v20
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v45, v45
	v_fmac_f32_e32 v50, v65, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v42, 0x7fc00000, v42, vcc_lo
	v_cvt_f32_ubyte0_e32 v55, v55
	v_mul_f32_e32 v45, 0x3b000000, v45
	v_and_b32_e32 v54, 0x7f, v20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v42, 0x80000000, v19, v42
	v_mul_f32_e32 v55, 0x3b000000, v55
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v56, v54, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v55, v55, v56 :: v_dual_lshlrev_b32 v70, 16, v19
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v52, 0x80000000, v70, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v43, v43, v44, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v54, 24, v20
	v_lshlrev_b32_e32 v53, 16, v20
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v43, 0x7fc00000, v43, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v44, 0x80000000, v54, v44
	v_bfe_u32 v54, v20, 16, 7
	v_and_or_b32 v43, 0x80000000, v53, v43
	v_bfe_u32 v53, v20, 24, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_cvt_f32_ubyte0_e32 v53, v53
	v_fmac_f32_e32 v50, v52, v46
	v_lshl_add_u32 v46, v54, 20, 0x3c000000
	v_bfe_u32 v52, v20, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v50, v51, v60 :: v_dual_cndmask_b32 v45, v45, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_lshl_add_u32 v46, v52, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v51, 0x3b000000, v53 :: v_dual_fmac_f32 v50, v42, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v42, 0x7fc00000, v45, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	v_dual_fmac_f32 v50, v44, v61 :: v_dual_lshlrev_b32 v45, 8, v20
	v_lshlrev_b32_e32 v44, 16, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v46, v51, v46, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_and_or_b32 v42, 0x80000000, v45, v42
	v_dual_fmac_f32 v50, v43, v48 :: v_dual_and_b32 v43, 0xffff0000, v49
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v45, 0x7fc00000, v46 :: v_dual_fmac_f32 v50, v42, v44
	v_or_b32_e32 v42, 32, v41
	v_and_or_b32 v45, 0x80000000, v20, v45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v50, v45, v43
	v_add_f32_e32 v0, v0, v50
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s12, v42
	s_cbranch_execz .LBB317_68
; %bb.74:                               ;   in Loop: Header=BB317_70 Depth=1
	v_lshl_add_u32 v46, v42, 5, 0
	s_wait_loadcnt 0x2
	v_bfe_u32 v52, v21, 8, 3
	v_bfe_u32 v53, v21, 8, 7
	v_bfe_u32 v62, v21, 16, 3
	v_bfe_u32 v66, v22, 8, 7
	ds_load_b128 v[42:45], v46
	ds_load_b128 v[46:49], v46 offset:16
	v_cvt_f32_ubyte0_e32 v52, v52
	v_bfe_u32 v71, v23, 8, 3
	s_mov_b32 s11, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v52, 0x3b000000, v52 :: v_dual_lshlrev_b32 v63, 16, v21
	v_and_b32_e32 v50, 7, v21
	v_cvt_f32_ubyte0_e32 v71, v71
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v50, v50
	s_wait_dscnt 0x1
	v_dual_mul_f32 v50, 0x3b000000, v50 :: v_dual_lshlrev_b32 v57, 16, v44
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v59, 16, v46
	v_and_b32_e32 v51, 0x7f, v21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v54, v51, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v51
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, v50, v54, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v51
	v_lshlrev_b32_e32 v61, 16, v48
	v_lshl_add_u32 v54, v53, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v50, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v52, v54, vcc_lo
	v_bfe_u32 v52, v21, 16, 7
	v_cvt_f32_ubyte0_e32 v54, v62
	v_lshlrev_b32_e32 v62, 24, v21
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v58, 16, v45
	v_lshl_add_u32 v53, v52, 20, 0x3c000000
	v_mul_f32_e32 v54, 0x3b000000, v54
	v_and_or_b32 v50, 0x80000000, v62, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v51, vcc_lo
	v_bfe_u32 v62, v21, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	v_lshlrev_b32_e32 v56, 16, v43
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v51, 0x80000000, v63, v51
	v_cvt_f32_ubyte0_e32 v62, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, v54, v53, vcc_lo
	v_bfe_u32 v54, v21, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_and_b32_e32 v63, 7, v22
	v_mul_f32_e32 v62, 0x3b000000, v62
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v64, v54, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v53, vcc_lo
	v_lshlrev_b32_e32 v53, 8, v21
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_and_b32_e32 v55, 0xffff0000, v42
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v52, 0x80000000, v53, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v64, vcc_lo
	v_bfe_u32 v64, v22, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_cvt_f32_ubyte0_e32 v53, v63
	v_lshlrev_b32_e32 v60, 16, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v54, 0x7fc00000, v62, vcc_lo
	v_cvt_f32_ubyte0_e32 v62, v64
	v_bfe_u32 v64, v22, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v53, 0x3b000000, v53 :: v_dual_mul_f32 v62, 0x3b000000, v62
	v_cvt_f32_ubyte0_e32 v64, v64
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v64, 0x3b000000, v64
	v_and_b32_e32 v65, 0x7f, v22
	v_lshl_add_u32 v63, v65, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v53, v53, v63 :: v_dual_and_b32 v44, 0xffff0000, v44
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshl_add_u32 v63, v66, 20, 0x3c000000
	v_bfe_u32 v65, v22, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v53, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_and_b32_e32 v45, 0xffff0000, v45
	v_lshl_add_u32 v67, v65, 20, 0x3c000000
	v_fma_f32 v50, v50, v42, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_lshlrev_b32_e32 v66, 16, v22
	v_fmac_f32_e32 v50, v51, v55
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v62, 0x7fc00000, v62 :: v_dual_lshlrev_b32 v55, 8, v23
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v50, v52, v56
	v_and_or_b32 v62, 0x80000000, v66, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshlrev_b32_e32 v63, 24, v22
	v_and_b32_e32 v65, 7, v23
	v_bfe_u32 v66, v22, 24, 7
	v_and_b32_e32 v67, 0x7f, v23
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_and_or_b32 v53, 0x80000000, v63, v53
	v_bfe_u32 v63, v22, 24, 3
	v_cvt_f32_ubyte0_e32 v65, v65
	v_lshl_add_u32 v69, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_lshl_add_u32 v70, v67, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v63, v63
	v_mul_f32_e32 v65, 0x3b000000, v65
	v_and_or_b32 v54, 0x80000000, v21, v54
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v63, 0x3b000000, v63
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v63, v63, v69 :: v_dual_and_b32 v46, 0xffff0000, v46
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v48, 0xffff0000, v48
	v_bfe_u32 v69, v23, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v70, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v66, v69, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, 0x7fc00000, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v68, 8, v22
	v_lshlrev_b32_e32 v67, 24, v23
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v63, 0x80000000, v22, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_and_or_b32 v64, 0x80000000, v68, v64
	v_bfe_u32 v68, v23, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v65, 0x80000000, v67, v65
	v_bfe_u32 v67, v23, 16, 3
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v67, v67
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_mul_f32 v67, 0x3b000000, v67
	v_mul_f32_e32 v70, 0x3b000000, v71
	v_and_b32_e32 v43, 0xffff0000, v43
	v_bfe_u32 v71, v23, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v66, v70, v66, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	v_bfe_u32 v69, v23, 16, 7
	v_lshl_add_u32 v42, v71, 20, 0x3c000000
	v_fmac_f32_e32 v50, v54, v43
	v_bfe_u32 v43, v24, 8, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v66, vcc_lo
	v_lshl_add_u32 v72, v69, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	v_fmac_f32_e32 v50, v53, v57
	v_cvt_f32_ubyte0_e32 v43, v43
	v_bfe_u32 v53, v24, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v67, v72, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	v_dual_fmac_f32 v50, v62, v44 :: v_dual_and_b32 v47, 0xffff0000, v47
	v_mul_f32_e32 v43, 0x3b000000, v43
	v_lshl_add_u32 v44, v53, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v42, v68, v42, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v50, v64, v58 :: v_dual_cndmask_b32 v51, 0x7fc00000, v67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v50, v63, v45
	v_bfe_u32 v45, v24, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	v_and_or_b32 v51, 0x80000000, v55, v51
	v_and_b32_e32 v55, 7, v24
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v45, v45
	v_fmac_f32_e32 v50, v65, v59
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v42, 0x7fc00000, v42, vcc_lo
	v_cvt_f32_ubyte0_e32 v55, v55
	v_mul_f32_e32 v45, 0x3b000000, v45
	v_and_b32_e32 v54, 0x7f, v24
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v42, 0x80000000, v23, v42
	v_mul_f32_e32 v55, 0x3b000000, v55
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v56, v54, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v55, v55, v56 :: v_dual_lshlrev_b32 v70, 16, v23
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v52, 0x80000000, v70, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v43, v43, v44, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v54, 24, v24
	v_lshlrev_b32_e32 v53, 16, v24
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v43, 0x7fc00000, v43, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v44, 0x80000000, v54, v44
	v_bfe_u32 v54, v24, 16, 7
	v_and_or_b32 v43, 0x80000000, v53, v43
	v_bfe_u32 v53, v24, 24, 3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_cvt_f32_ubyte0_e32 v53, v53
	v_fmac_f32_e32 v50, v52, v46
	v_lshl_add_u32 v46, v54, 20, 0x3c000000
	v_bfe_u32 v52, v24, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v50, v51, v60 :: v_dual_cndmask_b32 v45, v45, v46
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_lshl_add_u32 v46, v52, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v51, 0x3b000000, v53 :: v_dual_fmac_f32 v50, v42, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v42, 0x7fc00000, v45, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	v_dual_fmac_f32 v50, v44, v61 :: v_dual_lshlrev_b32 v45, 8, v24
	v_lshlrev_b32_e32 v44, 16, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v46, v51, v46, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_and_or_b32 v42, 0x80000000, v45, v42
	v_dual_fmac_f32 v50, v43, v48 :: v_dual_and_b32 v43, 0xffff0000, v49
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v45, 0x7fc00000, v46 :: v_dual_fmac_f32 v50, v42, v44
	v_or_b32_e32 v42, 64, v41
	v_and_or_b32 v45, 0x80000000, v24, v45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v50, v45, v43
	v_add_f32_e32 v0, v0, v50
	s_delay_alu instid0(VALU_DEP_4)
	v_cmpx_gt_i32_e64 s12, v42
	s_cbranch_execz .LBB317_67
; %bb.75:                               ;   in Loop: Header=BB317_70 Depth=1
	v_lshl_add_u32 v46, v42, 5, 0
	s_wait_loadcnt 0x1
	v_bfe_u32 v52, v25, 8, 3
	v_bfe_u32 v53, v25, 8, 7
	v_bfe_u32 v62, v25, 16, 3
	v_bfe_u32 v66, v26, 8, 7
	ds_load_b128 v[42:45], v46
	ds_load_b128 v[46:49], v46 offset:16
	v_cvt_f32_ubyte0_e32 v52, v52
	v_bfe_u32 v71, v27, 8, 3
	v_or_b32_e32 v41, 0x60, v41
	s_mov_b32 s14, exec_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v52, 0x3b000000, v52 :: v_dual_lshlrev_b32 v63, 16, v25
	v_and_b32_e32 v50, 7, v25
	v_cvt_f32_ubyte0_e32 v71, v71
	v_cvt_f32_ubyte0_e32 v50, v50
	s_wait_dscnt 0x1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v50, 0x3b000000, v50 :: v_dual_lshlrev_b32 v57, 16, v44
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v59, 16, v46
	v_and_b32_e32 v51, 0x7f, v25
	v_lshl_add_u32 v54, v51, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v51
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v50, v50, v54, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v51
	v_lshlrev_b32_e32 v61, 16, v48
	v_lshl_add_u32 v54, v53, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v50, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, v52, v54, vcc_lo
	v_bfe_u32 v52, v25, 16, 7
	v_cvt_f32_ubyte0_e32 v54, v62
	v_lshlrev_b32_e32 v62, 24, v25
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v58, 16, v45
	v_lshl_add_u32 v53, v52, 20, 0x3c000000
	v_mul_f32_e32 v54, 0x3b000000, v54
	v_and_or_b32 v50, 0x80000000, v62, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v51, vcc_lo
	v_bfe_u32 v62, v25, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	v_lshlrev_b32_e32 v56, 16, v43
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_and_or_b32 v51, 0x80000000, v63, v51
	v_cvt_f32_ubyte0_e32 v62, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, v54, v53, vcc_lo
	v_bfe_u32 v54, v25, 24, 7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_and_b32_e32 v63, 7, v26
	v_mul_f32_e32 v62, 0x3b000000, v62
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v64, v54, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v53, vcc_lo
	v_lshlrev_b32_e32 v53, 8, v25
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_and_b32_e32 v55, 0xffff0000, v42
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v52, 0x80000000, v53, v52
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v64, vcc_lo
	v_bfe_u32 v64, v26, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_cvt_f32_ubyte0_e32 v53, v63
	v_lshlrev_b32_e32 v60, 16, v47
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v54, 0x7fc00000, v62, vcc_lo
	v_cvt_f32_ubyte0_e32 v62, v64
	v_bfe_u32 v64, v26, 16, 3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_mul_f32 v53, 0x3b000000, v53 :: v_dual_mul_f32 v62, 0x3b000000, v62
	v_cvt_f32_ubyte0_e32 v64, v64
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v64, 0x3b000000, v64
	v_and_b32_e32 v65, 0x7f, v26
	v_lshl_add_u32 v63, v65, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v53, v53, v63 :: v_dual_and_b32 v44, 0xffff0000, v44
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshlrev_b32_e32 v42, 16, v42
	v_lshl_add_u32 v63, v66, 20, 0x3c000000
	v_bfe_u32 v65, v26, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v53, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_and_b32_e32 v45, 0xffff0000, v45
	v_lshl_add_u32 v67, v65, 20, 0x3c000000
	v_fma_f32 v42, v50, v42, 0
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, v62, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_lshlrev_b32_e32 v66, 16, v26
	v_fmac_f32_e32 v42, v51, v55
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v62, 0x7fc00000, v62 :: v_dual_lshlrev_b32 v55, 8, v27
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v42, v52, v56
	v_and_or_b32 v62, 0x80000000, v66, v62
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshlrev_b32_e32 v63, 24, v26
	v_and_b32_e32 v65, 7, v27
	v_bfe_u32 v66, v26, 24, 7
	v_and_b32_e32 v67, 0x7f, v27
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_and_or_b32 v53, 0x80000000, v63, v53
	v_bfe_u32 v63, v26, 24, 3
	v_cvt_f32_ubyte0_e32 v65, v65
	v_lshl_add_u32 v69, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_lshl_add_u32 v70, v67, 20, 0x3c000000
	v_cvt_f32_ubyte0_e32 v63, v63
	v_mul_f32_e32 v65, 0x3b000000, v65
	v_and_or_b32 v54, 0x80000000, v25, v54
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v63, 0x3b000000, v63
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v63, v63, v69 :: v_dual_and_b32 v46, 0xffff0000, v46
	v_cmp_lt_u32_e32 vcc_lo, 7, v67
	v_and_b32_e32 v48, 0xffff0000, v48
	v_bfe_u32 v69, v27, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v70, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v66, v69, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, 0x7fc00000, v63, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v67
	v_lshlrev_b32_e32 v68, 8, v26
	v_lshlrev_b32_e32 v67, 24, v27
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v63, 0x80000000, v26, v63
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_and_or_b32 v64, 0x80000000, v68, v64
	v_bfe_u32 v68, v27, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_and_or_b32 v65, 0x80000000, v67, v65
	v_bfe_u32 v67, v27, 16, 3
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v67, v67
	v_dual_mul_f32 v68, 0x3b000000, v68 :: v_dual_mul_f32 v67, 0x3b000000, v67
	v_mul_f32_e32 v70, 0x3b000000, v71
	v_and_b32_e32 v43, 0xffff0000, v43
	v_bfe_u32 v71, v27, 24, 7
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v66, v70, v66, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	v_bfe_u32 v69, v27, 16, 7
	v_lshl_add_u32 v50, v71, 20, 0x3c000000
	v_fmac_f32_e32 v42, v54, v43
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v66, vcc_lo
	v_lshl_add_u32 v72, v69, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v69
	v_fmac_f32_e32 v42, v53, v57
	v_bfe_u32 v53, v28, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v67, v72, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v71
	v_dual_fmac_f32 v42, v62, v44 :: v_dual_and_b32 v47, 0xffff0000, v47
	v_lshl_add_u32 v44, v53, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, v68, v50, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v69
	s_wait_alu 0xfffd
	v_dual_fmac_f32 v42, v64, v58 :: v_dual_cndmask_b32 v51, 0x7fc00000, v67
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v71
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v42, v63, v45
	v_bfe_u32 v45, v28, 16, 3
	v_and_or_b32 v51, 0x80000000, v55, v51
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v50, 0x7fc00000, v50 :: v_dual_and_b32 v55, 7, v28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v45, v45
	v_fmac_f32_e32 v42, v65, v59
	v_cvt_f32_ubyte0_e32 v55, v55
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_and_or_b32 v43, 0x80000000, v27, v50
	v_bfe_u32 v50, v28, 8, 3
	v_mul_f32_e32 v45, 0x3b000000, v45
	v_and_b32_e32 v54, 0x7f, v28
	v_mul_f32_e32 v55, 0x3b000000, v55
	v_cvt_f32_ubyte0_e32 v50, v50
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v56, v54, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_lshlrev_b32_e32 v70, 16, v27
	s_wait_alu 0xfffd
	v_dual_mul_f32 v50, 0x3b000000, v50 :: v_dual_cndmask_b32 v55, v55, v56
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v52, 0x80000000, v70, v66
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	v_fmac_f32_e32 v42, v52, v46
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, v50, v44, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_lshlrev_b32_e32 v54, 24, v28
	v_bfe_u32 v52, v28, 24, 7
	v_fmac_f32_e32 v42, v51, v60
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v55, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v42, v43, v47 :: v_dual_lshlrev_b32 v53, 16, v28
	v_lshlrev_b32_e32 v47, 16, v49
	v_and_or_b32 v50, 0x80000000, v54, v50
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, 0x7fc00000, v44, vcc_lo
	v_bfe_u32 v54, v28, 16, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v42, v50, v61
	v_and_or_b32 v44, 0x80000000, v53, v44
	v_bfe_u32 v53, v28, 24, 3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v46, v54, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v54
	v_fmac_f32_e32 v42, v44, v48
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_ubyte0_e32 v53, v53
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v45, v45, v46 :: v_dual_and_b32 v44, 0xffff0000, v49
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v54
	v_lshl_add_u32 v46, v52, 20, 0x3c000000
	v_mul_f32_e32 v51, 0x3b000000, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v43, 0x7fc00000, v45, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v46, v51, v46 :: v_dual_lshlrev_b32 v45, 8, v28
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v43, 0x80000000, v45, v43
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v45, 0x7fc00000, v46 :: v_dual_fmac_f32 v42, v43, v47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_or_b32 v45, 0x80000000, v28, v45
	v_fmac_f32_e32 v42, v45, v44
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v0, v0, v42
	v_cmpx_gt_i32_e64 s12, v41
	s_cbranch_execz .LBB317_66
; %bb.76:                               ;   in Loop: Header=BB317_70 Depth=1
	v_lshl_add_u32 v45, v41, 5, 0
	s_wait_loadcnt 0x0
	v_and_b32_e32 v49, 7, v29
	v_and_b32_e32 v50, 0x7f, v29
	v_bfe_u32 v51, v29, 8, 3
	v_bfe_u32 v52, v29, 8, 7
	ds_load_b128 v[41:44], v45
	ds_load_b128 v[45:48], v45 offset:16
	v_cvt_f32_ubyte0_e32 v49, v49
	v_lshl_add_u32 v53, v50, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v50
	v_cvt_f32_ubyte0_e32 v51, v51
	v_bfe_u32 v61, v29, 16, 3
	v_mul_f32_e32 v49, 0x3b000000, v49
	v_bfe_u32 v65, v30, 8, 7
	v_bfe_u32 v70, v31, 8, 3
	v_mul_f32_e32 v51, 0x3b000000, v51
	s_delay_alu instid0(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v70, v70
	s_wait_dscnt 0x1
	v_lshlrev_b32_e32 v56, 16, v43
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v49, v49, v53 :: v_dual_lshlrev_b32 v60, 16, v47
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v50
	v_lshlrev_b32_e32 v58, 16, v45
	v_lshl_add_u32 v53, v52, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, 0x7fc00000, v49, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v50, v51, v53 :: v_dual_lshlrev_b32 v55, 16, v42
	v_bfe_u32 v51, v29, 16, 7
	v_cvt_f32_ubyte0_e32 v53, v61
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_lshlrev_b32_e32 v61, 24, v29
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v52, v51, 20, 0x3c000000
	v_mul_f32_e32 v53, 0x3b000000, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v50, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v51
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v52, v53, v52 :: v_dual_and_b32 v43, 0xffff0000, v43
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v51
	v_lshlrev_b32_e32 v62, 16, v29
	v_bfe_u32 v53, v29, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v51, 0x7fc00000, v52, vcc_lo
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v50, 0x80000000, v62, v50
	v_and_b32_e32 v62, 7, v30
	v_and_or_b32 v49, 0x80000000, v61, v49
	v_bfe_u32 v61, v29, 24, 3
	v_lshl_add_u32 v63, v53, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v61, v61
	v_mul_f32_e32 v61, 0x3b000000, v61
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v61, v61, v63, vcc_lo
	v_bfe_u32 v63, v30, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v53, 0x7fc00000, v61, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v61, v63
	v_bfe_u32 v63, v30, 16, 3
	v_mul_f32_e32 v61, 0x3b000000, v61
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v63, v63
	v_dual_mul_f32 v63, 0x3b000000, v63 :: v_dual_lshlrev_b32 v52, 8, v29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v51, 0x80000000, v52, v51
	v_and_b32_e32 v64, 0x7f, v30
	v_cvt_f32_ubyte0_e32 v52, v62
	v_lshlrev_b32_e32 v59, 16, v46
	v_lshl_add_u32 v62, v64, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v52, 0x3b000000, v52
	v_cmp_lt_u32_e32 vcc_lo, 7, v64
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v52, v52, v62 :: v_dual_lshlrev_b32 v57, 16, v44
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v64
	v_lshl_add_u32 v62, v65, 20, 0x3c000000
	v_bfe_u32 v64, v30, 16, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v52, 0x7fc00000, v52, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	v_and_b32_e32 v54, 0xffff0000, v41
	v_lshl_add_u32 v66, v64, 20, 0x3c000000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v61, v61, v62, vcc_lo
	v_lshlrev_b32_e32 v62, 24, v30
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	v_lshlrev_b32_e32 v65, 16, v30
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v52, 0x80000000, v62, v52
	v_bfe_u32 v62, v30, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v61, 0x7fc00000, v61, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v64
	v_and_b32_e32 v44, 0xffff0000, v44
	v_cvt_f32_ubyte0_e32 v62, v62
	v_lshlrev_b32_e32 v41, 16, v41
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, v63, v66, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v64
	v_and_b32_e32 v64, 7, v31
	v_mul_f32_e32 v62, 0x3b000000, v62
	v_fma_f32 v41, v49, v41, 0
	v_and_b32_e32 v66, 0x7f, v31
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v63, 0x7fc00000, v63, vcc_lo
	v_cvt_f32_ubyte0_e32 v64, v64
	v_dual_fmac_f32 v41, v50, v54 :: v_dual_lshlrev_b32 v54, 8, v31
	v_and_or_b32 v61, 0x80000000, v65, v61
	v_bfe_u32 v65, v30, 24, 7
	v_lshl_add_u32 v69, v66, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v64, 0x3b000000, v64 :: v_dual_fmac_f32 v41, v51, v55
	v_lshl_add_u32 v68, v65, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v65
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_cndmask_b32 v62, v62, v68 :: v_dual_and_b32 v45, 0xffff0000, v45
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	v_and_b32_e32 v47, 0xffff0000, v47
	v_bfe_u32 v68, v31, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, v64, v69, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v65
	s_delay_alu instid0(VALU_DEP_3)
	v_lshl_add_u32 v65, v68, 20, 0x3c000000
	v_mul_f32_e32 v69, 0x3b000000, v70
	v_bfe_u32 v70, v31, 24, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v62, 0x7fc00000, v62, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_lshlrev_b32_e32 v66, 24, v31
	v_lshl_add_u32 v49, v70, 20, 0x3c000000
	v_and_or_b32 v53, 0x80000000, v29, v53
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v64, 0x7fc00000, v64, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_and_b32_e32 v42, 0xffff0000, v42
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v64, 0x80000000, v66, v64
	v_bfe_u32 v66, v31, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v69, v65, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	v_bfe_u32 v68, v31, 16, 7
	v_fmac_f32_e32 v41, v53, v42
	v_cvt_f32_ubyte0_e32 v66, v66
	v_lshlrev_b32_e32 v69, 16, v31
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, 0x7fc00000, v65, vcc_lo
	v_lshl_add_u32 v71, v68, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v68
	v_mul_f32_e32 v66, 0x3b000000, v66
	v_lshlrev_b32_e32 v67, 8, v30
	v_fmac_f32_e32 v41, v52, v56
	v_and_or_b32 v62, 0x80000000, v30, v62
	v_bfe_u32 v52, v32, 8, 7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, v66, v71, vcc_lo
	v_and_or_b32 v63, 0x80000000, v67, v63
	v_bfe_u32 v67, v31, 24, 3
	v_cmp_lt_u32_e32 vcc_lo, 7, v70
	v_fmac_f32_e32 v41, v61, v43
	v_lshl_add_u32 v43, v52, 20, 0x3c000000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v67, v67
	v_fmac_f32_e32 v41, v63, v57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v67, 0x3b000000, v67
	v_dual_fmac_f32 v41, v62, v44 :: v_dual_and_b32 v46, 0xffff0000, v46
	v_bfe_u32 v44, v32, 16, 3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3)
	v_cndmask_b32_e32 v49, v67, v49, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v68
	v_fmac_f32_e32 v41, v64, v58
	v_cvt_f32_ubyte0_e32 v44, v44
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v50, 0x7fc00000, v66, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v70
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v44, 0x3b000000, v44
	v_and_b32_e32 v53, 0x7f, v32
	v_and_or_b32 v50, 0x80000000, v54, v50
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v49, 0x7fc00000, v49 :: v_dual_and_b32 v54, 7, v32
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v55, v53, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	v_cvt_f32_ubyte0_e32 v54, v54
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v42, 0x80000000, v31, v49
	v_bfe_u32 v49, v32, 8, 3
	v_mul_f32_e32 v54, 0x3b000000, v54
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v49, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v54, v54, v55, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v52
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v49, 0x3b000000, v49
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v43, v49, v43, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshlrev_b32_e32 v53, 24, v32
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v49, 0x7fc00000, v54, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v52
	v_lshlrev_b32_e32 v52, 16, v32
	v_and_or_b32 v51, 0x80000000, v69, v65
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v49, 0x80000000, v53, v49
	v_bfe_u32 v53, v32, 16, 7
	v_fmac_f32_e32 v41, v51, v45
	v_bfe_u32 v51, v32, 24, 7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshl_add_u32 v45, v53, 20, 0x3c000000
	v_fmac_f32_e32 v41, v50, v59
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v41, v42, v46 :: v_dual_lshlrev_b32 v46, 16, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v43, 0x7fc00000, v43, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v53
	v_fmac_f32_e32 v41, v49, v60
	s_delay_alu instid0(VALU_DEP_3)
	v_and_or_b32 v43, 0x80000000, v52, v43
	v_bfe_u32 v52, v32, 24, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v44, v44, v45, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v53
	v_lshl_add_u32 v45, v51, 20, 0x3c000000
	v_fmac_f32_e32 v41, v43, v47
	v_cvt_f32_ubyte0_e32 v52, v52
	v_and_b32_e32 v43, 0xffff0000, v48
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v42, 0x7fc00000, v44, vcc_lo
	v_cmp_lt_u32_e32 vcc_lo, 7, v51
	v_lshlrev_b32_e32 v44, 8, v32
	v_mul_f32_e32 v50, 0x3b000000, v52
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_and_or_b32 v42, 0x80000000, v44, v42
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v45, v50, v45, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v51
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v41, v42, v46 :: v_dual_cndmask_b32 v44, 0x7fc00000, v45
	v_and_or_b32 v44, 0x80000000, v32, v44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v41, v44, v43
	v_add_f32_e32 v0, v0, v41
	s_branch .LBB317_66
.LBB317_77:
	s_wait_loadcnt 0x3
	v_mbcnt_lo_u32_b32 v17, -1, 0
	s_mov_b32 s8, 0
	s_mov_b32 s0, exec_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_xor_b32_e32 v18, 16, v17
	v_xor_b32_e32 v19, 8, v17
	v_cmp_gt_i32_e32 vcc_lo, 32, v18
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v18, v17, v18, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v19, v17, v19, vcc_lo
	v_lshlrev_b32_e32 v19, 2, v19
	v_lshlrev_b32_e32 v18, 2, v18
	ds_bpermute_b32 v18, v18, v0
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v18
	ds_bpermute_b32 v18, v19, v0
	v_xor_b32_e32 v19, 4, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v19, v17, v19, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v0, v0, v18 :: v_dual_lshlrev_b32 v19, 2, v19
	ds_bpermute_b32 v18, v19, v0
	v_xor_b32_e32 v19, 2, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v19
	s_wait_dscnt 0x0
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v19, v17, v19 :: v_dual_add_f32 v0, v0, v18
	v_lshlrev_b32_e32 v19, 2, v19
	ds_bpermute_b32 v18, v19, v0
	v_xor_b32_e32 v19, 1, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v17, v17, v19, vcc_lo
	s_wait_dscnt 0x0
	v_dual_add_f32 v0, v0, v18 :: v_dual_lshlrev_b32 v17, 2, v17
	ds_bpermute_b32 v17, v17, v0
	v_cmpx_eq_u32_e32 0, v37
	s_cbranch_execz .LBB317_83
; %bb.78:
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v17, s1, v0
	v_and_b32_e32 v0, 0x7fffffff, v17
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s9, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s9, exec_lo, s9
; %bb.79:
	v_bfe_u32 v0, v17, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v17, v0, 0x7fff
                                        ; implicit-def: $vgpr17
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.80:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s9, s9
; %bb.81:
	v_lshrrev_b32_e32 v0, 16, v17
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.82:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s9
	v_lshlrev_b64_e32 v[17:18], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v17, vcc_lo, s16, v17
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, s17, v18, vcc_lo
	global_store_b16 v[17:18], v0, off
.LBB317_83:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
.LBB317_84:
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 vcc_lo, exec_lo, s8
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB317_111
; %bb.85:
	s_wait_dscnt 0x0
	v_mov_b32_e32 v17, 0
	s_and_not1_b32 vcc_lo, exec_lo, s7
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB317_105
; %bb.86:
	v_mov_b32_e32 v17, 0
	s_and_saveexec_b32 s0, s5
	s_cbranch_execz .LBB317_94
; %bb.87:
	v_lshl_add_u32 v0, v37, 5, 0
	s_wait_loadcnt 0x2
	v_perm_b32 v21, 0, v13, 0x10c000c
	v_perm_b32 v13, 0, v13, 0x30c020c
	s_wait_loadcnt 0x1
	v_perm_b32 v27, 0, v14, 0x10c000c
	v_perm_b32 v14, 0, v14, 0x30c020c
	ds_load_b128 v[17:20], v0
	v_lshrrev_b32_e32 v25, 1, v21
	v_and_b32_e32 v26, 0x80008000, v21
	ds_load_b128 v[21:24], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	v_and_or_b32 v25, 0x3f803f80, v25, v26
	v_lshrrev_b32_e32 v26, 1, v27
	v_and_b32_e32 v27, 0x80008000, v27
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v0, 0x3f803f80, v0, v13
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v13, v25, v17, 0
	v_perm_b32 v17, 0, v15, 0x10c000c
	v_and_or_b32 v25, 0x3f803f80, v26, v27
	v_lshrrev_b32_e32 v26, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_dot2_f32_f16 v0, v0, v18, v13
	v_lshrrev_b32_e32 v13, 1, v17
	v_and_b32_e32 v17, 0x80008000, v17
	v_perm_b32 v15, 0, v15, 0x30c020c
	v_and_or_b32 v14, 0x3f803f80, v26, v14
	v_dot2_f32_f16 v0, v25, v19, v0
	v_perm_b32 v18, 0, v16, 0x10c000c
	v_and_or_b32 v13, 0x3f803f80, v13, v17
	v_lshrrev_b32_e32 v17, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	v_dot2_f32_f16 v0, v14, v20, v0
	v_lshrrev_b32_e32 v14, 1, v18
	v_and_b32_e32 v18, 0x80008000, v18
	v_perm_b32 v16, 0, v16, 0x30c020c
	v_and_or_b32 v15, 0x3f803f80, v17, v15
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v13, v21, v0
	v_and_or_b32 v13, 0x3f803f80, v14, v18
	v_lshrrev_b32_e32 v14, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v0, v15, v22, v0
	v_and_or_b32 v14, 0x3f803f80, v14, v16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v0, v13, v23, v0
	v_dot2_f32_f16 v17, v14, v24, v0
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB317_93
; %bb.88:
	v_lshl_add_u32 v0, v40, 5, 0
	v_perm_b32 v18, 0, v9, 0x10c000c
	v_perm_b32 v9, 0, v9, 0x30c020c
	v_perm_b32 v24, 0, v10, 0x10c000c
	v_perm_b32 v10, 0, v10, 0x30c020c
	ds_load_b128 v[13:16], v0
	v_lshrrev_b32_e32 v22, 1, v18
	v_and_b32_e32 v23, 0x80008000, v18
	ds_load_b128 v[18:21], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_and_or_b32 v22, 0x3f803f80, v22, v23
	v_lshrrev_b32_e32 v23, 1, v24
	v_and_b32_e32 v24, 0x80008000, v24
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v0, 0x3f803f80, v0, v9
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v9, v22, v13, v17
	v_perm_b32 v13, 0, v11, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v23, v24
	v_lshrrev_b32_e32 v22, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_dot2_f32_f16 v0, v0, v14, v9
	v_lshrrev_b32_e32 v9, 1, v13
	v_and_b32_e32 v13, 0x80008000, v13
	v_perm_b32 v11, 0, v11, 0x30c020c
	v_and_or_b32 v10, 0x3f803f80, v22, v10
	v_dot2_f32_f16 v0, v17, v15, v0
	v_perm_b32 v14, 0, v12, 0x10c000c
	v_and_or_b32 v9, 0x3f803f80, v9, v13
	v_lshrrev_b32_e32 v13, 1, v11
	v_and_b32_e32 v11, 0x80008000, v11
	v_dot2_f32_f16 v0, v10, v16, v0
	v_lshrrev_b32_e32 v10, 1, v14
	v_and_b32_e32 v14, 0x80008000, v14
	v_perm_b32 v12, 0, v12, 0x30c020c
	v_and_or_b32 v11, 0x3f803f80, v13, v11
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v9, v18, v0
	v_and_or_b32 v9, 0x3f803f80, v10, v14
	v_lshrrev_b32_e32 v10, 1, v12
	v_and_b32_e32 v12, 0x80008000, v12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v0, v11, v19, v0
	v_and_or_b32 v10, 0x3f803f80, v10, v12
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v0, v9, v20, v0
	v_dot2_f32_f16 v17, v10, v21, v0
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB317_92
; %bb.89:
	v_lshl_add_u32 v0, v39, 5, 0
	v_perm_b32 v13, 0, v5, 0x10c000c
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_perm_b32 v20, 0, v6, 0x10c000c
	v_perm_b32 v6, 0, v6, 0x30c020c
	ds_load_b128 v[9:12], v0
	v_lshrrev_b32_e32 v18, 1, v13
	v_and_b32_e32 v19, 0x80008000, v13
	ds_load_b128 v[13:16], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_and_or_b32 v18, 0x3f803f80, v18, v19
	v_lshrrev_b32_e32 v19, 1, v20
	v_and_b32_e32 v20, 0x80008000, v20
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v0, 0x3f803f80, v0, v5
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v5, v18, v9, v17
	v_perm_b32 v9, 0, v7, 0x10c000c
	v_and_or_b32 v17, 0x3f803f80, v19, v20
	v_lshrrev_b32_e32 v18, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_dot2_f32_f16 v0, v0, v10, v5
	v_lshrrev_b32_e32 v5, 1, v9
	v_and_b32_e32 v9, 0x80008000, v9
	v_perm_b32 v7, 0, v7, 0x30c020c
	v_and_or_b32 v6, 0x3f803f80, v18, v6
	v_dot2_f32_f16 v0, v17, v11, v0
	v_perm_b32 v10, 0, v8, 0x10c000c
	v_and_or_b32 v5, 0x3f803f80, v5, v9
	v_lshrrev_b32_e32 v9, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_dot2_f32_f16 v0, v6, v12, v0
	v_lshrrev_b32_e32 v6, 1, v10
	v_and_b32_e32 v10, 0x80008000, v10
	v_perm_b32 v8, 0, v8, 0x30c020c
	v_and_or_b32 v7, 0x3f803f80, v9, v7
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v5, v13, v0
	v_and_or_b32 v5, 0x3f803f80, v6, v10
	v_lshrrev_b32_e32 v6, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v0, v7, v14, v0
	v_and_or_b32 v6, 0x3f803f80, v6, v8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v0, v5, v15, v0
	v_dot2_f32_f16 v17, v6, v16, v0
	s_and_saveexec_b32 s3, s2
	s_cbranch_execz .LBB317_91
; %bb.90:
	v_lshl_add_u32 v0, v38, 5, 0
	v_perm_b32 v9, 0, v1, 0x10c000c
	v_perm_b32 v1, 0, v1, 0x30c020c
	v_perm_b32 v15, 0, v2, 0x10c000c
	v_perm_b32 v2, 0, v2, 0x30c020c
	ds_load_b128 v[5:8], v0
	v_lshrrev_b32_e32 v13, 1, v9
	v_and_b32_e32 v14, 0x80008000, v9
	ds_load_b128 v[9:12], v0 offset:16
	v_lshrrev_b32_e32 v0, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_and_or_b32 v13, 0x3f803f80, v13, v14
	v_lshrrev_b32_e32 v14, 1, v15
	v_and_b32_e32 v15, 0x80008000, v15
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v0, 0x3f803f80, v0, v1
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v13, v5, v17
	v_perm_b32 v5, 0, v3, 0x10c000c
	v_and_or_b32 v13, 0x3f803f80, v14, v15
	v_lshrrev_b32_e32 v14, 1, v2
	v_and_b32_e32 v2, 0x80008000, v2
	v_dot2_f32_f16 v0, v0, v6, v1
	v_lshrrev_b32_e32 v1, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_and_or_b32 v2, 0x3f803f80, v14, v2
	v_dot2_f32_f16 v0, v13, v7, v0
	v_perm_b32 v6, 0, v4, 0x10c000c
	v_and_or_b32 v1, 0x3f803f80, v1, v5
	v_lshrrev_b32_e32 v5, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_dot2_f32_f16 v0, v2, v8, v0
	v_lshrrev_b32_e32 v2, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	v_perm_b32 v4, 0, v4, 0x30c020c
	v_and_or_b32 v3, 0x3f803f80, v5, v3
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v0, v1, v9, v0
	v_and_or_b32 v1, 0x3f803f80, v2, v6
	v_lshrrev_b32_e32 v2, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v0, v3, v10, v0
	v_and_or_b32 v2, 0x3f803f80, v2, v4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v0, v1, v11, v0
	v_dot2_f32_f16 v17, v2, v12, v0
.LBB317_91:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB317_92:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_93:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB317_94:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	s_cmp_lt_u32 s13, 0x810
	s_cbranch_scc1 .LBB317_105
; %bb.95:
	v_lshlrev_b32_e32 v1, 5, v37
	v_or_b32_e32 v0, 0x80, v37
	s_add_co_i32 s0, s6, -1
	s_delay_alu instid0(VALU_DEP_2)
	v_add3_u32 v2, v1, 0, 0x1000
	s_branch .LBB317_100
.LBB317_96:                             ;   in Loop: Header=BB317_100 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
.LBB317_97:                             ;   in Loop: Header=BB317_100 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
.LBB317_98:                             ;   in Loop: Header=BB317_100 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s3
.LBB317_99:                             ;   in Loop: Header=BB317_100 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s2
	v_add_nc_u32_e32 v0, 0x80, v0
	v_add_nc_u32_e32 v2, 0x1000, v2
	s_add_co_i32 s0, s0, -1
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s0, 0
	s_cbranch_scc0 .LBB317_105
.LBB317_100:                            ; =>This Inner Loop Header: Depth=1
	s_mov_b32 s2, exec_lo
	v_cmpx_gt_i32_e64 s12, v0
	s_cbranch_execz .LBB317_99
; %bb.101:                              ;   in Loop: Header=BB317_100 Depth=1
	v_ashrrev_i32_e32 v1, 31, v0
	ds_load_b128 v[7:10], v2
	ds_load_b128 v[11:14], v2 offset:16
	v_lshlrev_b64_e32 v[3:4], 4, v[0:1]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v3, vcc_lo, v35, v3
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v4, null, v36, v4, vcc_lo
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v16, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v15, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_lshrrev_b32_e32 v18, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_and_or_b32 v1, 0x3f803f80, v15, v1
	v_lshrrev_b32_e32 v15, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v3, 0x3f803f80, v18, v3
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v7, v17
	v_perm_b32 v7, 0, v5, 0x10c000c
	v_and_or_b32 v15, 0x3f803f80, v15, v16
	v_lshrrev_b32_e32 v16, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_dot2_f32_f16 v1, v3, v8, v1
	v_lshrrev_b32_e32 v3, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_and_or_b32 v4, 0x3f803f80, v16, v4
	v_dot2_f32_f16 v1, v15, v9, v1
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v3, 0x3f803f80, v3, v7
	v_lshrrev_b32_e32 v7, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v1, v4, v10, v1
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v7, v5
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v3, v11, v1
	v_and_or_b32 v3, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v4, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v5, v5, v12, v1
	v_add_nc_u32_e32 v1, 32, v0
	v_and_or_b32 v4, 0x3f803f80, v4, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v3, v3, v13, v5
	v_cmp_gt_i32_e32 vcc_lo, s12, v1
	s_delay_alu instid0(VALU_DEP_2)
	v_dot2_f32_f16 v17, v4, v14, v3
	s_and_saveexec_b32 s3, vcc_lo
	s_cbranch_execz .LBB317_98
; %bb.102:                              ;   in Loop: Header=BB317_100 Depth=1
	v_cndmask_b32_e32 v3, 0, v1, vcc_lo
	ds_load_b128 v[7:10], v2 offset:1024
	ds_load_b128 v[11:14], v2 offset:1040
	v_ashrrev_i32_e32 v4, 31, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b64_e32 v[3:4], 4, v[3:4]
	v_add_co_u32 v3, vcc_lo, v35, v3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v4, null, v36, v4, vcc_lo
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v16, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v15, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_lshrrev_b32_e32 v18, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_and_or_b32 v1, 0x3f803f80, v15, v1
	v_lshrrev_b32_e32 v15, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v3, 0x3f803f80, v18, v3
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v7, v17
	v_perm_b32 v7, 0, v5, 0x10c000c
	v_and_or_b32 v15, 0x3f803f80, v15, v16
	v_lshrrev_b32_e32 v16, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_dot2_f32_f16 v1, v3, v8, v1
	v_lshrrev_b32_e32 v3, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_and_or_b32 v4, 0x3f803f80, v16, v4
	v_dot2_f32_f16 v1, v15, v9, v1
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v3, 0x3f803f80, v3, v7
	v_lshrrev_b32_e32 v7, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v1, v4, v10, v1
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v7, v5
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v3, v11, v1
	v_and_or_b32 v3, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v4, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v5, v5, v12, v1
	v_add_nc_u32_e32 v1, 64, v0
	v_and_or_b32 v4, 0x3f803f80, v4, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v3, v3, v13, v5
	v_cmp_gt_i32_e32 vcc_lo, s12, v1
	s_delay_alu instid0(VALU_DEP_2)
	v_dot2_f32_f16 v17, v4, v14, v3
	s_and_saveexec_b32 s4, vcc_lo
	s_cbranch_execz .LBB317_97
; %bb.103:                              ;   in Loop: Header=BB317_100 Depth=1
	v_cndmask_b32_e32 v3, 0, v1, vcc_lo
	ds_load_b128 v[7:10], v2 offset:2048
	ds_load_b128 v[11:14], v2 offset:2064
	v_ashrrev_i32_e32 v4, 31, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b64_e32 v[3:4], 4, v[3:4]
	v_add_co_u32 v3, vcc_lo, v35, v3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v4, null, v36, v4, vcc_lo
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v16, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v15, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_lshrrev_b32_e32 v18, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_and_or_b32 v1, 0x3f803f80, v15, v1
	v_lshrrev_b32_e32 v15, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v3, 0x3f803f80, v18, v3
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v7, v17
	v_perm_b32 v7, 0, v5, 0x10c000c
	v_and_or_b32 v15, 0x3f803f80, v15, v16
	v_lshrrev_b32_e32 v16, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_dot2_f32_f16 v1, v3, v8, v1
	v_lshrrev_b32_e32 v3, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_and_or_b32 v4, 0x3f803f80, v16, v4
	v_dot2_f32_f16 v1, v15, v9, v1
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v3, 0x3f803f80, v3, v7
	v_lshrrev_b32_e32 v7, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v1, v4, v10, v1
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v7, v5
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v3, v11, v1
	v_and_or_b32 v3, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v4, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v5, v5, v12, v1
	v_add_nc_u32_e32 v1, 0x60, v0
	v_and_or_b32 v4, 0x3f803f80, v4, v6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dot2_f32_f16 v3, v3, v13, v5
	v_cmp_gt_i32_e32 vcc_lo, s12, v1
	s_delay_alu instid0(VALU_DEP_2)
	v_dot2_f32_f16 v17, v4, v14, v3
	s_and_saveexec_b32 s5, vcc_lo
	s_cbranch_execz .LBB317_96
; %bb.104:                              ;   in Loop: Header=BB317_100 Depth=1
	v_cndmask_b32_e32 v3, 0, v1, vcc_lo
	ds_load_b128 v[7:10], v2 offset:3072
	ds_load_b128 v[11:14], v2 offset:3088
	v_ashrrev_i32_e32 v4, 31, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_lshlrev_b64_e32 v[3:4], 4, v[3:4]
	v_add_co_u32 v3, vcc_lo, v35, v3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_add_co_ci_u32_e64 v4, null, v36, v4, vcc_lo
	global_load_b128 v[3:6], v[3:4], off th:TH_LOAD_NT
	s_wait_loadcnt 0x0
	v_perm_b32 v1, 0, v3, 0x10c000c
	v_perm_b32 v3, 0, v3, 0x30c020c
	v_perm_b32 v16, 0, v4, 0x10c000c
	v_perm_b32 v4, 0, v4, 0x30c020c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v15, 1, v1
	v_and_b32_e32 v1, 0x80008000, v1
	v_lshrrev_b32_e32 v18, 1, v3
	v_and_b32_e32 v3, 0x80008000, v3
	v_and_or_b32 v1, 0x3f803f80, v15, v1
	v_lshrrev_b32_e32 v15, 1, v16
	v_and_b32_e32 v16, 0x80008000, v16
	s_delay_alu instid0(VALU_DEP_4)
	v_and_or_b32 v3, 0x3f803f80, v18, v3
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v1, v1, v7, v17
	v_perm_b32 v7, 0, v5, 0x10c000c
	v_and_or_b32 v15, 0x3f803f80, v15, v16
	v_lshrrev_b32_e32 v16, 1, v4
	v_and_b32_e32 v4, 0x80008000, v4
	v_dot2_f32_f16 v1, v3, v8, v1
	v_lshrrev_b32_e32 v3, 1, v7
	v_and_b32_e32 v7, 0x80008000, v7
	v_perm_b32 v5, 0, v5, 0x30c020c
	v_and_or_b32 v4, 0x3f803f80, v16, v4
	v_dot2_f32_f16 v1, v15, v9, v1
	v_perm_b32 v8, 0, v6, 0x10c000c
	v_and_or_b32 v3, 0x3f803f80, v3, v7
	v_lshrrev_b32_e32 v7, 1, v5
	v_and_b32_e32 v5, 0x80008000, v5
	v_dot2_f32_f16 v1, v4, v10, v1
	v_lshrrev_b32_e32 v4, 1, v8
	v_and_b32_e32 v8, 0x80008000, v8
	v_perm_b32 v6, 0, v6, 0x30c020c
	v_and_or_b32 v5, 0x3f803f80, v7, v5
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v1, v3, v11, v1
	v_and_or_b32 v3, 0x3f803f80, v4, v8
	v_lshrrev_b32_e32 v4, 1, v6
	v_and_b32_e32 v6, 0x80008000, v6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v1, v5, v12, v1
	v_and_or_b32 v4, 0x3f803f80, v4, v6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v1, v3, v13, v1
	v_dot2_f32_f16 v17, v4, v14, v1
	s_branch .LBB317_96
.LBB317_105:
	v_mbcnt_lo_u32_b32 v0, -1, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_xor_b32_e32 v1, 16, v0
	v_xor_b32_e32 v2, 8, v0
	v_xor_b32_e32 v3, 4, v0
	v_cmp_gt_i32_e32 vcc_lo, 32, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v2
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_delay_alu instid0(VALU_DEP_2)
	v_lshlrev_b32_e32 v2, 2, v2
	v_lshlrev_b32_e32 v1, 2, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo
	ds_bpermute_b32 v1, v1, v17
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v17, v1
	ds_bpermute_b32 v2, v2, v1
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	ds_bpermute_b32 v2, v3, v1
	v_xor_b32_e32 v3, 2, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo
	v_lshlrev_b32_e32 v3, 2, v3
	s_wait_dscnt 0x0
	v_add_f32_e32 v1, v1, v2
	ds_bpermute_b32 v2, v3, v1
	v_xor_b32_e32 v3, 1, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, v0, v3, vcc_lo
	v_cmp_eq_u32_e32 vcc_lo, 0, v37
	s_wait_dscnt 0x0
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v3, 2, v0
	ds_bpermute_b32 v1, v3, v0
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB317_111
; %bb.106:
	s_wait_dscnt 0x0
	v_add_f32_e32 v0, v0, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v0, 0x47800000, v0
	v_mul_f32_e32 v1, s1, v0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v0, 0x7fffffff, v1
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v0
                                        ; implicit-def: $vgpr0
	s_and_saveexec_b32 s0, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s0, exec_lo, s0
; %bb.107:
	v_bfe_u32 v0, v1, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v0, v1, v0, 0x7fff
                                        ; implicit-def: $vgpr1
	v_lshrrev_b32_e32 v0, 16, v0
; %bb.108:
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s0, s0
; %bb.109:
	v_lshrrev_b32_e32 v0, 16, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v0, 64, v0
; %bb.110:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s0
	v_lshlrev_b64_e32 v[1:2], 1, v[33:34]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v1, vcc_lo, s16, v1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo
	global_store_b16 v[1:2], v0, off
.LBB317_111:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 328
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 75
		.amdhsa_next_free_sgpr 30
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 213
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii,"axG",@progbits,_ZN12_GLOBAL__N_120fp8_gemv_pair_kernelILi1E7ik_bf16Li2ELi8EEEvPKS1_PKhPKfPT0_iS5_S7_S9_ii,comdat
.Lfunc_end317:
