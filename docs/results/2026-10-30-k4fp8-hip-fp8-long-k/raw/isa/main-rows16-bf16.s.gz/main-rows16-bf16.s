_ZN12_GLOBAL__N_120fp8_gemv_rows_kernelILi16ELi2E7ik_bf16EEvPKS1_PKhPKfPT1_iii: ; @_ZN12_GLOBAL__N_120fp8_gemv_rows_kernelILi16ELi2E7ik_bf16EEvPKS1_PKhPKfPT1_iii
; %bb.0:
	s_load_b96 s[24:26], s[0:1], 0x20
	v_lshrrev_b32_e32 v1, 4, v0
	s_load_b256 s[16:23], s[0:1], 0x0
	v_mov_b32_e32 v69, 0
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v71, 0
	v_mov_b32_e32 v72, 0
	s_wait_kmcnt 0x0
	s_add_co_i32 s4, s24, 15
	s_mul_i32 s28, s26, ttmp9
	s_ashr_i32 s2, s4, 31
	s_ashr_i32 s29, s28, 31
	s_lshr_b32 s5, s2, 28
	s_lshl_b64 s[2:3], s[28:29], 4
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)
	v_dual_mov_b32 v2, s3 :: v_dual_and_b32 v99, 14, v1
	s_add_co_i32 s4, s4, s5
	s_ashr_i32 s27, s4, 4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_or_b32_e32 v1, s2, v99
	v_mov_b32_e32 v74, v2
	s_cmp_lt_i32 s28, s27
	s_cselect_b32 s7, -1, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_mov_b32_e32 v73, v1
	s_cmp_ge_i32 s28, s27
	s_cbranch_scc1 .LBB139_6
; %bb.1:
	v_mov_b32_e32 v69, 0
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v71, 0
	v_mov_b32_e32 v72, 0
	s_ashr_i32 s3, s24, 31
	s_mov_b32 s2, s24
	s_mov_b32 s4, exec_lo
	s_wait_alu 0xfffe
	v_cmpx_gt_i64_e64 s[2:3], v[1:2]
; %bb.2:
	s_ashr_i32 s5, s25, 31
	v_mad_co_u64_u32 v[71:72], null, v1, s25, s[18:19]
	v_mul_lo_u32 v3, v2, s25
	v_mul_lo_u32 v4, v1, s5
	s_delay_alu instid0(VALU_DEP_1)
	v_add3_u32 v72, v3, v72, v4
; %bb.3:
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v1, 1, v1
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[1:2]
	s_and_saveexec_b32 s2, vcc_lo
; %bb.4:
	s_ashr_i32 s3, s25, 31
	v_mad_co_u64_u32 v[69:70], null, v1, s25, s[18:19]
	v_mul_lo_u32 v2, v2, s25
	s_wait_alu 0xfffe
	v_mul_lo_u32 v1, v1, s3
	s_delay_alu instid0(VALU_DEP_1)
	v_add3_u32 v70, v2, v70, v1
; %bb.5:
	s_or_b32 exec_lo, exec_lo, s2
.LBB139_6:
	s_ashr_i32 s2, s25, 31
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v100, 31, v0
	s_wait_alu 0xfffe
	s_lshr_b32 s2, s2, 28
	v_cmp_ne_u64_e32 vcc_lo, 0, v[71:72]
	s_wait_alu 0xfffe
	s_add_co_i32 s2, s25, s2
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v101, 4, v100
	s_wait_alu 0xfffe
	s_ashr_i32 s29, s2, 4
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v8, 0
	v_cmp_gt_i32_e64 s2, s29, v100
	v_mov_b32_e32 v7, 0
	s_and_b32 s3, s2, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB139_8
; %bb.7:
	v_add_co_u32 v2, s3, v71, v101
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v3, null, 0, v72, s3
	global_load_b128 v[5:8], v[2:3], off th:TH_LOAD_NT
.LBB139_8:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_cmp_ne_u64_e64 s6, 0, v[69:70]
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0
	v_mov_b32_e32 v4, 0
	s_and_b32 s3, s2, s6
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s4, s3
	s_cbranch_execz .LBB139_10
; %bb.9:
	v_add_co_u32 v1, s3, v69, v101
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, 0, v70, s3
	global_load_b128 v[1:4], v[1:2], off th:TH_LOAD_NT
.LBB139_10:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s4
	v_or_b32_e32 v10, 32, v100
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v14, 0
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v16, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s3, s29, v10
	v_mov_b32_e32 v15, 0
	s_and_b32 s4, vcc_lo, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB139_12
; %bb.11:
	v_add_co_u32 v10, s4, v71, v101
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v11, null, 0, v72, s4
	global_load_b128 v[13:16], v[10:11], off offset:512 th:TH_LOAD_NT
.LBB139_12:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0
	v_mov_b32_e32 v12, 0
	s_and_b32 s4, s6, s3
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s5, s4
	s_cbranch_execz .LBB139_14
; %bb.13:
	v_add_co_u32 v9, s4, v69, v101
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v10, null, 0, v70, s4
	global_load_b128 v[9:12], v[9:10], off offset:512 th:TH_LOAD_NT
.LBB139_14:
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s5
	v_or_b32_e32 v18, 64, v100
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v22, 0
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e64 s4, s29, v18
	v_mov_b32_e32 v23, 0
	s_and_b32 s5, vcc_lo, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s5
	s_cbranch_execz .LBB139_16
; %bb.15:
	v_add_co_u32 v18, s5, v71, v101
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v19, null, 0, v72, s5
	global_load_b128 v[21:24], v[18:19], off offset:1024 th:TH_LOAD_NT
.LBB139_16:
	s_or_b32 exec_lo, exec_lo, s8
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0
	v_mov_b32_e32 v20, 0
	s_and_b32 s5, s6, s4
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s8, s5
	s_cbranch_execz .LBB139_18
; %bb.17:
	v_add_co_u32 v17, s5, v69, v101
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v18, null, 0, v70, s5
	global_load_b128 v[17:20], v[17:18], off offset:1024 th:TH_LOAD_NT
.LBB139_18:
	s_or_b32 exec_lo, exec_lo, s8
	v_or_b32_e32 v26, 0x60, v100
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v30, 0
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v32, 0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)
	v_cmp_gt_i32_e64 s5, s29, v26
	v_mov_b32_e32 v31, 0
	s_and_b32 s9, vcc_lo, s5
	s_and_saveexec_b32 s8, s9
	s_cbranch_execz .LBB139_20
; %bb.19:
	v_add_co_u32 v26, vcc_lo, v71, v101
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v27, null, 0, v72, vcc_lo
	global_load_b128 v[29:32], v[26:27], off offset:1536 th:TH_LOAD_NT
.LBB139_20:
	s_or_b32 exec_lo, exec_lo, s8
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0
	v_mov_b32_e32 v28, 0
	s_and_b32 s8, s6, s5
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_saveexec_b32 s6, s8
	s_cbranch_execz .LBB139_22
; %bb.21:
	v_add_co_u32 v25, vcc_lo, v69, v101
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, 0, v70, vcc_lo
	global_load_b128 v[25:28], v[25:26], off offset:1536 th:TH_LOAD_NT
.LBB139_22:
	s_or_b32 exec_lo, exec_lo, s6
	s_cmp_lt_i32 s26, 1
	s_cselect_b32 s6, -1, 0
	s_xor_b32 s7, s7, -1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)
	s_or_b32 s6, s6, s7
	s_and_b32 vcc_lo, exec_lo, s6
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB139_105
; %bb.23:
	s_load_b64 s[20:21], s[20:21], 0x0
	v_dual_mov_b32 v76, 0 :: v_dual_and_b32 v33, 15, v0
	s_add_nc_u64 s[34:35], s[0:1], 48
	v_bfe_u32 v35, v0, 4, 1
	v_dual_mov_b32 v81, 0 :: v_dual_and_b32 v36, 16, v0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_mad_co_i64_i32 v[33:34], null, s24, v33, 0
	v_lshlrev_b32_e32 v38, 1, v35
	v_dual_mov_b32 v82, 0 :: v_dual_and_b32 v37, 8, v0
	v_lshl_add_u32 v102, v100, 4, 0
	v_lshlrev_b32_e32 v105, 7, v0
	v_mbcnt_lo_u32_b32 v106, -1, 0
	v_lshlrev_b64_e32 v[33:34], 1, v[33:34]
	s_mov_b32 s31, 0
	s_mov_b32 s33, s25
	s_mov_b32 s36, s24
	s_mov_b32 s38, s25
	s_wait_kmcnt 0x0
	s_cmp_ngt_f32 s21, 0
	v_add_co_u32 v33, vcc_lo, s22, v33
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v34, null, s23, v34, vcc_lo
	s_cselect_b32 s39, -1, 0
	s_cmp_gt_f32 s21, 0
	v_add_co_u32 v103, vcc_lo, v33, v38
	v_and_b32_e32 v33, 4, v0
	s_cselect_b32 s0, -1, 0
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v104, null, 0, v34, vcc_lo
	s_and_b32 s1, s0, exec_lo
	s_cselect_b32 s1, s21, 1.0
	s_add_co_i32 s6, s25, 0x7ff
	s_add_co_i32 s40, s27, -1
	s_ashr_i32 s7, s6, 31
	s_mul_f32 s20, s20, s1
	s_lshr_b32 s7, s7, 21
	v_sub_co_u32 v77, s1, s24, v35
	s_add_co_i32 s6, s6, s7
	s_add_co_i32 s7, s25, -1
	s_ashr_i32 s41, s6, 11
	s_cmp_lt_u32 s7, 0x800
	v_and_b32_e32 v34, 2, v0
	s_cselect_b32 s22, -1, 0
	s_cmp_gt_i32 s25, 0
	v_cmp_eq_u32_e64 s7, 0, v33
	s_cselect_b32 s23, -1, 0
	s_cmp_gt_i32 s25, 0x800
	v_and_b32_e32 v35, 1, v0
	s_cselect_b32 s42, -1, 0
	s_ashr_i32 s37, s24, 31
	v_cmp_eq_u32_e64 s8, 0, v34
	v_sub_co_ci_u32_e64 v78, null, s37, 0, s1
	v_cmp_eq_u32_e64 s1, 0, v36
	v_lshlrev_b32_e32 v36, 4, v0
	v_cmp_eq_u32_e64 s6, 0, v37
	v_cmp_eq_u32_e64 s9, 0, v35
	s_mov_b32 s45, 0
                                        ; implicit-def: $vgpr85_vgpr86
                                        ; implicit-def: $vgpr83_vgpr84
                                        ; implicit-def: $vgpr60
                                        ; implicit-def: $vgpr52
                                        ; implicit-def: $vgpr44
                                        ; implicit-def: $vgpr64
                                        ; implicit-def: $vgpr56
                                        ; implicit-def: $vgpr48
                                        ; implicit-def: $vgpr40
	v_add_co_u32 v33, s10, s16, v36
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v34, null, s17, 0, s10
	s_max_i32 s16, s41, 1
	v_add_co_u32 v79, vcc_lo, v33, 8
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v80, null, 0, v34, vcc_lo
	s_mov_b32 s17, 0xc3e00000
                                        ; implicit-def: $vgpr36
	s_branch .LBB139_25
.LBB139_24:                             ;   in Loop: Header=BB139_25 Depth=1
	s_add_co_i32 s28, s28, 1
	s_mov_b32 s45, s24
	s_wait_alu 0xfffe
	s_cmp_lt_i32 s28, s27
	s_cselect_b32 s10, -1, 0
	s_wait_alu 0xfffe
	s_and_b32 s10, s43, s10
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s10
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB139_105
.LBB139_25:                             ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB139_29 Depth 2
                                        ;       Child Loop BB139_38 Depth 3
	s_add_co_i32 s24, s45, 1
	v_cmp_ne_u64_e64 s10, 0, v[71:72]
	s_wait_alu 0xfffe
	s_cmp_lt_i32 s24, s26
	s_cselect_b32 s43, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 s11, s22, s43
	s_cmp_lt_i32 s28, s40
	s_cselect_b32 s12, -1, 0
	s_and_not1_b32 vcc_lo, exec_lo, s23
	s_wait_alu 0xfffe
	s_and_b32 s44, s11, s12
	s_cbranch_vccnz .LBB139_95
; %bb.26:                               ;   in Loop: Header=BB139_25 Depth=1
	s_cmp_eq_u32 s45, 0
	v_cmp_ne_u64_e64 s11, 0, v[69:70]
	s_cselect_b32 s14, -1, 0
	s_add_co_i32 s12, s28, 1
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v107, 0
	s_wait_alu 0xfffe
	s_ashr_i32 s13, s12, 31
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v109, 0
	s_wait_alu 0xfffe
	s_lshl_b64 s[12:13], s[12:13], 4
	s_wait_alu 0xfffe
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v88, s13
	v_or_b32_e32 v87, s12, v99
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v126, 0
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v128, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_mad_co_u64_u32 v[65:66], null, v87, s38, s[18:19]
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[87:88]
	v_dual_mov_b32 v68, s13 :: v_dual_mov_b32 v119, 0
	v_dual_mov_b32 v130, 0 :: v_dual_mov_b32 v121, 0
	v_mov_b32_e32 v112, 0
	s_wait_dscnt 0x0
	v_mad_co_u64_u32 v[66:67], null, s13, s38, v[66:67]
	v_or_b32_e32 v67, 1, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v89, 0, v65, vcc_lo
	v_add_co_u32 v75, s12, v65, s38
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v114, 0
	v_cndmask_b32_e32 v90, 0, v66, vcc_lo
	v_add_co_u32 v91, vcc_lo, v65, v101
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v92, null, 0, v66, vcc_lo
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[67:68]
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v93, null, 0, v66, s12
	v_add_co_u32 v95, s13, v75, v101
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_mov_b32 v113, 0 :: v_dual_cndmask_b32 v94, 0, v93
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v96, null, 0, v93, s13
	v_cndmask_b32_e32 v93, 0, v75, vcc_lo
	v_cmp_ne_u64_e64 s12, 0, v[89:90]
	v_dual_mov_b32 v127, 0 :: v_dual_mov_b32 v124, 0
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v116, 0
	v_dual_mov_b32 v118, 0 :: v_dual_mov_b32 v133, 0
	v_dual_mov_b32 v120, 0 :: v_dual_mov_b32 v125, 0
	v_dual_mov_b32 v122, 0 :: v_dual_mov_b32 v131, 0
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v135, 0
	v_dual_mov_b32 v134, 0 :: v_dual_mov_b32 v137, 0
	v_mov_b32_e32 v136, 0
	v_mov_b32_e32 v138, 0
	s_mov_b32 s46, 0
	s_or_b32 s47, s42, s14
	s_and_b32 s48, s2, vcc_lo
	s_and_b32 s49, vcc_lo, s3
	s_and_b32 s50, s2, s12
	s_and_b32 s51, s12, s3
	s_and_b32 s52, s12, s4
	s_and_b32 s53, vcc_lo, s4
	s_and_b32 s54, s12, s5
	s_and_b32 s55, vcc_lo, s5
	s_branch .LBB139_29
.LBB139_27:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
.LBB139_28:                             ;   in Loop: Header=BB139_29 Depth=2
	s_cmp_eq_u32 s46, s16
	s_cbranch_scc1 .LBB139_96
.LBB139_29:                             ;   Parent Loop BB139_25 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB139_38 Depth 3
	s_wait_alu 0xfffe
	s_and_not1_b32 vcc_lo, exec_lo, s47
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB139_33
; %bb.30:                               ;   in Loop: Header=BB139_29 Depth=2
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccz .LBB139_41
.LBB139_31:                             ;   in Loop: Header=BB139_29 Depth=2
	s_and_saveexec_b32 s13, s10
	s_cbranch_execnz .LBB139_58
.LBB139_32:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	s_add_co_i32 s46, s46, 1
	s_wait_alu 0xfffe
	s_cmp_ge_i32 s46, s41
	s_cbranch_scc1 .LBB139_28
	s_branch .LBB139_79
.LBB139_33:                             ;   in Loop: Header=BB139_29 Depth=2
	s_or_b32 s12, s46, s45
	s_wait_alu 0xfffe
	s_cmp_eq_u32 s12, 0
	s_cbranch_scc1 .LBB139_35
; %bb.34:                               ;   in Loop: Header=BB139_29 Depth=2
	s_wait_loadcnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
.LBB139_35:                             ;   in Loop: Header=BB139_29 Depth=2
	s_lshl_b32 s30, s46, 11
	s_mov_b32 s58, exec_lo
	s_wait_alu 0xfffe
	s_sub_co_i32 s12, s25, s30
	s_wait_alu 0xfffe
	s_min_i32 s12, s12, 0x800
	s_wait_alu 0xfffe
	s_ashr_i32 s13, s12, 31
	s_wait_alu 0xfffe
	s_lshr_b32 s13, s13, 29
	s_wait_alu 0xfffe
	s_add_co_i32 s12, s12, s13
	s_wait_alu 0xfffe
	s_ashr_i32 s56, s12, 3
	s_wait_alu 0xfffe
	s_lshl_b32 s57, s56, 4
	s_wait_alu 0xfffe
	v_cmpx_gt_i32_e64 s57, v0
	s_cbranch_execz .LBB139_40
; %bb.36:                               ;   in Loop: Header=BB139_29 Depth=2
	s_abs_i32 s59, s56
	v_dual_mov_b32 v98, v80 :: v_dual_mov_b32 v97, v79
	s_wait_alu 0xfffe
	s_cvt_f32_u32 s12, s59
	s_sub_co_i32 s15, 0, s59
	v_mov_b32_e32 v75, v105
	v_mov_b32_e32 v139, v0
	s_wait_alu 0xfffe
	v_rcp_iflag_f32_e32 v65, s12
	s_load_b32 s12, s[34:35], 0xc
	s_lshl_b32 s14, s56, 7
	s_ashr_i32 s60, s56, 31
	s_mov_b32 s61, 0
	s_sub_co_i32 s62, 0, s56
	s_sub_co_i32 s63, 0, s14
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_2)
	v_readfirstlane_b32 s13, v65
	s_mul_f32 s13, s13, 0x4f7ffffe
	s_wait_alu 0xfffe
	s_cvt_u32_f32 s13, s13
	s_wait_kmcnt 0x0
	s_and_b32 s64, s12, 0xffff
	s_wait_alu 0xfffe
	s_mul_i32 s15, s15, s13
	s_lshl_b32 s65, s64, 7
	s_mul_hi_u32 s12, s13, s15
	s_lshl_b32 s67, s64, 4
	s_wait_alu 0xfffe
	s_add_co_i32 s66, s13, s12
	s_branch .LBB139_38
.LBB139_37:                             ;   in Loop: Header=BB139_38 Depth=3
	v_mad_co_u64_u32 v[141:142], null, s63, v140, v[75:76]
	v_mul_lo_u32 v142, s62, v140
	v_lshl_add_u32 v140, v140, 12, 0
	v_add_co_u32 v97, s12, v97, s67
	v_add_nc_u32_e32 v75, s65, v75
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v98, null, 0, v98, s12
	v_and_b32_e32 v141, 0x80, v141
	v_add_lshl_u32 v142, v139, v142, 3
	v_add_nc_u32_e32 v139, s64, v139
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_lshlrev_b32_e32 v141, 4, v141
	v_and_b32_e32 v142, -16, v142
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cmp_le_i32_e32 vcc_lo, s57, v139
	v_add3_u32 v140, v140, v141, v142
	s_or_b32 s61, vcc_lo, s61
	s_wait_loadcnt 0x0
	ds_store_b128 v140, v[65:68]
	s_wait_alu 0xfffe
	s_and_not1_b32 exec_lo, exec_lo, s61
	s_cbranch_execz .LBB139_40
.LBB139_38:                             ;   Parent Loop BB139_25 Depth=1
                                        ;     Parent Loop BB139_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_wait_alu 0xfffe
	v_mul_hi_u32 v65, v139, s66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mul_lo_u32 v66, v65, s59
	v_sub_nc_u32_e32 v66, v139, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_subrev_nc_u32_e32 v68, s59, v66
	v_cmp_le_u32_e32 vcc_lo, s59, v66
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, v66, v68 :: v_dual_add_nc_u32 v67, 1, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v65, v65, v67, vcc_lo
	v_cmp_le_u32_e32 vcc_lo, s59, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_add_nc_u32_e32 v67, 1, v65
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v65, v67, vcc_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_xor_b32_e32 v65, s60, v65
	v_subrev_nc_u32_e32 v140, s60, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_mad_co_i64_i32 v[65:66], null, v140, s33, s[30:31]
	v_ashrrev_i32_e32 v67, 31, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_lshrrev_b32_e32 v68, 29, v67
	v_mul_lo_u32 v67, v140, s56
	v_add_co_u32 v65, vcc_lo, v65, v68
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_ashrrev_i32_e32 v68, 31, v67
	v_lshlrev_b64_e32 v[65:66], 1, v[65:66]
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_lshlrev_b64_e32 v[67:68], 4, v[67:68]
	v_and_b32_e32 v65, -16, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_sub_co_u32 v65, vcc_lo, v65, v67
	s_wait_alu 0xfffd
	v_sub_co_ci_u32_e64 v66, null, v66, v68, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v65, vcc_lo, v97, v65
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v66, null, v98, v66, vcc_lo
	s_and_not1_b32 vcc_lo, exec_lo, s0
	global_load_b128 v[65:68], v[65:66], off offset:-8
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB139_37
; %bb.39:                               ;   in Loop: Header=BB139_38 Depth=3
	s_wait_loadcnt 0x0
	v_lshlrev_b32_e32 v141, 16, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_div_scale_f32 v142, null, s21, s21, v141
	v_rcp_f32_e32 v146, v142
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fma_f32 v152, -v142, v146, 1.0
	v_fmac_f32_e32 v146, v152, v146
	v_div_scale_f32 v150, vcc_lo, v141, s21, v141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v156, v150, v146 :: v_dual_and_b32 v65, 0xffff0000, v65
	v_div_scale_f32 v143, null, s21, s21, v65
	v_div_scale_f32 v154, s12, v65, s21, v65
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fma_f32 v160, -v142, v156, v150
	v_rcp_f32_e32 v147, v143
	v_lshlrev_b32_e32 v145, 16, v67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v156, v160, v146 :: v_dual_and_b32 v67, 0xffff0000, v67
	v_div_scale_f32 v158, null, s21, s21, v145
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)
	v_fma_f32 v142, -v142, v156, v150
	v_fma_f32 v153, -v143, v147, 1.0
	v_lshlrev_b32_e32 v144, 16, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fmas_f32 v142, v142, v146, v156
	v_fmac_f32_e32 v147, v153, v147
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_div_scale_f32 v148, null, s21, s21, v144
	v_and_b32_e32 v66, 0xffff0000, v66
	v_div_scale_f32 v155, s13, v144, s21, v144
	v_rcp_f32_e32 v151, v148
	v_mul_f32_e32 v157, v154, v147
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(TRANS32_DEP_2)
	v_div_scale_f32 v152, null, s21, s21, v66
	s_mov_b32 vcc_lo, s12
	v_div_scale_f32 v161, s14, v66, s21, v66
	v_rcp_f32_e32 v159, v152
	v_div_scale_f32 v146, null, s21, s21, v67
	v_fma_f32 v153, -v148, v151, 1.0
	v_div_fixup_f32 v141, v142, s21, v141
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)
	v_fmac_f32_e32 v151, v153, v151
	v_fma_f32 v153, -v143, v157, v154
	v_lshlrev_b32_e32 v149, 16, v68
	v_and_b32_e32 v68, 0xffff0000, v68
	v_fma_f32 v162, -v152, v159, 1.0
	v_mul_f32_e32 v160, v155, v151
	v_fmac_f32_e32 v157, v153, v147
	v_rcp_f32_e32 v153, v158
	v_div_scale_f32 v156, null, s21, s21, v68
	v_fmac_f32_e32 v159, v162, v159
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_fma_f32 v143, -v143, v157, v154
	v_fma_f32 v150, -v148, v160, v155
	v_med3_num_f32 v141, v141, s17, 0x43e00000
	s_wait_alu 0xfffe
	v_div_fmas_f32 v143, v143, v147, v157
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v160, v150, v151
	s_mov_b32 vcc_lo, s13
	v_fma_f32 v142, -v158, v153, 1.0
	v_div_fixup_f32 v65, v143, s21, v65
	v_mul_f32_e32 v143, v161, v159
	v_fma_f32 v147, -v148, v160, v155
	v_rcp_f32_e32 v148, v146
	v_fmac_f32_e32 v153, v142, v153
	v_div_scale_f32 v142, s12, v145, s21, v145
	v_fma_f32 v150, -v152, v143, v161
	v_med3_num_f32 v65, v65, s17, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)
	v_fmac_f32_e32 v143, v150, v159
	v_rcp_f32_e32 v150, v156
	v_fma_f32 v154, -v146, v148, 1.0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fma_f32 v152, -v152, v143, v161
	v_fmac_f32_e32 v148, v154, v148
	v_div_scale_f32 v154, s13, v67, s21, v67
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fma_f32 v162, -v156, v150, 1.0
	v_mul_f32_e32 v161, v154, v148
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v150, v162, v150
	s_wait_alu 0xfffe
	v_div_fmas_f32 v147, v147, v151, v160
	v_div_scale_f32 v151, null, s21, s21, v149
	s_mov_b32 vcc_lo, s14
	v_div_fixup_f32 v144, v147, s21, v144
	v_rcp_f32_e32 v155, v151
	v_mul_f32_e32 v147, v142, v153
	s_wait_alu 0xfffe
	v_div_fmas_f32 v143, v152, v159, v143
	v_fma_f32 v152, -v146, v161, v154
	s_mov_b32 vcc_lo, s12
	v_med3_num_f32 v144, v144, s17, 0x43e00000
	v_fma_f32 v160, -v158, v147, v142
	v_div_fixup_f32 v66, v143, s21, v66
	v_fmac_f32_e32 v161, v152, v148
	v_fma_f32 v157, -v151, v155, 1.0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v147, v160, v153
	v_div_scale_f32 v160, s14, v68, s21, v68
	v_fma_f32 v146, -v146, v161, v154
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v155, v157, v155
	v_div_scale_f32 v157, s15, v149, s21, v149
	v_fma_f32 v142, -v158, v147, v142
	v_mul_f32_e32 v152, v160, v150
	v_med3_num_f32 v66, v66, s17, 0x43e00000
	v_mul_f32_e32 v159, v157, v155
	s_wait_alu 0xfffe
	v_div_fmas_f32 v142, v142, v153, v147
	v_fma_f32 v147, -v156, v152, v160
	s_mov_b32 vcc_lo, s13
	v_fma_f32 v143, -v151, v159, v157
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_div_fixup_f32 v142, v142, s21, v145
	v_fmac_f32_e32 v152, v147, v150
	s_delay_alu instid0(VALU_DEP_3)
	v_fmac_f32_e32 v159, v143, v155
	s_wait_alu 0xfffe
	v_div_fmas_f32 v143, v146, v148, v161
	s_mov_b32 vcc_lo, s15
	v_mov_b32_e32 v146, 0
	v_med3_num_f32 v142, v142, s17, 0x43e00000
	v_fma_f32 v145, -v151, v159, v157
	v_div_fixup_f32 v67, v143, s21, v67
	v_fma_f32 v143, -v156, v152, v160
	v_cvt_pk_fp8_f32 v146, v141, v65
	v_mov_b32_e32 v65, 0
	s_wait_alu 0xfffe
	v_div_fmas_f32 v145, v145, v155, v159
	s_mov_b32 vcc_lo, s14
	v_med3_num_f32 v67, v67, s17, 0x43e00000
	s_wait_alu 0xfffe
	v_div_fmas_f32 v143, v143, v150, v152
	v_cvt_pk_fp8_f32 v146, v144, v66 op_sel:[0,0,1]
	v_div_fixup_f32 v145, v145, s21, v149
	v_cvt_pk_fp8_f32 v65, v142, v67
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_div_fixup_f32 v68, v143, s21, v68
	v_perm_b32 v66, 0, v146, 0x10c000c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_med3_num_f32 v141, v145, s17, 0x43e00000
	v_perm_b32 v67, 0, v146, 0x30c020c
	v_med3_num_f32 v68, v68, s17, 0x43e00000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_lshrrev_b32_e32 v142, 1, v67
	v_and_b32_e32 v67, 0x80008000, v67
	v_cvt_pk_fp8_f32 v65, v141, v68 op_sel:[0,0,1]
	v_lshrrev_b32_e32 v68, 1, v66
	v_and_b32_e32 v66, 0x80008000, v66
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_perm_b32 v141, 0, v65, 0x10c000c
	v_perm_b32 v65, 0, v65, 0x30c020c
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_lshrrev_b32_e32 v144, 1, v65
	v_and_b32_e32 v145, 0x80008000, v65
	v_and_or_b32 v65, 0x3f803f80, v68, v66
	v_and_or_b32 v66, 0x3f803f80, v142, v67
	v_and_or_b32 v67, 0x3f803f80, v143, v141
	v_and_or_b32 v68, 0x3f803f80, v144, v145
	s_branch .LBB139_37
.LBB139_40:                             ;   in Loop: Header=BB139_29 Depth=2
	s_or_b32 exec_lo, exec_lo, s58
	s_wait_loadcnt_dscnt 0x0
	s_barrier_signal -1
	s_barrier_wait -1
	global_inv scope:SCOPE_SE
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB139_31
.LBB139_41:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v38, 0
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v40, 0
	v_mov_b32_e32 v39, 0
	s_and_saveexec_b32 s12, s50
	s_cbranch_execz .LBB139_43
; %bb.42:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[37:40], v[91:92], off th:TH_LOAD_NT
.LBB139_43:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0
	v_mov_b32_e32 v36, 0
	s_and_saveexec_b32 s12, s48
	s_cbranch_execz .LBB139_45
; %bb.44:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[33:36], v[95:96], off th:TH_LOAD_NT
.LBB139_45:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v46, 0
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v48, 0
	v_mov_b32_e32 v47, 0
	s_and_saveexec_b32 s12, s51
	s_cbranch_execz .LBB139_47
; %bb.46:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[45:48], v[91:92], off offset:512 th:TH_LOAD_NT
.LBB139_47:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0
	v_mov_b32_e32 v44, 0
	s_and_saveexec_b32 s12, s49
	s_cbranch_execz .LBB139_49
; %bb.48:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[41:44], v[95:96], off offset:512 th:TH_LOAD_NT
.LBB139_49:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v54, 0
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v56, 0
	v_mov_b32_e32 v55, 0
	s_and_saveexec_b32 s12, s52
	s_cbranch_execz .LBB139_51
; %bb.50:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[53:56], v[91:92], off offset:1024 th:TH_LOAD_NT
.LBB139_51:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v51, 0
	v_mov_b32_e32 v52, 0
	s_and_saveexec_b32 s12, s53
	s_cbranch_execz .LBB139_53
; %bb.52:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[49:52], v[95:96], off offset:1024 th:TH_LOAD_NT
.LBB139_53:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v62, 0
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v64, 0
	v_mov_b32_e32 v63, 0
	s_and_saveexec_b32 s12, s54
	s_cbranch_execz .LBB139_55
; %bb.54:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[61:64], v[91:92], off offset:1536 th:TH_LOAD_NT
.LBB139_55:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v59, 0
	v_mov_b32_e32 v60, 0
	s_and_saveexec_b32 s12, s55
	s_cbranch_execz .LBB139_57
; %bb.56:                               ;   in Loop: Header=BB139_29 Depth=2
	global_load_b128 v[57:60], v[95:96], off offset:1536 th:TH_LOAD_NT
.LBB139_57:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_dual_mov_b32 v81, v87 :: v_dual_mov_b32 v82, v88
	v_dual_mov_b32 v83, v89 :: v_dual_mov_b32 v84, v90
	v_dual_mov_b32 v85, v93 :: v_dual_mov_b32 v86, v94
	s_and_saveexec_b32 s13, s10
	s_cbranch_execz .LBB139_32
.LBB139_58:                             ;   in Loop: Header=BB139_29 Depth=2
	v_lshl_or_b32 v65, s46, 7, v100
	s_and_not1_b32 vcc_lo, exec_lo, s39
	s_mov_b32 s14, -1
                                        ; implicit-def: $vgpr66
                                        ; implicit-def: $vgpr68
                                        ; implicit-def: $vgpr75
                                        ; implicit-def: $vgpr139
                                        ; implicit-def: $vgpr140
                                        ; implicit-def: $vgpr143
                                        ; implicit-def: $vgpr144
                                        ; implicit-def: $vgpr147
                                        ; implicit-def: $vgpr148
                                        ; implicit-def: $vgpr151
                                        ; implicit-def: $vgpr152
                                        ; implicit-def: $vgpr155
                                        ; implicit-def: $vgpr156
                                        ; implicit-def: $vgpr159
                                        ; implicit-def: $vgpr160
                                        ; implicit-def: $vgpr163
                                        ; implicit-def: $vgpr67
                                        ; implicit-def: $vgpr97
                                        ; implicit-def: $vgpr98
                                        ; implicit-def: $vgpr141
                                        ; implicit-def: $vgpr142
                                        ; implicit-def: $vgpr145
                                        ; implicit-def: $vgpr146
                                        ; implicit-def: $vgpr149
                                        ; implicit-def: $vgpr150
                                        ; implicit-def: $vgpr153
                                        ; implicit-def: $vgpr154
                                        ; implicit-def: $vgpr157
                                        ; implicit-def: $vgpr158
                                        ; implicit-def: $vgpr161
                                        ; implicit-def: $vgpr162
                                        ; implicit-def: $vgpr164
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_i32_e64 s12, s29, v65
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB139_68
; %bb.59:                               ;   in Loop: Header=BB139_29 Depth=2
	v_dual_mov_b32 v66, v137 :: v_dual_mov_b32 v75, v136
	v_dual_mov_b32 v68, v138 :: v_dual_mov_b32 v139, v135
	v_dual_mov_b32 v140, v134 :: v_dual_mov_b32 v143, v132
	v_dual_mov_b32 v144, v131 :: v_dual_mov_b32 v147, v125
	v_dual_mov_b32 v148, v133 :: v_dual_mov_b32 v151, v122
	v_dual_mov_b32 v152, v120 :: v_dual_mov_b32 v155, v118
	v_dual_mov_b32 v156, v116 :: v_dual_mov_b32 v159, v124
	v_dual_mov_b32 v160, v114 :: v_dual_mov_b32 v163, v112
	v_dual_mov_b32 v67, v130 :: v_dual_mov_b32 v98, v128
	v_dual_mov_b32 v97, v129 :: v_dual_mov_b32 v142, v126
	v_dual_mov_b32 v141, v127 :: v_dual_mov_b32 v146, v121
	v_dual_mov_b32 v145, v123 :: v_dual_mov_b32 v150, v117
	v_dual_mov_b32 v149, v119 :: v_dual_mov_b32 v154, v113
	v_dual_mov_b32 v153, v115 :: v_dual_mov_b32 v158, v109
	v_dual_mov_b32 v157, v111 :: v_dual_mov_b32 v162, v108
	v_dual_mov_b32 v161, v107 :: v_dual_mov_b32 v164, v110
	s_and_saveexec_b32 s14, s12
	s_cbranch_execz .LBB139_67
; %bb.60:                               ;   in Loop: Header=BB139_29 Depth=2
	ds_load_b128 v[139:142], v102
	s_mov_b32 s15, exec_lo
	s_wait_dscnt 0x0
	v_and_b32_e32 v97, 0xffff0000, v140
	v_lshlrev_b32_e32 v75, 16, v140
	s_wait_loadcnt 0x0
	v_and_b32_e32 v68, 7, v5
	v_lshlrev_b32_e32 v98, 16, v141
	v_lshlrev_b32_e32 v144, 16, v142
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	v_and_b32_e32 v66, 0x7f, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_bfe_u32 v68, v5, 8, 3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 24, v5
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v163, 0x80000000, v67, v66
	v_bfe_u32 v66, v5, 8, 7
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v5, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 16, v5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v164, 0x80000000, v67, v66
	v_bfe_u32 v66, v5, 16, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v5, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 8, v5
	v_and_or_b32 v165, 0x80000000, v67, v66
	v_bfe_u32 v66, v5, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_and_b32_e32 v68, 7, v6
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v166, 0x80000000, v5, v66
	v_and_b32_e32 v66, 0x7f, v6
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v6, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 24, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_and_or_b32 v167, 0x80000000, v67, v66
	v_bfe_u32 v66, v6, 8, 7
	v_and_b32_e32 v143, 0xffff0000, v141
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v6, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 16, v6
	v_and_or_b32 v168, 0x80000000, v67, v66
	v_bfe_u32 v66, v6, 16, 7
	v_and_b32_e32 v145, 0xffff0000, v142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v6, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 8, v6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v169, 0x80000000, v67, v66
	v_bfe_u32 v66, v6, 24, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_and_b32_e32 v68, 7, v7
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_and_or_b32 v170, 0x80000000, v6, v66
	v_and_b32_e32 v66, 0x7f, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v7, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_lshlrev_b32_e32 v67, 24, v7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v171, 0x80000000, v67, v66
	v_bfe_u32 v66, v7, 8, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v7, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_lshlrev_b32_e32 v67, 16, v7
	v_and_or_b32 v172, 0x80000000, v67, v66
	v_bfe_u32 v66, v7, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_bfe_u32 v68, v7, 24, 3
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_lshlrev_b32_e32 v67, 8, v7
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v173, 0x80000000, v67, v66
	v_bfe_u32 v66, v7, 24, 7
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v67, v68, v67 :: v_dual_and_b32 v68, 7, v8
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_cvt_f32_ubyte0_e32 v68, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v68, 0x3b000000, v68
	v_and_or_b32 v174, 0x80000000, v7, v66
	v_and_b32_e32 v66, 0x7f, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v8, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 24, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v175, 0x80000000, v67, v66
	v_bfe_u32 v66, v8, 8, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v8, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 16, v8
	v_and_or_b32 v176, 0x80000000, v67, v66
	v_bfe_u32 v66, v8, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v8, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 8, v8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v177, 0x80000000, v67, v66
	v_bfe_u32 v66, v8, 24, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_and_b32_e32 v68, 7, v1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_and_or_b32 v179, 0x80000000, v8, v66
	v_and_b32_e32 v66, 0x7f, v1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v68, 0x3b000000, v68
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v1, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 24, v1
	v_and_or_b32 v178, 0x80000000, v67, v66
	v_bfe_u32 v66, v1, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v1, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 16, v1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v180, 0x80000000, v67, v66
	v_bfe_u32 v66, v1, 16, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v1, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 8, v1
	v_and_or_b32 v181, 0x80000000, v67, v66
	v_bfe_u32 v66, v1, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_and_b32_e32 v68, 7, v2
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)
	v_and_or_b32 v182, 0x80000000, v1, v66
	v_and_b32_e32 v66, 0x7f, v2
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v2, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 24, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v183, 0x80000000, v67, v66
	v_bfe_u32 v66, v2, 8, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v2, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 16, v2
	v_and_or_b32 v184, 0x80000000, v67, v66
	v_bfe_u32 v66, v2, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v2, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 8, v2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v185, 0x80000000, v67, v66
	v_bfe_u32 v66, v2, 24, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_and_b32_e32 v68, 7, v3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_and_or_b32 v186, 0x80000000, v2, v66
	v_and_b32_e32 v66, 0x7f, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v3, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_lshlrev_b32_e32 v67, 24, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v187, 0x80000000, v67, v66
	v_bfe_u32 v66, v3, 8, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v3, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_lshlrev_b32_e32 v67, 16, v3
	v_and_or_b32 v188, 0x80000000, v67, v66
	v_bfe_u32 v66, v3, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v3, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_lshlrev_b32_e32 v67, 8, v3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v189, 0x80000000, v67, v66
	v_bfe_u32 v66, v3, 24, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_and_b32_e32 v68, 7, v4
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_and_or_b32 v190, 0x80000000, v3, v66
	v_and_b32_e32 v66, 0x7f, v4
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_mul_f32_e32 v68, 0x3b000000, v68
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v4, 8, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 24, v4
	v_and_or_b32 v191, 0x80000000, v67, v66
	v_bfe_u32 v66, v4, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v4, 16, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_f32_ubyte0_e32 v68, v68
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 16, v4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v192, 0x80000000, v67, v66
	v_bfe_u32 v66, v4, 16, 7
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_bfe_u32 v68, v4, 24, 3
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_cvt_f32_ubyte0_e32 v68, v68
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_mul_f32_e32 v68, 0x3b000000, v68
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v66, 0x7fc00000, v67 :: v_dual_lshlrev_b32 v67, 8, v4
	v_and_or_b32 v193, 0x80000000, v67, v66
	v_bfe_u32 v66, v4, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v67, v66, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v66
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v67, v68, v67, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v66
	v_and_b32_e32 v68, 0xffff0000, v139
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v66, 0x7fc00000, v67, vcc_lo
	v_lshlrev_b32_e32 v67, 16, v139
	ds_load_b128 v[139:142], v102 offset:2048
	v_and_or_b32 v194, 0x80000000, v4, v66
	v_fma_f32 v66, v163, v67, 0
	v_fmac_f32_e32 v66, v164, v68
	v_fma_f32 v67, v178, v67, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v165, v75 :: v_dual_fmac_f32 v67, v180, v68
	v_dual_fmac_f32 v66, v166, v97 :: v_dual_fmac_f32 v67, v181, v75
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v146, 16, v139
	v_lshlrev_b32_e32 v148, 16, v141
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v66, v167, v98 :: v_dual_lshlrev_b32 v147, 16, v140
	v_dual_fmac_f32 v67, v182, v97 :: v_dual_and_b32 v140, 0xffff0000, v140
	v_lshlrev_b32_e32 v149, 16, v142
	v_and_b32_e32 v142, 0xffff0000, v142
	v_dual_fmac_f32 v66, v168, v143 :: v_dual_fmac_f32 v67, v183, v98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v66, v169, v144 :: v_dual_and_b32 v139, 0xffff0000, v139
	v_dual_fmac_f32 v67, v184, v143 :: v_dual_fmac_f32 v66, v170, v145
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v67, v185, v144
	v_dual_fmac_f32 v66, v171, v146 :: v_dual_and_b32 v141, 0xffff0000, v141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v186, v145 :: v_dual_fmac_f32 v66, v172, v139
	v_dual_fmac_f32 v67, v187, v146 :: v_dual_fmac_f32 v66, v173, v147
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v188, v139 :: v_dual_fmac_f32 v66, v174, v140
	v_dual_fmac_f32 v67, v189, v147 :: v_dual_fmac_f32 v66, v175, v148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v190, v140 :: v_dual_fmac_f32 v66, v176, v141
	v_dual_fmac_f32 v67, v191, v148 :: v_dual_fmac_f32 v66, v177, v149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v67, v192, v141 :: v_dual_fmac_f32 v66, v179, v142
	v_fmac_f32_e32 v67, v193, v149
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v67, v194, v142
	ds_load_b128 v[139:142], v102 offset:4096
	v_add_f32_e32 v67, v67, v130
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v75, 16, v139
	v_and_b32_e32 v97, 0xffff0000, v139
	v_lshlrev_b32_e32 v98, 16, v140
	v_and_b32_e32 v143, 0xffff0000, v140
	v_lshlrev_b32_e32 v144, 16, v141
	v_fma_f32 v68, v163, v75, 0
	v_fma_f32 v75, v178, v75, 0
	v_and_b32_e32 v145, 0xffff0000, v141
	v_lshlrev_b32_e32 v146, 16, v142
	v_and_b32_e32 v147, 0xffff0000, v142
	ds_load_b128 v[139:142], v102 offset:6144
	v_fmac_f32_e32 v75, v180, v97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v68, v164, v97 :: v_dual_fmac_f32 v75, v181, v98
	v_fmac_f32_e32 v75, v182, v143
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v75, v183, v144 :: v_dual_lshlrev_b32 v148, 16, v139
	v_fmac_f32_e32 v75, v184, v145
	v_and_b32_e32 v139, 0xffff0000, v139
	v_lshlrev_b32_e32 v149, 16, v140
	v_and_b32_e32 v140, 0xffff0000, v140
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v75, v185, v146 :: v_dual_lshlrev_b32 v150, 16, v141
	v_and_b32_e32 v141, 0xffff0000, v141
	v_lshlrev_b32_e32 v151, 16, v142
	v_dual_fmac_f32 v75, v186, v147 :: v_dual_and_b32 v142, 0xffff0000, v142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v75, v187, v148
	v_fmac_f32_e32 v75, v188, v139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v75, v189, v149
	v_fmac_f32_e32 v75, v190, v140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v75, v191, v150
	v_dual_fmac_f32 v75, v192, v141 :: v_dual_fmac_f32 v68, v165, v98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_add_f32 v66, v66, v137 :: v_dual_fmac_f32 v75, v193, v151
	v_fmac_f32_e32 v68, v166, v143
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v75, v194, v142 :: v_dual_fmac_f32 v68, v167, v144
	v_add_f32_e32 v97, v75, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v68, v168, v145
	v_fmac_f32_e32 v68, v169, v146
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v68, v170, v147
	v_fmac_f32_e32 v68, v171, v148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v68, v172, v139
	v_fmac_f32_e32 v68, v173, v149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v68, v174, v140
	v_fmac_f32_e32 v68, v175, v150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v68, v176, v141
	v_fmac_f32_e32 v68, v177, v151
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v68, v179, v142
	ds_load_b128 v[139:142], v102 offset:8192
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v98, 16, v139
	v_and_b32_e32 v143, 0xffff0000, v139
	v_lshlrev_b32_e32 v144, 16, v140
	v_and_b32_e32 v145, 0xffff0000, v140
	v_lshlrev_b32_e32 v146, 16, v141
	v_fma_f32 v75, v163, v98, 0
	v_and_b32_e32 v147, 0xffff0000, v141
	v_lshlrev_b32_e32 v148, 16, v142
	v_and_b32_e32 v149, 0xffff0000, v142
	ds_load_b128 v[139:142], v102 offset:10240
	v_fmac_f32_e32 v75, v164, v143
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v75, v165, v144
	v_fmac_f32_e32 v75, v166, v145
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v75, v167, v146 :: v_dual_lshlrev_b32 v150, 16, v139
	v_fmac_f32_e32 v75, v168, v147
	v_and_b32_e32 v139, 0xffff0000, v139
	v_lshlrev_b32_e32 v151, 16, v140
	v_and_b32_e32 v140, 0xffff0000, v140
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v75, v169, v148 :: v_dual_lshlrev_b32 v152, 16, v141
	v_and_b32_e32 v141, 0xffff0000, v141
	v_lshlrev_b32_e32 v153, 16, v142
	v_dual_fmac_f32 v75, v170, v149 :: v_dual_and_b32 v142, 0xffff0000, v142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v75, v171, v150
	v_fmac_f32_e32 v75, v172, v139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v75, v173, v151
	v_dual_fmac_f32 v75, v174, v140 :: v_dual_add_f32 v68, v68, v138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v75, v175, v152
	v_fmac_f32_e32 v75, v176, v141
	v_fma_f32 v98, v178, v98, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v75, v177, v153 :: v_dual_fmac_f32 v98, v180, v143
	v_dual_fmac_f32 v75, v179, v142 :: v_dual_fmac_f32 v98, v181, v144
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_add_f32 v75, v75, v136 :: v_dual_fmac_f32 v98, v182, v145
	v_fmac_f32_e32 v98, v183, v146
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v98, v184, v147
	v_fmac_f32_e32 v98, v185, v148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v98, v186, v149
	v_fmac_f32_e32 v98, v187, v150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v98, v188, v139
	v_fmac_f32_e32 v98, v189, v151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v98, v190, v140
	v_fmac_f32_e32 v98, v191, v152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v98, v192, v141
	v_fmac_f32_e32 v98, v193, v153
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v98, v194, v142
	ds_load_b128 v[139:142], v102 offset:12288
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v143, 16, v139
	v_and_b32_e32 v144, 0xffff0000, v139
	v_lshlrev_b32_e32 v145, 16, v140
	v_and_b32_e32 v146, 0xffff0000, v140
	v_lshlrev_b32_e32 v147, 16, v141
	v_and_b32_e32 v148, 0xffff0000, v141
	v_lshlrev_b32_e32 v149, 16, v142
	v_and_b32_e32 v150, 0xffff0000, v142
	ds_load_b128 v[139:142], v102 offset:14336
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v151, 16, v139
	v_and_b32_e32 v152, 0xffff0000, v139
	v_fma_f32 v139, v163, v143, 0
	v_lshlrev_b32_e32 v153, 16, v140
	v_and_b32_e32 v140, 0xffff0000, v140
	v_lshlrev_b32_e32 v154, 16, v141
	v_and_b32_e32 v141, 0xffff0000, v141
	v_fmac_f32_e32 v139, v164, v144
	v_fma_f32 v143, v178, v143, 0
	v_lshlrev_b32_e32 v155, 16, v142
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v139, v165, v145
	v_fmac_f32_e32 v139, v166, v146
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v139, v167, v147
	v_fmac_f32_e32 v139, v168, v148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v139, v169, v149
	v_fmac_f32_e32 v139, v170, v150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v139, v171, v151
	v_fmac_f32_e32 v139, v172, v152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v139, v173, v153
	v_fmac_f32_e32 v139, v174, v140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_add_f32 v98, v98, v128 :: v_dual_fmac_f32 v139, v175, v154
	v_fmac_f32_e32 v139, v176, v141
	v_fmac_f32_e32 v143, v180, v144
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v139, v177, v155
	v_fmac_f32_e32 v143, v181, v145
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v182, v146
	v_dual_fmac_f32 v143, v183, v147 :: v_dual_and_b32 v142, 0xffff0000, v142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v139, v179, v142
	v_fmac_f32_e32 v143, v184, v148
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add_f32_e32 v139, v139, v135
	v_fmac_f32_e32 v143, v185, v149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v186, v150
	v_fmac_f32_e32 v143, v187, v151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v188, v152
	v_fmac_f32_e32 v143, v189, v153
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v190, v140
	v_fmac_f32_e32 v143, v191, v154
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v192, v141
	v_fmac_f32_e32 v143, v193, v155
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v194, v142
	v_add_f32_e32 v141, v143, v127
	ds_load_b128 v[142:145], v102 offset:16384
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v146, 16, v142
	v_and_b32_e32 v153, 0xffff0000, v145
	v_and_b32_e32 v147, 0xffff0000, v142
	v_lshlrev_b32_e32 v148, 16, v143
	v_lshlrev_b32_e32 v150, 16, v144
	v_fma_f32 v140, v163, v146, 0
	v_and_b32_e32 v149, 0xffff0000, v143
	v_and_b32_e32 v151, 0xffff0000, v144
	v_lshlrev_b32_e32 v152, 16, v145
	ds_load_b128 v[142:145], v102 offset:18432
	v_fmac_f32_e32 v140, v164, v147
	v_fma_f32 v146, v178, v146, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v140, v165, v148
	v_fmac_f32_e32 v140, v166, v149
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v140, v167, v150
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v154, 16, v142
	v_fmac_f32_e32 v140, v168, v151
	v_and_b32_e32 v142, 0xffff0000, v142
	v_lshlrev_b32_e32 v156, 16, v144
	v_lshlrev_b32_e32 v155, 16, v143
	v_and_b32_e32 v144, 0xffff0000, v144
	v_dual_fmac_f32 v140, v169, v152 :: v_dual_and_b32 v143, 0xffff0000, v143
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v140, v170, v153
	v_fmac_f32_e32 v146, v180, v147
	v_fmac_f32_e32 v140, v171, v154
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v146, v181, v148
	v_fmac_f32_e32 v140, v172, v142
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v146, v182, v149
	v_dual_fmac_f32 v140, v173, v155 :: v_dual_lshlrev_b32 v157, 16, v145
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v146, v183, v150 :: v_dual_and_b32 v145, 0xffff0000, v145
	v_fmac_f32_e32 v140, v174, v143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v146, v184, v151
	v_fmac_f32_e32 v140, v175, v156
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v146, v185, v152
	v_fmac_f32_e32 v140, v176, v144
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v146, v186, v153
	v_fmac_f32_e32 v140, v177, v157
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v146, v187, v154
	v_fmac_f32_e32 v140, v179, v145
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v146, v188, v142
	v_fmac_f32_e32 v146, v189, v155
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v146, v190, v143
	v_fmac_f32_e32 v146, v191, v156
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v146, v192, v144
	v_fmac_f32_e32 v146, v193, v157
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v146, v194, v145
	v_add_f32_e32 v142, v146, v126
	ds_load_b128 v[143:146], v102 offset:20480
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v147, 16, v143
	v_and_b32_e32 v148, 0xffff0000, v143
	v_dual_add_f32 v140, v140, v134 :: v_dual_lshlrev_b32 v149, 16, v144
	v_lshlrev_b32_e32 v151, 16, v145
	v_and_b32_e32 v150, 0xffff0000, v144
	v_and_b32_e32 v152, 0xffff0000, v145
	v_lshlrev_b32_e32 v153, 16, v146
	v_and_b32_e32 v154, 0xffff0000, v146
	ds_load_b128 v[143:146], v102 offset:22528
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v155, 16, v143
	v_and_b32_e32 v156, 0xffff0000, v143
	v_fma_f32 v143, v163, v147, 0
	v_lshlrev_b32_e32 v157, 16, v144
	v_and_b32_e32 v144, 0xffff0000, v144
	v_lshlrev_b32_e32 v158, 16, v145
	v_and_b32_e32 v145, 0xffff0000, v145
	v_fmac_f32_e32 v143, v164, v148
	v_lshlrev_b32_e32 v159, 16, v146
	v_and_b32_e32 v146, 0xffff0000, v146
	v_fma_f32 v147, v178, v147, 0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v165, v149
	v_fmac_f32_e32 v143, v166, v150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v167, v151
	v_fmac_f32_e32 v143, v168, v152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v169, v153
	v_fmac_f32_e32 v143, v170, v154
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v171, v155
	v_fmac_f32_e32 v143, v172, v156
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v173, v157
	v_fmac_f32_e32 v143, v174, v144
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v175, v158
	v_fmac_f32_e32 v143, v176, v145
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v143, v177, v159
	v_fmac_f32_e32 v143, v179, v146
	v_fmac_f32_e32 v147, v180, v148
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add_f32_e32 v143, v143, v132
	v_fmac_f32_e32 v147, v181, v149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v182, v150
	v_fmac_f32_e32 v147, v183, v151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v184, v152
	v_fmac_f32_e32 v147, v185, v153
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v186, v154
	v_fmac_f32_e32 v147, v187, v155
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v188, v156
	v_fmac_f32_e32 v147, v189, v157
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v190, v144
	v_fmac_f32_e32 v147, v191, v158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v192, v145
	v_fmac_f32_e32 v147, v193, v159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v194, v146
	v_add_f32_e32 v145, v147, v123
	ds_load_b128 v[146:149], v102 offset:24576
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v150, 16, v146
	v_and_b32_e32 v157, 0xffff0000, v149
	v_and_b32_e32 v151, 0xffff0000, v146
	v_lshlrev_b32_e32 v152, 16, v147
	v_lshlrev_b32_e32 v154, 16, v148
	v_fma_f32 v144, v163, v150, 0
	v_and_b32_e32 v153, 0xffff0000, v147
	v_and_b32_e32 v155, 0xffff0000, v148
	v_lshlrev_b32_e32 v156, 16, v149
	ds_load_b128 v[146:149], v102 offset:26624
	v_fmac_f32_e32 v144, v164, v151
	v_fma_f32 v150, v178, v150, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v144, v165, v152
	v_fmac_f32_e32 v144, v166, v153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v144, v167, v154
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v158, 16, v146
	v_fmac_f32_e32 v144, v168, v155
	v_and_b32_e32 v146, 0xffff0000, v146
	v_lshlrev_b32_e32 v160, 16, v148
	v_lshlrev_b32_e32 v159, 16, v147
	v_and_b32_e32 v148, 0xffff0000, v148
	v_dual_fmac_f32 v144, v169, v156 :: v_dual_and_b32 v147, 0xffff0000, v147
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v144, v170, v157
	v_fmac_f32_e32 v150, v180, v151
	v_fmac_f32_e32 v144, v171, v158
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v150, v181, v152
	v_fmac_f32_e32 v144, v172, v146
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v150, v182, v153
	v_dual_fmac_f32 v144, v173, v159 :: v_dual_lshlrev_b32 v161, 16, v149
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v150, v183, v154 :: v_dual_and_b32 v149, 0xffff0000, v149
	v_fmac_f32_e32 v144, v174, v147
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v150, v184, v155
	v_fmac_f32_e32 v144, v175, v160
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v150, v185, v156
	v_fmac_f32_e32 v144, v176, v148
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v150, v186, v157
	v_fmac_f32_e32 v144, v177, v161
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v150, v187, v158
	v_fmac_f32_e32 v144, v179, v149
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v150, v188, v146
	v_fmac_f32_e32 v150, v189, v159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v150, v190, v147
	v_fmac_f32_e32 v150, v191, v160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v150, v192, v148
	v_fmac_f32_e32 v150, v193, v161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v150, v194, v149
	v_add_f32_e32 v146, v150, v121
	ds_load_b128 v[147:150], v102 offset:28672
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v151, 16, v147
	v_and_b32_e32 v152, 0xffff0000, v147
	v_dual_add_f32 v144, v144, v131 :: v_dual_lshlrev_b32 v153, 16, v148
	v_lshlrev_b32_e32 v155, 16, v149
	v_and_b32_e32 v154, 0xffff0000, v148
	v_and_b32_e32 v156, 0xffff0000, v149
	v_lshlrev_b32_e32 v157, 16, v150
	v_and_b32_e32 v158, 0xffff0000, v150
	ds_load_b128 v[147:150], v102 offset:30720
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v159, 16, v147
	v_and_b32_e32 v160, 0xffff0000, v147
	v_fma_f32 v147, v163, v151, 0
	v_lshlrev_b32_e32 v161, 16, v148
	v_and_b32_e32 v148, 0xffff0000, v148
	v_lshlrev_b32_e32 v162, 16, v149
	v_and_b32_e32 v149, 0xffff0000, v149
	v_fmac_f32_e32 v147, v164, v152
	v_fma_f32 v151, v178, v151, 0
	v_lshlrev_b32_e32 v195, 16, v150
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v165, v153
	v_fmac_f32_e32 v147, v166, v154
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v167, v155
	v_fmac_f32_e32 v147, v168, v156
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v169, v157
	v_fmac_f32_e32 v147, v170, v158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v171, v159
	v_fmac_f32_e32 v147, v172, v160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v173, v161
	v_fmac_f32_e32 v147, v174, v148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v147, v175, v162
	v_fmac_f32_e32 v147, v176, v149
	v_dual_fmac_f32 v151, v180, v152 :: v_dual_and_b32 v150, 0xffff0000, v150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v147, v177, v195
	v_fmac_f32_e32 v151, v181, v153
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v147, v179, v150
	v_fmac_f32_e32 v151, v182, v154
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add_f32_e32 v147, v147, v125
	v_fmac_f32_e32 v151, v183, v155
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v184, v156
	v_fmac_f32_e32 v151, v185, v157
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v186, v158
	v_fmac_f32_e32 v151, v187, v159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v188, v160
	v_fmac_f32_e32 v151, v189, v161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v190, v148
	v_fmac_f32_e32 v151, v191, v162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v192, v149
	v_fmac_f32_e32 v151, v193, v195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v194, v150
	v_add_f32_e32 v149, v151, v119
	ds_load_b128 v[150:153], v102 offset:32768
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v154, 16, v150
	v_and_b32_e32 v159, 0xffff0000, v152
	v_and_b32_e32 v155, 0xffff0000, v150
	v_lshlrev_b32_e32 v156, 16, v151
	v_and_b32_e32 v161, 0xffff0000, v153
	v_fma_f32 v148, v163, v154, 0
	v_and_b32_e32 v157, 0xffff0000, v151
	v_lshlrev_b32_e32 v158, 16, v152
	v_lshlrev_b32_e32 v160, 16, v153
	ds_load_b128 v[150:153], v102 offset:34816
	v_fmac_f32_e32 v148, v164, v155
	v_fma_f32 v154, v178, v154, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v148, v165, v156
	v_fmac_f32_e32 v148, v166, v157
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v167, v158
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v162, 16, v150
	v_fmac_f32_e32 v148, v168, v159
	v_fmac_f32_e32 v154, v180, v155
	v_and_b32_e32 v150, 0xffff0000, v150
	v_lshlrev_b32_e32 v196, 16, v152
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v148, v169, v160 :: v_dual_lshlrev_b32 v195, 16, v151
	v_fmac_f32_e32 v154, v181, v156
	v_and_b32_e32 v152, 0xffff0000, v152
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v148, v170, v161 :: v_dual_and_b32 v151, 0xffff0000, v151
	v_fmac_f32_e32 v154, v182, v157
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v171, v162
	v_fmac_f32_e32 v154, v183, v158
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v172, v150
	v_dual_fmac_f32 v154, v184, v159 :: v_dual_lshlrev_b32 v197, 16, v153
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v173, v195
	v_dual_fmac_f32 v154, v185, v160 :: v_dual_and_b32 v153, 0xffff0000, v153
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v174, v151
	v_fmac_f32_e32 v154, v186, v161
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v175, v196
	v_fmac_f32_e32 v154, v187, v162
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v176, v152
	v_fmac_f32_e32 v154, v188, v150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v177, v197
	v_fmac_f32_e32 v154, v189, v195
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v148, v179, v153
	v_fmac_f32_e32 v154, v190, v151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v154, v191, v196
	v_fmac_f32_e32 v154, v192, v152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v154, v193, v197
	v_fmac_f32_e32 v154, v194, v153
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v150, v154, v117
	ds_load_b128 v[151:154], v102 offset:36864
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v155, 16, v151
	v_and_b32_e32 v156, 0xffff0000, v151
	v_dual_add_f32 v148, v148, v133 :: v_dual_lshlrev_b32 v157, 16, v152
	v_lshlrev_b32_e32 v161, 16, v154
	v_and_b32_e32 v158, 0xffff0000, v152
	v_lshlrev_b32_e32 v159, 16, v153
	v_and_b32_e32 v160, 0xffff0000, v153
	v_and_b32_e32 v162, 0xffff0000, v154
	ds_load_b128 v[151:154], v102 offset:38912
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v195, 16, v151
	v_and_b32_e32 v196, 0xffff0000, v151
	v_fma_f32 v151, v163, v155, 0
	v_lshlrev_b32_e32 v197, 16, v152
	v_and_b32_e32 v152, 0xffff0000, v152
	v_lshlrev_b32_e32 v198, 16, v153
	v_and_b32_e32 v153, 0xffff0000, v153
	v_fmac_f32_e32 v151, v164, v156
	v_fma_f32 v155, v178, v155, 0
	v_lshlrev_b32_e32 v199, 16, v154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v165, v157
	v_fmac_f32_e32 v151, v166, v158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v167, v159
	v_fmac_f32_e32 v151, v168, v160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v169, v161
	v_fmac_f32_e32 v151, v170, v162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v171, v195
	v_fmac_f32_e32 v151, v172, v196
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v173, v197
	v_fmac_f32_e32 v151, v174, v152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v151, v175, v198
	v_fmac_f32_e32 v151, v176, v153
	v_fmac_f32_e32 v155, v180, v156
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v151, v177, v199
	v_fmac_f32_e32 v155, v181, v157
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v182, v158
	v_dual_fmac_f32 v155, v183, v159 :: v_dual_and_b32 v154, 0xffff0000, v154
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v151, v179, v154
	v_fmac_f32_e32 v155, v184, v160
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add_f32_e32 v151, v151, v122
	v_fmac_f32_e32 v155, v185, v161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v186, v162
	v_fmac_f32_e32 v155, v187, v195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v188, v196
	v_fmac_f32_e32 v155, v189, v197
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v190, v152
	v_fmac_f32_e32 v155, v191, v198
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v192, v153
	v_fmac_f32_e32 v155, v193, v199
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v194, v154
	v_add_f32_e32 v153, v155, v115
	ds_load_b128 v[154:157], v102 offset:40960
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v158, 16, v154
	v_and_b32_e32 v197, 0xffff0000, v157
	v_and_b32_e32 v159, 0xffff0000, v154
	v_lshlrev_b32_e32 v160, 16, v155
	v_lshlrev_b32_e32 v162, 16, v156
	v_fma_f32 v152, v163, v158, 0
	v_and_b32_e32 v161, 0xffff0000, v155
	v_and_b32_e32 v195, 0xffff0000, v156
	v_lshlrev_b32_e32 v196, 16, v157
	ds_load_b128 v[154:157], v102 offset:43008
	v_fmac_f32_e32 v152, v164, v159
	v_fma_f32 v158, v178, v158, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v152, v165, v160
	v_fmac_f32_e32 v152, v166, v161
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v152, v167, v162
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v198, 16, v154
	v_fmac_f32_e32 v152, v168, v195
	v_and_b32_e32 v154, 0xffff0000, v154
	v_lshlrev_b32_e32 v200, 16, v156
	v_lshlrev_b32_e32 v199, 16, v155
	v_and_b32_e32 v156, 0xffff0000, v156
	v_dual_fmac_f32 v152, v169, v196 :: v_dual_and_b32 v155, 0xffff0000, v155
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v152, v170, v197
	v_fmac_f32_e32 v158, v180, v159
	v_fmac_f32_e32 v152, v171, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v158, v181, v160
	v_fmac_f32_e32 v152, v172, v154
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v158, v182, v161
	v_dual_fmac_f32 v152, v173, v199 :: v_dual_lshlrev_b32 v201, 16, v157
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dual_fmac_f32 v158, v183, v162 :: v_dual_and_b32 v157, 0xffff0000, v157
	v_fmac_f32_e32 v152, v174, v155
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v158, v184, v195
	v_fmac_f32_e32 v152, v175, v200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v158, v185, v196
	v_fmac_f32_e32 v152, v176, v156
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v158, v186, v197
	v_fmac_f32_e32 v152, v177, v201
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v158, v187, v198
	v_fmac_f32_e32 v152, v179, v157
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v158, v188, v154
	v_fmac_f32_e32 v158, v189, v199
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v158, v190, v155
	v_fmac_f32_e32 v158, v191, v200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v158, v192, v156
	v_fmac_f32_e32 v158, v193, v201
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v158, v194, v157
	v_add_f32_e32 v154, v158, v113
	ds_load_b128 v[155:158], v102 offset:45056
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v159, 16, v155
	v_and_b32_e32 v160, 0xffff0000, v155
	v_lshlrev_b32_e32 v161, 16, v156
	v_dual_add_f32 v152, v152, v120 :: v_dual_lshlrev_b32 v195, 16, v157
	v_and_b32_e32 v162, 0xffff0000, v156
	v_and_b32_e32 v196, 0xffff0000, v157
	v_lshlrev_b32_e32 v197, 16, v158
	v_and_b32_e32 v198, 0xffff0000, v158
	ds_load_b128 v[155:158], v102 offset:47104
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v199, 16, v155
	v_and_b32_e32 v200, 0xffff0000, v155
	v_fma_f32 v155, v163, v159, 0
	v_lshlrev_b32_e32 v201, 16, v156
	v_and_b32_e32 v156, 0xffff0000, v156
	v_lshlrev_b32_e32 v202, 16, v157
	v_and_b32_e32 v157, 0xffff0000, v157
	v_fmac_f32_e32 v155, v164, v160
	v_fma_f32 v159, v178, v159, 0
	v_lshlrev_b32_e32 v203, 16, v158
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v155, v165, v161 :: v_dual_and_b32 v158, 0xffff0000, v158
	v_fmac_f32_e32 v155, v166, v162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v167, v195
	v_fmac_f32_e32 v155, v168, v196
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v169, v197
	v_fmac_f32_e32 v155, v170, v198
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v171, v199
	v_fmac_f32_e32 v155, v172, v200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v173, v201
	v_fmac_f32_e32 v155, v174, v156
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v155, v175, v202
	v_fmac_f32_e32 v155, v176, v157
	v_fmac_f32_e32 v159, v180, v160
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v155, v177, v203
	v_fmac_f32_e32 v159, v181, v161
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v155, v179, v158
	v_fmac_f32_e32 v159, v182, v162
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add_f32_e32 v155, v155, v118
	v_fmac_f32_e32 v159, v183, v195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v184, v196
	v_fmac_f32_e32 v159, v185, v197
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v186, v198
	v_fmac_f32_e32 v159, v187, v199
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v188, v200
	v_fmac_f32_e32 v159, v189, v201
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v190, v156
	v_fmac_f32_e32 v159, v191, v202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v192, v157
	v_fmac_f32_e32 v159, v193, v203
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v194, v158
	v_add_f32_e32 v157, v159, v111
	ds_load_b128 v[158:161], v102 offset:49152
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v162, 16, v158
	v_and_b32_e32 v199, 0xffff0000, v160
	v_and_b32_e32 v195, 0xffff0000, v158
	v_lshlrev_b32_e32 v196, 16, v159
	v_and_b32_e32 v201, 0xffff0000, v161
	v_fma_f32 v156, v163, v162, 0
	v_and_b32_e32 v197, 0xffff0000, v159
	v_lshlrev_b32_e32 v198, 16, v160
	v_lshlrev_b32_e32 v200, 16, v161
	ds_load_b128 v[158:161], v102 offset:51200
	v_fmac_f32_e32 v156, v164, v195
	v_fma_f32 v162, v178, v162, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v156, v165, v196
	v_fmac_f32_e32 v156, v166, v197
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v167, v198
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v202, 16, v158
	v_fmac_f32_e32 v156, v168, v199
	v_fmac_f32_e32 v162, v180, v195
	v_and_b32_e32 v158, 0xffff0000, v158
	v_lshlrev_b32_e32 v204, 16, v160
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v156, v169, v200 :: v_dual_lshlrev_b32 v203, 16, v159
	v_fmac_f32_e32 v162, v181, v196
	v_and_b32_e32 v160, 0xffff0000, v160
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v156, v170, v201 :: v_dual_and_b32 v159, 0xffff0000, v159
	v_fmac_f32_e32 v162, v182, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v171, v202
	v_fmac_f32_e32 v162, v183, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v172, v158
	v_dual_fmac_f32 v162, v184, v199 :: v_dual_lshlrev_b32 v205, 16, v161
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v173, v203
	v_dual_fmac_f32 v162, v185, v200 :: v_dual_and_b32 v161, 0xffff0000, v161
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v174, v159
	v_fmac_f32_e32 v162, v186, v201
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v175, v204
	v_fmac_f32_e32 v162, v187, v202
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v176, v160
	v_fmac_f32_e32 v162, v188, v158
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v177, v205
	v_fmac_f32_e32 v162, v189, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v156, v179, v161
	v_fmac_f32_e32 v162, v190, v159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v162, v191, v204
	v_fmac_f32_e32 v162, v192, v160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v162, v193, v205
	v_fmac_f32_e32 v162, v194, v161
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v158, v162, v109
	ds_load_b128 v[159:162], v102 offset:53248
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v195, 16, v159
	v_and_b32_e32 v196, 0xffff0000, v159
	v_lshlrev_b32_e32 v197, 16, v160
	v_dual_add_f32 v156, v156, v116 :: v_dual_lshlrev_b32 v199, 16, v161
	v_and_b32_e32 v198, 0xffff0000, v160
	v_and_b32_e32 v200, 0xffff0000, v161
	v_lshlrev_b32_e32 v201, 16, v162
	v_and_b32_e32 v202, 0xffff0000, v162
	ds_load_b128 v[159:162], v102 offset:55296
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v203, 16, v159
	v_and_b32_e32 v204, 0xffff0000, v159
	v_fma_f32 v159, v163, v195, 0
	v_lshlrev_b32_e32 v205, 16, v160
	v_and_b32_e32 v160, 0xffff0000, v160
	v_lshlrev_b32_e32 v206, 16, v161
	v_and_b32_e32 v161, 0xffff0000, v161
	v_fmac_f32_e32 v159, v164, v196
	v_fma_f32 v195, v178, v195, 0
	v_lshlrev_b32_e32 v207, 16, v162
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v159, v165, v197 :: v_dual_and_b32 v162, 0xffff0000, v162
	v_fmac_f32_e32 v159, v166, v198
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v167, v199
	v_fmac_f32_e32 v159, v168, v200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v169, v201
	v_fmac_f32_e32 v159, v170, v202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v171, v203
	v_fmac_f32_e32 v159, v172, v204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v173, v205
	v_fmac_f32_e32 v159, v174, v160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v159, v175, v206
	v_fmac_f32_e32 v159, v176, v161
	v_fmac_f32_e32 v195, v180, v196
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v159, v177, v207
	v_fmac_f32_e32 v195, v181, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v159, v179, v162
	v_fmac_f32_e32 v195, v182, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_add_f32_e32 v159, v159, v124
	v_fmac_f32_e32 v195, v183, v199
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v195, v184, v200
	v_fmac_f32_e32 v195, v185, v201
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v195, v186, v202
	v_fmac_f32_e32 v195, v187, v203
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v195, v188, v204
	v_fmac_f32_e32 v195, v189, v205
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v195, v190, v160
	v_fmac_f32_e32 v195, v191, v206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v195, v192, v161
	v_fmac_f32_e32 v195, v193, v207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v195, v194, v162
	v_add_f32_e32 v161, v195, v107
	ds_load_b128 v[195:198], v102 offset:57344
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v162, 16, v195
	v_and_b32_e32 v205, 0xffff0000, v198
	v_and_b32_e32 v199, 0xffff0000, v195
	v_lshlrev_b32_e32 v200, 16, v196
	v_and_b32_e32 v201, 0xffff0000, v196
	v_fma_f32 v160, v163, v162, 0
	v_lshlrev_b32_e32 v202, 16, v197
	v_and_b32_e32 v203, 0xffff0000, v197
	v_lshlrev_b32_e32 v204, 16, v198
	ds_load_b128 v[195:198], v102 offset:59392
	v_fmac_f32_e32 v160, v164, v199
	v_fma_f32 v162, v178, v162, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v160, v165, v200
	v_fmac_f32_e32 v160, v166, v201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v160, v167, v202
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v206, 16, v195
	v_fmac_f32_e32 v160, v168, v203
	v_lshlrev_b32_e32 v208, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v207, 16, v196
	v_and_b32_e32 v196, 0xffff0000, v196
	v_dual_fmac_f32 v160, v169, v204 :: v_dual_and_b32 v195, 0xffff0000, v195
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v160, v170, v205 :: v_dual_lshlrev_b32 v209, 16, v198
	v_fmac_f32_e32 v162, v180, v199
	v_and_b32_e32 v198, 0xffff0000, v198
	v_fmac_f32_e32 v160, v171, v206
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v162, v181, v200
	v_fmac_f32_e32 v160, v172, v195
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v162, v182, v201
	v_fmac_f32_e32 v160, v173, v207
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v162, v183, v202
	v_fmac_f32_e32 v160, v174, v196
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v162, v184, v203
	v_fmac_f32_e32 v160, v175, v208
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v162, v185, v204
	v_fmac_f32_e32 v160, v176, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v162, v186, v205
	v_fmac_f32_e32 v160, v177, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v162, v187, v206
	v_fmac_f32_e32 v160, v179, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v162, v188, v195
	v_fmac_f32_e32 v162, v189, v207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v162, v190, v196
	v_fmac_f32_e32 v162, v191, v208
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v162, v192, v197
	v_fmac_f32_e32 v162, v193, v209
	s_delay_alu instid0(VALU_DEP_1)
	v_fmac_f32_e32 v162, v194, v198
	ds_load_b128 v[195:198], v102 offset:61440
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v199, 16, v195
	v_and_b32_e32 v200, 0xffff0000, v195
	v_lshlrev_b32_e32 v201, 16, v196
	v_and_b32_e32 v202, 0xffff0000, v196
	v_dual_add_f32 v160, v160, v114 :: v_dual_lshlrev_b32 v203, 16, v197
	v_fma_f32 v163, v163, v199, 0
	v_and_b32_e32 v204, 0xffff0000, v197
	v_lshlrev_b32_e32 v205, 16, v198
	v_and_b32_e32 v206, 0xffff0000, v198
	ds_load_b128 v[195:198], v102 offset:63488
	v_fmac_f32_e32 v163, v164, v200
	v_fma_f32 v164, v178, v199, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v163, v165, v201
	v_or_b32_e32 v165, 32, v65
	v_fmac_f32_e32 v163, v166, v202
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v163, v167, v203
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v207, 16, v195
	v_fmac_f32_e32 v163, v168, v204
	v_and_b32_e32 v195, 0xffff0000, v195
	v_lshlrev_b32_e32 v208, 16, v196
	v_and_b32_e32 v196, 0xffff0000, v196
	v_lshlrev_b32_e32 v209, 16, v197
	v_fmac_f32_e32 v163, v169, v205
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v210, 16, v198
	v_and_b32_e32 v198, 0xffff0000, v198
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v163, v170, v206
	v_fmac_f32_e32 v163, v171, v207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v163, v172, v195
	v_fmac_f32_e32 v163, v173, v208
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v163, v174, v196
	v_dual_add_f32 v162, v162, v108 :: v_dual_fmac_f32 v163, v175, v209
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v163, v176, v197
	v_dual_fmac_f32 v164, v180, v200 :: v_dual_fmac_f32 v163, v177, v210
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v164, v181, v201 :: v_dual_fmac_f32 v163, v179, v198
	v_dual_fmac_f32 v164, v182, v202 :: v_dual_add_f32 v163, v163, v112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v164, v183, v203
	v_fmac_f32_e32 v164, v184, v204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v164, v185, v205
	v_fmac_f32_e32 v164, v186, v206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v164, v187, v207
	v_fmac_f32_e32 v164, v188, v195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v164, v189, v208
	v_fmac_f32_e32 v164, v190, v196
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v164, v191, v209
	v_fmac_f32_e32 v164, v192, v197
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v164, v193, v210
	v_fmac_f32_e32 v164, v194, v198
	s_delay_alu instid0(VALU_DEP_1)
	v_add_f32_e32 v164, v164, v110
	v_cmpx_gt_i32_e64 s29, v165
	s_cbranch_execz .LBB139_66
; %bb.61:                               ;   in Loop: Header=BB139_29 Depth=2
	v_bfe_u32 v168, v13, 8, 3
	v_bfe_u32 v169, v13, 16, 3
	v_bfe_u32 v170, v13, 24, 3
	v_bfe_u32 v172, v14, 8, 3
	v_bfe_u32 v178, v15, 24, 3
	v_cvt_f32_ubyte0_e32 v168, v168
	v_and_b32_e32 v167, 7, v13
	v_cvt_f32_ubyte0_e32 v169, v169
	v_cvt_f32_ubyte0_e32 v170, v170
	v_cvt_f32_ubyte0_e32 v172, v172
	v_mul_f32_e32 v168, 0x3b000000, v168
	v_cvt_f32_ubyte0_e32 v167, v167
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_mul_f32 v169, 0x3b000000, v169 :: v_dual_mul_f32 v170, 0x3b000000, v170
	v_dual_mul_f32 v172, 0x3b000000, v172 :: v_dual_and_b32 v171, 7, v14
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v167, 0x3b000000, v167
	v_and_b32_e32 v165, 0x7f, v13
	v_bfe_u32 v173, v14, 16, 3
	v_cvt_f32_ubyte0_e32 v171, v171
	v_cvt_f32_ubyte0_e32 v178, v178
	v_and_b32_e32 v175, 7, v15
	v_lshl_add_u32 v166, v165, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v165
	v_mul_f32_e32 v171, 0x3b000000, v171
	v_cvt_f32_ubyte0_e32 v173, v173
	v_mul_f32_e32 v178, 0x3b000000, v178
	v_cvt_f32_ubyte0_e32 v175, v175
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v166, v167, v166, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v165
	v_bfe_u32 v174, v14, 24, 3
	v_bfe_u32 v176, v15, 8, 3
	v_mul_f32_e32 v175, 0x3b000000, v175
	v_mul_f32_e32 v173, 0x3b000000, v173
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v165, 0x7fc00000, v166 :: v_dual_lshlrev_b32 v166, 24, v13
	v_cvt_f32_ubyte0_e32 v174, v174
	v_bfe_u32 v177, v15, 16, 3
	v_bfe_u32 v181, v16, 16, 3
	v_bfe_u32 v184, v9, 8, 3
	v_and_or_b32 v165, 0x80000000, v166, v165
	v_bfe_u32 v166, v13, 8, 7
	v_cvt_f32_ubyte0_e32 v176, v176
	v_cvt_f32_ubyte0_e32 v177, v177
	v_cvt_f32_ubyte0_e32 v181, v181
	v_cvt_f32_ubyte0_e32 v184, v184
	v_lshl_add_u32 v167, v166, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v166
	v_bfe_u32 v180, v16, 8, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v181, 0x3b000000, v181 :: v_dual_mul_f32 v184, 0x3b000000, v184
	v_mul_f32_e32 v177, 0x3b000000, v177
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v167, v168, v167, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v166
	v_cvt_f32_ubyte0_e32 v180, v180
	v_and_b32_e32 v183, 7, v9
	v_bfe_u32 v186, v9, 24, 3
	v_bfe_u32 v182, v16, 24, 3
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v166, 0x7fc00000, v167 :: v_dual_lshlrev_b32 v167, 16, v13
	v_cvt_f32_ubyte0_e32 v183, v183
	v_cvt_f32_ubyte0_e32 v186, v186
	v_cvt_f32_ubyte0_e32 v182, v182
	v_bfe_u32 v185, v9, 16, 3
	v_and_or_b32 v166, 0x80000000, v167, v166
	v_bfe_u32 v167, v13, 16, 7
	v_dual_mul_f32 v183, 0x3b000000, v183 :: v_dual_mul_f32 v186, 0x3b000000, v186
	v_bfe_u32 v188, v10, 8, 3
	v_cvt_f32_ubyte0_e32 v185, v185
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v168, v167, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v167
	v_bfe_u32 v190, v10, 24, 3
	v_cvt_f32_ubyte0_e32 v188, v188
	v_mul_f32_e32 v185, 0x3b000000, v185
	v_bfe_u32 v189, v10, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v168, v169, v168, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v167
	v_mul_f32_e32 v188, 0x3b000000, v188
	v_cvt_f32_ubyte0_e32 v190, v190
	v_bfe_u32 v192, v11, 8, 3
	v_cvt_f32_ubyte0_e32 v189, v189
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v167, 0x7fc00000, v168 :: v_dual_lshlrev_b32 v168, 8, v13
	v_bfe_u32 v193, v11, 16, 3
	v_cvt_f32_ubyte0_e32 v192, v192
	v_bfe_u32 v197, v12, 16, 3
	v_mul_f32_e32 v189, 0x3b000000, v189
	v_and_or_b32 v167, 0x80000000, v168, v167
	v_bfe_u32 v168, v13, 24, 7
	v_mul_f32_e32 v192, 0x3b000000, v192
	v_cvt_f32_ubyte0_e32 v193, v193
	v_cvt_f32_ubyte0_e32 v197, v197
	v_bfe_u32 v194, v11, 24, 3
	v_lshl_add_u32 v169, v168, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v168
	v_bfe_u32 v196, v12, 8, 3
	v_mul_f32_e32 v197, 0x3b000000, v197
	v_mul_f32_e32 v193, 0x3b000000, v193
	v_cvt_f32_ubyte0_e32 v194, v194
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, v170, v169, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v168
	v_cvt_f32_ubyte0_e32 v196, v196
	v_bfe_u32 v198, v12, 24, 3
	s_mov_b32 s30, exec_lo
	v_mul_f32_e32 v174, 0x3b000000, v174
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v168, 0x7fc00000, v169, vcc_lo
	v_and_b32_e32 v169, 0x7f, v14
	v_cvt_f32_ubyte0_e32 v198, v198
	v_dual_mul_f32 v182, 0x3b000000, v182 :: v_dual_and_b32 v179, 7, v16
	v_mul_f32_e32 v176, 0x3b000000, v176
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v170, v169, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v169
	v_cvt_f32_ubyte0_e32 v179, v179
	v_dual_mul_f32 v180, 0x3b000000, v180 :: v_dual_and_b32 v187, 7, v10
	v_mul_f32_e32 v190, 0x3b000000, v190
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v170, v171, v170, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v169
	v_mul_f32_e32 v179, 0x3b000000, v179
	v_cvt_f32_ubyte0_e32 v187, v187
	v_and_b32_e32 v195, 7, v12
	v_and_b32_e32 v191, 7, v11
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, 0x7fc00000, v170, vcc_lo
	v_dual_mul_f32 v187, 0x3b000000, v187 :: v_dual_lshlrev_b32 v170, 24, v14
	v_cvt_f32_ubyte0_e32 v195, v195
	v_cvt_f32_ubyte0_e32 v191, v191
	v_mul_f32_e32 v194, 0x3b000000, v194
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_and_or_b32 v169, 0x80000000, v170, v169
	v_bfe_u32 v170, v14, 8, 7
	v_mul_f32_e32 v195, 0x3b000000, v195
	v_dual_mul_f32 v191, 0x3b000000, v191 :: v_dual_mul_f32 v196, 0x3b000000, v196
	v_mul_f32_e32 v198, 0x3b000000, v198
	v_lshl_add_u32 v171, v170, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v170
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v171, v172, v171, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v170
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v170, 0x7fc00000, v171 :: v_dual_lshlrev_b32 v171, 16, v14
	v_and_or_b32 v168, 0x80000000, v13, v168
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v170, 0x80000000, v171, v170
	v_bfe_u32 v171, v14, 16, 7
	v_lshl_add_u32 v172, v171, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v171
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v172, v173, v172, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v171
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v171, 0x7fc00000, v172 :: v_dual_lshlrev_b32 v172, 8, v14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v171, 0x80000000, v172, v171
	v_bfe_u32 v172, v14, 24, 7
	v_lshl_add_u32 v173, v172, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v172
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v173, v174, v173, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v172
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v172, 0x7fc00000, v173, vcc_lo
	v_and_b32_e32 v173, 0x7f, v15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v174, v173, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v173
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v174, v175, v174, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v173
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v173, 0x7fc00000, v174 :: v_dual_lshlrev_b32 v174, 24, v15
	v_and_or_b32 v173, 0x80000000, v174, v173
	v_bfe_u32 v174, v15, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v175, v174, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v174
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v175, v176, v175, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v174
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v174, 0x7fc00000, v175, vcc_lo
	v_lshlrev_b32_e32 v175, 16, v15
	v_and_or_b32 v172, 0x80000000, v14, v172
	v_and_or_b32 v174, 0x80000000, v175, v174
	v_bfe_u32 v175, v15, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v176, v175, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v175
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v176, v177, v176, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v175
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v175, 0x7fc00000, v176 :: v_dual_lshlrev_b32 v176, 8, v15
	v_and_or_b32 v175, 0x80000000, v176, v175
	v_bfe_u32 v176, v15, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v177, v176, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v176
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v177, v178, v177, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v176
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v176, 0x7fc00000, v177, vcc_lo
	v_and_b32_e32 v177, 0x7f, v16
	v_and_or_b32 v176, 0x80000000, v15, v176
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v178, v177, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v177
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v178, v179, v178, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v177
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v177, 0x7fc00000, v178 :: v_dual_lshlrev_b32 v178, 24, v16
	v_and_or_b32 v177, 0x80000000, v178, v177
	v_bfe_u32 v178, v16, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v179, v178, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v178
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v179, v180, v179, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v178
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v178, 0x7fc00000, v179 :: v_dual_lshlrev_b32 v179, 16, v16
	v_and_or_b32 v178, 0x80000000, v179, v178
	v_bfe_u32 v179, v16, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v180, v179, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v179
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v180, v181, v180, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v179
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v179, 0x7fc00000, v180, vcc_lo
	v_lshlrev_b32_e32 v180, 8, v16
	v_and_or_b32 v179, 0x80000000, v180, v179
	v_bfe_u32 v180, v16, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v181, v180, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v181, v182, v181, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v180
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v180, 0x7fc00000, v181, vcc_lo
	v_and_or_b32 v181, 0x80000000, v16, v180
	v_and_b32_e32 v180, 0x7f, v9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v182, v180, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v182, v183, v182, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v180
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v180, 0x7fc00000, v182, vcc_lo
	v_lshlrev_b32_e32 v182, 24, v9
	v_and_or_b32 v180, 0x80000000, v182, v180
	v_bfe_u32 v182, v9, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v183, v182, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v182
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v183, v184, v183, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v182
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v182, 0x7fc00000, v183 :: v_dual_lshlrev_b32 v183, 16, v9
	v_and_or_b32 v182, 0x80000000, v183, v182
	v_bfe_u32 v183, v9, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v184, v183, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v183
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v184, v185, v184, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v183
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v183, 0x7fc00000, v184 :: v_dual_lshlrev_b32 v184, 8, v9
	v_and_or_b32 v183, 0x80000000, v184, v183
	v_bfe_u32 v184, v9, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v185, v184, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v184
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v185, v186, v185, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v184
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v184, 0x7fc00000, v185, vcc_lo
	v_and_b32_e32 v185, 0x7f, v10
	v_and_or_b32 v184, 0x80000000, v9, v184
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v186, v185, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v185
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v186, v187, v186, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v185
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v185, 0x7fc00000, v186, vcc_lo
	v_lshlrev_b32_e32 v186, 24, v10
	v_and_or_b32 v185, 0x80000000, v186, v185
	v_bfe_u32 v186, v10, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v187, v186, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v186
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v187, v188, v187, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v186
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v186, 0x7fc00000, v187 :: v_dual_lshlrev_b32 v187, 16, v10
	v_and_or_b32 v186, 0x80000000, v187, v186
	v_bfe_u32 v187, v10, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v188, v187, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v187
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v188, v189, v188, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v187
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v187, 0x7fc00000, v188 :: v_dual_lshlrev_b32 v188, 8, v10
	v_and_or_b32 v187, 0x80000000, v188, v187
	v_bfe_u32 v188, v10, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v189, v188, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v188
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v189, v190, v189, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v188
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v188, 0x7fc00000, v189, vcc_lo
	v_and_b32_e32 v189, 0x7f, v11
	v_lshl_add_u32 v190, v189, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v189
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v190, v191, v190, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v189
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v189, 0x7fc00000, v190 :: v_dual_lshlrev_b32 v190, 24, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v189, 0x80000000, v190, v189
	v_bfe_u32 v190, v11, 8, 7
	v_lshl_add_u32 v191, v190, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v190
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v191, v192, v191, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v190
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v190, 0x7fc00000, v191, vcc_lo
	v_lshlrev_b32_e32 v191, 16, v11
	v_and_or_b32 v188, 0x80000000, v10, v188
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v190, 0x80000000, v191, v190
	v_bfe_u32 v191, v11, 16, 7
	v_lshl_add_u32 v192, v191, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v191
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v192, v193, v192, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v191
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v191, 0x7fc00000, v192 :: v_dual_lshlrev_b32 v192, 8, v11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v191, 0x80000000, v192, v191
	v_bfe_u32 v192, v11, 24, 7
	v_lshl_add_u32 v193, v192, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v192
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v193, v194, v193, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v192
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v192, 0x7fc00000, v193, vcc_lo
	v_and_b32_e32 v193, 0x7f, v12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v194, v193, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v193
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v194, v195, v194, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v193
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v193, 0x7fc00000, v194 :: v_dual_lshlrev_b32 v194, 24, v12
	v_and_or_b32 v193, 0x80000000, v194, v193
	v_bfe_u32 v194, v12, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v195, v194, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v194
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v195, v196, v195, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v194
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v194, 0x7fc00000, v195 :: v_dual_lshlrev_b32 v195, 16, v12
	v_and_or_b32 v194, 0x80000000, v195, v194
	v_bfe_u32 v195, v12, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v196, v195, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v195
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v196, v197, v196, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v195
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v195, 0x7fc00000, v196, vcc_lo
	v_lshlrev_b32_e32 v196, 8, v12
	v_and_or_b32 v195, 0x80000000, v196, v195
	v_bfe_u32 v196, v12, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v197, v196, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v196
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v197, v198, v197, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v196
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v196, 0x7fc00000, v197, vcc_lo
	ds_load_b128 v[197:200], v102 offset:512
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	v_fma_f32 v201, v180, v201, 0
	v_and_or_b32 v192, 0x80000000, v11, v192
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	ds_load_b128 v[197:200], v102 offset:2560
	v_fmac_f32_e32 v201, v182, v202
	v_and_or_b32 v196, 0x80000000, v12, v196
	v_fmac_f32_e32 v213, v167, v203
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v183, v203
	v_fmac_f32_e32 v213, v168, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v184, v204
	v_fmac_f32_e32 v213, v169, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v185, v205
	v_fmac_f32_e32 v213, v170, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v210, 16, v198
	v_and_b32_e32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v212, 16, v200
	v_dual_fmac_f32 v201, v186, v206 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v213, v171, v207
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v211, 16, v199
	v_fmac_f32_e32 v201, v187, v207
	v_fmac_f32_e32 v213, v172, v208
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v201, v188, v208
	v_fmac_f32_e32 v213, v173, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v189, v209
	v_fmac_f32_e32 v213, v174, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v190, v197
	v_fmac_f32_e32 v213, v175, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v191, v210
	v_fmac_f32_e32 v213, v176, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v192, v198
	v_fmac_f32_e32 v213, v177, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v193, v211
	v_fmac_f32_e32 v213, v178, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v194, v199
	v_fmac_f32_e32 v213, v179, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v195, v212
	v_fmac_f32_e32 v213, v181, v200
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:4608
	v_add_f32_e32 v66, v213, v66
	v_add_f32_e32 v67, v201, v67
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:6656
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:8704
	v_add_f32_e32 v68, v213, v68
	v_add_f32_e32 v97, v201, v97
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:10752
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:12800
	v_add_f32_e32 v75, v213, v75
	s_wait_dscnt 0x0
	v_dual_add_f32 v98, v201, v98 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:14848
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:16896
	v_add_f32_e32 v139, v213, v139
	v_add_f32_e32 v141, v201, v141
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:18944
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:20992
	v_add_f32_e32 v140, v213, v140
	s_wait_dscnt 0x0
	v_dual_add_f32 v142, v201, v142 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:23040
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:25088
	v_add_f32_e32 v143, v213, v143
	v_add_f32_e32 v145, v201, v145
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:27136
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:29184
	v_add_f32_e32 v144, v213, v144
	s_wait_dscnt 0x0
	v_dual_add_f32 v146, v201, v146 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:31232
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:33280
	v_add_f32_e32 v147, v213, v147
	v_add_f32_e32 v149, v201, v149
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:35328
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:37376
	v_add_f32_e32 v148, v213, v148
	s_wait_dscnt 0x0
	v_dual_add_f32 v150, v201, v150 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:39424
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:41472
	v_add_f32_e32 v151, v213, v151
	v_add_f32_e32 v153, v201, v153
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:43520
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:45568
	v_add_f32_e32 v152, v213, v152
	s_wait_dscnt 0x0
	v_dual_add_f32 v154, v201, v154 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:47616
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:49664
	v_add_f32_e32 v155, v213, v155
	v_add_f32_e32 v157, v201, v157
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:51712
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:53760
	v_add_f32_e32 v156, v213, v156
	s_wait_dscnt 0x0
	v_dual_add_f32 v158, v201, v158 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:55808
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:57856
	v_add_f32_e32 v159, v213, v159
	v_add_f32_e32 v161, v201, v161
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:59904
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:61952
	v_add_f32_e32 v160, v213, v160
	s_wait_dscnt 0x0
	v_dual_add_f32 v162, v201, v162 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v165, v165, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	v_and_b32_e32 v208, 0xffff0000, v200
	ds_load_b128 v[197:200], v102 offset:64000
	v_fmac_f32_e32 v165, v166, v202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v167, v203
	v_fmac_f32_e32 v165, v168, v204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v165, v169, v205
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_fmac_f32_e32 v165, v170, v206
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v210, 16, v198
	v_and_b32_e32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_fmac_f32_e32 v165, v171, v207
	v_and_b32_e32 v199, 0xffff0000, v199
	v_lshlrev_b32_e32 v212, 16, v200
	v_and_b32_e32 v200, 0xffff0000, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v172, v208
	v_fmac_f32_e32 v165, v173, v209
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v174, v197
	v_fmac_f32_e32 v165, v175, v210
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v176, v198
	v_fmac_f32_e32 v165, v177, v211
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v178, v199
	v_fmac_f32_e32 v165, v179, v212
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v181, v200
	v_add_f32_e32 v163, v165, v163
	v_fma_f32 v165, v180, v201, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v182, v202
	v_fmac_f32_e32 v165, v183, v203
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v184, v204
	v_fmac_f32_e32 v165, v185, v205
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v186, v206
	v_fmac_f32_e32 v165, v187, v207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v188, v208
	v_fmac_f32_e32 v165, v189, v209
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v190, v197
	v_fmac_f32_e32 v165, v191, v210
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v192, v198
	v_fmac_f32_e32 v165, v193, v211
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v194, v199
	v_fmac_f32_e32 v165, v195, v212
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v196, v200
	v_add_f32_e32 v164, v165, v164
	v_or_b32_e32 v165, 64, v65
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s29, v165
	s_cbranch_execz .LBB139_65
; %bb.62:                               ;   in Loop: Header=BB139_29 Depth=2
	v_bfe_u32 v168, v21, 8, 3
	v_bfe_u32 v169, v21, 16, 3
	v_bfe_u32 v170, v21, 24, 3
	v_bfe_u32 v172, v22, 8, 3
	v_bfe_u32 v178, v23, 24, 3
	v_cvt_f32_ubyte0_e32 v168, v168
	v_and_b32_e32 v167, 7, v21
	v_cvt_f32_ubyte0_e32 v169, v169
	v_cvt_f32_ubyte0_e32 v170, v170
	v_cvt_f32_ubyte0_e32 v172, v172
	v_mul_f32_e32 v168, 0x3b000000, v168
	v_cvt_f32_ubyte0_e32 v167, v167
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_mul_f32 v169, 0x3b000000, v169 :: v_dual_mul_f32 v170, 0x3b000000, v170
	v_dual_mul_f32 v172, 0x3b000000, v172 :: v_dual_and_b32 v171, 7, v22
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v167, 0x3b000000, v167
	v_and_b32_e32 v165, 0x7f, v21
	v_bfe_u32 v173, v22, 16, 3
	v_cvt_f32_ubyte0_e32 v171, v171
	v_cvt_f32_ubyte0_e32 v178, v178
	v_and_b32_e32 v175, 7, v23
	v_lshl_add_u32 v166, v165, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v165
	v_mul_f32_e32 v171, 0x3b000000, v171
	v_cvt_f32_ubyte0_e32 v173, v173
	v_mul_f32_e32 v178, 0x3b000000, v178
	v_cvt_f32_ubyte0_e32 v175, v175
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v166, v167, v166, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v165
	v_bfe_u32 v174, v22, 24, 3
	v_bfe_u32 v176, v23, 8, 3
	v_mul_f32_e32 v175, 0x3b000000, v175
	v_mul_f32_e32 v173, 0x3b000000, v173
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v165, 0x7fc00000, v166 :: v_dual_lshlrev_b32 v166, 24, v21
	v_cvt_f32_ubyte0_e32 v174, v174
	v_bfe_u32 v177, v23, 16, 3
	v_bfe_u32 v181, v24, 16, 3
	v_bfe_u32 v184, v17, 8, 3
	v_and_or_b32 v165, 0x80000000, v166, v165
	v_bfe_u32 v166, v21, 8, 7
	v_cvt_f32_ubyte0_e32 v176, v176
	v_cvt_f32_ubyte0_e32 v177, v177
	v_cvt_f32_ubyte0_e32 v181, v181
	v_cvt_f32_ubyte0_e32 v184, v184
	v_lshl_add_u32 v167, v166, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v166
	v_bfe_u32 v180, v24, 8, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v181, 0x3b000000, v181 :: v_dual_mul_f32 v184, 0x3b000000, v184
	v_mul_f32_e32 v177, 0x3b000000, v177
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v167, v168, v167, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v166
	v_cvt_f32_ubyte0_e32 v180, v180
	v_and_b32_e32 v183, 7, v17
	v_bfe_u32 v186, v17, 24, 3
	v_bfe_u32 v182, v24, 24, 3
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v166, 0x7fc00000, v167 :: v_dual_lshlrev_b32 v167, 16, v21
	v_cvt_f32_ubyte0_e32 v183, v183
	v_cvt_f32_ubyte0_e32 v186, v186
	v_cvt_f32_ubyte0_e32 v182, v182
	v_bfe_u32 v185, v17, 16, 3
	v_and_or_b32 v166, 0x80000000, v167, v166
	v_bfe_u32 v167, v21, 16, 7
	v_dual_mul_f32 v183, 0x3b000000, v183 :: v_dual_mul_f32 v186, 0x3b000000, v186
	v_bfe_u32 v188, v18, 8, 3
	v_cvt_f32_ubyte0_e32 v185, v185
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v168, v167, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v167
	v_bfe_u32 v190, v18, 24, 3
	v_cvt_f32_ubyte0_e32 v188, v188
	v_mul_f32_e32 v185, 0x3b000000, v185
	v_bfe_u32 v189, v18, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v168, v169, v168, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v167
	v_mul_f32_e32 v188, 0x3b000000, v188
	v_cvt_f32_ubyte0_e32 v190, v190
	v_bfe_u32 v192, v19, 8, 3
	v_cvt_f32_ubyte0_e32 v189, v189
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v167, 0x7fc00000, v168 :: v_dual_lshlrev_b32 v168, 8, v21
	v_bfe_u32 v193, v19, 16, 3
	v_cvt_f32_ubyte0_e32 v192, v192
	v_bfe_u32 v197, v20, 16, 3
	v_mul_f32_e32 v189, 0x3b000000, v189
	v_and_or_b32 v167, 0x80000000, v168, v167
	v_bfe_u32 v168, v21, 24, 7
	v_mul_f32_e32 v192, 0x3b000000, v192
	v_cvt_f32_ubyte0_e32 v193, v193
	v_cvt_f32_ubyte0_e32 v197, v197
	v_bfe_u32 v194, v19, 24, 3
	v_lshl_add_u32 v169, v168, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v168
	v_bfe_u32 v196, v20, 8, 3
	v_mul_f32_e32 v197, 0x3b000000, v197
	v_mul_f32_e32 v193, 0x3b000000, v193
	v_cvt_f32_ubyte0_e32 v194, v194
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, v170, v169, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v168
	v_cvt_f32_ubyte0_e32 v196, v196
	v_bfe_u32 v198, v20, 24, 3
	s_mov_b32 s56, exec_lo
	v_mul_f32_e32 v174, 0x3b000000, v174
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v168, 0x7fc00000, v169, vcc_lo
	v_and_b32_e32 v169, 0x7f, v22
	v_cvt_f32_ubyte0_e32 v198, v198
	v_dual_mul_f32 v182, 0x3b000000, v182 :: v_dual_and_b32 v179, 7, v24
	v_mul_f32_e32 v176, 0x3b000000, v176
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshl_add_u32 v170, v169, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v169
	v_cvt_f32_ubyte0_e32 v179, v179
	v_dual_mul_f32 v180, 0x3b000000, v180 :: v_dual_and_b32 v187, 7, v18
	v_mul_f32_e32 v190, 0x3b000000, v190
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v170, v171, v170, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v169
	v_mul_f32_e32 v179, 0x3b000000, v179
	v_cvt_f32_ubyte0_e32 v187, v187
	v_and_b32_e32 v195, 7, v20
	v_and_b32_e32 v191, 7, v19
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, 0x7fc00000, v170, vcc_lo
	v_dual_mul_f32 v187, 0x3b000000, v187 :: v_dual_lshlrev_b32 v170, 24, v22
	v_cvt_f32_ubyte0_e32 v195, v195
	v_cvt_f32_ubyte0_e32 v191, v191
	v_mul_f32_e32 v194, 0x3b000000, v194
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)
	v_and_or_b32 v169, 0x80000000, v170, v169
	v_bfe_u32 v170, v22, 8, 7
	v_mul_f32_e32 v195, 0x3b000000, v195
	v_dual_mul_f32 v191, 0x3b000000, v191 :: v_dual_mul_f32 v196, 0x3b000000, v196
	v_mul_f32_e32 v198, 0x3b000000, v198
	v_lshl_add_u32 v171, v170, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v170
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v171, v172, v171, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v170
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v170, 0x7fc00000, v171 :: v_dual_lshlrev_b32 v171, 16, v22
	v_and_or_b32 v168, 0x80000000, v21, v168
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v170, 0x80000000, v171, v170
	v_bfe_u32 v171, v22, 16, 7
	v_lshl_add_u32 v172, v171, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v171
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v172, v173, v172, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v171
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v171, 0x7fc00000, v172 :: v_dual_lshlrev_b32 v172, 8, v22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v171, 0x80000000, v172, v171
	v_bfe_u32 v172, v22, 24, 7
	v_lshl_add_u32 v173, v172, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v172
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v173, v174, v173, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v172
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v172, 0x7fc00000, v173, vcc_lo
	v_and_b32_e32 v173, 0x7f, v23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v174, v173, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v173
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v174, v175, v174, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v173
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v173, 0x7fc00000, v174 :: v_dual_lshlrev_b32 v174, 24, v23
	v_and_or_b32 v173, 0x80000000, v174, v173
	v_bfe_u32 v174, v23, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v175, v174, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v174
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v175, v176, v175, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v174
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v174, 0x7fc00000, v175, vcc_lo
	v_lshlrev_b32_e32 v175, 16, v23
	v_and_or_b32 v172, 0x80000000, v22, v172
	v_and_or_b32 v174, 0x80000000, v175, v174
	v_bfe_u32 v175, v23, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v176, v175, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v175
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v176, v177, v176, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v175
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v175, 0x7fc00000, v176 :: v_dual_lshlrev_b32 v176, 8, v23
	v_and_or_b32 v175, 0x80000000, v176, v175
	v_bfe_u32 v176, v23, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v177, v176, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v176
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v177, v178, v177, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v176
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v176, 0x7fc00000, v177, vcc_lo
	v_and_b32_e32 v177, 0x7f, v24
	v_and_or_b32 v176, 0x80000000, v23, v176
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v178, v177, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v177
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v178, v179, v178, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v177
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v177, 0x7fc00000, v178 :: v_dual_lshlrev_b32 v178, 24, v24
	v_and_or_b32 v177, 0x80000000, v178, v177
	v_bfe_u32 v178, v24, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v179, v178, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v178
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v179, v180, v179, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v178
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v178, 0x7fc00000, v179 :: v_dual_lshlrev_b32 v179, 16, v24
	v_and_or_b32 v178, 0x80000000, v179, v178
	v_bfe_u32 v179, v24, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v180, v179, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v179
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v180, v181, v180, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v179
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v179, 0x7fc00000, v180, vcc_lo
	v_lshlrev_b32_e32 v180, 8, v24
	v_and_or_b32 v179, 0x80000000, v180, v179
	v_bfe_u32 v180, v24, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v181, v180, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v181, v182, v181, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v180
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v180, 0x7fc00000, v181, vcc_lo
	v_and_or_b32 v181, 0x80000000, v24, v180
	v_and_b32_e32 v180, 0x7f, v17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v182, v180, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v182, v183, v182, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v180
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v180, 0x7fc00000, v182, vcc_lo
	v_lshlrev_b32_e32 v182, 24, v17
	v_and_or_b32 v180, 0x80000000, v182, v180
	v_bfe_u32 v182, v17, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v183, v182, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v182
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v183, v184, v183, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v182
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v182, 0x7fc00000, v183 :: v_dual_lshlrev_b32 v183, 16, v17
	v_and_or_b32 v182, 0x80000000, v183, v182
	v_bfe_u32 v183, v17, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v184, v183, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v183
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v184, v185, v184, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v183
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v183, 0x7fc00000, v184 :: v_dual_lshlrev_b32 v184, 8, v17
	v_and_or_b32 v183, 0x80000000, v184, v183
	v_bfe_u32 v184, v17, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v185, v184, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v184
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v185, v186, v185, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v184
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v184, 0x7fc00000, v185, vcc_lo
	v_and_b32_e32 v185, 0x7f, v18
	v_and_or_b32 v184, 0x80000000, v17, v184
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v186, v185, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v185
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v186, v187, v186, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v185
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v185, 0x7fc00000, v186, vcc_lo
	v_lshlrev_b32_e32 v186, 24, v18
	v_and_or_b32 v185, 0x80000000, v186, v185
	v_bfe_u32 v186, v18, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v187, v186, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v186
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v187, v188, v187, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v186
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v186, 0x7fc00000, v187 :: v_dual_lshlrev_b32 v187, 16, v18
	v_and_or_b32 v186, 0x80000000, v187, v186
	v_bfe_u32 v187, v18, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v188, v187, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v187
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v188, v189, v188, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v187
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v187, 0x7fc00000, v188 :: v_dual_lshlrev_b32 v188, 8, v18
	v_and_or_b32 v187, 0x80000000, v188, v187
	v_bfe_u32 v188, v18, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v189, v188, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v188
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v189, v190, v189, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v188
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v188, 0x7fc00000, v189, vcc_lo
	v_and_b32_e32 v189, 0x7f, v19
	v_lshl_add_u32 v190, v189, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v189
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v190, v191, v190, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v189
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v189, 0x7fc00000, v190 :: v_dual_lshlrev_b32 v190, 24, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v189, 0x80000000, v190, v189
	v_bfe_u32 v190, v19, 8, 7
	v_lshl_add_u32 v191, v190, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v190
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v191, v192, v191, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v190
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v190, 0x7fc00000, v191, vcc_lo
	v_lshlrev_b32_e32 v191, 16, v19
	v_and_or_b32 v188, 0x80000000, v18, v188
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v190, 0x80000000, v191, v190
	v_bfe_u32 v191, v19, 16, 7
	v_lshl_add_u32 v192, v191, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v191
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v192, v193, v192, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v191
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v191, 0x7fc00000, v192 :: v_dual_lshlrev_b32 v192, 8, v19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v191, 0x80000000, v192, v191
	v_bfe_u32 v192, v19, 24, 7
	v_lshl_add_u32 v193, v192, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v192
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v193, v194, v193, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v192
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v192, 0x7fc00000, v193, vcc_lo
	v_and_b32_e32 v193, 0x7f, v20
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v194, v193, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v193
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v194, v195, v194, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v193
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v193, 0x7fc00000, v194 :: v_dual_lshlrev_b32 v194, 24, v20
	v_and_or_b32 v193, 0x80000000, v194, v193
	v_bfe_u32 v194, v20, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v195, v194, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v194
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v195, v196, v195, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v194
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v194, 0x7fc00000, v195 :: v_dual_lshlrev_b32 v195, 16, v20
	v_and_or_b32 v194, 0x80000000, v195, v194
	v_bfe_u32 v195, v20, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v196, v195, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v195
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v196, v197, v196, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v195
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v195, 0x7fc00000, v196, vcc_lo
	v_lshlrev_b32_e32 v196, 8, v20
	v_and_or_b32 v195, 0x80000000, v196, v195
	v_bfe_u32 v196, v20, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v197, v196, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v196
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v197, v198, v197, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v196
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v196, 0x7fc00000, v197, vcc_lo
	ds_load_b128 v[197:200], v102 offset:1024
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	v_fma_f32 v201, v180, v201, 0
	v_and_or_b32 v192, 0x80000000, v19, v192
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	ds_load_b128 v[197:200], v102 offset:3072
	v_fmac_f32_e32 v201, v182, v202
	v_and_or_b32 v196, 0x80000000, v20, v196
	v_fmac_f32_e32 v213, v167, v203
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v183, v203
	v_fmac_f32_e32 v213, v168, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v184, v204
	v_fmac_f32_e32 v213, v169, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v185, v205
	v_fmac_f32_e32 v213, v170, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v210, 16, v198
	v_and_b32_e32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v212, 16, v200
	v_dual_fmac_f32 v201, v186, v206 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v213, v171, v207
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v211, 16, v199
	v_fmac_f32_e32 v201, v187, v207
	v_fmac_f32_e32 v213, v172, v208
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v201, v188, v208
	v_fmac_f32_e32 v213, v173, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v189, v209
	v_fmac_f32_e32 v213, v174, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v190, v197
	v_fmac_f32_e32 v213, v175, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v191, v210
	v_fmac_f32_e32 v213, v176, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v192, v198
	v_fmac_f32_e32 v213, v177, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v193, v211
	v_fmac_f32_e32 v213, v178, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v194, v199
	v_fmac_f32_e32 v213, v179, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v195, v212
	v_fmac_f32_e32 v213, v181, v200
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:5120
	v_add_f32_e32 v66, v213, v66
	v_add_f32_e32 v67, v201, v67
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:7168
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:9216
	v_add_f32_e32 v68, v213, v68
	v_add_f32_e32 v97, v201, v97
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:11264
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:13312
	v_add_f32_e32 v75, v213, v75
	s_wait_dscnt 0x0
	v_dual_add_f32 v98, v201, v98 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:15360
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:17408
	v_add_f32_e32 v139, v213, v139
	v_add_f32_e32 v141, v201, v141
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:19456
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:21504
	v_add_f32_e32 v140, v213, v140
	s_wait_dscnt 0x0
	v_dual_add_f32 v142, v201, v142 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:23552
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:25600
	v_add_f32_e32 v143, v213, v143
	v_add_f32_e32 v145, v201, v145
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:27648
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:29696
	v_add_f32_e32 v144, v213, v144
	s_wait_dscnt 0x0
	v_dual_add_f32 v146, v201, v146 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:31744
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:33792
	v_add_f32_e32 v147, v213, v147
	v_add_f32_e32 v149, v201, v149
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:35840
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:37888
	v_add_f32_e32 v148, v213, v148
	s_wait_dscnt 0x0
	v_dual_add_f32 v150, v201, v150 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:39936
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:41984
	v_add_f32_e32 v151, v213, v151
	v_add_f32_e32 v153, v201, v153
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:44032
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:46080
	v_add_f32_e32 v152, v213, v152
	s_wait_dscnt 0x0
	v_dual_add_f32 v154, v201, v154 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:48128
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:50176
	v_add_f32_e32 v155, v213, v155
	v_add_f32_e32 v157, v201, v157
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:52224
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:54272
	v_add_f32_e32 v156, v213, v156
	s_wait_dscnt 0x0
	v_dual_add_f32 v158, v201, v158 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:56320
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:58368
	v_add_f32_e32 v159, v213, v159
	v_add_f32_e32 v161, v201, v161
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:60416
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:62464
	v_add_f32_e32 v160, v213, v160
	s_wait_dscnt 0x0
	v_dual_add_f32 v162, v201, v162 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v165, v165, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	v_and_b32_e32 v208, 0xffff0000, v200
	ds_load_b128 v[197:200], v102 offset:64512
	v_fmac_f32_e32 v165, v166, v202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v167, v203
	v_fmac_f32_e32 v165, v168, v204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v165, v169, v205
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_fmac_f32_e32 v165, v170, v206
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v210, 16, v198
	v_and_b32_e32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_fmac_f32_e32 v165, v171, v207
	v_and_b32_e32 v199, 0xffff0000, v199
	v_lshlrev_b32_e32 v212, 16, v200
	v_and_b32_e32 v200, 0xffff0000, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v172, v208
	v_fmac_f32_e32 v165, v173, v209
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v174, v197
	v_fmac_f32_e32 v165, v175, v210
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v176, v198
	v_fmac_f32_e32 v165, v177, v211
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v178, v199
	v_fmac_f32_e32 v165, v179, v212
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v181, v200
	v_add_f32_e32 v163, v165, v163
	v_fma_f32 v165, v180, v201, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v182, v202
	v_fmac_f32_e32 v165, v183, v203
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v184, v204
	v_fmac_f32_e32 v165, v185, v205
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v186, v206
	v_fmac_f32_e32 v165, v187, v207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v188, v208
	v_fmac_f32_e32 v165, v189, v209
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v190, v197
	v_fmac_f32_e32 v165, v191, v210
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v192, v198
	v_fmac_f32_e32 v165, v193, v211
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v194, v199
	v_fmac_f32_e32 v165, v195, v212
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v196, v200
	v_add_f32_e32 v164, v165, v164
	v_or_b32_e32 v165, 0x60, v65
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s29, v165
	s_cbranch_execz .LBB139_64
; %bb.63:                               ;   in Loop: Header=BB139_29 Depth=2
	v_bfe_u32 v168, v29, 8, 3
	v_bfe_u32 v169, v29, 16, 3
	v_bfe_u32 v170, v29, 24, 3
	v_bfe_u32 v172, v30, 8, 3
	v_bfe_u32 v178, v31, 24, 3
	v_cvt_f32_ubyte0_e32 v168, v168
	v_and_b32_e32 v167, 7, v29
	v_cvt_f32_ubyte0_e32 v169, v169
	v_cvt_f32_ubyte0_e32 v170, v170
	v_cvt_f32_ubyte0_e32 v172, v172
	v_mul_f32_e32 v168, 0x3b000000, v168
	v_cvt_f32_ubyte0_e32 v167, v167
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_mul_f32 v169, 0x3b000000, v169 :: v_dual_mul_f32 v170, 0x3b000000, v170
	v_dual_mul_f32 v172, 0x3b000000, v172 :: v_dual_and_b32 v171, 7, v30
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_mul_f32_e32 v167, 0x3b000000, v167
	v_and_b32_e32 v165, 0x7f, v29
	v_bfe_u32 v173, v30, 16, 3
	v_cvt_f32_ubyte0_e32 v171, v171
	v_cvt_f32_ubyte0_e32 v178, v178
	v_and_b32_e32 v175, 7, v31
	v_lshl_add_u32 v166, v165, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v165
	v_mul_f32_e32 v171, 0x3b000000, v171
	v_cvt_f32_ubyte0_e32 v173, v173
	v_mul_f32_e32 v178, 0x3b000000, v178
	v_cvt_f32_ubyte0_e32 v175, v175
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v166, v167, v166, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v165
	v_bfe_u32 v174, v30, 24, 3
	v_bfe_u32 v176, v31, 8, 3
	v_mul_f32_e32 v175, 0x3b000000, v175
	v_mul_f32_e32 v173, 0x3b000000, v173
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v165, 0x7fc00000, v166 :: v_dual_lshlrev_b32 v166, 24, v29
	v_cvt_f32_ubyte0_e32 v174, v174
	v_bfe_u32 v177, v31, 16, 3
	v_bfe_u32 v181, v32, 16, 3
	v_bfe_u32 v184, v25, 8, 3
	v_and_or_b32 v165, 0x80000000, v166, v165
	v_bfe_u32 v166, v29, 8, 7
	v_cvt_f32_ubyte0_e32 v176, v176
	v_cvt_f32_ubyte0_e32 v177, v177
	v_cvt_f32_ubyte0_e32 v181, v181
	v_cvt_f32_ubyte0_e32 v184, v184
	v_lshl_add_u32 v167, v166, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v166
	v_bfe_u32 v180, v32, 8, 3
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v181, 0x3b000000, v181 :: v_dual_mul_f32 v184, 0x3b000000, v184
	v_mul_f32_e32 v177, 0x3b000000, v177
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v167, v168, v167, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v166
	v_cvt_f32_ubyte0_e32 v180, v180
	v_and_b32_e32 v183, 7, v25
	v_bfe_u32 v186, v25, 24, 3
	v_bfe_u32 v182, v32, 24, 3
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v166, 0x7fc00000, v167 :: v_dual_lshlrev_b32 v167, 16, v29
	v_cvt_f32_ubyte0_e32 v183, v183
	v_cvt_f32_ubyte0_e32 v186, v186
	v_cvt_f32_ubyte0_e32 v182, v182
	v_bfe_u32 v185, v25, 16, 3
	v_and_or_b32 v166, 0x80000000, v167, v166
	v_bfe_u32 v167, v29, 16, 7
	v_dual_mul_f32 v183, 0x3b000000, v183 :: v_dual_mul_f32 v186, 0x3b000000, v186
	v_bfe_u32 v188, v26, 8, 3
	v_cvt_f32_ubyte0_e32 v185, v185
	s_delay_alu instid0(VALU_DEP_4)
	v_lshl_add_u32 v168, v167, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v167
	v_bfe_u32 v190, v26, 24, 3
	v_cvt_f32_ubyte0_e32 v188, v188
	v_mul_f32_e32 v185, 0x3b000000, v185
	v_bfe_u32 v189, v26, 16, 3
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v168, v169, v168, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v167
	v_mul_f32_e32 v188, 0x3b000000, v188
	v_cvt_f32_ubyte0_e32 v190, v190
	v_bfe_u32 v192, v27, 8, 3
	v_cvt_f32_ubyte0_e32 v189, v189
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v167, 0x7fc00000, v168 :: v_dual_lshlrev_b32 v168, 8, v29
	v_bfe_u32 v193, v27, 16, 3
	v_cvt_f32_ubyte0_e32 v192, v192
	v_bfe_u32 v197, v28, 16, 3
	v_mul_f32_e32 v189, 0x3b000000, v189
	v_and_or_b32 v167, 0x80000000, v168, v167
	v_bfe_u32 v168, v29, 24, 7
	v_mul_f32_e32 v192, 0x3b000000, v192
	v_cvt_f32_ubyte0_e32 v193, v193
	v_cvt_f32_ubyte0_e32 v197, v197
	v_bfe_u32 v194, v27, 24, 3
	v_lshl_add_u32 v169, v168, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v168
	v_bfe_u32 v196, v28, 8, 3
	v_mul_f32_e32 v197, 0x3b000000, v197
	v_mul_f32_e32 v193, 0x3b000000, v193
	v_cvt_f32_ubyte0_e32 v194, v194
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, v170, v169, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v168
	v_cvt_f32_ubyte0_e32 v196, v196
	v_bfe_u32 v198, v28, 24, 3
	v_dual_mul_f32 v174, 0x3b000000, v174 :: v_dual_and_b32 v179, 7, v32
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v168, 0x7fc00000, v169, vcc_lo
	v_and_b32_e32 v169, 0x7f, v30
	v_cvt_f32_ubyte0_e32 v198, v198
	v_mul_f32_e32 v182, 0x3b000000, v182
	v_cvt_f32_ubyte0_e32 v179, v179
	v_mul_f32_e32 v176, 0x3b000000, v176
	v_lshl_add_u32 v170, v169, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v169
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mul_f32 v180, 0x3b000000, v180 :: v_dual_mul_f32 v179, 0x3b000000, v179
	v_and_b32_e32 v187, 7, v26
	v_mul_f32_e32 v190, 0x3b000000, v190
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v170, v171, v170, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v169
	v_and_b32_e32 v195, 7, v28
	v_cvt_f32_ubyte0_e32 v187, v187
	v_dual_mul_f32 v194, 0x3b000000, v194 :: v_dual_and_b32 v191, 7, v27
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v169, 0x7fc00000, v170, vcc_lo
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_mul_f32 v187, 0x3b000000, v187 :: v_dual_lshlrev_b32 v170, 24, v30
	v_cvt_f32_ubyte0_e32 v191, v191
	v_cvt_f32_ubyte0_e32 v195, v195
	v_mul_f32_e32 v196, 0x3b000000, v196
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)
	v_and_or_b32 v169, 0x80000000, v170, v169
	v_bfe_u32 v170, v30, 8, 7
	v_mul_f32_e32 v191, 0x3b000000, v191
	v_dual_mul_f32 v195, 0x3b000000, v195 :: v_dual_mul_f32 v198, 0x3b000000, v198
	v_lshl_add_u32 v171, v170, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v170
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v171, v172, v171, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v170
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v170, 0x7fc00000, v171 :: v_dual_lshlrev_b32 v171, 16, v30
	v_and_or_b32 v168, 0x80000000, v29, v168
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v170, 0x80000000, v171, v170
	v_bfe_u32 v171, v30, 16, 7
	v_lshl_add_u32 v172, v171, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v171
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v172, v173, v172, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v171
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v171, 0x7fc00000, v172 :: v_dual_lshlrev_b32 v172, 8, v30
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v171, 0x80000000, v172, v171
	v_bfe_u32 v172, v30, 24, 7
	v_lshl_add_u32 v173, v172, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v172
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v173, v174, v173, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v172
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v172, 0x7fc00000, v173, vcc_lo
	v_and_b32_e32 v173, 0x7f, v31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v174, v173, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v173
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v174, v175, v174, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v173
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v173, 0x7fc00000, v174 :: v_dual_lshlrev_b32 v174, 24, v31
	v_and_or_b32 v173, 0x80000000, v174, v173
	v_bfe_u32 v174, v31, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v175, v174, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v174
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v175, v176, v175, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v174
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v174, 0x7fc00000, v175, vcc_lo
	v_lshlrev_b32_e32 v175, 16, v31
	v_and_or_b32 v172, 0x80000000, v30, v172
	v_and_or_b32 v174, 0x80000000, v175, v174
	v_bfe_u32 v175, v31, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v176, v175, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v175
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v176, v177, v176, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v175
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v175, 0x7fc00000, v176 :: v_dual_lshlrev_b32 v176, 8, v31
	v_and_or_b32 v175, 0x80000000, v176, v175
	v_bfe_u32 v176, v31, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v177, v176, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v176
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v177, v178, v177, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v176
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v176, 0x7fc00000, v177, vcc_lo
	v_and_b32_e32 v177, 0x7f, v32
	v_and_or_b32 v176, 0x80000000, v31, v176
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v178, v177, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v177
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v178, v179, v178, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v177
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v177, 0x7fc00000, v178 :: v_dual_lshlrev_b32 v178, 24, v32
	v_and_or_b32 v177, 0x80000000, v178, v177
	v_bfe_u32 v178, v32, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v179, v178, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v178
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v179, v180, v179, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v178
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v178, 0x7fc00000, v179 :: v_dual_lshlrev_b32 v179, 16, v32
	v_and_or_b32 v178, 0x80000000, v179, v178
	v_bfe_u32 v179, v32, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v180, v179, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v179
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v180, v181, v180, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v179
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v179, 0x7fc00000, v180, vcc_lo
	v_lshlrev_b32_e32 v180, 8, v32
	v_and_or_b32 v179, 0x80000000, v180, v179
	v_bfe_u32 v180, v32, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v181, v180, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v181, v182, v181, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v180
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v180, 0x7fc00000, v181, vcc_lo
	v_and_or_b32 v181, 0x80000000, v32, v180
	v_and_b32_e32 v180, 0x7f, v25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v182, v180, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v180
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v182, v183, v182, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v180
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v180, 0x7fc00000, v182, vcc_lo
	v_lshlrev_b32_e32 v182, 24, v25
	v_and_or_b32 v180, 0x80000000, v182, v180
	v_bfe_u32 v182, v25, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v183, v182, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v182
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v183, v184, v183, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v182
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v182, 0x7fc00000, v183 :: v_dual_lshlrev_b32 v183, 16, v25
	v_and_or_b32 v182, 0x80000000, v183, v182
	v_bfe_u32 v183, v25, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v184, v183, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v183
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v184, v185, v184, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v183
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v183, 0x7fc00000, v184 :: v_dual_lshlrev_b32 v184, 8, v25
	v_and_or_b32 v183, 0x80000000, v184, v183
	v_bfe_u32 v184, v25, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v185, v184, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v184
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v185, v186, v185, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v184
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v184, 0x7fc00000, v185, vcc_lo
	v_and_b32_e32 v185, 0x7f, v26
	v_and_or_b32 v184, 0x80000000, v25, v184
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v186, v185, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v185
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v186, v187, v186, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v185
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v185, 0x7fc00000, v186, vcc_lo
	v_lshlrev_b32_e32 v186, 24, v26
	v_and_or_b32 v185, 0x80000000, v186, v185
	v_bfe_u32 v186, v26, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v187, v186, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v186
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v187, v188, v187, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v186
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v186, 0x7fc00000, v187 :: v_dual_lshlrev_b32 v187, 16, v26
	v_and_or_b32 v186, 0x80000000, v187, v186
	v_bfe_u32 v187, v26, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v188, v187, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v187
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v188, v189, v188, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v187
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v187, 0x7fc00000, v188 :: v_dual_lshlrev_b32 v188, 8, v26
	v_and_or_b32 v187, 0x80000000, v188, v187
	v_bfe_u32 v188, v26, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v189, v188, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v188
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v189, v190, v189, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v188
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v188, 0x7fc00000, v189, vcc_lo
	v_and_b32_e32 v189, 0x7f, v27
	v_lshl_add_u32 v190, v189, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v189
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v190, v191, v190, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v189
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v189, 0x7fc00000, v190 :: v_dual_lshlrev_b32 v190, 24, v27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v189, 0x80000000, v190, v189
	v_bfe_u32 v190, v27, 8, 7
	v_lshl_add_u32 v191, v190, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v190
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v191, v192, v191, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v190
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v190, 0x7fc00000, v191, vcc_lo
	v_lshlrev_b32_e32 v191, 16, v27
	v_and_or_b32 v188, 0x80000000, v26, v188
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v190, 0x80000000, v191, v190
	v_bfe_u32 v191, v27, 16, 7
	v_lshl_add_u32 v192, v191, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v191
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v192, v193, v192, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v191
	s_wait_alu 0xfffd
	v_dual_cndmask_b32 v191, 0x7fc00000, v192 :: v_dual_lshlrev_b32 v192, 8, v27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_and_or_b32 v191, 0x80000000, v192, v191
	v_bfe_u32 v192, v27, 24, 7
	v_lshl_add_u32 v193, v192, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v192
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_cndmask_b32_e32 v193, v194, v193, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v192
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v192, 0x7fc00000, v193, vcc_lo
	v_and_b32_e32 v193, 0x7f, v28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v194, v193, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v193
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v194, v195, v194, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v193
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v193, 0x7fc00000, v194 :: v_dual_lshlrev_b32 v194, 24, v28
	v_and_or_b32 v193, 0x80000000, v194, v193
	v_bfe_u32 v194, v28, 8, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v195, v194, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v194
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v195, v196, v195, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v194
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_cndmask_b32 v194, 0x7fc00000, v195 :: v_dual_lshlrev_b32 v195, 16, v28
	v_and_or_b32 v194, 0x80000000, v195, v194
	v_bfe_u32 v195, v28, 16, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v196, v195, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v195
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v196, v197, v196, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v195
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_cndmask_b32_e32 v195, 0x7fc00000, v196, vcc_lo
	v_lshlrev_b32_e32 v196, 8, v28
	v_and_or_b32 v195, 0x80000000, v196, v195
	v_bfe_u32 v196, v28, 24, 7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_lshl_add_u32 v197, v196, 20, 0x3c000000
	v_cmp_lt_u32_e32 vcc_lo, 7, v196
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v197, v198, v197, vcc_lo
	v_cmp_ne_u32_e32 vcc_lo, 0x7f, v196
	s_wait_alu 0xfffd
	s_delay_alu instid0(VALU_DEP_2)
	v_cndmask_b32_e32 v196, 0x7fc00000, v197, vcc_lo
	ds_load_b128 v[197:200], v102 offset:1536
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	v_fma_f32 v201, v180, v201, 0
	v_and_or_b32 v192, 0x80000000, v27, v192
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	ds_load_b128 v[197:200], v102 offset:3584
	v_fmac_f32_e32 v201, v182, v202
	v_and_or_b32 v196, 0x80000000, v28, v196
	v_fmac_f32_e32 v213, v167, v203
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v183, v203
	v_fmac_f32_e32 v213, v168, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v184, v204
	v_fmac_f32_e32 v213, v169, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v185, v205
	v_fmac_f32_e32 v213, v170, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v210, 16, v198
	v_and_b32_e32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v212, 16, v200
	v_dual_fmac_f32 v201, v186, v206 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v213, v171, v207
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v211, 16, v199
	v_fmac_f32_e32 v201, v187, v207
	v_fmac_f32_e32 v213, v172, v208
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_fmac_f32_e32 v201, v188, v208
	v_fmac_f32_e32 v213, v173, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v189, v209
	v_fmac_f32_e32 v213, v174, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v190, v197
	v_fmac_f32_e32 v213, v175, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v191, v210
	v_fmac_f32_e32 v213, v176, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v192, v198
	v_fmac_f32_e32 v213, v177, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v193, v211
	v_fmac_f32_e32 v213, v178, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v194, v199
	v_fmac_f32_e32 v213, v179, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v201, v195, v212
	v_fmac_f32_e32 v213, v181, v200
	s_delay_alu instid0(VALU_DEP_2)
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:5632
	v_add_f32_e32 v66, v213, v66
	v_add_f32_e32 v67, v201, v67
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:7680
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:9728
	v_add_f32_e32 v68, v213, v68
	v_add_f32_e32 v97, v201, v97
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:11776
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:13824
	v_add_f32_e32 v75, v213, v75
	s_wait_dscnt 0x0
	v_dual_add_f32 v98, v201, v98 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:15872
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:17920
	v_add_f32_e32 v139, v213, v139
	v_add_f32_e32 v141, v201, v141
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:19968
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:22016
	v_add_f32_e32 v140, v213, v140
	s_wait_dscnt 0x0
	v_dual_add_f32 v142, v201, v142 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:24064
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:26112
	v_add_f32_e32 v143, v213, v143
	v_add_f32_e32 v145, v201, v145
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:28160
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:30208
	v_add_f32_e32 v144, v213, v144
	s_wait_dscnt 0x0
	v_dual_add_f32 v146, v201, v146 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:32256
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:34304
	v_add_f32_e32 v147, v213, v147
	v_add_f32_e32 v149, v201, v149
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:36352
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:38400
	v_add_f32_e32 v148, v213, v148
	s_wait_dscnt 0x0
	v_dual_add_f32 v150, v201, v150 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:40448
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:42496
	v_add_f32_e32 v151, v213, v151
	v_add_f32_e32 v153, v201, v153
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:44544
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:46592
	v_add_f32_e32 v152, v213, v152
	s_wait_dscnt 0x0
	v_dual_add_f32 v154, v201, v154 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:48640
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:50688
	v_add_f32_e32 v155, v213, v155
	v_add_f32_e32 v157, v201, v157
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:52736
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:54784
	v_add_f32_e32 v156, v213, v156
	s_wait_dscnt 0x0
	v_dual_add_f32 v158, v201, v158 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:56832
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:58880
	v_add_f32_e32 v159, v213, v159
	v_add_f32_e32 v161, v201, v161
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v213, v165, v201, 0
	v_fma_f32 v201, v180, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_fmac_f32 v213, v166, v202 :: v_dual_and_b32 v208, 0xffff0000, v200
	v_fmac_f32_e32 v201, v182, v202
	ds_load_b128 v[197:200], v102 offset:60928
	v_fmac_f32_e32 v213, v167, v203
	v_fmac_f32_e32 v201, v183, v203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v168, v204
	v_fmac_f32_e32 v201, v184, v204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v169, v205
	v_fmac_f32_e32 v201, v185, v205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v170, v206
	v_fmac_f32_e32 v201, v186, v206
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_and_b32_e32 v197, 0xffff0000, v197
	v_dual_fmac_f32 v213, v171, v207 :: v_dual_lshlrev_b32 v210, 16, v198
	v_dual_fmac_f32 v201, v187, v207 :: v_dual_and_b32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_and_b32_e32 v199, 0xffff0000, v199
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_fmac_f32_e32 v213, v172, v208
	v_fmac_f32_e32 v201, v188, v208
	v_lshlrev_b32_e32 v212, 16, v200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_fmac_f32 v213, v173, v209 :: v_dual_and_b32 v200, 0xffff0000, v200
	v_fmac_f32_e32 v201, v189, v209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v174, v197
	v_fmac_f32_e32 v201, v190, v197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v175, v210
	v_fmac_f32_e32 v201, v191, v210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v176, v198
	v_fmac_f32_e32 v201, v192, v198
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v177, v211
	v_fmac_f32_e32 v201, v193, v211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v178, v199
	v_fmac_f32_e32 v201, v194, v199
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v179, v212
	v_fmac_f32_e32 v201, v195, v212
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v213, v181, v200
	v_fmac_f32_e32 v201, v196, v200
	ds_load_b128 v[197:200], v102 offset:62976
	v_add_f32_e32 v160, v213, v160
	s_wait_dscnt 0x0
	v_dual_add_f32 v162, v201, v162 :: v_dual_lshlrev_b32 v201, 16, v197
	v_and_b32_e32 v202, 0xffff0000, v197
	v_lshlrev_b32_e32 v203, 16, v198
	v_and_b32_e32 v204, 0xffff0000, v198
	v_lshlrev_b32_e32 v205, 16, v199
	v_fma_f32 v165, v165, v201, 0
	v_and_b32_e32 v206, 0xffff0000, v199
	v_lshlrev_b32_e32 v207, 16, v200
	v_and_b32_e32 v208, 0xffff0000, v200
	ds_load_b128 v[197:200], v102 offset:65024
	v_fmac_f32_e32 v165, v166, v202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v167, v203
	v_fmac_f32_e32 v165, v168, v204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)
	v_fmac_f32_e32 v165, v169, v205
	s_wait_dscnt 0x0
	v_lshlrev_b32_e32 v209, 16, v197
	v_fmac_f32_e32 v165, v170, v206
	v_and_b32_e32 v197, 0xffff0000, v197
	v_lshlrev_b32_e32 v210, 16, v198
	v_and_b32_e32 v198, 0xffff0000, v198
	v_lshlrev_b32_e32 v211, 16, v199
	v_fmac_f32_e32 v165, v171, v207
	v_and_b32_e32 v199, 0xffff0000, v199
	v_lshlrev_b32_e32 v212, 16, v200
	v_and_b32_e32 v200, 0xffff0000, v200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v172, v208
	v_fmac_f32_e32 v165, v173, v209
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v174, v197
	v_fmac_f32_e32 v165, v175, v210
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v176, v198
	v_fmac_f32_e32 v165, v177, v211
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v178, v199
	v_fmac_f32_e32 v165, v179, v212
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v181, v200
	v_add_f32_e32 v163, v165, v163
	v_fma_f32 v165, v180, v201, 0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v182, v202
	v_fmac_f32_e32 v165, v183, v203
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v184, v204
	v_fmac_f32_e32 v165, v185, v205
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v186, v206
	v_fmac_f32_e32 v165, v187, v207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v188, v208
	v_fmac_f32_e32 v165, v189, v209
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v190, v197
	v_fmac_f32_e32 v165, v191, v210
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v192, v198
	v_fmac_f32_e32 v165, v193, v211
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v194, v199
	v_fmac_f32_e32 v165, v195, v212
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_fmac_f32_e32 v165, v196, v200
	v_add_f32_e32 v164, v165, v164
.LBB139_64:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s56
.LBB139_65:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s30
.LBB139_66:                             ;   in Loop: Header=BB139_29 Depth=2
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s15
.LBB139_67:                             ;   in Loop: Header=BB139_29 Depth=2
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s14
	s_mov_b32 s14, 0
.LBB139_68:                             ;   in Loop: Header=BB139_29 Depth=2
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s14
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB139_78
; %bb.69:                               ;   in Loop: Header=BB139_29 Depth=2
	s_and_saveexec_b32 s14, s12
	s_cbranch_execz .LBB139_77
; %bb.70:                               ;   in Loop: Header=BB139_29 Depth=2
	s_wait_loadcnt 0x0
	v_perm_b32 v66, 0, v5, 0x10c000c
	s_mov_b32 s12, exec_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v67, 1, v66
	v_and_b32_e32 v66, 0x80008000, v66
	v_and_or_b32 v66, 0x3f803f80, v67, v66
	v_perm_b32 v67, 0, v5, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v68, 1, v67
	v_and_b32_e32 v67, 0x80008000, v67
	v_and_or_b32 v67, 0x3f803f80, v68, v67
	v_perm_b32 v68, 0, v6, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v75, 1, v68
	v_and_b32_e32 v68, 0x80008000, v68
	v_and_or_b32 v68, 0x3f803f80, v75, v68
	v_perm_b32 v75, 0, v6, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v97, 1, v75
	v_and_b32_e32 v75, 0x80008000, v75
	v_and_or_b32 v75, 0x3f803f80, v97, v75
	v_perm_b32 v97, 0, v7, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v98, 1, v97
	v_and_b32_e32 v97, 0x80008000, v97
	v_and_or_b32 v97, 0x3f803f80, v98, v97
	v_perm_b32 v98, 0, v7, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v139, 1, v98
	v_and_b32_e32 v98, 0x80008000, v98
	v_and_or_b32 v98, 0x3f803f80, v139, v98
	v_perm_b32 v139, 0, v8, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v140, 1, v139
	v_and_b32_e32 v139, 0x80008000, v139
	v_and_or_b32 v139, 0x3f803f80, v140, v139
	v_perm_b32 v140, 0, v8, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v141, 1, v140
	v_and_b32_e32 v140, 0x80008000, v140
	v_and_or_b32 v140, 0x3f803f80, v141, v140
	v_perm_b32 v141, 0, v1, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v142, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v1, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v144, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v2, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v148, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v2, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v146, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v3, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v145, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v3, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v143, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v4, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v147, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v141, 0x3f803f80, v147, v141
	v_perm_b32 v147, 0, v4, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v149, 1, v147
	v_and_b32_e32 v147, 0x80008000, v147
	v_and_or_b32 v147, 0x3f803f80, v149, v147
	ds_load_b128 v[149:152], v102
	ds_load_b128 v[153:156], v102 offset:2048
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v137, v66, v149, v137
	v_dot2_f32_f16 v130, v142, v149, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v67, v150, v137
	v_dot2_f32_f16 v130, v144, v150, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v68, v151, v137
	v_dot2_f32_f16 v130, v148, v151, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v75, v152, v137
	v_dot2_f32_f16 v130, v146, v152, v130
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v97, v153, v137
	v_dot2_f32_f16 v130, v145, v153, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v98, v154, v137
	v_dot2_f32_f16 v130, v143, v154, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v139, v155, v137
	v_dot2_f32_f16 v130, v141, v155, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v140, v156, v137
	v_dot2_f32_f16 v130, v147, v156, v130
	ds_load_b128 v[149:152], v102 offset:4096
	ds_load_b128 v[153:156], v102 offset:6144
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v138, v66, v149, v138
	v_dot2_f32_f16 v129, v142, v149, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v67, v150, v138
	v_dot2_f32_f16 v129, v144, v150, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v68, v151, v138
	v_dot2_f32_f16 v129, v148, v151, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v75, v152, v138
	v_dot2_f32_f16 v129, v146, v152, v129
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v97, v153, v138
	v_dot2_f32_f16 v129, v145, v153, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v98, v154, v138
	v_dot2_f32_f16 v129, v143, v154, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v139, v155, v138
	v_dot2_f32_f16 v129, v141, v155, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v140, v156, v138
	v_dot2_f32_f16 v129, v147, v156, v129
	ds_load_b128 v[149:152], v102 offset:8192
	ds_load_b128 v[153:156], v102 offset:10240
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v136, v66, v149, v136
	v_dot2_f32_f16 v128, v142, v149, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v67, v150, v136
	v_dot2_f32_f16 v128, v144, v150, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v68, v151, v136
	v_dot2_f32_f16 v128, v148, v151, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v75, v152, v136
	v_dot2_f32_f16 v128, v146, v152, v128
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v97, v153, v136
	v_dot2_f32_f16 v128, v145, v153, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v98, v154, v136
	v_dot2_f32_f16 v128, v143, v154, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v139, v155, v136
	v_dot2_f32_f16 v128, v141, v155, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v140, v156, v136
	v_dot2_f32_f16 v128, v147, v156, v128
	ds_load_b128 v[149:152], v102 offset:12288
	ds_load_b128 v[153:156], v102 offset:14336
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v135, v66, v149, v135
	v_dot2_f32_f16 v127, v142, v149, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v67, v150, v135
	v_dot2_f32_f16 v127, v144, v150, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v68, v151, v135
	v_dot2_f32_f16 v127, v148, v151, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v75, v152, v135
	v_dot2_f32_f16 v127, v146, v152, v127
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v97, v153, v135
	v_dot2_f32_f16 v127, v145, v153, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v98, v154, v135
	v_dot2_f32_f16 v127, v143, v154, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v139, v155, v135
	v_dot2_f32_f16 v127, v141, v155, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v140, v156, v135
	v_dot2_f32_f16 v127, v147, v156, v127
	ds_load_b128 v[149:152], v102 offset:16384
	ds_load_b128 v[153:156], v102 offset:18432
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v134, v66, v149, v134
	v_dot2_f32_f16 v126, v142, v149, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v67, v150, v134
	v_dot2_f32_f16 v126, v144, v150, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v68, v151, v134
	v_dot2_f32_f16 v126, v148, v151, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v75, v152, v134
	v_dot2_f32_f16 v126, v146, v152, v126
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v97, v153, v134
	v_dot2_f32_f16 v126, v145, v153, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v98, v154, v134
	v_dot2_f32_f16 v126, v143, v154, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v139, v155, v134
	v_dot2_f32_f16 v126, v141, v155, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v140, v156, v134
	v_dot2_f32_f16 v126, v147, v156, v126
	ds_load_b128 v[149:152], v102 offset:20480
	ds_load_b128 v[153:156], v102 offset:22528
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v132, v66, v149, v132
	v_dot2_f32_f16 v123, v142, v149, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v67, v150, v132
	v_dot2_f32_f16 v123, v144, v150, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v68, v151, v132
	v_dot2_f32_f16 v123, v148, v151, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v75, v152, v132
	v_dot2_f32_f16 v123, v146, v152, v123
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v97, v153, v132
	v_dot2_f32_f16 v123, v145, v153, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v98, v154, v132
	v_dot2_f32_f16 v123, v143, v154, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v139, v155, v132
	v_dot2_f32_f16 v123, v141, v155, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v140, v156, v132
	v_dot2_f32_f16 v123, v147, v156, v123
	ds_load_b128 v[149:152], v102 offset:24576
	ds_load_b128 v[153:156], v102 offset:26624
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v131, v66, v149, v131
	v_dot2_f32_f16 v121, v142, v149, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v67, v150, v131
	v_dot2_f32_f16 v121, v144, v150, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v68, v151, v131
	v_dot2_f32_f16 v121, v148, v151, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v75, v152, v131
	v_dot2_f32_f16 v121, v146, v152, v121
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v97, v153, v131
	v_dot2_f32_f16 v121, v145, v153, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v98, v154, v131
	v_dot2_f32_f16 v121, v143, v154, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v139, v155, v131
	v_dot2_f32_f16 v121, v141, v155, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v140, v156, v131
	v_dot2_f32_f16 v121, v147, v156, v121
	ds_load_b128 v[149:152], v102 offset:28672
	ds_load_b128 v[153:156], v102 offset:30720
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v125, v66, v149, v125
	v_dot2_f32_f16 v119, v142, v149, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v67, v150, v125
	v_dot2_f32_f16 v119, v144, v150, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v68, v151, v125
	v_dot2_f32_f16 v119, v148, v151, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v75, v152, v125
	v_dot2_f32_f16 v119, v146, v152, v119
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v97, v153, v125
	v_dot2_f32_f16 v119, v145, v153, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v98, v154, v125
	v_dot2_f32_f16 v119, v143, v154, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v139, v155, v125
	v_dot2_f32_f16 v119, v141, v155, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v140, v156, v125
	v_dot2_f32_f16 v119, v147, v156, v119
	ds_load_b128 v[149:152], v102 offset:32768
	ds_load_b128 v[153:156], v102 offset:34816
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v133, v66, v149, v133
	v_dot2_f32_f16 v117, v142, v149, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v67, v150, v133
	v_dot2_f32_f16 v117, v144, v150, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v68, v151, v133
	v_dot2_f32_f16 v117, v148, v151, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v75, v152, v133
	v_dot2_f32_f16 v117, v146, v152, v117
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v97, v153, v133
	v_dot2_f32_f16 v117, v145, v153, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v98, v154, v133
	v_dot2_f32_f16 v117, v143, v154, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v139, v155, v133
	v_dot2_f32_f16 v117, v141, v155, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v140, v156, v133
	v_dot2_f32_f16 v117, v147, v156, v117
	ds_load_b128 v[149:152], v102 offset:36864
	ds_load_b128 v[153:156], v102 offset:38912
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v122, v66, v149, v122
	v_dot2_f32_f16 v115, v142, v149, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v67, v150, v122
	v_dot2_f32_f16 v115, v144, v150, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v68, v151, v122
	v_dot2_f32_f16 v115, v148, v151, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v75, v152, v122
	v_dot2_f32_f16 v115, v146, v152, v115
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v97, v153, v122
	v_dot2_f32_f16 v115, v145, v153, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v98, v154, v122
	v_dot2_f32_f16 v115, v143, v154, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v139, v155, v122
	v_dot2_f32_f16 v115, v141, v155, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v140, v156, v122
	v_dot2_f32_f16 v115, v147, v156, v115
	ds_load_b128 v[149:152], v102 offset:40960
	ds_load_b128 v[153:156], v102 offset:43008
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v120, v66, v149, v120
	v_dot2_f32_f16 v113, v142, v149, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v67, v150, v120
	v_dot2_f32_f16 v113, v144, v150, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v68, v151, v120
	v_dot2_f32_f16 v113, v148, v151, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v75, v152, v120
	v_dot2_f32_f16 v113, v146, v152, v113
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v97, v153, v120
	v_dot2_f32_f16 v113, v145, v153, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v98, v154, v120
	v_dot2_f32_f16 v113, v143, v154, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v139, v155, v120
	v_dot2_f32_f16 v113, v141, v155, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v140, v156, v120
	v_dot2_f32_f16 v113, v147, v156, v113
	ds_load_b128 v[149:152], v102 offset:45056
	ds_load_b128 v[153:156], v102 offset:47104
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v118, v66, v149, v118
	v_dot2_f32_f16 v111, v142, v149, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v67, v150, v118
	v_dot2_f32_f16 v111, v144, v150, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v68, v151, v118
	v_dot2_f32_f16 v111, v148, v151, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v75, v152, v118
	v_dot2_f32_f16 v111, v146, v152, v111
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v97, v153, v118
	v_dot2_f32_f16 v111, v145, v153, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v98, v154, v118
	v_dot2_f32_f16 v111, v143, v154, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v139, v155, v118
	v_dot2_f32_f16 v111, v141, v155, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v140, v156, v118
	v_dot2_f32_f16 v111, v147, v156, v111
	ds_load_b128 v[149:152], v102 offset:49152
	ds_load_b128 v[153:156], v102 offset:51200
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v116, v66, v149, v116
	v_dot2_f32_f16 v109, v142, v149, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v67, v150, v116
	v_dot2_f32_f16 v109, v144, v150, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v68, v151, v116
	v_dot2_f32_f16 v109, v148, v151, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v75, v152, v116
	v_dot2_f32_f16 v109, v146, v152, v109
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v97, v153, v116
	v_dot2_f32_f16 v109, v145, v153, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v98, v154, v116
	v_dot2_f32_f16 v109, v143, v154, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v139, v155, v116
	v_dot2_f32_f16 v109, v141, v155, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v140, v156, v116
	v_dot2_f32_f16 v109, v147, v156, v109
	ds_load_b128 v[149:152], v102 offset:53248
	ds_load_b128 v[153:156], v102 offset:55296
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v124, v66, v149, v124
	v_dot2_f32_f16 v107, v142, v149, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v67, v150, v124
	v_dot2_f32_f16 v107, v144, v150, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v68, v151, v124
	v_dot2_f32_f16 v107, v148, v151, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v75, v152, v124
	v_dot2_f32_f16 v107, v146, v152, v107
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v97, v153, v124
	v_dot2_f32_f16 v107, v145, v153, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v98, v154, v124
	v_dot2_f32_f16 v107, v143, v154, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v139, v155, v124
	v_dot2_f32_f16 v107, v141, v155, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v140, v156, v124
	v_dot2_f32_f16 v107, v147, v156, v107
	ds_load_b128 v[149:152], v102 offset:57344
	ds_load_b128 v[153:156], v102 offset:59392
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v114, v66, v149, v114
	v_dot2_f32_f16 v108, v142, v149, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v67, v150, v114
	v_dot2_f32_f16 v108, v144, v150, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v68, v151, v114
	v_dot2_f32_f16 v108, v148, v151, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v75, v152, v114
	v_dot2_f32_f16 v108, v146, v152, v108
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v97, v153, v114
	v_dot2_f32_f16 v108, v145, v153, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v98, v154, v114
	v_dot2_f32_f16 v108, v143, v154, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v139, v155, v114
	v_dot2_f32_f16 v108, v141, v155, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v140, v156, v114
	v_dot2_f32_f16 v108, v147, v156, v108
	ds_load_b128 v[149:152], v102 offset:61440
	ds_load_b128 v[153:156], v102 offset:63488
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v66, v66, v149, v112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v67, v150, v66
	v_dot2_f32_f16 v66, v68, v151, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v75, v152, v66
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v66, v97, v153, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v98, v154, v66
	v_dot2_f32_f16 v66, v139, v155, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v112, v140, v156, v66
	v_dot2_f32_f16 v66, v142, v149, v110
	v_dot2_f32_f16 v66, v144, v150, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v148, v151, v66
	v_dot2_f32_f16 v66, v146, v152, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v145, v153, v66
	v_dot2_f32_f16 v66, v143, v154, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v141, v155, v66
	v_dot2_f32_f16 v110, v147, v156, v66
	v_or_b32_e32 v66, 32, v65
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s29, v66
	s_cbranch_execz .LBB139_76
; %bb.71:                               ;   in Loop: Header=BB139_29 Depth=2
	v_perm_b32 v66, 0, v13, 0x10c000c
	s_mov_b32 s15, exec_lo
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v67, 1, v66
	v_and_b32_e32 v66, 0x80008000, v66
	v_and_or_b32 v66, 0x3f803f80, v67, v66
	v_perm_b32 v67, 0, v13, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v68, 1, v67
	v_and_b32_e32 v67, 0x80008000, v67
	v_and_or_b32 v67, 0x3f803f80, v68, v67
	v_perm_b32 v68, 0, v14, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v75, 1, v68
	v_and_b32_e32 v68, 0x80008000, v68
	v_and_or_b32 v68, 0x3f803f80, v75, v68
	v_perm_b32 v75, 0, v14, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v97, 1, v75
	v_and_b32_e32 v75, 0x80008000, v75
	v_and_or_b32 v75, 0x3f803f80, v97, v75
	v_perm_b32 v97, 0, v15, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v98, 1, v97
	v_and_b32_e32 v97, 0x80008000, v97
	v_and_or_b32 v97, 0x3f803f80, v98, v97
	v_perm_b32 v98, 0, v15, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v139, 1, v98
	v_and_b32_e32 v98, 0x80008000, v98
	v_and_or_b32 v98, 0x3f803f80, v139, v98
	v_perm_b32 v139, 0, v16, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v140, 1, v139
	v_and_b32_e32 v139, 0x80008000, v139
	v_and_or_b32 v139, 0x3f803f80, v140, v139
	v_perm_b32 v140, 0, v16, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v141, 1, v140
	v_and_b32_e32 v140, 0x80008000, v140
	v_and_or_b32 v140, 0x3f803f80, v141, v140
	v_perm_b32 v141, 0, v9, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v142, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v9, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v144, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v10, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v148, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v10, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v146, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v11, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v145, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v11, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v143, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v12, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v147, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v141, 0x3f803f80, v147, v141
	v_perm_b32 v147, 0, v12, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v149, 1, v147
	v_and_b32_e32 v147, 0x80008000, v147
	v_and_or_b32 v147, 0x3f803f80, v149, v147
	ds_load_b128 v[149:152], v102 offset:512
	ds_load_b128 v[153:156], v102 offset:2560
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v137, v66, v149, v137
	v_dot2_f32_f16 v130, v142, v149, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v67, v150, v137
	v_dot2_f32_f16 v130, v144, v150, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v68, v151, v137
	v_dot2_f32_f16 v130, v148, v151, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v75, v152, v137
	v_dot2_f32_f16 v130, v146, v152, v130
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v97, v153, v137
	v_dot2_f32_f16 v130, v145, v153, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v98, v154, v137
	v_dot2_f32_f16 v130, v143, v154, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v139, v155, v137
	v_dot2_f32_f16 v130, v141, v155, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v140, v156, v137
	v_dot2_f32_f16 v130, v147, v156, v130
	ds_load_b128 v[149:152], v102 offset:4608
	ds_load_b128 v[153:156], v102 offset:6656
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v138, v66, v149, v138
	v_dot2_f32_f16 v129, v142, v149, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v67, v150, v138
	v_dot2_f32_f16 v129, v144, v150, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v68, v151, v138
	v_dot2_f32_f16 v129, v148, v151, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v75, v152, v138
	v_dot2_f32_f16 v129, v146, v152, v129
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v97, v153, v138
	v_dot2_f32_f16 v129, v145, v153, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v98, v154, v138
	v_dot2_f32_f16 v129, v143, v154, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v139, v155, v138
	v_dot2_f32_f16 v129, v141, v155, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v140, v156, v138
	v_dot2_f32_f16 v129, v147, v156, v129
	ds_load_b128 v[149:152], v102 offset:8704
	ds_load_b128 v[153:156], v102 offset:10752
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v136, v66, v149, v136
	v_dot2_f32_f16 v128, v142, v149, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v67, v150, v136
	v_dot2_f32_f16 v128, v144, v150, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v68, v151, v136
	v_dot2_f32_f16 v128, v148, v151, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v75, v152, v136
	v_dot2_f32_f16 v128, v146, v152, v128
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v97, v153, v136
	v_dot2_f32_f16 v128, v145, v153, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v98, v154, v136
	v_dot2_f32_f16 v128, v143, v154, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v139, v155, v136
	v_dot2_f32_f16 v128, v141, v155, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v140, v156, v136
	v_dot2_f32_f16 v128, v147, v156, v128
	ds_load_b128 v[149:152], v102 offset:12800
	ds_load_b128 v[153:156], v102 offset:14848
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v135, v66, v149, v135
	v_dot2_f32_f16 v127, v142, v149, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v67, v150, v135
	v_dot2_f32_f16 v127, v144, v150, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v68, v151, v135
	v_dot2_f32_f16 v127, v148, v151, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v75, v152, v135
	v_dot2_f32_f16 v127, v146, v152, v127
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v97, v153, v135
	v_dot2_f32_f16 v127, v145, v153, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v98, v154, v135
	v_dot2_f32_f16 v127, v143, v154, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v139, v155, v135
	v_dot2_f32_f16 v127, v141, v155, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v140, v156, v135
	v_dot2_f32_f16 v127, v147, v156, v127
	ds_load_b128 v[149:152], v102 offset:16896
	ds_load_b128 v[153:156], v102 offset:18944
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v134, v66, v149, v134
	v_dot2_f32_f16 v126, v142, v149, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v67, v150, v134
	v_dot2_f32_f16 v126, v144, v150, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v68, v151, v134
	v_dot2_f32_f16 v126, v148, v151, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v75, v152, v134
	v_dot2_f32_f16 v126, v146, v152, v126
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v97, v153, v134
	v_dot2_f32_f16 v126, v145, v153, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v98, v154, v134
	v_dot2_f32_f16 v126, v143, v154, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v139, v155, v134
	v_dot2_f32_f16 v126, v141, v155, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v140, v156, v134
	v_dot2_f32_f16 v126, v147, v156, v126
	ds_load_b128 v[149:152], v102 offset:20992
	ds_load_b128 v[153:156], v102 offset:23040
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v132, v66, v149, v132
	v_dot2_f32_f16 v123, v142, v149, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v67, v150, v132
	v_dot2_f32_f16 v123, v144, v150, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v68, v151, v132
	v_dot2_f32_f16 v123, v148, v151, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v75, v152, v132
	v_dot2_f32_f16 v123, v146, v152, v123
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v97, v153, v132
	v_dot2_f32_f16 v123, v145, v153, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v98, v154, v132
	v_dot2_f32_f16 v123, v143, v154, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v139, v155, v132
	v_dot2_f32_f16 v123, v141, v155, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v140, v156, v132
	v_dot2_f32_f16 v123, v147, v156, v123
	ds_load_b128 v[149:152], v102 offset:25088
	ds_load_b128 v[153:156], v102 offset:27136
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v131, v66, v149, v131
	v_dot2_f32_f16 v121, v142, v149, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v67, v150, v131
	v_dot2_f32_f16 v121, v144, v150, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v68, v151, v131
	v_dot2_f32_f16 v121, v148, v151, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v75, v152, v131
	v_dot2_f32_f16 v121, v146, v152, v121
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v97, v153, v131
	v_dot2_f32_f16 v121, v145, v153, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v98, v154, v131
	v_dot2_f32_f16 v121, v143, v154, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v139, v155, v131
	v_dot2_f32_f16 v121, v141, v155, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v140, v156, v131
	v_dot2_f32_f16 v121, v147, v156, v121
	ds_load_b128 v[149:152], v102 offset:29184
	ds_load_b128 v[153:156], v102 offset:31232
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v125, v66, v149, v125
	v_dot2_f32_f16 v119, v142, v149, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v67, v150, v125
	v_dot2_f32_f16 v119, v144, v150, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v68, v151, v125
	v_dot2_f32_f16 v119, v148, v151, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v75, v152, v125
	v_dot2_f32_f16 v119, v146, v152, v119
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v97, v153, v125
	v_dot2_f32_f16 v119, v145, v153, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v98, v154, v125
	v_dot2_f32_f16 v119, v143, v154, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v139, v155, v125
	v_dot2_f32_f16 v119, v141, v155, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v140, v156, v125
	v_dot2_f32_f16 v119, v147, v156, v119
	ds_load_b128 v[149:152], v102 offset:33280
	ds_load_b128 v[153:156], v102 offset:35328
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v133, v66, v149, v133
	v_dot2_f32_f16 v117, v142, v149, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v67, v150, v133
	v_dot2_f32_f16 v117, v144, v150, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v68, v151, v133
	v_dot2_f32_f16 v117, v148, v151, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v75, v152, v133
	v_dot2_f32_f16 v117, v146, v152, v117
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v97, v153, v133
	v_dot2_f32_f16 v117, v145, v153, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v98, v154, v133
	v_dot2_f32_f16 v117, v143, v154, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v139, v155, v133
	v_dot2_f32_f16 v117, v141, v155, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v140, v156, v133
	v_dot2_f32_f16 v117, v147, v156, v117
	ds_load_b128 v[149:152], v102 offset:37376
	ds_load_b128 v[153:156], v102 offset:39424
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v122, v66, v149, v122
	v_dot2_f32_f16 v115, v142, v149, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v67, v150, v122
	v_dot2_f32_f16 v115, v144, v150, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v68, v151, v122
	v_dot2_f32_f16 v115, v148, v151, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v75, v152, v122
	v_dot2_f32_f16 v115, v146, v152, v115
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v97, v153, v122
	v_dot2_f32_f16 v115, v145, v153, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v98, v154, v122
	v_dot2_f32_f16 v115, v143, v154, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v139, v155, v122
	v_dot2_f32_f16 v115, v141, v155, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v140, v156, v122
	v_dot2_f32_f16 v115, v147, v156, v115
	ds_load_b128 v[149:152], v102 offset:41472
	ds_load_b128 v[153:156], v102 offset:43520
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v120, v66, v149, v120
	v_dot2_f32_f16 v113, v142, v149, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v67, v150, v120
	v_dot2_f32_f16 v113, v144, v150, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v68, v151, v120
	v_dot2_f32_f16 v113, v148, v151, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v75, v152, v120
	v_dot2_f32_f16 v113, v146, v152, v113
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v97, v153, v120
	v_dot2_f32_f16 v113, v145, v153, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v98, v154, v120
	v_dot2_f32_f16 v113, v143, v154, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v139, v155, v120
	v_dot2_f32_f16 v113, v141, v155, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v140, v156, v120
	v_dot2_f32_f16 v113, v147, v156, v113
	ds_load_b128 v[149:152], v102 offset:45568
	ds_load_b128 v[153:156], v102 offset:47616
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v118, v66, v149, v118
	v_dot2_f32_f16 v111, v142, v149, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v67, v150, v118
	v_dot2_f32_f16 v111, v144, v150, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v68, v151, v118
	v_dot2_f32_f16 v111, v148, v151, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v75, v152, v118
	v_dot2_f32_f16 v111, v146, v152, v111
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v97, v153, v118
	v_dot2_f32_f16 v111, v145, v153, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v98, v154, v118
	v_dot2_f32_f16 v111, v143, v154, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v139, v155, v118
	v_dot2_f32_f16 v111, v141, v155, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v140, v156, v118
	v_dot2_f32_f16 v111, v147, v156, v111
	ds_load_b128 v[149:152], v102 offset:49664
	ds_load_b128 v[153:156], v102 offset:51712
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v116, v66, v149, v116
	v_dot2_f32_f16 v109, v142, v149, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v67, v150, v116
	v_dot2_f32_f16 v109, v144, v150, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v68, v151, v116
	v_dot2_f32_f16 v109, v148, v151, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v75, v152, v116
	v_dot2_f32_f16 v109, v146, v152, v109
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v97, v153, v116
	v_dot2_f32_f16 v109, v145, v153, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v98, v154, v116
	v_dot2_f32_f16 v109, v143, v154, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v139, v155, v116
	v_dot2_f32_f16 v109, v141, v155, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v140, v156, v116
	v_dot2_f32_f16 v109, v147, v156, v109
	ds_load_b128 v[149:152], v102 offset:53760
	ds_load_b128 v[153:156], v102 offset:55808
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v124, v66, v149, v124
	v_dot2_f32_f16 v107, v142, v149, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v67, v150, v124
	v_dot2_f32_f16 v107, v144, v150, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v68, v151, v124
	v_dot2_f32_f16 v107, v148, v151, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v75, v152, v124
	v_dot2_f32_f16 v107, v146, v152, v107
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v97, v153, v124
	v_dot2_f32_f16 v107, v145, v153, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v98, v154, v124
	v_dot2_f32_f16 v107, v143, v154, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v139, v155, v124
	v_dot2_f32_f16 v107, v141, v155, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v140, v156, v124
	v_dot2_f32_f16 v107, v147, v156, v107
	ds_load_b128 v[149:152], v102 offset:57856
	ds_load_b128 v[153:156], v102 offset:59904
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v114, v66, v149, v114
	v_dot2_f32_f16 v108, v142, v149, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v67, v150, v114
	v_dot2_f32_f16 v108, v144, v150, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v68, v151, v114
	v_dot2_f32_f16 v108, v148, v151, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v75, v152, v114
	v_dot2_f32_f16 v108, v146, v152, v108
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v97, v153, v114
	v_dot2_f32_f16 v108, v145, v153, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v98, v154, v114
	v_dot2_f32_f16 v108, v143, v154, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v139, v155, v114
	v_dot2_f32_f16 v108, v141, v155, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v140, v156, v114
	v_dot2_f32_f16 v108, v147, v156, v108
	ds_load_b128 v[149:152], v102 offset:61952
	ds_load_b128 v[153:156], v102 offset:64000
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v66, v66, v149, v112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v67, v150, v66
	v_dot2_f32_f16 v66, v68, v151, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v75, v152, v66
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v66, v97, v153, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v98, v154, v66
	v_dot2_f32_f16 v66, v139, v155, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v112, v140, v156, v66
	v_dot2_f32_f16 v66, v142, v149, v110
	v_dot2_f32_f16 v66, v144, v150, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v148, v151, v66
	v_dot2_f32_f16 v66, v146, v152, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v145, v153, v66
	v_dot2_f32_f16 v66, v143, v154, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v141, v155, v66
	v_dot2_f32_f16 v110, v147, v156, v66
	v_or_b32_e32 v66, 64, v65
	s_delay_alu instid0(VALU_DEP_1)
	v_cmpx_gt_i32_e64 s29, v66
	s_cbranch_execz .LBB139_75
; %bb.72:                               ;   in Loop: Header=BB139_29 Depth=2
	v_perm_b32 v66, 0, v21, 0x10c000c
	v_or_b32_e32 v65, 0x60, v65
	s_mov_b32 s30, exec_lo
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v67, 1, v66
	v_and_b32_e32 v66, 0x80008000, v66
	v_and_or_b32 v66, 0x3f803f80, v67, v66
	v_perm_b32 v67, 0, v21, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v68, 1, v67
	v_and_b32_e32 v67, 0x80008000, v67
	v_and_or_b32 v67, 0x3f803f80, v68, v67
	v_perm_b32 v68, 0, v22, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v75, 1, v68
	v_and_b32_e32 v68, 0x80008000, v68
	v_and_or_b32 v68, 0x3f803f80, v75, v68
	v_perm_b32 v75, 0, v22, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v97, 1, v75
	v_and_b32_e32 v75, 0x80008000, v75
	v_and_or_b32 v75, 0x3f803f80, v97, v75
	v_perm_b32 v97, 0, v23, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v98, 1, v97
	v_and_b32_e32 v97, 0x80008000, v97
	v_and_or_b32 v97, 0x3f803f80, v98, v97
	v_perm_b32 v98, 0, v23, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v139, 1, v98
	v_and_b32_e32 v98, 0x80008000, v98
	v_and_or_b32 v98, 0x3f803f80, v139, v98
	v_perm_b32 v139, 0, v24, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v140, 1, v139
	v_and_b32_e32 v139, 0x80008000, v139
	v_and_or_b32 v139, 0x3f803f80, v140, v139
	v_perm_b32 v140, 0, v24, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v141, 1, v140
	v_and_b32_e32 v140, 0x80008000, v140
	v_and_or_b32 v140, 0x3f803f80, v141, v140
	v_perm_b32 v141, 0, v17, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v142, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v17, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v144, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v18, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v148, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v18, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v146, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v19, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v145, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v19, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v143, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v143, 0x3f803f80, v143, v141
	v_perm_b32 v141, 0, v20, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v147, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v141, 0x3f803f80, v147, v141
	v_perm_b32 v147, 0, v20, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v149, 1, v147
	v_and_b32_e32 v147, 0x80008000, v147
	v_and_or_b32 v147, 0x3f803f80, v149, v147
	ds_load_b128 v[149:152], v102 offset:1024
	ds_load_b128 v[153:156], v102 offset:3072
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v137, v66, v149, v137
	v_dot2_f32_f16 v130, v142, v149, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v67, v150, v137
	v_dot2_f32_f16 v130, v144, v150, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v68, v151, v137
	v_dot2_f32_f16 v130, v148, v151, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v75, v152, v137
	v_dot2_f32_f16 v130, v146, v152, v130
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v97, v153, v137
	v_dot2_f32_f16 v130, v145, v153, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v98, v154, v137
	v_dot2_f32_f16 v130, v143, v154, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v139, v155, v137
	v_dot2_f32_f16 v130, v141, v155, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v140, v156, v137
	v_dot2_f32_f16 v130, v147, v156, v130
	ds_load_b128 v[149:152], v102 offset:5120
	ds_load_b128 v[153:156], v102 offset:7168
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v138, v66, v149, v138
	v_dot2_f32_f16 v129, v142, v149, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v67, v150, v138
	v_dot2_f32_f16 v129, v144, v150, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v68, v151, v138
	v_dot2_f32_f16 v129, v148, v151, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v75, v152, v138
	v_dot2_f32_f16 v129, v146, v152, v129
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v97, v153, v138
	v_dot2_f32_f16 v129, v145, v153, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v98, v154, v138
	v_dot2_f32_f16 v129, v143, v154, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v139, v155, v138
	v_dot2_f32_f16 v129, v141, v155, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v140, v156, v138
	v_dot2_f32_f16 v129, v147, v156, v129
	ds_load_b128 v[149:152], v102 offset:9216
	ds_load_b128 v[153:156], v102 offset:11264
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v136, v66, v149, v136
	v_dot2_f32_f16 v128, v142, v149, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v67, v150, v136
	v_dot2_f32_f16 v128, v144, v150, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v68, v151, v136
	v_dot2_f32_f16 v128, v148, v151, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v75, v152, v136
	v_dot2_f32_f16 v128, v146, v152, v128
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v97, v153, v136
	v_dot2_f32_f16 v128, v145, v153, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v98, v154, v136
	v_dot2_f32_f16 v128, v143, v154, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v139, v155, v136
	v_dot2_f32_f16 v128, v141, v155, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v140, v156, v136
	v_dot2_f32_f16 v128, v147, v156, v128
	ds_load_b128 v[149:152], v102 offset:13312
	ds_load_b128 v[153:156], v102 offset:15360
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v135, v66, v149, v135
	v_dot2_f32_f16 v127, v142, v149, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v67, v150, v135
	v_dot2_f32_f16 v127, v144, v150, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v68, v151, v135
	v_dot2_f32_f16 v127, v148, v151, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v75, v152, v135
	v_dot2_f32_f16 v127, v146, v152, v127
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v97, v153, v135
	v_dot2_f32_f16 v127, v145, v153, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v98, v154, v135
	v_dot2_f32_f16 v127, v143, v154, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v139, v155, v135
	v_dot2_f32_f16 v127, v141, v155, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v140, v156, v135
	v_dot2_f32_f16 v127, v147, v156, v127
	ds_load_b128 v[149:152], v102 offset:17408
	ds_load_b128 v[153:156], v102 offset:19456
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v134, v66, v149, v134
	v_dot2_f32_f16 v126, v142, v149, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v67, v150, v134
	v_dot2_f32_f16 v126, v144, v150, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v68, v151, v134
	v_dot2_f32_f16 v126, v148, v151, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v75, v152, v134
	v_dot2_f32_f16 v126, v146, v152, v126
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v97, v153, v134
	v_dot2_f32_f16 v126, v145, v153, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v98, v154, v134
	v_dot2_f32_f16 v126, v143, v154, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v139, v155, v134
	v_dot2_f32_f16 v126, v141, v155, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v140, v156, v134
	v_dot2_f32_f16 v126, v147, v156, v126
	ds_load_b128 v[149:152], v102 offset:21504
	ds_load_b128 v[153:156], v102 offset:23552
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v132, v66, v149, v132
	v_dot2_f32_f16 v123, v142, v149, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v67, v150, v132
	v_dot2_f32_f16 v123, v144, v150, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v68, v151, v132
	v_dot2_f32_f16 v123, v148, v151, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v75, v152, v132
	v_dot2_f32_f16 v123, v146, v152, v123
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v97, v153, v132
	v_dot2_f32_f16 v123, v145, v153, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v98, v154, v132
	v_dot2_f32_f16 v123, v143, v154, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v139, v155, v132
	v_dot2_f32_f16 v123, v141, v155, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v140, v156, v132
	v_dot2_f32_f16 v123, v147, v156, v123
	ds_load_b128 v[149:152], v102 offset:25600
	ds_load_b128 v[153:156], v102 offset:27648
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v131, v66, v149, v131
	v_dot2_f32_f16 v121, v142, v149, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v67, v150, v131
	v_dot2_f32_f16 v121, v144, v150, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v68, v151, v131
	v_dot2_f32_f16 v121, v148, v151, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v75, v152, v131
	v_dot2_f32_f16 v121, v146, v152, v121
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v97, v153, v131
	v_dot2_f32_f16 v121, v145, v153, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v98, v154, v131
	v_dot2_f32_f16 v121, v143, v154, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v139, v155, v131
	v_dot2_f32_f16 v121, v141, v155, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v140, v156, v131
	v_dot2_f32_f16 v121, v147, v156, v121
	ds_load_b128 v[149:152], v102 offset:29696
	ds_load_b128 v[153:156], v102 offset:31744
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v125, v66, v149, v125
	v_dot2_f32_f16 v119, v142, v149, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v67, v150, v125
	v_dot2_f32_f16 v119, v144, v150, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v68, v151, v125
	v_dot2_f32_f16 v119, v148, v151, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v75, v152, v125
	v_dot2_f32_f16 v119, v146, v152, v119
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v97, v153, v125
	v_dot2_f32_f16 v119, v145, v153, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v98, v154, v125
	v_dot2_f32_f16 v119, v143, v154, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v139, v155, v125
	v_dot2_f32_f16 v119, v141, v155, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v140, v156, v125
	v_dot2_f32_f16 v119, v147, v156, v119
	ds_load_b128 v[149:152], v102 offset:33792
	ds_load_b128 v[153:156], v102 offset:35840
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v133, v66, v149, v133
	v_dot2_f32_f16 v117, v142, v149, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v67, v150, v133
	v_dot2_f32_f16 v117, v144, v150, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v68, v151, v133
	v_dot2_f32_f16 v117, v148, v151, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v75, v152, v133
	v_dot2_f32_f16 v117, v146, v152, v117
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v97, v153, v133
	v_dot2_f32_f16 v117, v145, v153, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v98, v154, v133
	v_dot2_f32_f16 v117, v143, v154, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v139, v155, v133
	v_dot2_f32_f16 v117, v141, v155, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v140, v156, v133
	v_dot2_f32_f16 v117, v147, v156, v117
	ds_load_b128 v[149:152], v102 offset:37888
	ds_load_b128 v[153:156], v102 offset:39936
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v122, v66, v149, v122
	v_dot2_f32_f16 v115, v142, v149, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v67, v150, v122
	v_dot2_f32_f16 v115, v144, v150, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v68, v151, v122
	v_dot2_f32_f16 v115, v148, v151, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v75, v152, v122
	v_dot2_f32_f16 v115, v146, v152, v115
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v97, v153, v122
	v_dot2_f32_f16 v115, v145, v153, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v98, v154, v122
	v_dot2_f32_f16 v115, v143, v154, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v139, v155, v122
	v_dot2_f32_f16 v115, v141, v155, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v140, v156, v122
	v_dot2_f32_f16 v115, v147, v156, v115
	ds_load_b128 v[149:152], v102 offset:41984
	ds_load_b128 v[153:156], v102 offset:44032
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v120, v66, v149, v120
	v_dot2_f32_f16 v113, v142, v149, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v67, v150, v120
	v_dot2_f32_f16 v113, v144, v150, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v68, v151, v120
	v_dot2_f32_f16 v113, v148, v151, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v75, v152, v120
	v_dot2_f32_f16 v113, v146, v152, v113
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v97, v153, v120
	v_dot2_f32_f16 v113, v145, v153, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v98, v154, v120
	v_dot2_f32_f16 v113, v143, v154, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v139, v155, v120
	v_dot2_f32_f16 v113, v141, v155, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v140, v156, v120
	v_dot2_f32_f16 v113, v147, v156, v113
	ds_load_b128 v[149:152], v102 offset:46080
	ds_load_b128 v[153:156], v102 offset:48128
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v118, v66, v149, v118
	v_dot2_f32_f16 v111, v142, v149, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v67, v150, v118
	v_dot2_f32_f16 v111, v144, v150, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v68, v151, v118
	v_dot2_f32_f16 v111, v148, v151, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v75, v152, v118
	v_dot2_f32_f16 v111, v146, v152, v111
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v97, v153, v118
	v_dot2_f32_f16 v111, v145, v153, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v98, v154, v118
	v_dot2_f32_f16 v111, v143, v154, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v139, v155, v118
	v_dot2_f32_f16 v111, v141, v155, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v140, v156, v118
	v_dot2_f32_f16 v111, v147, v156, v111
	ds_load_b128 v[149:152], v102 offset:50176
	ds_load_b128 v[153:156], v102 offset:52224
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v116, v66, v149, v116
	v_dot2_f32_f16 v109, v142, v149, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v67, v150, v116
	v_dot2_f32_f16 v109, v144, v150, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v68, v151, v116
	v_dot2_f32_f16 v109, v148, v151, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v75, v152, v116
	v_dot2_f32_f16 v109, v146, v152, v109
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v97, v153, v116
	v_dot2_f32_f16 v109, v145, v153, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v98, v154, v116
	v_dot2_f32_f16 v109, v143, v154, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v139, v155, v116
	v_dot2_f32_f16 v109, v141, v155, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v140, v156, v116
	v_dot2_f32_f16 v109, v147, v156, v109
	ds_load_b128 v[149:152], v102 offset:54272
	ds_load_b128 v[153:156], v102 offset:56320
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v124, v66, v149, v124
	v_dot2_f32_f16 v107, v142, v149, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v67, v150, v124
	v_dot2_f32_f16 v107, v144, v150, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v68, v151, v124
	v_dot2_f32_f16 v107, v148, v151, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v75, v152, v124
	v_dot2_f32_f16 v107, v146, v152, v107
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v97, v153, v124
	v_dot2_f32_f16 v107, v145, v153, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v98, v154, v124
	v_dot2_f32_f16 v107, v143, v154, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v139, v155, v124
	v_dot2_f32_f16 v107, v141, v155, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v140, v156, v124
	v_dot2_f32_f16 v107, v147, v156, v107
	ds_load_b128 v[149:152], v102 offset:58368
	ds_load_b128 v[153:156], v102 offset:60416
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v114, v66, v149, v114
	v_dot2_f32_f16 v108, v142, v149, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v67, v150, v114
	v_dot2_f32_f16 v108, v144, v150, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v68, v151, v114
	v_dot2_f32_f16 v108, v148, v151, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v75, v152, v114
	v_dot2_f32_f16 v108, v146, v152, v108
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v97, v153, v114
	v_dot2_f32_f16 v108, v145, v153, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v98, v154, v114
	v_dot2_f32_f16 v108, v143, v154, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v139, v155, v114
	v_dot2_f32_f16 v108, v141, v155, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v140, v156, v114
	v_dot2_f32_f16 v108, v147, v156, v108
	ds_load_b128 v[149:152], v102 offset:62464
	ds_load_b128 v[153:156], v102 offset:64512
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v66, v66, v149, v112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v67, v150, v66
	v_dot2_f32_f16 v66, v68, v151, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v75, v152, v66
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v66, v97, v153, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v98, v154, v66
	v_dot2_f32_f16 v66, v139, v155, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v112, v140, v156, v66
	v_dot2_f32_f16 v66, v142, v149, v110
	v_dot2_f32_f16 v66, v144, v150, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v148, v151, v66
	v_dot2_f32_f16 v66, v146, v152, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v145, v153, v66
	v_dot2_f32_f16 v66, v143, v154, v66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v66, v141, v155, v66
	v_dot2_f32_f16 v110, v147, v156, v66
	v_cmpx_gt_i32_e64 s29, v65
	s_cbranch_execz .LBB139_74
; %bb.73:                               ;   in Loop: Header=BB139_29 Depth=2
	v_perm_b32 v65, 0, v29, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v66, 1, v65
	v_and_b32_e32 v65, 0x80008000, v65
	v_and_or_b32 v65, 0x3f803f80, v66, v65
	v_perm_b32 v66, 0, v29, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v67, 1, v66
	v_and_b32_e32 v66, 0x80008000, v66
	v_and_or_b32 v66, 0x3f803f80, v67, v66
	v_perm_b32 v67, 0, v30, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v68, 1, v67
	v_and_b32_e32 v67, 0x80008000, v67
	v_and_or_b32 v67, 0x3f803f80, v68, v67
	v_perm_b32 v68, 0, v30, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v75, 1, v68
	v_and_b32_e32 v68, 0x80008000, v68
	v_and_or_b32 v68, 0x3f803f80, v75, v68
	v_perm_b32 v75, 0, v31, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v97, 1, v75
	v_and_b32_e32 v75, 0x80008000, v75
	v_and_or_b32 v75, 0x3f803f80, v97, v75
	v_perm_b32 v97, 0, v31, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v98, 1, v97
	v_and_b32_e32 v97, 0x80008000, v97
	v_and_or_b32 v97, 0x3f803f80, v98, v97
	v_perm_b32 v98, 0, v32, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v139, 1, v98
	v_and_b32_e32 v98, 0x80008000, v98
	v_and_or_b32 v98, 0x3f803f80, v139, v98
	v_perm_b32 v139, 0, v32, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v140, 1, v139
	v_and_b32_e32 v139, 0x80008000, v139
	v_and_or_b32 v139, 0x3f803f80, v140, v139
	v_perm_b32 v140, 0, v25, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v141, 1, v140
	v_and_b32_e32 v140, 0x80008000, v140
	v_and_or_b32 v140, 0x3f803f80, v141, v140
	v_perm_b32 v141, 0, v25, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v147, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v26, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v146, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v26, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v145, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v27, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v144, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v27, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v143, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v28, 0x10c000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v142, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v142, 0x3f803f80, v142, v141
	v_perm_b32 v141, 0, v28, 0x30c020c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_lshrrev_b32_e32 v148, 1, v141
	v_and_b32_e32 v141, 0x80008000, v141
	v_and_or_b32 v141, 0x3f803f80, v148, v141
	ds_load_b128 v[148:151], v102 offset:1536
	ds_load_b128 v[152:155], v102 offset:3584
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v137, v65, v148, v137
	v_dot2_f32_f16 v130, v140, v148, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v66, v149, v137
	v_dot2_f32_f16 v130, v147, v149, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v67, v150, v137
	v_dot2_f32_f16 v130, v146, v150, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v68, v151, v137
	v_dot2_f32_f16 v130, v145, v151, v130
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v75, v152, v137
	v_dot2_f32_f16 v130, v144, v152, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v97, v153, v137
	v_dot2_f32_f16 v130, v143, v153, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v98, v154, v137
	v_dot2_f32_f16 v130, v142, v154, v130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v137, v139, v155, v137
	v_dot2_f32_f16 v130, v141, v155, v130
	ds_load_b128 v[148:151], v102 offset:5632
	ds_load_b128 v[152:155], v102 offset:7680
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v138, v65, v148, v138
	v_dot2_f32_f16 v129, v140, v148, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v66, v149, v138
	v_dot2_f32_f16 v129, v147, v149, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v67, v150, v138
	v_dot2_f32_f16 v129, v146, v150, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v68, v151, v138
	v_dot2_f32_f16 v129, v145, v151, v129
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v75, v152, v138
	v_dot2_f32_f16 v129, v144, v152, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v97, v153, v138
	v_dot2_f32_f16 v129, v143, v153, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v98, v154, v138
	v_dot2_f32_f16 v129, v142, v154, v129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v138, v139, v155, v138
	v_dot2_f32_f16 v129, v141, v155, v129
	ds_load_b128 v[148:151], v102 offset:9728
	ds_load_b128 v[152:155], v102 offset:11776
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v136, v65, v148, v136
	v_dot2_f32_f16 v128, v140, v148, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v66, v149, v136
	v_dot2_f32_f16 v128, v147, v149, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v67, v150, v136
	v_dot2_f32_f16 v128, v146, v150, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v68, v151, v136
	v_dot2_f32_f16 v128, v145, v151, v128
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v75, v152, v136
	v_dot2_f32_f16 v128, v144, v152, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v97, v153, v136
	v_dot2_f32_f16 v128, v143, v153, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v98, v154, v136
	v_dot2_f32_f16 v128, v142, v154, v128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v136, v139, v155, v136
	v_dot2_f32_f16 v128, v141, v155, v128
	ds_load_b128 v[148:151], v102 offset:13824
	ds_load_b128 v[152:155], v102 offset:15872
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v135, v65, v148, v135
	v_dot2_f32_f16 v127, v140, v148, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v66, v149, v135
	v_dot2_f32_f16 v127, v147, v149, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v67, v150, v135
	v_dot2_f32_f16 v127, v146, v150, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v68, v151, v135
	v_dot2_f32_f16 v127, v145, v151, v127
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v75, v152, v135
	v_dot2_f32_f16 v127, v144, v152, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v97, v153, v135
	v_dot2_f32_f16 v127, v143, v153, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v98, v154, v135
	v_dot2_f32_f16 v127, v142, v154, v127
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v135, v139, v155, v135
	v_dot2_f32_f16 v127, v141, v155, v127
	ds_load_b128 v[148:151], v102 offset:17920
	ds_load_b128 v[152:155], v102 offset:19968
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v134, v65, v148, v134
	v_dot2_f32_f16 v126, v140, v148, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v66, v149, v134
	v_dot2_f32_f16 v126, v147, v149, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v67, v150, v134
	v_dot2_f32_f16 v126, v146, v150, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v68, v151, v134
	v_dot2_f32_f16 v126, v145, v151, v126
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v75, v152, v134
	v_dot2_f32_f16 v126, v144, v152, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v97, v153, v134
	v_dot2_f32_f16 v126, v143, v153, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v98, v154, v134
	v_dot2_f32_f16 v126, v142, v154, v126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v134, v139, v155, v134
	v_dot2_f32_f16 v126, v141, v155, v126
	ds_load_b128 v[148:151], v102 offset:22016
	ds_load_b128 v[152:155], v102 offset:24064
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v132, v65, v148, v132
	v_dot2_f32_f16 v123, v140, v148, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v66, v149, v132
	v_dot2_f32_f16 v123, v147, v149, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v67, v150, v132
	v_dot2_f32_f16 v123, v146, v150, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v68, v151, v132
	v_dot2_f32_f16 v123, v145, v151, v123
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v75, v152, v132
	v_dot2_f32_f16 v123, v144, v152, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v97, v153, v132
	v_dot2_f32_f16 v123, v143, v153, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v98, v154, v132
	v_dot2_f32_f16 v123, v142, v154, v123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v132, v139, v155, v132
	v_dot2_f32_f16 v123, v141, v155, v123
	ds_load_b128 v[148:151], v102 offset:26112
	ds_load_b128 v[152:155], v102 offset:28160
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v131, v65, v148, v131
	v_dot2_f32_f16 v121, v140, v148, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v66, v149, v131
	v_dot2_f32_f16 v121, v147, v149, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v67, v150, v131
	v_dot2_f32_f16 v121, v146, v150, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v68, v151, v131
	v_dot2_f32_f16 v121, v145, v151, v121
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v75, v152, v131
	v_dot2_f32_f16 v121, v144, v152, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v97, v153, v131
	v_dot2_f32_f16 v121, v143, v153, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v98, v154, v131
	v_dot2_f32_f16 v121, v142, v154, v121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v131, v139, v155, v131
	v_dot2_f32_f16 v121, v141, v155, v121
	ds_load_b128 v[148:151], v102 offset:30208
	ds_load_b128 v[152:155], v102 offset:32256
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v125, v65, v148, v125
	v_dot2_f32_f16 v119, v140, v148, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v66, v149, v125
	v_dot2_f32_f16 v119, v147, v149, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v67, v150, v125
	v_dot2_f32_f16 v119, v146, v150, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v68, v151, v125
	v_dot2_f32_f16 v119, v145, v151, v119
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v75, v152, v125
	v_dot2_f32_f16 v119, v144, v152, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v97, v153, v125
	v_dot2_f32_f16 v119, v143, v153, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v98, v154, v125
	v_dot2_f32_f16 v119, v142, v154, v119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v125, v139, v155, v125
	v_dot2_f32_f16 v119, v141, v155, v119
	ds_load_b128 v[148:151], v102 offset:34304
	ds_load_b128 v[152:155], v102 offset:36352
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v133, v65, v148, v133
	v_dot2_f32_f16 v117, v140, v148, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v66, v149, v133
	v_dot2_f32_f16 v117, v147, v149, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v67, v150, v133
	v_dot2_f32_f16 v117, v146, v150, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v68, v151, v133
	v_dot2_f32_f16 v117, v145, v151, v117
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v75, v152, v133
	v_dot2_f32_f16 v117, v144, v152, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v97, v153, v133
	v_dot2_f32_f16 v117, v143, v153, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v98, v154, v133
	v_dot2_f32_f16 v117, v142, v154, v117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v133, v139, v155, v133
	v_dot2_f32_f16 v117, v141, v155, v117
	ds_load_b128 v[148:151], v102 offset:38400
	ds_load_b128 v[152:155], v102 offset:40448
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v122, v65, v148, v122
	v_dot2_f32_f16 v115, v140, v148, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v66, v149, v122
	v_dot2_f32_f16 v115, v147, v149, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v67, v150, v122
	v_dot2_f32_f16 v115, v146, v150, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v68, v151, v122
	v_dot2_f32_f16 v115, v145, v151, v115
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v75, v152, v122
	v_dot2_f32_f16 v115, v144, v152, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v97, v153, v122
	v_dot2_f32_f16 v115, v143, v153, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v98, v154, v122
	v_dot2_f32_f16 v115, v142, v154, v115
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v122, v139, v155, v122
	v_dot2_f32_f16 v115, v141, v155, v115
	ds_load_b128 v[148:151], v102 offset:42496
	ds_load_b128 v[152:155], v102 offset:44544
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v120, v65, v148, v120
	v_dot2_f32_f16 v113, v140, v148, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v66, v149, v120
	v_dot2_f32_f16 v113, v147, v149, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v67, v150, v120
	v_dot2_f32_f16 v113, v146, v150, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v68, v151, v120
	v_dot2_f32_f16 v113, v145, v151, v113
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v75, v152, v120
	v_dot2_f32_f16 v113, v144, v152, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v97, v153, v120
	v_dot2_f32_f16 v113, v143, v153, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v98, v154, v120
	v_dot2_f32_f16 v113, v142, v154, v113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v120, v139, v155, v120
	v_dot2_f32_f16 v113, v141, v155, v113
	ds_load_b128 v[148:151], v102 offset:46592
	ds_load_b128 v[152:155], v102 offset:48640
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v118, v65, v148, v118
	v_dot2_f32_f16 v111, v140, v148, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v66, v149, v118
	v_dot2_f32_f16 v111, v147, v149, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v67, v150, v118
	v_dot2_f32_f16 v111, v146, v150, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v68, v151, v118
	v_dot2_f32_f16 v111, v145, v151, v111
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v75, v152, v118
	v_dot2_f32_f16 v111, v144, v152, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v97, v153, v118
	v_dot2_f32_f16 v111, v143, v153, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v98, v154, v118
	v_dot2_f32_f16 v111, v142, v154, v111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v118, v139, v155, v118
	v_dot2_f32_f16 v111, v141, v155, v111
	ds_load_b128 v[148:151], v102 offset:50688
	ds_load_b128 v[152:155], v102 offset:52736
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v116, v65, v148, v116
	v_dot2_f32_f16 v109, v140, v148, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v66, v149, v116
	v_dot2_f32_f16 v109, v147, v149, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v67, v150, v116
	v_dot2_f32_f16 v109, v146, v150, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v68, v151, v116
	v_dot2_f32_f16 v109, v145, v151, v109
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v75, v152, v116
	v_dot2_f32_f16 v109, v144, v152, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v97, v153, v116
	v_dot2_f32_f16 v109, v143, v153, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v98, v154, v116
	v_dot2_f32_f16 v109, v142, v154, v109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v116, v139, v155, v116
	v_dot2_f32_f16 v109, v141, v155, v109
	ds_load_b128 v[148:151], v102 offset:54784
	ds_load_b128 v[152:155], v102 offset:56832
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v124, v65, v148, v124
	v_dot2_f32_f16 v107, v140, v148, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v66, v149, v124
	v_dot2_f32_f16 v107, v147, v149, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v67, v150, v124
	v_dot2_f32_f16 v107, v146, v150, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v68, v151, v124
	v_dot2_f32_f16 v107, v145, v151, v107
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v75, v152, v124
	v_dot2_f32_f16 v107, v144, v152, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v97, v153, v124
	v_dot2_f32_f16 v107, v143, v153, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v98, v154, v124
	v_dot2_f32_f16 v107, v142, v154, v107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v124, v139, v155, v124
	v_dot2_f32_f16 v107, v141, v155, v107
	ds_load_b128 v[148:151], v102 offset:58880
	ds_load_b128 v[152:155], v102 offset:60928
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v114, v65, v148, v114
	v_dot2_f32_f16 v108, v140, v148, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v66, v149, v114
	v_dot2_f32_f16 v108, v147, v149, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v67, v150, v114
	v_dot2_f32_f16 v108, v146, v150, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v68, v151, v114
	v_dot2_f32_f16 v108, v145, v151, v108
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v75, v152, v114
	v_dot2_f32_f16 v108, v144, v152, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v97, v153, v114
	v_dot2_f32_f16 v108, v143, v153, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v98, v154, v114
	v_dot2_f32_f16 v108, v142, v154, v108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_dot2_f32_f16 v114, v139, v155, v114
	v_dot2_f32_f16 v108, v141, v155, v108
	ds_load_b128 v[148:151], v102 offset:62976
	ds_load_b128 v[152:155], v102 offset:65024
	s_wait_dscnt 0x1
	v_dot2_f32_f16 v65, v65, v148, v112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v65, v66, v149, v65
	v_dot2_f32_f16 v65, v67, v150, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v65, v68, v151, v65
	s_wait_dscnt 0x0
	v_dot2_f32_f16 v65, v75, v152, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v65, v97, v153, v65
	v_dot2_f32_f16 v65, v98, v154, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v112, v139, v155, v65
	v_dot2_f32_f16 v65, v140, v148, v110
	v_dot2_f32_f16 v65, v147, v149, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v65, v146, v150, v65
	v_dot2_f32_f16 v65, v145, v151, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v65, v144, v152, v65
	v_dot2_f32_f16 v65, v143, v153, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dot2_f32_f16 v65, v142, v154, v65
	v_dot2_f32_f16 v110, v141, v155, v65
.LBB139_74:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s30
.LBB139_75:                             ;   in Loop: Header=BB139_29 Depth=2
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s15
.LBB139_76:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
.LBB139_77:                             ;   in Loop: Header=BB139_29 Depth=2
	s_delay_alu instid0(SALU_CYCLE_1)
	s_or_b32 exec_lo, exec_lo, s14
	v_dual_mov_b32 v66, v137 :: v_dual_mov_b32 v75, v136
	v_dual_mov_b32 v68, v138 :: v_dual_mov_b32 v139, v135
	v_dual_mov_b32 v140, v134 :: v_dual_mov_b32 v143, v132
	v_dual_mov_b32 v144, v131 :: v_dual_mov_b32 v147, v125
	v_dual_mov_b32 v148, v133 :: v_dual_mov_b32 v151, v122
	v_dual_mov_b32 v152, v120 :: v_dual_mov_b32 v155, v118
	v_dual_mov_b32 v156, v116 :: v_dual_mov_b32 v159, v124
	v_dual_mov_b32 v160, v114 :: v_dual_mov_b32 v163, v112
	v_dual_mov_b32 v67, v130 :: v_dual_mov_b32 v98, v128
	v_dual_mov_b32 v97, v129 :: v_dual_mov_b32 v142, v126
	v_dual_mov_b32 v141, v127 :: v_dual_mov_b32 v146, v121
	v_dual_mov_b32 v145, v123 :: v_dual_mov_b32 v150, v117
	v_dual_mov_b32 v149, v119 :: v_dual_mov_b32 v154, v113
	v_dual_mov_b32 v153, v115 :: v_dual_mov_b32 v158, v109
	v_dual_mov_b32 v157, v111 :: v_dual_mov_b32 v162, v108
	v_dual_mov_b32 v161, v107 :: v_dual_mov_b32 v164, v110
.LBB139_78:                             ;   in Loop: Header=BB139_29 Depth=2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_dual_mov_b32 v110, v164 :: v_dual_mov_b32 v107, v161
	v_dual_mov_b32 v108, v162 :: v_dual_mov_b32 v109, v158
	s_delay_alu instid0(VALU_DEP_4)
	v_dual_mov_b32 v111, v157 :: v_dual_mov_b32 v126, v142
	v_dual_mov_b32 v113, v154 :: v_dual_mov_b32 v128, v98
	v_dual_mov_b32 v115, v153 :: v_dual_mov_b32 v130, v67
	v_dual_mov_b32 v117, v150 :: v_dual_mov_b32 v112, v163
	v_dual_mov_b32 v119, v149 :: v_dual_mov_b32 v114, v160
	v_dual_mov_b32 v121, v146 :: v_dual_mov_b32 v124, v159
	v_dual_mov_b32 v123, v145 :: v_dual_mov_b32 v116, v156
	v_dual_mov_b32 v127, v141 :: v_dual_mov_b32 v118, v155
	v_dual_mov_b32 v129, v97 :: v_dual_mov_b32 v120, v152
	v_dual_mov_b32 v122, v151 :: v_dual_mov_b32 v133, v148
	v_dual_mov_b32 v125, v147 :: v_dual_mov_b32 v132, v143
	v_dual_mov_b32 v131, v144 :: v_dual_mov_b32 v134, v140
	v_dual_mov_b32 v135, v139 :: v_dual_mov_b32 v136, v75
	v_dual_mov_b32 v138, v68 :: v_dual_mov_b32 v137, v66
	s_or_b32 exec_lo, exec_lo, s13
	s_add_co_i32 s46, s46, 1
	s_wait_alu 0xfffe
	s_cmp_ge_i32 s46, s41
	s_cbranch_scc1 .LBB139_28
.LBB139_79:                             ;   in Loop: Header=BB139_29 Depth=2
	v_lshl_or_b32 v75, s46, 7, v100
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v6, 0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v8, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s29, v75
	v_lshlrev_b64_e32 v[65:66], 4, v[75:76]
	v_mov_b32_e32 v7, 0
	s_and_b32 s12, s10, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s13, s12
	s_cbranch_execz .LBB139_81
; %bb.80:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v2, s12, v71, v65
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v3, null, v72, v66, s12
	global_load_b128 v[5:8], v[2:3], off th:TH_LOAD_NT
.LBB139_81:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0
	v_mov_b32_e32 v4, 0
	s_and_b32 s13, s11, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s12, s13
	s_cbranch_execz .LBB139_83
; %bb.82:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v1, vcc_lo, v69, v65
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v2, null, v70, v66, vcc_lo
	global_load_b128 v[1:4], v[1:2], off th:TH_LOAD_NT
.LBB139_83:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_or_b32_e32 v10, 32, v75
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v14, 0
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v16, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s29, v10
	v_mov_b32_e32 v15, 0
	s_and_b32 s12, s10, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s13, s12
	s_cbranch_execz .LBB139_85
; %bb.84:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v10, s12, v71, v65
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v11, null, v72, v66, s12
	global_load_b128 v[13:16], v[10:11], off offset:512 th:TH_LOAD_NT
.LBB139_85:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0
	v_mov_b32_e32 v12, 0
	s_and_b32 s13, s11, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s12, s13
	s_cbranch_execz .LBB139_87
; %bb.86:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v9, vcc_lo, v69, v65
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v10, null, v70, v66, vcc_lo
	global_load_b128 v[9:12], v[9:10], off offset:512 th:TH_LOAD_NT
.LBB139_87:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_or_b32_e32 v18, 64, v75
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v22, 0
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s29, v18
	v_mov_b32_e32 v23, 0
	s_and_b32 s12, s10, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s13, s12
	s_cbranch_execz .LBB139_89
; %bb.88:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v18, s12, v71, v65
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v19, null, v72, v66, s12
	global_load_b128 v[21:24], v[18:19], off offset:1024 th:TH_LOAD_NT
.LBB139_89:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0
	v_mov_b32_e32 v20, 0
	s_and_b32 s13, s11, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s12, s13
	s_cbranch_execz .LBB139_91
; %bb.90:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v17, vcc_lo, v69, v65
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v18, null, v70, v66, vcc_lo
	global_load_b128 v[17:20], v[17:18], off offset:1024 th:TH_LOAD_NT
.LBB139_91:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s12
	v_or_b32_e32 v26, 0x60, v75
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v30, 0
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v32, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cmp_gt_i32_e32 vcc_lo, s29, v26
	v_mov_b32_e32 v31, 0
	s_and_b32 s12, s10, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s13, s12
	s_cbranch_execz .LBB139_93
; %bb.92:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v26, s12, v71, v65
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v27, null, v72, v66, s12
	global_load_b128 v[29:32], v[26:27], off offset:1536 th:TH_LOAD_NT
.LBB139_93:                             ;   in Loop: Header=BB139_29 Depth=2
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s13
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0
	v_mov_b32_e32 v28, 0
	s_and_b32 s13, s11, vcc_lo
	s_wait_alu 0xfffe
	s_and_saveexec_b32 s12, s13
	s_cbranch_execz .LBB139_27
; %bb.94:                               ;   in Loop: Header=BB139_29 Depth=2
	v_add_co_u32 v25, vcc_lo, v69, v65
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v26, null, v70, v66, vcc_lo
	global_load_b128 v[25:28], v[25:26], off offset:1536 th:TH_LOAD_NT
	s_branch .LBB139_27
.LBB139_95:                             ;   in Loop: Header=BB139_25 Depth=1
	v_dual_mov_b32 v137, v76 :: v_dual_mov_b32 v138, v76
	v_dual_mov_b32 v136, v76 :: v_dual_mov_b32 v135, v76
	v_dual_mov_b32 v134, v76 :: v_dual_mov_b32 v131, v76
	v_dual_mov_b32 v132, v76 :: v_dual_mov_b32 v125, v76
	v_dual_mov_b32 v133, v76 :: v_dual_mov_b32 v122, v76
	v_dual_mov_b32 v120, v76 :: v_dual_mov_b32 v129, v76
	v_dual_mov_b32 v118, v76 :: v_dual_mov_b32 v127, v76
	v_dual_mov_b32 v116, v76 :: v_dual_mov_b32 v123, v76
	v_dual_mov_b32 v124, v76 :: v_dual_mov_b32 v121, v76
	v_dual_mov_b32 v114, v76 :: v_dual_mov_b32 v119, v76
	v_dual_mov_b32 v112, v76 :: v_dual_mov_b32 v117, v76
	v_dual_mov_b32 v130, v76 :: v_dual_mov_b32 v115, v76
	v_dual_mov_b32 v128, v76 :: v_dual_mov_b32 v113, v76
	v_dual_mov_b32 v126, v76 :: v_dual_mov_b32 v111, v76
	v_dual_mov_b32 v109, v76 :: v_dual_mov_b32 v108, v76
	v_dual_mov_b32 v107, v76 :: v_dual_mov_b32 v110, v76
.LBB139_96:                             ;   in Loop: Header=BB139_25 Depth=1
	s_mov_b32 s10, exec_lo
	v_cmpx_ne_u64_e32 0, v[71:72]
	s_cbranch_execz .LBB139_103
; %bb.97:                               ;   in Loop: Header=BB139_25 Depth=1
	v_xor_b32_e32 v65, 16, v106
	v_cndmask_b32_e64 v89, v130, v137, s1
	v_cndmask_b32_e64 v68, v136, v128, s1
	v_cndmask_b32_e64 v91, v128, v136, s1
	s_wait_dscnt 0x0
	v_cndmask_b32_e64 v67, v138, v129, s1
	v_cmp_gt_i32_e32 vcc_lo, 32, v65
	v_cndmask_b32_e64 v75, v135, v127, s1
	v_cndmask_b32_e64 v87, v134, v126, s1
	v_cndmask_b32_e64 v88, v132, v123, s1
	v_cndmask_b32_e64 v66, v137, v130, s1
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v65, v106, v65, vcc_lo
	v_cndmask_b32_e64 v95, v125, v119, s1
	v_cndmask_b32_e64 v94, v131, v121, s1
	v_cndmask_b32_e64 v96, v133, v117, s1
	v_cndmask_b32_e64 v97, v122, v115, s1
	v_lshlrev_b32_e32 v65, 2, v65
	v_cndmask_b32_e64 v90, v129, v138, s1
	v_cndmask_b32_e64 v92, v127, v135, s1
	v_cndmask_b32_e64 v93, v126, v134, s1
	v_cndmask_b32_e64 v98, v123, v132, s1
	ds_bpermute_b32 v68, v65, v68
	v_cndmask_b32_e64 v115, v115, v122, s1
	s_wait_dscnt 0x0
	v_add_f32_e32 v68, v91, v68
	ds_bpermute_b32 v67, v65, v67
	ds_bpermute_b32 v75, v65, v75
	ds_bpermute_b32 v87, v65, v87
	ds_bpermute_b32 v88, v65, v88
	ds_bpermute_b32 v66, v65, v66
	ds_bpermute_b32 v95, v65, v95
	ds_bpermute_b32 v94, v65, v94
	ds_bpermute_b32 v96, v65, v96
	ds_bpermute_b32 v97, v65, v97
	v_cndmask_b32_e64 v91, v118, v111, s1
	v_cndmask_b32_e64 v111, v111, v118, s1
	ds_bpermute_b32 v91, v65, v91
	s_wait_dscnt 0x9
	v_add_f32_e32 v67, v90, v67
	s_wait_dscnt 0x8
	v_add_f32_e32 v75, v92, v75
	v_cndmask_b32_e64 v90, v120, v113, s1
	v_cndmask_b32_e64 v92, v116, v109, s1
	s_wait_dscnt 0x6
	v_add_f32_e32 v88, v98, v88
	v_cndmask_b32_e64 v98, v117, v133, s1
	v_add_f32_e32 v87, v93, v87
	v_cndmask_b32_e64 v93, v119, v125, s1
	ds_bpermute_b32 v90, v65, v90
	ds_bpermute_b32 v92, v65, v92
	v_cndmask_b32_e64 v117, v114, v108, s1
	s_wait_dscnt 0x7
	v_add_f32_e32 v66, v89, v66
	v_cndmask_b32_e64 v89, v121, v131, s1
	s_wait_dscnt 0x6
	v_add_f32_e32 v93, v93, v95
	v_cndmask_b32_e64 v113, v113, v120, s1
	ds_bpermute_b32 v95, v65, v117
	s_wait_dscnt 0x5
	v_dual_add_f32 v89, v89, v94 :: v_dual_add_f32 v94, v98, v96
	s_wait_dscnt 0x4
	v_add_f32_e32 v96, v115, v97
	v_cndmask_b32_e64 v97, v124, v107, s1
	v_cndmask_b32_e64 v98, v112, v110, s1
	v_xor_b32_e32 v115, 8, v106
	v_cndmask_b32_e64 v107, v107, v124, s1
	v_cndmask_b32_e64 v110, v110, v112, s1
	ds_bpermute_b32 v97, v65, v97
	ds_bpermute_b32 v65, v65, v98
	v_cndmask_b32_e64 v98, v109, v116, s1
	v_cmp_gt_i32_e32 vcc_lo, 32, v115
	s_wait_dscnt 0x4
	v_add_f32_e32 v90, v113, v90
	s_wait_dscnt 0x3
	v_add_f32_e32 v92, v98, v92
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v109, v106, v115, vcc_lo
	v_cndmask_b32_e64 v98, v108, v114, s1
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_cndmask_b32_e64 v112, v87, v92, s6
	s_wait_dscnt 0x2
	v_dual_add_f32 v95, v98, v95 :: v_dual_lshlrev_b32 v108, 2, v109
	v_cndmask_b32_e64 v98, v68, v90, s6
	v_cndmask_b32_e64 v68, v90, v68, s6
	v_xor_b32_e32 v90, 4, v106
	v_cndmask_b32_e64 v109, v66, v94, s6
	v_cndmask_b32_e64 v66, v94, v66, s6
	ds_bpermute_b32 v98, v108, v98
	ds_bpermute_b32 v94, v108, v112
	v_cmp_gt_i32_e32 vcc_lo, 32, v90
	s_wait_dscnt 0x3
	v_add_f32_e32 v97, v107, v97
	ds_bpermute_b32 v109, v108, v109
	v_add_f32_e32 v91, v111, v91
	v_cndmask_b32_e64 v111, v67, v96, s6
	v_cndmask_b32_e64 v67, v96, v67, s6
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v90, v106, v90, vcc_lo
	s_wait_dscnt 0x3
	v_add_f32_e32 v65, v110, v65
	v_cndmask_b32_e64 v112, v88, v97, s6
	ds_bpermute_b32 v111, v108, v111
	v_cndmask_b32_e64 v87, v92, v87, s6
	v_lshlrev_b32_e32 v90, 2, v90
	v_cndmask_b32_e64 v113, v93, v65, s6
	v_cndmask_b32_e64 v88, v97, v88, s6
	v_cndmask_b32_e64 v65, v65, v93, s6
	s_wait_dscnt 0x3
	v_add_f32_e32 v68, v68, v98
	v_cndmask_b32_e64 v107, v89, v95, s6
	v_cndmask_b32_e64 v89, v95, v89, s6
	s_wait_dscnt 0x1
	v_dual_add_f32 v87, v87, v94 :: v_dual_add_f32 v66, v66, v109
	v_cndmask_b32_e64 v110, v75, v91, s6
	ds_bpermute_b32 v96, v108, v107
	v_cndmask_b32_e64 v75, v91, v75, s6
	v_cndmask_b32_e64 v91, v66, v87, s7
	ds_bpermute_b32 v107, v108, v110
	ds_bpermute_b32 v110, v108, v112
	ds_bpermute_b32 v108, v108, v113
	s_wait_dscnt 0x4
	v_add_f32_e32 v67, v67, v111
	ds_bpermute_b32 v91, v90, v91
	v_cndmask_b32_e64 v66, v87, v66, s7
	v_xor_b32_e32 v87, 2, v106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_cmp_gt_i32_e32 vcc_lo, 32, v87
	s_wait_dscnt 0x4
	v_add_f32_e32 v89, v89, v96
	v_cndmask_b32_e64 v92, v68, v89, s7
	s_wait_dscnt 0x1
	v_dual_add_f32 v88, v88, v110 :: v_dual_add_f32 v65, v65, v108
	v_cndmask_b32_e64 v68, v89, v68, s7
	s_wait_dscnt 0x0
	v_add_f32_e32 v66, v66, v91
	ds_bpermute_b32 v92, v90, v92
	v_add_f32_e32 v75, v75, v107
	v_cndmask_b32_e64 v93, v67, v88, s7
	v_cndmask_b32_e64 v67, v88, v67, s7
	ds_bpermute_b32 v93, v90, v93
	s_wait_dscnt 0x1
	v_add_f32_e32 v68, v68, v92
	v_cndmask_b32_e64 v94, v75, v65, s7
	v_cndmask_b32_e64 v65, v65, v75, s7
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v75, v106, v87, vcc_lo
	v_cndmask_b32_e64 v87, v66, v68, s8
	ds_bpermute_b32 v90, v90, v94
	v_cndmask_b32_e64 v66, v68, v66, s8
	v_xor_b32_e32 v68, 1, v106
	v_lshlrev_b32_e32 v75, 2, v75
	s_delay_alu instid0(VALU_DEP_2)
	v_cmp_gt_i32_e32 vcc_lo, 32, v68
	s_wait_dscnt 0x1
	v_add_f32_e32 v67, v67, v93
	ds_bpermute_b32 v87, v75, v87
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v68, v106, v68, vcc_lo
	v_cmp_lt_i64_e32 vcc_lo, v[73:74], v[77:78]
	s_wait_dscnt 0x1
	v_add_f32_e32 v65, v65, v90
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e64 v88, v67, v65, s8
	v_cndmask_b32_e64 v67, v65, v67, s8
	s_wait_dscnt 0x0
	v_add_f32_e32 v65, v66, v87
	ds_bpermute_b32 v75, v75, v88
	s_wait_dscnt 0x0
	v_dual_add_f32 v66, v67, v75 :: v_dual_lshlrev_b32 v67, 2, v68
	s_delay_alu instid0(VALU_DEP_1)
	v_cndmask_b32_e64 v68, v65, v66, s9
	ds_bpermute_b32 v67, v67, v68
	s_and_b32 exec_lo, exec_lo, vcc_lo
	s_cbranch_execz .LBB139_103
; %bb.98:                               ;   in Loop: Header=BB139_25 Depth=1
	v_cndmask_b32_e64 v65, v66, v65, s9
	s_wait_dscnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add_f32_e32 v65, v65, v67
	v_mul_f32_e32 v66, 0x47800000, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cndmask_b32_e64 v65, v65, v66, s0
	v_mul_f32_e32 v66, s20, v65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v65, 0x7fffffff, v66
	v_cmp_gt_u32_e32 vcc_lo, 0x7f800001, v65
                                        ; implicit-def: $vgpr65
	s_and_saveexec_b32 s11, vcc_lo
	s_wait_alu 0xfffe
	s_xor_b32 s11, exec_lo, s11
; %bb.99:                               ;   in Loop: Header=BB139_25 Depth=1
	v_bfe_u32 v65, v66, 16, 1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_add3_u32 v65, v66, v65, 0x7fff
                                        ; implicit-def: $vgpr66
	v_lshrrev_b32_e32 v65, 16, v65
; %bb.100:                              ;   in Loop: Header=BB139_25 Depth=1
	s_wait_alu 0xfffe
	s_and_not1_saveexec_b32 s11, s11
; %bb.101:                              ;   in Loop: Header=BB139_25 Depth=1
	v_lshrrev_b32_e32 v65, 16, v66
	s_delay_alu instid0(VALU_DEP_1)
	v_or_b32_e32 v65, 64, v65
; %bb.102:                              ;   in Loop: Header=BB139_25 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s11
	v_lshlrev_b64_e32 v[66:67], 1, v[73:74]
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)
	v_add_co_u32 v66, vcc_lo, v103, v66
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v67, null, v104, v67, vcc_lo
	global_store_b16 v[66:67], v65, off
.LBB139_103:                            ;   in Loop: Header=BB139_25 Depth=1
	s_wait_alu 0xfffe
	s_or_b32 exec_lo, exec_lo, s10
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s44
	s_wait_alu 0xfffe
	s_cbranch_vccnz .LBB139_24
; %bb.104:                              ;   in Loop: Header=BB139_25 Depth=1
	v_dual_mov_b32 v69, v85 :: v_dual_mov_b32 v70, v86
	v_dual_mov_b32 v71, v83 :: v_dual_mov_b32 v72, v84
	s_wait_loadcnt 0x0
	v_dual_mov_b32 v28, v60 :: v_dual_mov_b32 v27, v59
	v_dual_mov_b32 v26, v58 :: v_dual_mov_b32 v25, v57
	v_dual_mov_b32 v20, v52 :: v_dual_mov_b32 v19, v51
	v_dual_mov_b32 v18, v50 :: v_dual_mov_b32 v17, v49
	v_dual_mov_b32 v12, v44 :: v_dual_mov_b32 v11, v43
	v_dual_mov_b32 v10, v42 :: v_dual_mov_b32 v9, v41
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v3, v35
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v1, v33
	v_dual_mov_b32 v32, v64 :: v_dual_mov_b32 v31, v63
	v_dual_mov_b32 v30, v62 :: v_dual_mov_b32 v29, v61
	v_dual_mov_b32 v24, v56 :: v_dual_mov_b32 v23, v55
	v_dual_mov_b32 v22, v54 :: v_dual_mov_b32 v21, v53
	v_dual_mov_b32 v16, v48 :: v_dual_mov_b32 v15, v47
	v_dual_mov_b32 v14, v46 :: v_dual_mov_b32 v13, v45
	v_dual_mov_b32 v8, v40 :: v_dual_mov_b32 v7, v39
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v5, v37
	v_dual_mov_b32 v73, v81 :: v_dual_mov_b32 v74, v82
	s_branch .LBB139_24
.LBB139_105:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _ZN12_GLOBAL__N_120fp8_gemv_rows_kernelILi16ELi2E7ik_bf16EEvPKS1_PKhPKfPT1_iii
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 304
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 214
		.amdhsa_next_free_sgpr 68
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 255
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._ZN12_GLOBAL__N_120fp8_gemv_rows_kernelILi16ELi2E7ik_bf16EEvPKS1_PKhPKfPT1_iii,"axG",@progbits,_ZN12_GLOBAL__N_120fp8_gemv_rows_kernelILi16ELi2E7ik_bf16EEvPKS1_PKhPKfPT1_iii,comdat
.Lfunc_end139:
